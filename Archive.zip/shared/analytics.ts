// Analytics and performance tracking for revenue optimization

export interface ContentMetrics {
  articleId?: number;
  reviewId?: number;
  views: number;
  engagementTime: number;
  shareCount: number;
  conversionRate: number; // For premium content
}

export interface UserBehavior {
  sessionId: string;
  userId?: number;
  pageViews: string[];
  timeSpent: number;
  referralSource: string;
  deviceType: 'mobile' | 'tablet' | 'desktop';
  location: string;
}

export interface RevenueMetrics {
  subscriptionConversions: number;
  advertisingRevenue: number;
  affiliateCommissions: number;
  premiumContentAccess: number;
}

// For AI content generation tracking
export interface ContentSource {
  id: number;
  type: 'ai_generated' | 'human_written' | 'curated';
  sourceApi?: string;
  confidence?: number;
  lastUpdated: Date;
}