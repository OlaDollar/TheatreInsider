import { pgTable, text, serial, integer, boolean, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const articles = pgTable("articles", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  excerpt: text("excerpt").notNull(),
  author: text("author").notNull(),
  category: text("category").notNull(), // "news", "review", "announcement", "cabaret", "concert"
  region: text("region").notNull(), // "uk", "us", "both"
  venue_type: text("venue_type"), // "west_end", "off_west_end", "broadway", "off_broadway", "national", "regional"
  imageUrl: text("image_url").notNull(),
  isFeatured: boolean("is_featured").default(false),
  isPremium: boolean("is_premium").default(false),
  slug: text("slug").notNull().unique(),
  metaDescription: text("meta_description"),
  tags: text("tags").array(),
  viewCount: integer("view_count").default(0),
  sourceUrl: text("source_url"), // Original article URL for testing
  sourceOutlet: text("source_outlet"), // Original publication name
  publishedAt: timestamp("published_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  showTitle: text("show_title").notNull(),
  venue: text("venue").notNull(),
  rating: integer("rating"), // NULL for observations, 1-5 for actual reviews // 1-5 stars
  reviewText: text("review_text").notNull(),
  excerpt: text("excerpt").notNull(),
  reviewer: text("reviewer").notNull(),
  imageUrl: text("image_url").notNull(),
  region: text("region").notNull(), // "uk", "us"
  slug: text("slug").notNull().unique(),
  metaDescription: text("meta_description"),
  tags: text("tags").array(),
  viewCount: integer("view_count").default(0),
  sourceUrl: text("source_url"), // Original review URL for testing
  sourceOutlet: text("source_outlet"), // Original publication name
  publishedAt: timestamp("published_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const shows = pgTable("shows", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  venue: text("venue").notNull(),
  region: text("region").notNull(), // "uk", "us"
  venue_type: text("venue_type"), // "west_end", "off_west_end", "broadway", "off_broadway", "national", "regional"
  status: text("status").notNull(), // "running", "announced", "closed"
  popularity: integer("popularity").default(0),
  description: text("description"),
  openingDate: timestamp("opening_date"),
  closingDate: timestamp("closing_date"),
  ticketUrl: text("ticket_url"),
  officialWebsite: text("official_website"),
  imageUrl: text("image_url"),
  director: text("director"),
  composer: text("composer"),
  cast: text("cast").array(),
  genre: text("genre"),
  duration: text("duration"),
  ageRating: text("age_rating"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  priceRange: text("price_range"),
  matineeDays: text("matinee_days"), // Comma-separated days
  eveningDays: text("evening_days"), // Comma-separated days
  lastCastUpdate: timestamp("last_cast_update"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const newsletters = pgTable("newsletters", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  subscribedAt: timestamp("subscribed_at").defaultNow().notNull(),
});

// Crossword answers storage with session-based retention
export const crosswordAnswers = pgTable("crossword_answers", {
  id: serial("id").primaryKey(),
  userId: text("user_id"), // For authenticated users
  sessionId: text("session_id"), // For anonymous users
  date: text("date").notNull(), // YYYY-MM-DD format
  answers: text("answers").notNull(), // JSON string of grid answers
  completedClues: text("completed_clues").notNull(), // JSON array of completed clue numbers
  completedAt: timestamp("completed_at"),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User subscriptions for premium content
export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  email: text("email").notNull(),
  plan: text("plan").notNull(), // "free", "premium", "annual"
  status: text("status").notNull(), // "active", "cancelled", "expired"
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  currentPeriodStart: timestamp("current_period_start"),
  currentPeriodEnd: timestamp("current_period_end"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Comments system for engagement
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  articleId: integer("article_id").references(() => articles.id),
  reviewId: integer("review_id").references(() => reviews.id),
  authorName: text("author_name").notNull(),
  authorEmail: text("author_email").notNull(),
  content: text("content").notNull(),
  isApproved: boolean("is_approved").default(false),
  parentId: integer("parent_id"), // For nested comments
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Content performance tracking
export const analytics = pgTable("analytics", {
  id: serial("id").primaryKey(),
  contentType: text("content_type").notNull(), // "article", "review"
  contentId: integer("content_id").notNull(),
  event: text("event").notNull(), // "view", "share", "like", "conversion"
  userId: integer("user_id").references(() => users.id),
  sessionId: text("session_id"),
  userAgent: text("user_agent"),
  ipAddress: text("ip_address"),
  referrer: text("referrer"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const performers = pgTable("performers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  biography: text("biography"),
  birthDate: date("birth_date"),
  deathDate: date("death_date"),
  nationality: text("nationality"), // "uk", "us", "international"
  status: text("status").notNull(), // "active", "retired", "deceased"
  imageUrl: text("image_url"),
  isFeatured: boolean("is_featured").default(false),
  notableFor: text("notable_for"), // Brief description of what they're known for
  awards: text("awards").array(), // Array of awards
  socialLinks: text("social_links").array(), // Array of social media links
  slug: text("slug").notNull().unique(),
  metaDescription: text("meta_description"),
  tags: text("tags").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const productions = pgTable("productions", {
  id: serial("id").primaryKey(),
  showId: integer("show_id").references(() => shows.id),
  title: text("title").notNull(), // Specific production title (may differ from show)
  venue: text("venue").notNull(),
  region: text("region").notNull(), // "uk", "us"
  venue_type: text("venue_type"), // "west_end", "off_west_end", "broadway", "off_broadway", "national", "regional", "youth", "development", "cabaret", "concert_hall"
  openingDate: date("opening_date"),
  closingDate: date("closing_date"),
  isCurrentlyRunning: boolean("is_currently_running").default(false),
  director: text("director"),
  musicalDirector: text("musical_director"),
  choreographer: text("choreographer"),
  description: text("description"),
  slug: text("slug").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});

export const performerRoles = pgTable("performer_roles", {
  id: serial("id").primaryKey(),
  performerId: integer("performer_id").references(() => performers.id),
  productionId: integer("production_id").references(() => productions.id),
  role: text("role").notNull(), // Character name or role type
  roleType: text("role_type").notNull(), // "lead", "supporting", "ensemble", "understudy", "replacement"
  startDate: date("start_date"),
  endDate: date("end_date"),
  isOriginalCast: boolean("is_original_cast").default(false),
  isReplacement: boolean("is_replacement").default(false),
  notes: text("notes"), // Any special notes about the role
  createdAt: timestamp("created_at").defaultNow().notNull()
});

export const performerMedia = pgTable("performer_media", {
  id: serial("id").primaryKey(),
  performerId: integer("performer_id").references(() => performers.id),
  mediaType: text("media_type").notNull(), // "book", "biography", "documentary", "tv_show", "film", "interview"
  title: text("title").notNull(),
  description: text("description"),
  releaseDate: date("release_date"),
  url: text("url"), // Link to book, video, etc.
  isRecent: boolean("is_recent").default(false), // Released in past 25 years
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Awards ceremony data
export const awardCeremonies = pgTable("award_ceremonies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(), // "Olivier Awards", "Tony Awards", "Drama Desk Awards", etc.
  year: integer("year").notNull(),
  date: date("date"),
  venue: text("venue"),
  host: text("host"),
  city: text("city"),
  country: text("country"),
  broadcastChannel: text("broadcast_channel"),
  theme: text("theme"),
  totalNominations: integer("total_nominations"),
  totalAwards: integer("total_awards"),
  slug: text("slug").notNull().unique(),
  officialUrl: text("official_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const awardCategories = pgTable("award_categories", {
  id: serial("id").primaryKey(),
  ceremonyId: integer("ceremony_id").references(() => awardCeremonies.id),
  categoryName: text("category_name").notNull(), // "Best Actor", "Best Musical", etc.
  categoryType: text("category_type").notNull(), // "acting", "production", "technical", etc.
  isMainCategory: boolean("is_main_category").default(false),
  presentedBy: text("presented_by"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const awardNominees = pgTable("award_nominees", {
  id: serial("id").primaryKey(),
  ceremonyId: integer("ceremony_id").references(() => awardCeremonies.id),
  categoryId: integer("category_id").references(() => awardCategories.id),
  nomineeName: text("nominee_name").notNull(),
  showTitle: text("show_title"),
  venue: text("venue"),
  role: text("role"), // For acting categories
  isWinner: boolean("is_winner").default(false),
  presentedBy: text("presented_by"),
  acceptanceSpeech: text("acceptance_speech"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertArticleSchema = createInsertSchema(articles).omit({
  id: true,
  slug: true,
  viewCount: true,
  publishedAt: true,
  updatedAt: true,
  createdAt: true,
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  slug: true,
  viewCount: true,
  publishedAt: true,
  updatedAt: true,
  createdAt: true,
});

export const insertShowSchema = createInsertSchema(shows).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertNewsletterSchema = createInsertSchema(newsletters).omit({
  id: true,
  subscribedAt: true,
});

export const topicFollowers = pgTable("topic_followers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  email: text("email").notNull(),
  topic: text("topic").notNull(),
  topicType: text("topic_type", { enum: ["show", "performer", "venue", "category", "keyword"] }).notNull(),
  frequency: text("frequency", { enum: ["immediate", "daily", "weekly"] }).default("immediate"),
  isActive: boolean("is_active").default(true),
  lastSent: timestamp("last_sent"),
  createdAt: timestamp("created_at").defaultNow()
});

export const cookieConsents = pgTable("cookie_consents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  sessionId: text("session_id"),
  essential: boolean("essential").default(true),
  analytics: boolean("analytics").default(false),
  marketing: boolean("marketing").default(false),
  preferences: boolean("preferences").default(false),
  locale: text("locale").notNull(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  consentTimestamp: timestamp("consent_timestamp").defaultNow(),
  lastUpdated: timestamp("last_updated").defaultNow()
});

export const insertTopicFollowerSchema = createInsertSchema(topicFollowers).omit({
  id: true,
  createdAt: true,
});

export const insertCookieConsentSchema = createInsertSchema(cookieConsents).omit({
  id: true,
  consentTimestamp: true,
  lastUpdated: true,
});

// Arts Education Schools
export const artsEducationSchools = pgTable("arts_education_schools", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  shortName: text("short_name"), // RADA, LAMDA, etc.
  city: text("city").notNull(),
  country: text("country").notNull(),
  region: text("region").notNull(), // "london", "manchester", "new_york", etc.
  foundedYear: integer("founded_year"),
  schoolType: text("school_type").notNull(), // "drama", "music", "dance", "combined"
  ranking: integer("ranking"), // Global or national ranking
  website: text("website"),
  address: text("address"),
  phone: text("phone"),
  email: text("email"),
  accreditation: text("accreditation").array(), // Accrediting bodies
  facilities: text("facilities").array(), // Theatre spaces, studios, etc.
  notableAlumni: text("notable_alumni").array(),
  description: text("description"),
  admissionOverview: text("admission_overview"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const artsEducationCourses = pgTable("arts_education_courses", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").references(() => artsEducationSchools.id),
  courseName: text("course_name").notNull(),
  courseType: text("course_type").notNull(), // "bachelor", "master", "diploma", "certificate"
  duration: text("duration").notNull(), // "3 years", "2 years", etc.
  startDates: text("start_dates").array(), // ["September", "January"]
  applicationDeadline: text("application_deadline"),
  audititionRequired: boolean("audition_required").default(false),
  auditionDates: text("audition_dates").array(),
  courseFee: integer("course_fee"), // Annual fee in local currency
  currency: text("currency").default("GBP"),
  scholarshipsAvailable: boolean("scholarships_available").default(false),
  intakeNumber: integer("intake_number"), // Number of students accepted
  applicationRequirements: text("application_requirements").array(),
  certificateAwarded: text("certificate_awarded"), // BA, MA, Diploma, etc.
  accreditation: text("accreditation"),
  courseDescription: text("course_description"),
  modules: text("modules").array(),
  assessmentMethods: text("assessment_methods").array(),
  careerOutcomes: text("career_outcomes").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const artsEducationTeachers = pgTable("arts_education_teachers", {
  id: serial("id").primaryKey(),
  schoolId: integer("school_id").references(() => artsEducationSchools.id),
  name: text("name").notNull(),
  title: text("title"), // Professor, Lecturer, etc.
  department: text("department"),
  specialization: text("specialization").array(),
  qualifications: text("qualifications").array(),
  experience: text("experience"),
  notableCredits: text("notable_credits").array(),
  courses: text("courses").array(), // Courses they teach
  bio: text("bio"),
  contactEmail: text("contact_email"),
  profileUrl: text("profile_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertArtsEducationSchoolSchema = createInsertSchema(artsEducationSchools).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertArtsEducationCourseSchema = createInsertSchema(artsEducationCourses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertArtsEducationTeacherSchema = createInsertSchema(artsEducationTeachers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type ArtsEducationSchool = typeof artsEducationSchools.$inferSelect;
export type ArtsEducationCourse = typeof artsEducationCourses.$inferSelect;
export type ArtsEducationTeacher = typeof artsEducationTeachers.$inferSelect;
export type InsertArtsEducationSchool = z.infer<typeof insertArtsEducationSchoolSchema>;
export type InsertArtsEducationCourse = z.infer<typeof insertArtsEducationCourseSchema>;
export type InsertArtsEducationTeacher = z.infer<typeof insertArtsEducationTeacherSchema>;

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertArticle = z.infer<typeof insertArticleSchema>;
export type Article = typeof articles.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;
export type InsertShow = z.infer<typeof insertShowSchema>;
export type Show = typeof shows.$inferSelect;
export type InsertNewsletter = z.infer<typeof insertNewsletterSchema>;
export type Newsletter = typeof newsletters.$inferSelect;

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  createdAt: true,
});

export const insertAnalyticsSchema = createInsertSchema(analytics).omit({
  id: true,
  createdAt: true,
});

export const insertPerformerSchema = createInsertSchema(performers).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertProductionSchema = createInsertSchema(productions).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertPerformerRoleSchema = createInsertSchema(performerRoles).omit({
  id: true,
  createdAt: true
});

export const insertPerformerMediaSchema = createInsertSchema(performerMedia).omit({
  id: true,
  createdAt: true
});

// Venues table for theatre locations
export const venues = pgTable("venues", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address"),
  capacity: integer("capacity"),
  website: text("website"),
  region: text("region"), // "uk", "us"
  venue_type: text("venue_type"), // "west_end", "broadway", "regional", etc.
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Cast members table for tracking current cast
export const castMembers = pgTable("cast_members", {
  id: serial("id").primaryKey(),
  showId: integer("show_id").references(() => shows.id),
  character: text("character").notNull(),
  actor: text("actor").notNull(),
  isAlternate: boolean("is_alternate").default(false),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertVenueSchema = createInsertSchema(venues).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCastMemberSchema = createInsertSchema(castMembers).omit({
  id: true,
  createdAt: true,
});

// Scraper logs for tracking all scraper actions
export const scraperLogs = pgTable("scraper_logs", {
  id: serial("id").primaryKey(),
  scraperName: text("scraper_name").notNull(), // "arts-education", "awards-ceremony", "theatre-data", etc.
  action: text("action").notNull(), // "add", "update", "archived", "validation_failed"
  entityType: text("entity_type").notNull(), // "school", "course", "teacher", "show", "ceremony", etc.
  entityId: text("entity_id"), // ID of the affected entity
  entityName: text("entity_name").notNull(), // Human readable name
  previousData: text("previous_data"), // JSON string of previous data (for updates)
  newData: text("new_data"), // JSON string of new data
  validationStatus: text("validation_status"), // "valid", "invalid", "outdated", "archived"
  validationReason: text("validation_reason"), // Reason for validation failure
  sourceUrl: text("source_url"), // URL scraped from (if applicable)
  notes: text("notes"), // Additional notes
  processingTime: integer("processing_time"), // Time taken in milliseconds
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Data validation tracking
export const dataValidation = pgTable("data_validation", {
  id: serial("id").primaryKey(),
  entityType: text("entity_type").notNull(), // "school", "show", etc.
  entityId: text("entity_id").notNull(),
  validationDate: timestamp("validation_date").defaultNow().notNull(),
  isValid: boolean("is_valid").notNull(),
  validationChecks: text("validation_checks").array(), // List of checks performed
  failedChecks: text("failed_checks").array(), // List of failed checks
  nextValidationDate: timestamp("next_validation_date"), // When to check again
  archivedAt: timestamp("archived_at"), // When data was archived
  archivedReason: text("archived_reason"), // Why it was archived
});

export const insertScraperLogSchema = createInsertSchema(scraperLogs).omit({
  id: true,
  createdAt: true,
});

export const insertDataValidationSchema = createInsertSchema(dataValidation).omit({
  id: true,
  validationDate: true,
});

export type ScraperLog = typeof scraperLogs.$inferSelect;
export type InsertScraperLog = z.infer<typeof insertScraperLogSchema>;
export type DataValidation = typeof dataValidation.$inferSelect;
export type InsertDataValidation = z.infer<typeof insertDataValidationSchema>;

export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;
export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;
export type Analytics = typeof analytics.$inferSelect;

export type InsertPerformer = z.infer<typeof insertPerformerSchema>;
export type Performer = typeof performers.$inferSelect;
export type InsertProduction = z.infer<typeof insertProductionSchema>;
export type Production = typeof productions.$inferSelect;
export type InsertPerformerRole = z.infer<typeof insertPerformerRoleSchema>;
export type PerformerRole = typeof performerRoles.$inferSelect;
export type InsertPerformerMedia = z.infer<typeof insertPerformerMediaSchema>;
export type PerformerMedia = typeof performerMedia.$inferSelect;

export type InsertVenue = z.infer<typeof insertVenueSchema>;
export type Venue = typeof venues.$inferSelect;
export type InsertCastMember = z.infer<typeof insertCastMemberSchema>;
export type CastMember = typeof castMembers.$inferSelect;
