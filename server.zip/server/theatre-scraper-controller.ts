import { dailyTheatreScraper } from './daily-theatre-scraper';

export class TheatreScraperController {
  
  // Enable scrapers for live/UAT environments
  static enableScrapers(): void {
    dailyTheatreScraper.enable();
    console.log('✅ Theatre scrapers ENABLED for live/UAT environment');
  }

  // Disable scrapers for development
  static disableScrapers(): void {
    dailyTheatreScraper.disable();
    console.log('🛑 Theatre scrapers DISABLED for development');
  }

  // Manual trigger for testing/UAT
  static async runManualScraping(): Promise<any> {
    console.log('🔄 Manual theatre scraping triggered');
    return await dailyTheatreScraper.triggerManualScraping();
  }

  // Check scraper status
  static getScraperStatus(): {
    enabled: boolean;
    lastResults: any;
    environment: string;
  } {
    return {
      enabled: dailyTheatreScraper.isScrapingEnabled(),
      lastResults: dailyTheatreScraper.getLastResults(),
      environment: process.env.NODE_ENV || 'development'
    };
  }

  // Environment-based auto-configuration
  static configureForEnvironment(environment: 'development' | 'staging' | 'production'): void {
    switch (environment) {
      case 'development':
        this.disableScrapers();
        console.log('🔧 Configured for DEVELOPMENT - scrapers disabled');
        break;
      case 'staging':
        this.enableScrapers();
        console.log('🧪 Configured for STAGING/UAT - scrapers enabled');
        break;
      case 'production':
        this.enableScrapers();
        console.log('🚀 Configured for PRODUCTION - scrapers enabled');
        break;
    }
  }
}

// Auto-configure based on environment variable
const currentEnv = (process.env.NODE_ENV || 'development') as 'development' | 'staging' | 'production';
TheatreScraperController.configureForEnvironment(currentEnv);

export { TheatreScraperController as scraperController };