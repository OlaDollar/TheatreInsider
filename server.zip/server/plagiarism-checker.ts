interface PlagiarismResult {
  isOriginal: boolean;
  riskScore: number;
  issues: {
    type: 'structure' | 'phrase' | 'attribution' | 'style';
    severity: 'low' | 'medium' | 'high' | 'critical';
    description: string;
    matches: string[];
  }[];
  recommendations: string[];
}

export class PlagiarismChecker {
  private commonNewsPatterns = [
    // Wire service patterns
    /\b(REUTERS|AP|AFP|PA)\b/gi,
    /\b(NEW YORK|LONDON|LOS ANGELES)\s*[-—]/gi,
    /\(Reuters\)|Associated Press|Press Association/gi,
    
    // Direct quote patterns that suggest copying
    /"\s*[A-Z][^"]{100,}"\s*,?\s*(said|told|explained|announced)/gi,
    
    // News-specific terminology
    /\b(breaking news|developing story|this is a developing story)\b/gi,
    /\b(sources close to|people familiar with|insiders say)\b/gi,
    
    // Editorial annotations
    /\b(UPDATE:|CORRECTION:|EDITOR'S NOTE:|CLARIFICATION:)\b/gi,
    
    // Copyright indicators
    /©\s*\d{4}|copyright\s*\d{4}|all rights reserved/gi
  ];

  private suspiciousPatterns = [
    // Overly formal attribution
    /according to a statement (released|issued) by/gi,
    /in response to questions from this reporter/gi,
    /when reached for comment/gi,
    
    // Complex direct quotes (likely copied)
    /"[^"]{200,}"/g,
    
    // Industry jargon that's often copied
    /\b(industry observers|market analysts|entertainment executives)\b/gi
  ];

  async checkContent(title: string, content: string): Promise<PlagiarismResult> {
    const issues: PlagiarismResult['issues'] = [];
    let riskScore = 0;
    const recommendations: string[] = [];

    // Check for news service patterns
    for (const pattern of this.commonNewsPatterns) {
      const matches = content.match(pattern);
      if (matches) {
        const severity = this.getSeverityForPattern(pattern);
        riskScore += this.getScoreForSeverity(severity) * matches.length;
        
        issues.push({
          type: 'attribution',
          severity,
          description: 'Content contains patterns typical of news wire services or press releases',
          matches: matches.slice(0, 3) // Limit to first 3 matches
        });
      }
    }

    // Check for suspicious patterns
    for (const pattern of this.suspiciousPatterns) {
      const matches = content.match(pattern);
      if (matches) {
        riskScore += 3 * matches.length;
        
        issues.push({
          type: 'phrase',
          severity: 'medium',
          description: 'Contains phrases commonly found in copied journalism',
          matches: matches.slice(0, 2)
        });
      }
    }

    // Analyze sentence structure
    const structureAnalysis = this.analyzeStructure(content);
    riskScore += structureAnalysis.score;
    if (structureAnalysis.issues.length > 0) {
      issues.push(...structureAnalysis.issues);
    }

    // Check writing style consistency
    const styleAnalysis = this.analyzeWritingStyle(content);
    riskScore += styleAnalysis.score;
    if (styleAnalysis.issues.length > 0) {
      issues.push(...styleAnalysis.issues);
    }

    // Generate recommendations
    if (riskScore > 15) {
      recommendations.push('Significantly rewrite content to ensure originality');
      recommendations.push('Remove direct quotes and replace with paraphrased content');
      recommendations.push('Add original analysis and Mark Shenton\'s perspective');
    } else if (riskScore > 8) {
      recommendations.push('Review and paraphrase any direct quotes');
      recommendations.push('Add more original commentary and insight');
    } else if (riskScore > 3) {
      recommendations.push('Consider adding more original analysis');
    }

    // Add positive recommendations
    if (riskScore < 5) {
      recommendations.push('Content appears original - good work maintaining authentic voice');
    }

    return {
      isOriginal: riskScore < 10,
      riskScore,
      issues,
      recommendations
    };
  }

  private getSeverityForPattern(pattern: RegExp): PlagiarismResult['issues'][0]['severity'] {
    const patternStr = pattern.toString();
    
    if (patternStr.includes('copyright|REUTERS|AP ')) {
      return 'critical';
    }
    if (patternStr.includes('UPDATE:|CORRECTION:')) {
      return 'high';
    }
    if (patternStr.includes('sources close to|breaking news')) {
      return 'medium';
    }
    return 'low';
  }

  private getScoreForSeverity(severity: PlagiarismResult['issues'][0]['severity']): number {
    switch (severity) {
      case 'critical': return 8;
      case 'high': return 5;
      case 'medium': return 3;
      case 'low': return 1;
      default: return 1;
    }
  }

  private analyzeStructure(content: string): { score: number; issues: PlagiarismResult['issues'] } {
    const issues: PlagiarismResult['issues'] = [];
    let score = 0;

    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 10);
    
    // Check for unusual sentence length patterns
    const avgLength = sentences.reduce((sum, s) => sum + s.length, 0) / sentences.length;
    const shortSentences = sentences.filter(s => s.length < 30);
    const longSentences = sentences.filter(s => s.length > 150);

    if (shortSentences.length > sentences.length * 0.6) {
      score += 4;
      issues.push({
        type: 'structure',
        severity: 'medium',
        description: 'Unusually high proportion of short sentences may indicate copied bullet points or headlines',
        matches: ['sentence structure analysis']
      });
    }

    if (longSentences.length > sentences.length * 0.25) {
      score += 3;
      issues.push({
        type: 'structure',
        severity: 'medium',
        description: 'Many complex sentences may indicate copied formal writing',
        matches: ['complex sentence analysis']
      });
    }

    // Check for list-like structures (often copied)
    const listPatterns = content.match(/^\s*[-•*]\s+/gm);
    if (listPatterns && listPatterns.length > 3) {
      score += 2;
      issues.push({
        type: 'structure',
        severity: 'low',
        description: 'Bullet point format may indicate copied press release content',
        matches: [`${listPatterns.length} bullet points found`]
      });
    }

    return { score, issues };
  }

  private analyzeWritingStyle(content: string): { score: number; issues: PlagiarismResult['issues'] } {
    const issues: PlagiarismResult['issues'] = [];
    let score = 0;

    // Check for inconsistent voice (first person vs third person)
    const firstPersonMatches = content.match(/\b(I|my|mine|myself)\b/gi) || [];
    const thirdPersonMatches = content.match(/\b(he|she|they|their|them)\b/gi) || [];
    
    if (firstPersonMatches.length > 0 && thirdPersonMatches.length > firstPersonMatches.length * 3) {
      score += 3;
      issues.push({
        type: 'style',
        severity: 'medium',
        description: 'Inconsistent narrative voice may indicate mixed source content',
        matches: ['voice consistency analysis']
      });
    }

    // Check for overly formal language (often indicates copying from press releases)
    const formalPatterns = [
      /\b(furthermore|nevertheless|consequently|therefore|henceforth)\b/gi,
      /\b(pursuant to|in accordance with|with regard to)\b/gi
    ];

    let formalMatches = 0;
    for (const pattern of formalPatterns) {
      const matches = content.match(pattern);
      if (matches) {
        formalMatches += matches.length;
      }
    }

    if (formalMatches > 3) {
      score += 2;
      issues.push({
        type: 'style',
        severity: 'low',
        description: 'Overly formal language may indicate copied corporate or legal content',
        matches: [`${formalMatches} formal phrases detected`]
      });
    }

    return { score, issues };
  }

  async generateOriginalityReport(title: string, content: string): Promise<string> {
    const result = await this.checkContent(title, content);
    
    return `
PLAGIARISM CHECK REPORT
Article: ${title}
Date: ${new Date().toISOString()}

ORIGINALITY SCORE: ${result.isOriginal ? 'PASS' : 'FAIL'}
Risk Score: ${result.riskScore}/20 (lower is better)

ISSUES FOUND: ${result.issues.length}
${result.issues.map(issue => 
  `- ${issue.severity.toUpperCase()}: ${issue.description}`
).join('\n')}

RECOMMENDATIONS:
${result.recommendations.map(rec => `- ${rec}`).join('\n')}

STATUS: ${result.isOriginal ? 
  'Content appears original and safe for publication' : 
  'Content requires review before publication due to plagiarism risk'
}
    `.trim();
  }
}

export const plagiarismChecker = new PlagiarismChecker();