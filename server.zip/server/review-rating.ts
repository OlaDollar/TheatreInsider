import { db } from "./db";
import { reviews } from "../shared/schema";
import { eq } from "drizzle-orm";

interface ReviewRating {
  reviewId: number;
  starRating: number; // 1-5
  hasSeenShow: boolean;
  externalRating?: number;
  externalSource?: string;
  externalUrl?: string;
}

interface ExternalReviewSource {
  name: string;
  baseUrl: string;
  ratingScale: number; // e.g., 5 for 1-5 stars, 10 for 1-10
  ratingSelector?: string;
  titleSelector?: string;
  contentSelector?: string;
}

export class ReviewRatingSystem {
  private externalSources: ExternalReviewSource[] = [
    {
      name: "The Guardian",
      baseUrl: "theatrespotlight.com",
      ratingScale: 5, // ★★★★★ (1-5 stars)
      ratingSelector: ".rating-stars",
      titleSelector: "h1",
      contentSelector: ".content__article-body"
    },
    {
      name: "Time Out",
      baseUrl: "timeout.com",
      ratingScale: 5, // ★★★★★ (1-5 stars)
      ratingSelector: ".rating",
      titleSelector: "h1",
      contentSelector: ".article-content"
    },
    {
      name: "The Stage",
      baseUrl: "thestage.co.uk",
      ratingScale: 5, // ★★★★★ (1-5 stars)
      ratingSelector: ".review-rating",
      titleSelector: "h1",
      contentSelector: ".review-content"
    },
    {
      name: "WhatsOnStage",
      baseUrl: "whatsonstage.com",
      ratingScale: 5, // ★★★★★ (1-5 stars)
      ratingSelector: ".star-rating",
      titleSelector: "h1",
      contentSelector: ".review-text"
    },
    {
      name: "New York Times",
      baseUrl: "nytimes.com",
      ratingScale: 4, // Critics' Pick, Recommended, Mixed, Poor (1-4 scale)
      ratingSelector: ".review-rating",
      titleSelector: "h1",
      contentSelector: ".story-body"
    },
    {
      name: "Variety",
      baseUrl: "variety.com",
      ratingScale: 10, // 1-10 rating system
      ratingSelector: ".rating-score",
      titleSelector: "h1",
      contentSelector: ".review-content"
    },
    {
      name: "The Hollywood Reporter",
      baseUrl: "hollywoodreporter.com",
      ratingScale: 4, // 1-4 stars system
      ratingSelector: ".rating",
      titleSelector: "h1",
      contentSelector: ".review-body"
    },
    {
      name: "Entertainment Weekly",
      baseUrl: "ew.com",
      ratingScale: 4, // A+, A, A-, B+, B, B-, C+, C, C-, D+, D, F (converted to 1-4)
      ratingSelector: ".grade",
      titleSelector: "h1",
      contentSelector: ".article-content"
    },
    {
      name: "The Times (UK)",
      baseUrl: "thetimes.co.uk",
      ratingScale: 5, // ★★★★★ (1-5 stars)
      ratingSelector: ".star-rating",
      titleSelector: "h1",
      contentSelector: ".article-body"
    },
    {
      name: "The Telegraph",
      baseUrl: "telegraph.co.uk",
      ratingScale: 5, // ★★★★★ (1-5 stars)
      ratingSelector: ".rating",
      titleSelector: "h1",
      contentSelector: ".article-content"
    },
    {
      name: "Financial Times",
      baseUrl: "ft.com",
      ratingScale: 5, // ★★★★★ (1-5 stars)
      ratingSelector: ".rating-stars",
      titleSelector: "h1",
      contentSelector: ".article-body"
    },
    {
      name: "Broadway.com",
      baseUrl: "broadway.com",
      ratingScale: 5, // ★★★★★ (1-5 stars)
      ratingSelector: ".star-rating",
      titleSelector: "h1",
      contentSelector: ".review-content"
    },
    {
      name: "TheaterMania",
      baseUrl: "theatermania.com",
      ratingScale: 5, // ★★★★★ (1-5 stars)
      ratingSelector: ".rating",
      titleSelector: "h1",
      contentSelector: ".review-text"
    },
    {
      name: "BroadwayWorld",
      baseUrl: "broadwayworld.com",
      ratingScale: 10, // 1-10 rating system
      ratingSelector: ".bww-rating",
      titleSelector: "h1",
      contentSelector: ".review-body"
    },
    {
      name: "Playbill",
      baseUrl: "playbill.com",
      ratingScale: 5, // ★★★★★ (1-5 stars)
      ratingSelector: ".star-rating",
      titleSelector: "h1",
      contentSelector: ".article-content"
    }
  ];

  async addRatingToReview(data: ReviewRating): Promise<{ success: boolean; message: string }> {
    try {
      // Validate star rating is 1-5
      if (data.starRating < 1 || data.starRating > 5) {
        return {
          success: false,
          message: "Star rating must be between 1 and 5"
        };
      }

      // Check if reviewer has seen the show
      if (!data.hasSeenShow) {
        return {
          success: false,
          message: "You can only rate shows you have seen"
        };
      }

      // Update review with rating
      await db
        .update(reviews)
        .set({
          starRating: data.starRating,
          hasSeenShow: data.hasSeenShow,
          externalRating: data.externalRating,
          externalSource: data.externalSource,
          externalUrl: data.externalUrl,
          updatedAt: new Date()
        })
        .where(eq(reviews.id, data.reviewId));

      return {
        success: true,
        message: `Review rated ${data.starRating} stars`
      };

    } catch (error) {
      console.error('Error adding rating to review:', error);
      return {
        success: false,
        message: "Failed to add rating to review"
      };
    }
  }

  async importExternalRating(externalUrl: string, reviewId: number): Promise<{ success: boolean; rating?: number; source?: string; message: string }> {
    try {
      const source = this.detectSource(externalUrl);
      if (!source) {
        return {
          success: false,
          message: "External source not supported"
        };
      }

      // In production, would scrape the external site
      // For now, simulate extracting rating
      const mockRating = this.simulateExternalRating(source, externalUrl);

      if (mockRating) {
        // Convert to 1-5 scale if needed
        const normalizedRating = this.normalizeRating(mockRating, source.ratingScale);

        await db
          .update(reviews)
          .set({
            starRating: normalizedRating,
            hasSeenShow: true, // Assume if they reviewed elsewhere, they've seen it
            externalRating: mockRating,
            externalSource: source.name,
            externalUrl: externalUrl,
            updatedAt: new Date()
          })
          .where(eq(reviews.id, reviewId));

        return {
          success: true,
          rating: normalizedRating,
          source: source.name,
          message: `Imported ${normalizedRating}-star rating from ${source.name}`
        };
      }

      return {
        success: false,
        message: "Could not extract rating from external source"
      };

    } catch (error) {
      console.error('Error importing external rating:', error);
      return {
        success: false,
        message: "Failed to import external rating"
      };
    }
  }

  private detectSource(url: string): ExternalReviewSource | null {
    return this.externalSources.find(source => 
      url.toLowerCase().includes(source.baseUrl)
    ) || null;
  }

  private simulateExternalRating(source: ExternalReviewSource, url: string): number | null {
    // Mock ratings for demo - in production would scrape actual ratings
    const mockRatings: Record<string, number> = {
      "The Guardian": Math.floor(Math.random() * 5) + 1,
      "Time Out": Math.floor(Math.random() * 5) + 1,
      "The Stage": Math.floor(Math.random() * 5) + 1,
      "WhatsOnStage": Math.floor(Math.random() * 5) + 1,
      "New York Times": Math.floor(Math.random() * 4) + 1,
      "Variety": Math.floor(Math.random() * 10) + 1
    };

    return mockRatings[source.name] || null;
  }

  private normalizeRating(rating: number, originalScale: number): number {
    // Convert any scale to 1-5 stars with precise mapping
    
    if (originalScale === 5) {
      // Already 1-5, return as-is
      return Math.max(1, Math.min(5, rating));
    }
    
    if (originalScale === 4) {
      // NYT/Hollywood Reporter style: 1-4 to 1-5 mapping
      const mapping: Record<number, number> = {
        1: 1, // Poor -> 1 star
        2: 2, // Mixed -> 2 stars  
        3: 4, // Recommended -> 4 stars
        4: 5  // Critics' Pick -> 5 stars
      };
      return mapping[rating] || Math.ceil((rating / 4) * 5);
    }
    
    if (originalScale === 10) {
      // Variety/BroadwayWorld style: 1-10 to 1-5 mapping
      const mapping: Record<number, number> = {
        1: 1, 2: 1,  // 1-2 -> 1 star
        3: 2, 4: 2,  // 3-4 -> 2 stars
        5: 3, 6: 3,  // 5-6 -> 3 stars
        7: 4, 8: 4,  // 7-8 -> 4 stars
        9: 5, 10: 5  // 9-10 -> 5 stars
      };
      return mapping[rating] || Math.ceil((rating / 10) * 5);
    }
    
    if (originalScale === 100) {
      // Percentage-based ratings: 0-100 to 1-5
      if (rating >= 90) return 5;
      if (rating >= 75) return 4;
      if (rating >= 60) return 3;
      if (rating >= 40) return 2;
      return 1;
    }
    
    // Letter grade conversion (Entertainment Weekly style)
    if (originalScale === 12) { // A+, A, A-, B+, B, B-, C+, C, C-, D+, D, F
      const gradeMapping: Record<number, number> = {
        12: 5, 11: 5, 10: 4, // A+, A, A-
        9: 4, 8: 3, 7: 3,    // B+, B, B-
        6: 3, 5: 2, 4: 2,    // C+, C, C-
        3: 2, 2: 1, 1: 1     // D+, D, F
      };
      return gradeMapping[rating] || 1;
    }
    
    // Default proportional conversion with floor/ceiling protection
    const normalized = (rating / originalScale) * 5;
    return Math.max(1, Math.min(5, Math.round(normalized)));
  }

  async validateReviewerAccess(reviewId: number, userId?: number): Promise<{ canRate: boolean; hasSeenShow: boolean; message: string }> {
    try {
      const review = await db
        .select()
        .from(reviews)
        .where(eq(reviews.id, reviewId))
        .limit(1);

      if (!review.length) {
        return {
          canRate: false,
          hasSeenShow: false,
          message: "Review not found"
        };
      }

      // Check if this is the reviewer's own review
      // In production, would check userId against review author
      const isOwnReview = true; // Simplified for demo

      if (!isOwnReview) {
        return {
          canRate: false,
          hasSeenShow: false,
          message: "You can only rate your own reviews"
        };
      }

      return {
        canRate: true,
        hasSeenShow: review[0].hasSeenShow || false,
        message: "You can rate this review"
      };

    } catch (error) {
      console.error('Error validating reviewer access:', error);
      return {
        canRate: false,
        hasSeenShow: false,
        message: "Failed to validate access"
      };
    }
  }

  async getReviewsWithRatings(filters?: {
    minRating?: number;
    maxRating?: number;
    hasRating?: boolean;
    region?: string;
    venue?: string;
  }): Promise<any[]> {
    try {
      // Get all reviews with ratings
      const allReviews = await db
        .select()
        .from(reviews);

      let filteredReviews = allReviews;

      if (filters) {
        filteredReviews = allReviews.filter(review => {
          if (filters.minRating && (!review.starRating || review.starRating < filters.minRating)) {
            return false;
          }
          
          if (filters.maxRating && (!review.starRating || review.starRating > filters.maxRating)) {
            return false;
          }
          
          if (filters.hasRating !== undefined) {
            const hasRating = review.starRating !== null;
            if (hasRating !== filters.hasRating) {
              return false;
            }
          }
          
          if (filters.region && review.region !== filters.region) {
            return false;
          }
          
          if (filters.venue && review.venue !== filters.venue) {
            return false;
          }

          return true;
        });
      }

      return filteredReviews.map(review => ({
        ...review,
        ratingDisplay: this.formatRatingDisplay(review.starRating),
        externalRatingDisplay: review.externalRating ? 
          this.formatExternalRating(review.externalRating, review.externalSource) : null
      }));

    } catch (error) {
      console.error('Error getting reviews with ratings:', error);
      return [];
    }
  }

  private formatRatingDisplay(rating: number | null): string | null {
    if (!rating) return null;
    
    const stars = "★".repeat(rating) + "☆".repeat(5 - rating);
    return `${stars} (${rating}/5)`;
  }

  private formatExternalRating(rating: number, source: string | null): string {
    const sourceInfo = source || "External Site";
    return `${rating} stars on ${sourceInfo}`;
  }

  async getAverageRating(showTitle: string, venue?: string): Promise<{ averageRating: number; totalReviews: number; ratingBreakdown: Record<number, number> }> {
    try {
      const showReviews = await db
        .select()
        .from(reviews)
        .where(eq(reviews.showTitle, showTitle));

      const ratedReviews = showReviews.filter(r => 
        r.starRating !== null && 
        r.hasSeenShow &&
        (!venue || r.venue === venue)
      );

      if (ratedReviews.length === 0) {
        return {
          averageRating: 0,
          totalReviews: 0,
          ratingBreakdown: {}
        };
      }

      const totalRating = ratedReviews.reduce((sum, review) => sum + (review.starRating || 0), 0);
      const averageRating = totalRating / ratedReviews.length;

      // Rating breakdown (how many 1-star, 2-star, etc.)
      const ratingBreakdown: Record<number, number> = {};
      for (let i = 1; i <= 5; i++) {
        ratingBreakdown[i] = ratedReviews.filter(r => r.starRating === i).length;
      }

      return {
        averageRating: Math.round(averageRating * 10) / 10, // Round to 1 decimal
        totalReviews: ratedReviews.length,
        ratingBreakdown
      };

    } catch (error) {
      console.error('Error calculating average rating:', error);
      return {
        averageRating: 0,
        totalReviews: 0,
        ratingBreakdown: {}
      };
    }
  }
}

export const reviewRatingSystem = new ReviewRatingSystem();