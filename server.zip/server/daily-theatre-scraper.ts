import cron from 'node-cron';
import { theatreCastScraper } from './theatre-cast-scraper';
import { venueShowScraper } from './venue-show-scraper';

interface ScrapingResult {
  timestamp: Date;
  successful: number;
  failed: number;
  changes: string[];
}

export class DailyTheatreScraper {
  private isRunning = false;
  private lastRunResults: ScrapingResult | null = null;
  private isEnabled = false; // Disabled by default - only enable for live/UAT

  constructor() {
    // Only schedule scrapers if enabled
    if (this.isEnabled) {
      this.scheduleDailyScrapings();
    } else {
      console.log('Theatre scrapers disabled - development mode');
    }
  }

  private scheduleDailyScrapings(): void {
    if (!this.isEnabled) {
      console.log('Theatre scraping is disabled - skipping scheduling');
      return;
    }

    // Run comprehensive scraping every day at 6:00 AM GMT
    const dailyJob = cron.schedule('0 6 * * *', async () => {
      console.log('Starting scheduled daily theatre scraping at 6:00 AM GMT');
      await this.runFullScraping();
    }, {
      scheduled: false,
      timezone: 'Europe/London'
    });

    // Run cast change detection every 4 hours during business hours
    const castJob = cron.schedule('0 9,13,17,21 * * *', async () => {
      console.log('Running cast change detection');
      await this.runCastChangeDetection();
    }, {
      scheduled: false,
      timezone: 'Europe/London'
    });

    // Quick status check every 2 hours (for show closures/openings)
    const statusJob = cron.schedule('0 */2 * * *', async () => {
      console.log('Running quick show status check');
      await this.runQuickStatusCheck();
    }, {
      scheduled: false
    });

    this.jobs = [dailyJob, castJob, statusJob];
    
    // Start the jobs
    this.jobs.forEach(job => job.start());

    console.log('Daily theatre scraping scheduled:');
    console.log('- Full scraping: 6:00 AM GMT daily');
    console.log('- Cast changes: 9 AM, 1 PM, 5 PM, 9 PM GMT');
    console.log('- Status checks: Every 2 hours');
  }

  async runFullScraping(): Promise<ScrapingResult> {
    if (this.isRunning) {
      console.log('Scraping already in progress, skipping...');
      return this.lastRunResults!;
    }

    this.isRunning = true;
    const startTime = new Date();
    let successful = 0;
    let failed = 0;
    const changes: string[] = [];

    try {
      console.log('Starting comprehensive theatre data scraping...');

      // 1. Scrape all cast information
      try {
        await theatreCastScraper.scrapeAllShows();
        successful++;
        console.log('✓ Cast scraping completed');
      } catch (error) {
        failed++;
        console.error('✗ Cast scraping failed:', error);
      }

      // 2. Scrape venue and show information
      try {
        await venueShowScraper.scrapeAllVenuesAndShows();
        successful++;
        console.log('✓ Venue/show scraping completed');
      } catch (error) {
        failed++;
        console.error('✗ Venue/show scraping failed:', error);
      }

      // 3. Detect and report changes
      try {
        const castChanges = await theatreCastScraper.detectCastChanges();
        changes.push(...castChanges.map(change => `Cast change: ${change}`));
        console.log(`✓ Detected ${castChanges.length} cast changes`);
      } catch (error) {
        console.error('✗ Change detection failed:', error);
      }

      const result: ScrapingResult = {
        timestamp: startTime,
        successful,
        failed,
        changes
      };

      this.lastRunResults = result;
      
      console.log(`Scraping completed: ${successful} successful, ${failed} failed, ${changes.length} changes detected`);
      
      // Send notifications about significant changes
      if (changes.length > 0) {
        await this.sendChangeNotifications(changes);
      }

      return result;

    } catch (error) {
      console.error('Full scraping failed:', error);
      throw error;
    } finally {
      this.isRunning = false;
    }
  }

  async runCastChangeDetection(): Promise<void> {
    try {
      console.log('Checking for cast changes...');
      
      // Run quick cast scrapers for major shows only
      const quickScrapers = [
        () => theatreCastScraper['scrapeOliverCast'](),
        () => theatreCastScraper['scrapeWickedCast'](),
        () => theatreCastScraper['scrapeHamiltonCast'](),
        () => theatreCastScraper['scrapePhantomCast'](),
        () => theatreCastScraper['scrapeLionKingCast']()
      ];

      const results = await Promise.allSettled(
        quickScrapers.map(scraper => scraper())
      );

      let successful = 0;
      let failed = 0;
      
      results.forEach((result, index) => {
        if (result.status === 'fulfilled') {
          successful++;
        } else {
          failed++;
          console.error(`Quick cast scraper ${index + 1} failed:`, result.reason);
        }
      });

      console.log(`Cast change detection: ${successful} successful, ${failed} failed`);
      
    } catch (error) {
      console.error('Cast change detection failed:', error);
    }
  }

  async runQuickStatusCheck(): Promise<void> {
    try {
      console.log('Running quick show status check...');
      
      // Check for shows that might be closing soon or have announced extensions
      const statusUrls = [
        'https://www.whatsonstage.com/news/',
        'https://www.westendtheatre.com/latest-news/',
        'https://www.broadwayworld.com/uk-regional/'
      ];

      for (const url of statusUrls) {
        try {
          const response = await fetch(url);
          const html = await response.text();
          
          // Look for keywords indicating show status changes
          const keywords = ['closing', 'extends', 'final performance', 'cast change', 'announces'];
          const hasNews = keywords.some(keyword => html.toLowerCase().includes(keyword));
          
          if (hasNews) {
            console.log(`Status update detected from ${url}`);
            // Trigger content aggregation to capture the news
          }
        } catch (error) {
          console.error(`Error checking ${url}:`, error);
        }
      }
      
    } catch (error) {
      console.error('Quick status check failed:', error);
    }
  }

  private async sendChangeNotifications(changes: string[]): Promise<void> {
    try {
      // Log changes for now - could be expanded to send emails/webhooks
      console.log('=== THEATRE CHANGES DETECTED ===');
      changes.forEach((change, index) => {
        console.log(`${index + 1}. ${change}`);
      });
      console.log('================================');
      
      // Could add email notifications, Slack webhooks, etc.
      
    } catch (error) {
      console.error('Error sending change notifications:', error);
    }
  }

  // Manual trigger for immediate scraping
  async triggerManualScraping(): Promise<ScrapingResult> {
    console.log('Manual theatre scraping triggered');
    return await this.runFullScraping();
  }

  // Get last scraping results
  getLastResults(): ScrapingResult | null {
    return this.lastRunResults;
  }

  // Enable scrapers for live/UAT environments
  enable(): void {
    this.isEnabled = true;
    this.scheduleDailyScrapings();
    console.log('Theatre scrapers enabled and scheduled');
  }

  // Disable scrapers for development
  disable(): void {
    this.isEnabled = false;
    this.jobs.forEach(job => job.stop());
    this.jobs = [];
    console.log('Theatre scrapers disabled');
  }

  // Check if scrapers are enabled
  isScrapingEnabled(): boolean {
    return this.isEnabled;
  }

  // Emergency stop for scraping
  stop(): void {
    this.isRunning = false;
    console.log('Theatre scraping stopped');
  }

  private jobs: cron.ScheduledTask[] = [];
}

// Create singleton instance
export const dailyTheatreScraper = new DailyTheatreScraper();