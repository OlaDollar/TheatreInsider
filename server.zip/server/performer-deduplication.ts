import { db } from "./db";
import { performers, performerRoles, performerMedia, productions } from "@shared/schema";
import { eq, like, or, and } from "drizzle-orm";

interface DuplicateGroup {
  primaryPerformer: any;
  duplicates: any[];
  reason: string;
  confidence: number;
}

interface MergeReport {
  merged: number;
  deleted: number;
  errors: string[];
  details: { from: string; to: string; reason: string }[];
}

export class PerformerDeduplicationService {
  
  async findDuplicatePerformers(): Promise<DuplicateGroup[]> {
    console.log('🔍 Scanning for duplicate performers...');
    
    const allPerformers = await db.select().from(performers);
    const duplicateGroups: DuplicateGroup[] = [];
    const processed = new Set<number>();
    
    for (const performer of allPerformers) {
      if (processed.has(performer.id)) continue;
      
      const duplicates = await this.findDuplicatesFor(performer, allPerformers);
      
      if (duplicates.length > 0) {
        duplicateGroups.push({
          primaryPerformer: performer,
          duplicates,
          reason: this.getDuplicateReason(performer, duplicates[0]),
          confidence: this.calculateConfidence(performer, duplicates[0])
        });
        
        // Mark all as processed
        processed.add(performer.id);
        duplicates.forEach(dup => processed.add(dup.id));
      }
    }
    
    console.log(`Found ${duplicateGroups.length} duplicate groups`);
    return duplicateGroups;
  }
  
  private async findDuplicatesFor(performer: any, allPerformers: any[]): Promise<any[]> {
    const duplicates = [];
    
    for (const other of allPerformers) {
      if (other.id === performer.id) continue;
      
      // Exact name match
      if (this.normalizedName(performer.name) === this.normalizedName(other.name)) {
        duplicates.push(other);
        continue;
      }
      
      // Slug match (most reliable)
      if (performer.slug === other.slug) {
        duplicates.push(other);
        continue;
      }
      
      // Similar name with same birth year
      if (this.areSimilarNames(performer.name, other.name) && 
          this.haveSameBirthYear(performer, other)) {
        duplicates.push(other);
        continue;
      }
      
      // Same notable works
      if (this.haveMatchingNotableWorks(performer, other)) {
        duplicates.push(other);
        continue;
      }
    }
    
    return duplicates;
  }
  
  private normalizedName(name: string): string {
    return name.toLowerCase()
      .replace(/[.,'"]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }
  
  private areSimilarNames(name1: string, name2: string): boolean {
    const norm1 = this.normalizedName(name1);
    const norm2 = this.normalizedName(name2);
    
    // Check if one is a subset of the other (e.g., "John Smith" vs "John William Smith")
    return norm1.includes(norm2) || norm2.includes(norm1);
  }
  
  private haveSameBirthYear(performer1: any, performer2: any): boolean {
    if (!performer1.birthDate || !performer2.birthDate) return false;
    
    const year1 = new Date(performer1.birthDate).getFullYear();
    const year2 = new Date(performer2.birthDate).getFullYear();
    
    return year1 === year2;
  }
  
  private haveMatchingNotableWorks(performer1: any, performer2: any): boolean {
    if (!performer1.notableFor || !performer2.notableFor) return false;
    
    const works1 = performer1.notableFor.toLowerCase();
    const works2 = performer2.notableFor.toLowerCase();
    
    // Check for common major shows
    const majorShows = ['phantom', 'lion king', 'wicked', 'hamilton', 'chicago', 'cats'];
    
    for (const show of majorShows) {
      if (works1.includes(show) && works2.includes(show)) {
        return true;
      }
    }
    
    return false;
  }
  
  private getDuplicateReason(primary: any, duplicate: any): string {
    if (primary.slug === duplicate.slug) return 'Identical slug';
    if (this.normalizedName(primary.name) === this.normalizedName(duplicate.name)) return 'Exact name match';
    if (this.haveSameBirthYear(primary, duplicate)) return 'Similar name + same birth year';
    if (this.haveMatchingNotableWorks(primary, duplicate)) return 'Same notable works';
    return 'Similar profile';
  }
  
  private calculateConfidence(primary: any, duplicate: any): number {
    let confidence = 0;
    
    if (primary.slug === duplicate.slug) confidence += 50;
    if (this.normalizedName(primary.name) === this.normalizedName(duplicate.name)) confidence += 40;
    if (this.haveSameBirthYear(primary, duplicate)) confidence += 30;
    if (this.haveMatchingNotableWorks(primary, duplicate)) confidence += 20;
    if (primary.nationality === duplicate.nationality) confidence += 10;
    
    return Math.min(100, confidence);
  }
  
  async mergePerformers(primaryId: number, duplicateId: number): Promise<{
    success: boolean;
    error?: string;
    mergedData?: any;
  }> {
    console.log(`🔀 Merging performer ${duplicateId} into ${primaryId}...`);
    
    try {
      const [primary] = await db.select().from(performers).where(eq(performers.id, primaryId));
      const [duplicate] = await db.select().from(performers).where(eq(performers.id, duplicateId));
      
      if (!primary || !duplicate) {
        return { success: false, error: 'One or both performers not found' };
      }
      
      // Merge performer data
      const mergedData = this.mergePerformerData(primary, duplicate);
      
      // Update primary performer with merged data
      await db.update(performers)
        .set(mergedData)
        .where(eq(performers.id, primaryId));
      
      // Transfer all roles from duplicate to primary
      await db.update(performerRoles)
        .set({ performerId: primaryId })
        .where(eq(performerRoles.performerId, duplicateId));
      
      // Transfer all media from duplicate to primary
      await db.update(performerMedia)
        .set({ performerId: primaryId })
        .where(eq(performerMedia.performerId, duplicateId));
      
      // Delete the duplicate performer
      await db.delete(performers).where(eq(performers.id, duplicateId));
      
      console.log(`✅ Successfully merged ${duplicate.name} into ${primary.name}`);
      
      return {
        success: true,
        mergedData: {
          primaryName: primary.name,
          duplicateName: duplicate.name,
          rolesTransferred: await this.countRoles(duplicateId),
          mediaTransferred: await this.countMedia(duplicateId)
        }
      };
      
    } catch (error) {
      console.error('Error merging performers:', error);
      return { success: false, error: error.message };
    }
  }
  
  private mergePerformerData(primary: any, duplicate: any): any {
    return {
      // Keep primary name unless duplicate is more complete
      name: primary.name.length >= duplicate.name.length ? primary.name : duplicate.name,
      
      // Merge biographies - take longer one
      biography: primary.biography && duplicate.biography 
        ? (primary.biography.length > duplicate.biography.length ? primary.biography : duplicate.biography)
        : primary.biography || duplicate.biography,
      
      // Keep earliest birth date if both exist
      birthDate: primary.birthDate && duplicate.birthDate
        ? (new Date(primary.birthDate) < new Date(duplicate.birthDate) ? primary.birthDate : duplicate.birthDate)
        : primary.birthDate || duplicate.birthDate,
      
      // Keep death date if either has it
      deathDate: primary.deathDate || duplicate.deathDate,
      
      // Keep primary nationality unless missing
      nationality: primary.nationality || duplicate.nationality,
      
      // Keep primary status unless missing
      status: primary.status || duplicate.status,
      
      // Merge notable works
      notableFor: this.mergeNotableWorks(primary.notableFor, duplicate.notableFor),
      
      // Merge awards arrays
      awards: [...(primary.awards || []), ...(duplicate.awards || [])].filter((award, index, arr) => 
        arr.indexOf(award) === index
      ),
      
      // Merge social links
      socialLinks: [...(primary.socialLinks || []), ...(duplicate.socialLinks || [])],
      
      // Keep better image URL
      imageUrl: primary.imageUrl || duplicate.imageUrl,
      
      // Mark as featured if either was featured
      isFeatured: primary.isFeatured || duplicate.isFeatured,
      
      // Keep primary slug
      slug: primary.slug,
      
      // Update meta description to reflect merged data
      metaDescription: `${primary.name} - ${this.mergeNotableWorks(primary.notableFor, duplicate.notableFor)}`,
      
      // Merge tags
      tags: [...(primary.tags || []), ...(duplicate.tags || [])].filter((tag, index, arr) => 
        arr.indexOf(tag) === index
      ),
      
      // Update timestamps
      updatedAt: new Date()
    };
  }
  
  private mergeNotableWorks(primary?: string, duplicate?: string): string {
    if (!primary && !duplicate) return '';
    if (!primary) return duplicate;
    if (!duplicate) return primary;
    
    // If works are very different, combine them
    if (!primary.toLowerCase().includes(duplicate.toLowerCase()) && 
        !duplicate.toLowerCase().includes(primary.toLowerCase())) {
      return `${primary}, ${duplicate}`;
    }
    
    // Otherwise, take the longer one
    return primary.length > duplicate.length ? primary : duplicate;
  }
  
  private async countRoles(performerId: number): Promise<number> {
    const roles = await db.select().from(performerRoles).where(eq(performerRoles.performerId, performerId));
    return roles.length;
  }
  
  private async countMedia(performerId: number): Promise<number> {
    const media = await db.select().from(performerMedia).where(eq(performerMedia.performerId, performerId));
    return media.length;
  }
  
  async deletePerformer(performerId: number): Promise<{
    success: boolean;
    error?: string;
    deletedData?: any;
  }> {
    console.log(`🗑️ Deleting performer ${performerId}...`);
    
    try {
      const [performer] = await db.select().from(performers).where(eq(performers.id, performerId));
      
      if (!performer) {
        return { success: false, error: 'Performer not found' };
      }
      
      // Count associated data before deletion
      const rolesCount = await this.countRoles(performerId);
      const mediaCount = await this.countMedia(performerId);
      
      // Delete associated data first
      await db.delete(performerRoles).where(eq(performerRoles.performerId, performerId));
      await db.delete(performerMedia).where(eq(performerMedia.performerId, performerId));
      
      // Delete the performer
      await db.delete(performers).where(eq(performers.id, performerId));
      
      console.log(`✅ Successfully deleted ${performer.name}`);
      
      return {
        success: true,
        deletedData: {
          name: performer.name,
          rolesDeleted: rolesCount,
          mediaDeleted: mediaCount
        }
      };
      
    } catch (error) {
      console.error('Error deleting performer:', error);
      return { success: false, error: error.message };
    }
  }
  
  async automaticMergeHighConfidence(minConfidence: number = 90): Promise<MergeReport> {
    console.log(`🤖 Starting automatic merge for duplicates with ${minConfidence}%+ confidence...`);
    
    const duplicateGroups = await this.findDuplicatePerformers();
    const report: MergeReport = {
      merged: 0,
      deleted: 0,
      errors: [],
      details: []
    };
    
    for (const group of duplicateGroups) {
      if (group.confidence >= minConfidence) {
        for (const duplicate of group.duplicates) {
          const result = await this.mergePerformers(group.primaryPerformer.id, duplicate.id);
          
          if (result.success) {
            report.merged++;
            report.details.push({
              from: duplicate.name,
              to: group.primaryPerformer.name,
              reason: group.reason
            });
          } else {
            report.errors.push(`Failed to merge ${duplicate.name}: ${result.error}`);
          }
        }
      }
    }
    
    console.log(`🎯 Automatic merge complete: ${report.merged} merged, ${report.errors.length} errors`);
    return report;
  }
  
  async generateDeduplicationReport(): Promise<string> {
    const duplicateGroups = await this.findDuplicatePerformers();
    
    let report = `# Performer Deduplication Report\n\n`;
    report += `**Date**: ${new Date().toISOString().split('T')[0]}\n`;
    report += `**Total Duplicate Groups Found**: ${duplicateGroups.length}\n\n`;
    
    if (duplicateGroups.length === 0) {
      report += `✅ No duplicates found. Database is clean!\n`;
      return report;
    }
    
    report += `## High Confidence Duplicates (90%+)\n\n`;
    const highConfidence = duplicateGroups.filter(g => g.confidence >= 90);
    
    if (highConfidence.length > 0) {
      for (const group of highConfidence) {
        report += `### ${group.primaryPerformer.name}\n`;
        report += `- **Reason**: ${group.reason}\n`;
        report += `- **Confidence**: ${group.confidence}%\n`;
        report += `- **Duplicates**: ${group.duplicates.map(d => d.name).join(', ')}\n`;
        report += `- **Action**: Safe for automatic merge\n\n`;
      }
    } else {
      report += `No high confidence duplicates found.\n\n`;
    }
    
    report += `## Medium Confidence Duplicates (70-89%)\n\n`;
    const mediumConfidence = duplicateGroups.filter(g => g.confidence >= 70 && g.confidence < 90);
    
    if (mediumConfidence.length > 0) {
      for (const group of mediumConfidence) {
        report += `### ${group.primaryPerformer.name}\n`;
        report += `- **Reason**: ${group.reason}\n`;
        report += `- **Confidence**: ${group.confidence}%\n`;
        report += `- **Duplicates**: ${group.duplicates.map(d => d.name).join(', ')}\n`;
        report += `- **Action**: Manual review recommended\n\n`;
      }
    } else {
      report += `No medium confidence duplicates found.\n\n`;
    }
    
    report += `## Low Confidence Duplicates (50-69%)\n\n`;
    const lowConfidence = duplicateGroups.filter(g => g.confidence >= 50 && g.confidence < 70);
    
    if (lowConfidence.length > 0) {
      for (const group of lowConfidence) {
        report += `### ${group.primaryPerformer.name}\n`;
        report += `- **Reason**: ${group.reason}\n`;
        report += `- **Confidence**: ${group.confidence}%\n`;
        report += `- **Duplicates**: ${group.duplicates.map(d => d.name).join(', ')}\n`;
        report += `- **Action**: Investigate manually\n\n`;
      }
    } else {
      report += `No low confidence duplicates found.\n\n`;
    }
    
    report += `## Recommended Actions\n\n`;
    report += `1. **Automatic Merge**: ${highConfidence.length} groups ready for automatic processing\n`;
    report += `2. **Manual Review**: ${mediumConfidence.length} groups need manual review\n`;
    report += `3. **Investigation**: ${lowConfidence.length} groups need detailed investigation\n\n`;
    
    return report;
  }
}

export const performerDeduplicationService = new PerformerDeduplicationService();