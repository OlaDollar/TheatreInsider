// Content safety filters to prevent legal issues

interface SafetyFilter {
  pattern: RegExp;
  severity: 'critical' | 'high' | 'medium';
  reason: string;
  replacement?: string;
}

export class ContentSafetyScanner {
  private prohibitedContent: SafetyFilter[] = [
    // Plagiarism indicators (CRITICAL - legal liability)
    {
      pattern: /copyright\s+©|all rights reserved|reproduction prohibited|exclusive to|originally published/gi,
      severity: 'critical',
      reason: 'Potential plagiarism - content appears to be copyrighted material',
      replacement: ''
    },
    
    // Direct quotes that are too long (potential copyright violation)
    {
      pattern: /"[^"]{200,}"/g,
      severity: 'high',
      reason: 'Extended direct quotes may violate copyright',
      replacement: 'paraphrased content'
    },
    
    // Attribution missing
    {
      pattern: /according to sources|industry insiders say|unnamed sources/gi,
      severity: 'medium',
      reason: 'Vague attribution may indicate copied content',
      replacement: 'theatre industry reports'
    },
    
    // Exact matches from known publications
    {
      pattern: /this article originally appeared|first published in|reprinted from/gi,
      severity: 'critical',
      reason: 'Content appears to be reprinted without permission'
    },
    
    // Suspicious sentence patterns that suggest copying
    {
      pattern: /\b(according to reports|sources close to|it has been reported|industry sources suggest)\b/gi,
      severity: 'medium',
      reason: 'Generic attribution phrases often indicate copied content'
    },
    
    // Direct newspaper-style openings
    {
      pattern: /^\s*(NEW YORK|LONDON|LOS ANGELES)\s*—/gm,
      severity: 'medium',
      reason: 'Wire service or newspaper-style dateline may indicate copying'
    }
  ];

  async scanContent(content: string, title: string): Promise<{
    safe: boolean;
    issues: { severity: string; reason: string; match: string }[];
    cleanedContent?: string;
  }> {
    const issues: { severity: string; reason: string; match: string }[] = [];
    let cleanedContent = content;
    let cleanedTitle = title;

    // Scan content and title
    const textToScan = `${title} ${content}`;

    for (const filter of this.prohibitedContent) {
      const matches = textToScan.match(filter.pattern);
      if (matches) {
        matches.forEach(match => {
          issues.push({
            severity: filter.severity,
            reason: filter.reason,
            match: match
          });
        });

        // Apply replacements if available
        if (filter.replacement) {
          cleanedContent = cleanedContent.replace(filter.pattern, filter.replacement);
          cleanedTitle = cleanedTitle.replace(filter.pattern, filter.replacement);
        }
      }
    }

    // Check for critical issues that should block publication
    const criticalIssues = issues.filter(issue => issue.severity === 'critical');
    const safe = criticalIssues.length === 0;

    return {
      safe,
      issues,
      cleanedContent: safe ? cleanedContent : undefined
    };
  }

  async moderateBeforePublication(article: any): Promise<{ approved: boolean; modifiedArticle?: any; reasons?: string[] }> {
    const scanResult = await this.scanContent(article.content, article.title);
    
    // Enhanced plagiarism check for AI-generated content
    const plagiarismCheck = await this.checkPlagiarismIndicators(article.content, article.title);
    
    const allIssues = [...scanResult.issues, ...plagiarismCheck.issues];
    const criticalIssues = allIssues.filter(issue => issue.severity === 'critical');
    
    if (criticalIssues.length > 0) {
      const criticalReasons = criticalIssues.map(issue => issue.reason);
      
      console.warn(`BLOCKED ARTICLE (PLAGIARISM RISK): ${article.title} - Reasons: ${criticalReasons.join(', ')}`);
      
      return {
        approved: false,
        reasons: criticalReasons
      };
    }

    // If safe but has medium/high issues, return cleaned version
    if (allIssues.length > 0) {
      console.log(`CLEANED ARTICLE: ${article.title} - Issues resolved: ${allIssues.length}`);
      
      return {
        approved: true,
        modifiedArticle: {
          ...article,
          content: scanResult.cleanedContent || article.content,
          plagiarismScore: plagiarismCheck.riskScore
        }
      };
    }

    return {
      approved: true,
      modifiedArticle: {
        ...article,
        plagiarismScore: 0
      }
    };
  }

  async checkPlagiarismIndicators(content: string, title: string): Promise<{
    issues: { severity: string; reason: string; match: string }[];
    riskScore: number;
  }> {
    const issues: { severity: string; reason: string; match: string }[] = [];
    let riskScore = 0;
    
    // Check for common plagiarism patterns
    const plagiarismPatterns = [
      {
        pattern: /\b(said in a statement|told reporters|confirmed to the press)\b/gi,
        weight: 2,
        reason: 'Direct quote attribution suggests potential copying from news sources'
      },
      {
        pattern: /\b(breaking news|exclusive report|this reporter)\b/gi,
        weight: 3,
        reason: 'News-style language may indicate copied journalism'
      },
      {
        pattern: /\b(sources familiar with|people close to|insiders say)\b/gi,
        weight: 2,
        reason: 'Anonymous source attribution common in copied news articles'
      },
      {
        pattern: /\b(UPDATE:|CORRECTION:|EDITOR\'S NOTE:)\b/gi,
        weight: 5,
        reason: 'Editorial annotations suggest copied content from other publications'
      }
    ];
    
    for (const check of plagiarismPatterns) {
      const matches = content.match(check.pattern);
      if (matches) {
        riskScore += check.weight * matches.length;
        
        matches.forEach(match => {
          issues.push({
            severity: riskScore > 10 ? 'critical' : 'medium',
            reason: check.reason,
            match
          });
        });
      }
    }
    
    // Check sentence structure similarity (basic heuristic)
    const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 20);
    const shortSentences = sentences.filter(s => s.length < 50).length;
    const longSentences = sentences.filter(s => s.length > 150).length;
    
    // Unusual sentence length distribution can indicate copying
    if (shortSentences > sentences.length * 0.7) {
      riskScore += 3;
      issues.push({
        severity: 'medium',
        reason: 'Unusual sentence structure may indicate copied bullet points or lists',
        match: 'sentence structure analysis'
      });
    }
    
    if (longSentences > sentences.length * 0.3) {
      riskScore += 2;
      issues.push({
        severity: 'medium', 
        reason: 'Many long sentences may indicate copied formal writing',
        match: 'sentence length analysis'
      });
    }
    
    return {
      issues,
      riskScore
    };
  }

  // Monitor content import for safety issues
  async monitorContentImport(): Promise<{
    totalScanned: number;
    blocked: number;
    cleaned: number;
    approved: number;
    criticalIssues: string[];
  }> {
    // This would be called during content aggregation
    return {
      totalScanned: 0,
      blocked: 0,
      cleaned: 0,
      approved: 0,
      criticalIssues: []
    };
  }
}

export const contentSafetyScanner = new ContentSafetyScanner();