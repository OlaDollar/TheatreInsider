/**
 * Theatre Crossword Data - Organized by difficulty and theme
 * Guardian-quality crossword answers with proper categorization
 */

export interface CrosswordAnswer {
  word: string;
  clue: string;
  category: 'show' | 'performer' | 'venue' | 'term' | 'composer' | 'writer' | 'producer';
  era: 'children' | 'current' | '25years' | '50years' | '75years';
  difficulty: 'easy' | 'medium' | 'hard' | 'dedicated';
  length: number;
}

// EASY LEVEL - Family-friendly shows with PG-rated content and lyrics
export const easyAnswers: CrosswordAnswer[] = [
  // Disney and family musicals with song lyrics
  { word: 'LION', clue: '"Circle of Life" big cat', category: 'show', era: 'current', difficulty: 'easy', length: 4 },
  { word: 'HAKUNA', clue: '"___ Matata" (no worries song)', category: 'show', era: 'current', difficulty: 'easy', length: 6 },
  { word: 'MATATA', clue: '"Hakuna ___" (no worries song)', category: 'show', era: 'current', difficulty: 'easy', length: 6 },
  { word: 'BELLE', clue: '"Be Our Guest" heroine', category: 'show', era: 'current', difficulty: 'easy', length: 5 },
  { word: 'BEAST', clue: 'Belle\'s enchanted friend', category: 'show', era: 'current', difficulty: 'easy', length: 5 },
  { word: 'ELSA', clue: '"Let It Go" ice queen', category: 'show', era: 'current', difficulty: 'easy', length: 4 },
  { word: 'ANNA', clue: '"Do You Want to Build a Snowman?" sister', category: 'show', era: 'current', difficulty: 'easy', length: 4 },
  { word: 'FROZEN', clue: 'Elsa and Anna\'s icy adventure', category: 'show', era: 'current', difficulty: 'easy', length: 6 },
  
  // Classic family shows with positive themes
  { word: 'ANNIE', clue: '"Tomorrow" optimistic orphan', category: 'show', era: 'current', difficulty: 'easy', length: 5 },
  { word: 'TOMORROW', clue: 'Annie\'s hopeful song', category: 'show', era: 'current', difficulty: 'easy', length: 8 },
  { word: 'SUNNY', clue: '"The sun\'ll come out ___"', category: 'show', era: 'current', difficulty: 'easy', length: 5 },
  { word: 'MAMMA', clue: '"___ Mia!" ABBA jukebox musical', category: 'show', era: 'current', difficulty: 'easy', length: 5 },
  { word: 'MIA', clue: '"Mamma ___!" ABBA musical', category: 'show', era: 'current', difficulty: 'easy', length: 3 },
  { word: 'DANCING', clue: '"___ Queen" ABBA hit', category: 'show', era: 'current', difficulty: 'easy', length: 7 },
  { word: 'QUEEN', clue: '"Dancing ___" ABBA hit', category: 'show', era: 'current', difficulty: 'easy', length: 5 },
  
  // Family-friendly performers and composers
  { word: 'ELTON', clue: '"Can You Feel the Love Tonight" composer', category: 'composer', era: 'current', difficulty: 'easy', length: 5 },
  { word: 'JOHN', clue: 'Elton ___ (Lion King songs)', category: 'composer', era: 'current', difficulty: 'easy', length: 4 },
  { word: 'RICE', clue: 'Tim ___ (positive musical lyrics)', category: 'writer', era: 'current', difficulty: 'easy', length: 4 },
  { word: 'TIM', clue: '___ Rice (uplifting song lyrics)', category: 'writer', era: 'current', difficulty: 'easy', length: 3 },
  { word: 'ALAN', clue: '___ Menken (Disney composer)', category: 'composer', era: 'current', difficulty: 'easy', length: 4 },
  { word: 'MENKEN', clue: 'Alan ___ (Beauty and Beast composer)', category: 'composer', era: 'current', difficulty: 'easy', length: 6 },
  
  // Factual theatre terms for families
  { word: 'SONG', clue: 'Musical theatre vocal number', category: 'term', era: 'current', difficulty: 'easy', length: 4 },
  { word: 'DANCE', clue: 'Choreographed stage movement', category: 'term', era: 'current', difficulty: 'easy', length: 5 },
  { word: 'STAGE', clue: 'Performance area in theatre', category: 'term', era: 'current', difficulty: 'easy', length: 5 },
  { word: 'ACT', clue: 'Major division of a play', category: 'term', era: 'current', difficulty: 'easy', length: 3 },
  { word: 'SCENE', clue: 'Subdivision of an act', category: 'term', era: 'current', difficulty: 'easy', length: 5 },
  { word: 'CAST', clue: 'All performers in a show', category: 'term', era: 'current', difficulty: 'easy', length: 4 },
  { word: 'PROPS', clue: 'Objects used on stage', category: 'term', era: 'current', difficulty: 'easy', length: 5 },
  { word: 'SCRIPT', clue: 'Written text of a play', category: 'term', era: 'current', difficulty: 'easy', length: 6 },
  { word: 'TICKET', clue: 'Theatre admission pass', category: 'term', era: 'current', difficulty: 'easy', length: 6 },
  { word: 'SEAT', clue: 'Audience chair in theatre', category: 'term', era: 'current', difficulty: 'easy', length: 4 }
];

// MEDIUM LEVEL - Contemporary musicals with sophisticated lyrics and themes
export const mediumAnswers: CrosswordAnswer[] = [
  // Hamilton with revolutionary lyrics
  { word: 'HAMILTON', clue: '"The Room Where It Happens" founding father', category: 'show', era: '25years', difficulty: 'medium', length: 8 },
  { word: 'BURR', clue: '"Wait for It" patient politician', category: 'show', era: '25years', difficulty: 'medium', length: 4 },
  { word: 'AARON', clue: '___ Burr (Hamilton rival)', category: 'show', era: '25years', difficulty: 'medium', length: 5 },
  { word: 'SATISFIED', clue: '"___ " (Angelica\'s Hamilton song)', category: 'show', era: '25years', difficulty: 'medium', length: 9 },
  { word: 'WAIT', clue: '"___ for It" (Burr\'s patience song)', category: 'show', era: '25years', difficulty: 'medium', length: 4 },
  
  // Wicked with empowerment themes
  { word: 'WICKED', clue: '"Defying Gravity" green witch musical', category: 'show', era: '25years', difficulty: 'medium', length: 6 },
  { word: 'DEFYING', clue: '"___ Gravity" (Elphaba\'s soaring song)', category: 'show', era: '25years', difficulty: 'medium', length: 7 },
  { word: 'GRAVITY', clue: '"Defying ___" (Wicked Act I finale)', category: 'show', era: '25years', difficulty: 'medium', length: 7 },
  { word: 'POPULAR', clue: '"___" (Glinda\'s makeover song)', category: 'show', era: '25years', difficulty: 'medium', length: 7 },
  { word: 'ELPHABA', clue: 'Wicked\'s misunderstood green heroine', category: 'show', era: '25years', difficulty: 'medium', length: 7 },
  { word: 'GLINDA', clue: 'Wicked\'s bubbly good witch', category: 'show', era: '25years', difficulty: 'medium', length: 6 },
  
  // Chicago with jazz themes
  { word: 'CHICAGO', clue: '"All That Jazz" murder musical', category: 'show', era: '25years', difficulty: 'medium', length: 7 },
  { word: 'RAZZLE', clue: '"___ Dazzle" (Billy Flynn song)', category: 'show', era: '25years', difficulty: 'medium', length: 6 },
  { word: 'DAZZLE', clue: '"Razzle ___" (Chicago showstopper)', category: 'show', era: '25years', difficulty: 'medium', length: 6 },
  { word: 'ROXIE', clue: 'Chicago\'s fame-seeking murderess', category: 'show', era: '25years', difficulty: 'medium', length: 5 },
  { word: 'VELMA', clue: 'Chicago\'s jazz-age killer', category: 'show', era: '25years', difficulty: 'medium', length: 5 },
  
  // Phantom with romantic lyrics
  { word: 'PHANTOM', clue: '"Music of the Night" masked composer', category: 'show', era: '25years', difficulty: 'medium', length: 7 },
  { word: 'MUSIC', clue: '"___ of the Night" (Phantom\'s seduction)', category: 'show', era: '25years', difficulty: 'medium', length: 5 },
  { word: 'NIGHT', clue: '"Music of the ___" (Phantom song)', category: 'show', era: '25years', difficulty: 'medium', length: 5 },
  { word: 'CHRISTINE', clue: 'Phantom\'s soprano obsession', category: 'show', era: '25years', difficulty: 'medium', length: 9 },
  
  // Les Miserables with revolutionary themes
  { word: 'MISERABLE', clue: 'Les ___ (French revolution musical)', category: 'show', era: '25years', difficulty: 'medium', length: 9 },
  { word: 'VALJEAN', clue: 'Jean ___ (Les Mis hero)', category: 'show', era: '25years', difficulty: 'medium', length: 7 },
  { word: 'JAVERT', clue: 'Les Mis pursuing inspector', category: 'show', era: '25years', difficulty: 'medium', length: 6 },
  { word: 'DREAM', clue: '"I ___ a Dream" (Fantine\'s lament)', category: 'show', era: '25years', difficulty: 'medium', length: 5 },
  { word: 'DREAMED', clue: '"I ___ a Dream" (Les Mis ballad)', category: 'show', era: '25years', difficulty: 'medium', length: 7 },
  
  // Modern musical stars
  { word: 'IDINA', clue: '"Let It Go" and "Defying Gravity" star', category: 'performer', era: '25years', difficulty: 'medium', length: 5 },
  { word: 'MENZEL', clue: 'Idina ___ (Frozen/Wicked star)', category: 'performer', era: '25years', difficulty: 'medium', length: 6 },
  { word: 'LUPONE', clue: 'Patti ___ (Evita/Sweeney legend)', category: 'performer', era: '25years', difficulty: 'medium', length: 6 },
  { word: 'BERNADETTE', clue: '___ Peters (Sunday in Park star)', category: 'performer', era: '25years', difficulty: 'medium', length: 10 },
  
  // Musical theatre craft terms
  { word: 'OVERTURE', clue: 'Musical\'s orchestral opening', category: 'term', era: 'current', difficulty: 'medium', length: 8 },
  { word: 'REPRISE', clue: 'Repeated musical number', category: 'term', era: 'current', difficulty: 'medium', length: 7 },
  { word: 'HARMONY', clue: 'Multiple vocal parts sung together', category: 'term', era: 'current', difficulty: 'medium', length: 7 },
  { word: 'BALLAD', clue: 'Slow tempo musical number', category: 'term', era: 'current', difficulty: 'medium', length: 6 },
  { word: 'CHORUS', clue: 'Group of background singers', category: 'term', era: 'current', difficulty: 'medium', length: 6 },
  { word: 'SOLO', clue: 'Single performer musical number', category: 'term', era: 'current', difficulty: 'medium', length: 4 },
  { word: 'DUET', clue: 'Two-person musical number', category: 'term', era: 'current', difficulty: 'medium', length: 4 },
  { word: 'FINALE', clue: 'Final number of a musical', category: 'term', era: 'current', difficulty: 'medium', length: 6 }
];

// HARD LEVEL - 50 years of theatre history with Guardian-quality clues
export const hardAnswers: CrosswordAnswer[] = [
  { word: 'OKLAHOMA', clue: 'First integrated musical by R&H', category: 'show', era: '50years', difficulty: 'hard', length: 8 },
  { word: 'CAROUSEL', clue: 'Billy Bigelow tragic tale', category: 'show', era: '50years', difficulty: 'hard', length: 8 },
  { word: 'COMPANY', clue: 'Bachelor party with Sondheim', category: 'show', era: '50years', difficulty: 'hard', length: 7 },
  { word: 'FOLLIES', clue: 'Sondheim reunion of showgirls', category: 'show', era: '50years', difficulty: 'hard', length: 7 },
  { word: 'SWEENEY', clue: 'Fleet Street demon barber', category: 'show', era: '50years', difficulty: 'hard', length: 7 },
  { word: 'TODD', clue: 'Demon barber surname', category: 'show', era: '50years', difficulty: 'hard', length: 4 },
  { word: 'EVITA', clue: 'Argentina controversial first lady', category: 'show', era: '50years', difficulty: 'hard', length: 5 },
  { word: 'JESUS', clue: 'Rock opera messiah', category: 'show', era: '50years', difficulty: 'hard', length: 5 },
  { word: 'CHRIST', clue: 'Superstar title middle name', category: 'show', era: '50years', difficulty: 'hard', length: 6 },
  { word: 'SUPERSTAR', clue: 'Rock opera title for messiah', category: 'show', era: '50years', difficulty: 'hard', length: 9 },
  
  // Historic performers (50 years)
  { word: 'GIELGUD', clue: 'Sir John ___, classical actor', category: 'performer', era: '50years', difficulty: 'hard', length: 7 },
  { word: 'OLIVIER', clue: 'Sir Laurence ___, theatre legend', category: 'performer', era: '50years', difficulty: 'hard', length: 7 },
  { word: 'LAURENCE', clue: 'Sir ___ Olivier, theatre legend', category: 'performer', era: '50years', difficulty: 'hard', length: 8 },
  { word: 'ETHEL', clue: '___ Merman, Broadway belter', category: 'performer', era: '50years', difficulty: 'hard', length: 5 },
  { word: 'MERMAN', clue: 'Ethel ___, Broadway belter', category: 'performer', era: '50years', difficulty: 'hard', length: 6 },
  
  // Historic venues
  { word: 'MAJESTIC', clue: 'Broadway theatre hosting Phantom', category: 'venue', era: '50years', difficulty: 'hard', length: 8 },
  { word: 'PALACE', clue: 'Historic Broadway vaudeville venue', category: 'venue', era: '50years', difficulty: 'hard', length: 6 },
  { word: 'LYCEUM', clue: 'Oldest Broadway theatre still operating', category: 'venue', era: '50years', difficulty: 'hard', length: 6 },
  { word: 'SHUBERT', clue: '___ Theatre, Broadway venue', category: 'venue', era: '50years', difficulty: 'hard', length: 7 },
  
  // Composers (50 years)
  { word: 'RODGERS', clue: 'Richard ___ (Oklahoma! composer)', category: 'composer', era: '50years', difficulty: 'hard', length: 7 },
  { word: 'RICHARD', clue: '___ Rodgers (Oklahoma! composer)', category: 'composer', era: '50years', difficulty: 'hard', length: 7 },
  { word: 'HAMMERSTEIN', clue: 'Oscar ___ II (Oklahoma! lyricist)', category: 'writer', era: '50years', difficulty: 'hard', length: 11 },
  { word: 'OSCAR', clue: '___ Hammerstein II (Oklahoma! lyricist)', category: 'writer', era: '50years', difficulty: 'hard', length: 5 },
  { word: 'LERNER', clue: 'Alan ___ (My Fair Lady lyricist)', category: 'writer', era: '50years', difficulty: 'hard', length: 6 },
  { word: 'LOEWE', clue: 'Frederick ___ (My Fair Lady composer)', category: 'composer', era: '50years', difficulty: 'hard', length: 5 },
  
  // Theatre terms (advanced)
  { word: 'PROSCENIUM', clue: 'Traditional theatre stage arch', category: 'term', era: '50years', difficulty: 'hard', length: 10 },
  { word: 'LIBRETTO', clue: 'Musical\'s book and lyrics', category: 'term', era: '50years', difficulty: 'hard', length: 8 },
  { word: 'ARIA', clue: 'Solo vocal piece in opera', category: 'term', era: '50years', difficulty: 'hard', length: 4 }
];

// DEDICATED LEVEL - 75 years of comprehensive theatre knowledge
export const dedicatedAnswers: CrosswordAnswer[] = [
  // Historic shows (75 years)
  { word: 'SHOWBOAT', clue: 'Kern & Hammerstein river musical', category: 'show', era: '75years', difficulty: 'dedicated', length: 8 },
  { word: 'PORGY', clue: '___ and Bess (Gershwin opera)', category: 'show', era: '75years', difficulty: 'dedicated', length: 5 },
  { word: 'BESS', clue: 'Porgy and ___ (Gershwin opera)', category: 'show', era: '75years', difficulty: 'dedicated', length: 4 },
  { word: 'ANYTHING', clue: '___ Goes (Cole Porter musical)', category: 'show', era: '75years', difficulty: 'dedicated', length: 8 },
  { word: 'GOES', clue: 'Anything ___ (Cole Porter musical)', category: 'show', era: '75years', difficulty: 'dedicated', length: 4 },
  { word: 'KISS', clue: '___ Me Kate (Cole Porter)', category: 'show', era: '75years', difficulty: 'dedicated', length: 4 },
  { word: 'KATE', clue: 'Kiss Me ___ (Cole Porter)', category: 'show', era: '75years', difficulty: 'dedicated', length: 4 },
  { word: 'BRIGADOON', clue: 'Lerner & Loewe Scottish musical', category: 'show', era: '75years', difficulty: 'dedicated', length: 9 },
  { word: 'CAMELOT', clue: 'Lerner & Loewe Arthurian musical', category: 'show', era: '75years', difficulty: 'dedicated', length: 7 },
  
  // Historic composers (75 years)
  { word: 'GERSHWIN', clue: 'George ___ (Porgy and Bess)', category: 'composer', era: '75years', difficulty: 'dedicated', length: 8 },
  { word: 'GEORGE', clue: '___ Gershwin (Porgy and Bess)', category: 'composer', era: '75years', difficulty: 'dedicated', length: 6 },
  { word: 'PORTER', clue: 'Cole ___ (Anything Goes)', category: 'composer', era: '75years', difficulty: 'dedicated', length: 6 },
  { word: 'COLE', clue: '___ Porter (Anything Goes)', category: 'composer', era: '75years', difficulty: 'dedicated', length: 4 },
  { word: 'KERN', clue: 'Jerome ___ (Show Boat composer)', category: 'composer', era: '75years', difficulty: 'dedicated', length: 4 },
  { word: 'JEROME', clue: '___ Kern (Show Boat composer)', category: 'composer', era: '75years', difficulty: 'dedicated', length: 6 },
  { word: 'BERLIN', clue: 'Irving ___ (Annie Get Your Gun)', category: 'composer', era: '75years', difficulty: 'dedicated', length: 6 },
  { word: 'IRVING', clue: '___ Berlin (Annie Get Your Gun)', category: 'composer', era: '75years', difficulty: 'dedicated', length: 6 },
  
  // Historic performers (75 years)
  { word: 'BARRYMORE', clue: 'John ___, theatrical dynasty', category: 'performer', era: '75years', difficulty: 'dedicated', length: 9 },
  { word: 'BERNHARDT', clue: 'Sarah ___, divine Sarah', category: 'performer', era: '75years', difficulty: 'dedicated', length: 9 },
  { word: 'SARAH', clue: '___ Bernhardt, divine Sarah', category: 'performer', era: '75years', difficulty: 'dedicated', length: 5 },
  { word: 'HAYES', clue: 'Helen ___, First Lady of Theatre', category: 'performer', era: '75years', difficulty: 'dedicated', length: 5 },
  { word: 'HELEN', clue: '___ Hayes, First Lady of Theatre', category: 'performer', era: '75years', difficulty: 'dedicated', length: 5 },
  
  // Historic venues and terms
  { word: 'VAUDEVILLE', clue: 'Pre-Broadway variety entertainment', category: 'term', era: '75years', difficulty: 'dedicated', length: 10 },
  { word: 'BURLESQUE', clue: 'Theatrical comedy and satire', category: 'term', era: '75years', difficulty: 'dedicated', length: 9 },
  { word: 'MELODRAMA', clue: 'Exaggerated dramatic form', category: 'term', era: '75years', difficulty: 'dedicated', length: 9 },
  { word: 'OPERETTA', clue: 'Light opera form', category: 'term', era: '75years', difficulty: 'dedicated', length: 8 },
  
  // Historic producers and directors
  { word: 'ZIEGFELD', clue: 'Florenz ___, Follies producer', category: 'producer', era: '75years', difficulty: 'dedicated', length: 8 },
  { word: 'FLORENZ', clue: '___ Ziegfeld, Follies producer', category: 'producer', era: '75years', difficulty: 'dedicated', length: 7 },
  { word: 'BELASCO', clue: 'David ___, Broadway pioneer', category: 'producer', era: '75years', difficulty: 'dedicated', length: 7 },
  { word: 'DAVID', clue: '___ Belasco, Broadway pioneer', category: 'producer', era: '75years', difficulty: 'dedicated', length: 5 },
  { word: 'COHAN', clue: 'George M. ___, Yankee Doodle Dandy', category: 'producer', era: '75years', difficulty: 'dedicated', length: 5 },
  { word: 'BOOTH', clue: 'Edwin ___, theatrical dynasty', category: 'performer', era: '75years', difficulty: 'dedicated', length: 5 },
  { word: 'EDWIN', clue: '___ Booth, Players Club founder', category: 'performer', era: '75years', difficulty: 'dedicated', length: 5 },
  { word: 'EQUITY', clue: 'Actors union organization', category: 'term', era: '75years', difficulty: 'dedicated', length: 6 },
  { word: 'DRAMA', clue: 'Serious theatrical form', category: 'term', era: '75years', difficulty: 'dedicated', length: 5 },
  { word: 'COMEDY', clue: 'Humorous theatrical form', category: 'term', era: '75years', difficulty: 'dedicated', length: 6 },
  { word: 'TRAGEDY', clue: 'Classical dramatic form', category: 'term', era: '75years', difficulty: 'dedicated', length: 7 },
  { word: 'FARCE', clue: 'Broad comedy theatrical style', category: 'term', era: '75years', difficulty: 'dedicated', length: 5 },
  { word: 'REVUE', clue: 'Variety show theatrical format', category: 'term', era: '75years', difficulty: 'dedicated', length: 5 }
];

// Combined arrays for easy access
export const allAnswers = {
  easy: easyAnswers,
  medium: mediumAnswers,
  hard: hardAnswers,
  dedicated: dedicatedAnswers
};

// Get answers by difficulty with no duplicates
export function getAnswersByDifficulty(difficulty: 'easy' | 'medium' | 'hard' | 'dedicated'): CrosswordAnswer[] {
  return allAnswers[difficulty];
}

// Ensure no duplicates across all levels
export function validateNoDuplicates(): boolean {
  const allWords = new Set<string>();
  let duplicates = false;
  
  Object.values(allAnswers).forEach(answers => {
    answers.forEach(answer => {
      if (allWords.has(answer.word)) {
        console.error(`Duplicate word found: ${answer.word}`);
        duplicates = true;
      }
      allWords.add(answer.word);
    });
  });
  
  return !duplicates;
}