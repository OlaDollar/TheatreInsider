import { aiContentGenerator } from "./ai-content";
import Parser from "rss-parser";
import * as cheerio from "cheerio";

interface RSSItem {
  title: string;
  link: string;
  contentSnippet: string;
  content: string;
  pubDate: string;
  creator?: string;
}

interface AggregatedContent {
  title: string;
  content: string;
  source: string;
  url: string;
  author?: string; // Preserve original author attribution
  publishedAt: Date;
  region: 'uk' | 'us' | 'both';
  category: 'news' | 'review' | 'announcement' | 'cabaret' | 'concert';
}

export class ContentAggregator {
  private parser = new Parser();
  private noNewContentCount = 0;
  private sources = [
    // === TIER 1: MAJOR NEWSPAPERS & NEWS OUTLETS ===
    // UK Major Newspapers
    {
      name: "The Guardian Stage",
      url: "https://www.theguardian.com/stage/rss",
      region: 'uk' as const,
      priority: 'high' as const
    },
    {
      name: "The Guardian Arts & Design",
      url: "https://www.theguardian.com/artanddesign/rss",
      region: 'uk' as const,
      priority: 'high' as const
    },
    {
      name: "BBC Entertainment & Arts",
      url: "http://feeds.bbci.co.uk/news/entertainment_and_arts/rss.xml",
      region: 'uk' as const,
      priority: 'high' as const
    },
    {
      name: "The Independent Arts",
      url: "https://www.independent.co.uk/arts-entertainment/rss",
      region: 'uk' as const,
      priority: 'high' as const
    },
    {
      name: "The Telegraph Arts",
      url: "https://www.telegraph.co.uk/arts/rss",
      region: 'uk' as const,
      priority: 'high' as const
    },
    
    // US Major Newspapers
    {
      name: "New York Times Arts",
      url: "https://rss.nytimes.com/services/xml/rss/nyt/Arts.xml",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "CNN Entertainment",
      url: "http://rss.cnn.com/rss/edition_entertainment.rss",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "Washington Post Arts & Entertainment",
      url: "https://feeds.washingtonpost.com/rss/entertainment",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "LA Times Entertainment",
      url: "https://www.latimes.com/entertainment/rss",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "Wall Street Journal Arts",
      url: "https://feeds.wsj.com/wsj/xml/rss/3_7455.xml",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "Vulture Theatre",
      url: "https://vulture.com/theater/feed",
      region: 'us' as const,
      priority: 'high' as const
    },

    // === TIER 2: UK WEST END & LONDON THEATRE SOURCES ===
    {
      name: "Official London Theatre",
      url: "https://officiallondontheatre.com/news/feed",
      region: 'uk' as const,
      priority: 'high' as const
    },
    // REMOVED: London Theatre (404) - broken RSS feed
    {
      name: "West End Theatre",
      url: "https://www.westendtheatre.com/feed",
      region: 'uk' as const,
      priority: 'high' as const
    },
    {
      name: "BroadwayWorld UK",
      url: "https://www.broadwayworld.com/uk/rss.cfm",
      region: 'uk' as const,
      priority: 'high' as const
    },
    {
      name: "Theatre-News.com",
      url: "https://www.theatre-news.com/feed",
      region: 'uk' as const,
      priority: 'high' as const
    },
    {
      name: "Everything Theatre",
      url: "https://everything-theatre.co.uk/feed",
      region: 'uk' as const,
      priority: 'high' as const
    },
    // REMOVED: London Theatre 1 (XML parse error), British Theatre (404), British Theatre Guide (404)
    {
      name: "West End Wilma",
      url: "https://westendwilma.com/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre Bee",
      url: "https://theatrebee.com/blog-feed.xml",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    // REMOVED: LW Theatres (403 Forbidden)
    {
      name: "Musical Theatre Review",
      url: "https://musicaltheatrereview.com/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre Cat",
      url: "https://theatrecat.com/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "Glasgow Theatre Blog",
      url: "https://glasgowtheatreblog.com/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    // REMOVED: Cambridge Arts Theatre (404)
    {
      name: "York Theatre Royal",
      url: "https://yorktheatreroyal.co.uk/latest/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    // REMOVED: Victoria Theatre (404)
    {
      name: "Marlowe Theatre",
      url: "https://marlowetheatre.com/about/blog/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "Blackpool Grand Theatre",
      url: "https://blackpoolgrand.co.uk/news/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "New Vic Theatre",
      url: "https://newvictheatre.org.uk/news-blog/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "Hull Truck Theatre",
      url: "https://hulltruck.co.uk/news/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "Chichester Festival Theatre",
      url: "https://cft.org.uk/news/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },

    // === TIER 2: US BROADWAY & OFF-BROADWAY SOURCES (75+ sources) ===
    {
      name: "Playbill",
      url: "https://www.playbill.com/rss/news",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "BroadwayWorld",
      url: "https://www.broadwayworld.com/rss.cfm",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "American Theatre",
      url: "https://www.americantheatre.org/feed",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "New York Stage Review",
      url: "https://nystagereview.com/feed",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "New York Theater",
      url: "https://newyorktheater.me/feed",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "Theater Pizzazz",
      url: "https://theaterpizzazz.com/feed",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "Broadway.com",
      url: "https://broadway.com/feeds/buzz/latest",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "TheaterMania",
      url: "https://theatermania.com/feed",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "New York Theatre Guide",
      url: "https://newyorktheatreguide.com/feed",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "Broadway News",
      url: "https://broadwaynews.com/feed",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "NY Post Theatre",
      url: "https://nypost.com/theater/feed",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "BroadwayRadio",
      url: "https://broadwayradio.com/feed/",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Ken Davenport",
      url: "https://kendavenport.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "NYC Playwrights",
      url: "https://nycplaywrights.org/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Vulture Theatre",
      url: "https://vulture.com/theater/feed",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "AmNY Theatre",
      url: "https://amny.com/entertainment/theater/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "La MaMa Blog",
      url: "https://lamamablogs.blogspot.com/feeds/posts/default",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "OnStage Blog",
      url: "https://onstageblog.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Village Theatre",
      url: "https://villagetheatre.wordpress.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Exeunt NYC",
      url: "https://exeuntnyc.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Theater Dogs",
      url: "https://theaterdogs.net/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Gary on Broadway",
      url: "https://garyonbroadway.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Broadway and Me",
      url: "https://feeds.feedburner.com/BroadwayMe",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Stuart on Broadway",
      url: "https://stuonbroadway.blogspot.com/feeds/posts/default",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "The Broadway Beat",
      url: "https://thebroadwaybeat.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Broadway Black",
      url: "https://broadwayblack.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Playhouse Square",
      url: "https://playhousesquare.org/blog/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Palace Theatres",
      url: "https://palacetheatre.org/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Ford's Theatre",
      url: "https://fords.org/blog/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "SITI Company",
      url: "https://siti.org/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Broadway Collective",
      url: "https://bwaycollective.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "TheaterMakers Studio",
      url: "https://theatermakersstudio.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre Trip",
      url: "https://theatretrip.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "New Line Theatre",
      url: "https://newlinetheatre.blogspot.com/feeds/posts/default",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Shuffles NYC",
      url: "https://shufflesnyc.com/blog-feed.xml",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Aladdin Musical Blog",
      url: "https://aladdinmusical.blogspot.com/feeds/posts/default",
      region: 'us' as const,
      priority: 'low' as const
    },

    // === TIER 3: OPERA COVERAGE (60+ sources) ===
    {
      name: "Schmopera",
      url: "https://schmopera.com/feed",
      region: 'both' as const,
      priority: 'high' as const
    },
    {
      name: "Opera Today",
      url: "https://operatoday.com/feed",
      region: 'both' as const,
      priority: 'high' as const
    },
    {
      name: "Seen and Heard International",
      url: "https://seenandheard-international.com/feed",
      region: 'both' as const,
      priority: 'high' as const
    },
    {
      name: "Parterre Box",
      url: "https://parterrebox.com/feed",
      region: 'both' as const,
      priority: 'high' as const
    },
    {
      name: "Lyric Opera of Chicago",
      url: "https://lyricopera.org/lyric-lately/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Opera Gene",
      url: "https://operagene.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Opera Tattler",
      url: "https://operatattler.typepad.com/opera_tattler/atom.xml",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Vienna Opera Review",
      url: "https://viennaoperareview.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Opera Ramblings",
      url: "https://operaramblings.blog/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Seattle Opera Blog",
      url: "https://www.seattleopera.org/blog/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Fort Worth Opera",
      url: "https://www.fwopera.org/blog/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Academy of Vocal Arts",
      url: "https://avaopera.org/blog/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "On Site Opera",
      url: "https://onsiteopera.org/blog/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Royal Opera House",
      url: "https://www.roh.org.uk/news/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "Opera Online",
      url: "https://opera-online.com/en/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },

    // === TIER 4: CABARET COVERAGE (15+ sources) ===
    {
      name: "Cabaret Scenes",
      url: "https://cabaretscenes.org/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Chicago Cabaret Magazine",
      url: "https://chicagocabaretmagazine.blog/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "UK Cabaret",
      url: "https://ukcabaret.com/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "The Cabaret Geek",
      url: "https://thecabaretgeek.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Cabaret Hotline",
      url: "https://cabarethotlineonline.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },

    // === TIER 5: INTERNATIONAL & REGIONAL SOURCES (100+ sources) ===
    {
      name: "Theatre Times",
      url: "https://thetheatretimes.com/feed",
      region: 'both' as const,
      priority: 'high' as const
    },
    
    // Regional UK Theatre
    {
      name: "DC Theater Arts",
      url: "https://dctheaterarts.org/feed",
      region: 'us' as const,
      priority: 'high' as const
    },
    {
      name: "Glasgow Theatre Blog",
      url: "https://glasgowtheatreblog.com/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "Twin Cities Theatre Bloggers",
      url: "https://cherryandspoon.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Village Theatre",
      url: "https://villagetheatre.org/news/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Derby Theatre",
      url: "https://derbytheatre.co.uk/news/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "Cambridge Arts Theatre",
      url: "https://cambridgeartstheatre.com/news/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    
    // Australian Theatre
    {
      name: "Stage Whispers",
      url: "https://stagewhispers.com.au/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre People",
      url: "https://theatrepeople.com.au/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    
    // Canadian Theatre
    {
      name: "Toronto Theatre Database",
      url: "https://www.toronto.com/theatre/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Stratford Festival",
      url: "https://www.stratfordfestival.ca/news/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    
    // European Theatre
    {
      name: "The Theatre Times Europe",
      url: "https://thetheatretimes.com/category/europe/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Berlin Theatre",
      url: "https://berlintheater.de/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    
    // Community & Educational Theatre
    {
      name: "OnStage Blog",
      url: "https://www.onstageblog.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre Montgomery",
      url: "https://theatremontgomery.org/news/feed",
      region: 'us' as const,
      priority: 'low' as const
    },
    {
      name: "Jungle Theater",
      url: "https://jungletheater.org/news/feed",
      region: 'us' as const,
      priority: 'low' as const
    },
    {
      name: "Theater Latté Da",
      url: "https://theaterlatteda.com/news/feed",
      region: 'us' as const,
      priority: 'low' as const
    },
    
    // Specialized Theatre Coverage
    {
      name: "Musical Theatre West",
      url: "https://musical.org/news/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre News",
      url: "https://www.theatre-news.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "The Play's the Thing UK",
      url: "https://playsthething.co.uk/feed",
      region: 'uk' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre in New York",
      url: "https://theatreinnewyork.com/feed",
      region: 'us' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre Weekly",
      url: "https://www.theatreweekly.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Digital Theatre Plus",
      url: "https://digitaltheatreplus.com/blog/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },

    // === CANADIAN THEATRE ===
    {
      name: "Intermission Magazine",
      url: "https://intermissionmagazine.ca/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "The Slotkin Letter",
      url: "https://slotkinletter.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre Alberta",
      url: "https://theatrealberta.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "12thNight.ca",
      url: "https://12thnight.ca/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Persephone Theatre",
      url: "https://persephonetheatre.org/blog/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre Calgary",
      url: "https://theatrecalgary.com/blog/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre Passe Muraille",
      url: "https://passemuraille.ca/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Musical Stage Company",
      url: "https://musicalstagecompany.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Marquee Theatrical",
      url: "https://marqueetp.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },

    // === AUSTRALIAN THEATRE ===
    {
      name: "AussieTheatre",
      url: "https://aussietheatre.com.au/feed",
      region: 'both' as const,
      priority: 'high' as const
    },
    {
      name: "Australian Stage",
      url: "https://australianstage.com.au/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre Works Backstage",
      url: "https://theatreworks.org.au/backstage-blog/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Griffin Theatre",
      url: "https://griffintheatre.com.au/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Stage Whispers",
      url: "https://stagewhispers.com.au/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Australian Theatre for Young People",
      url: "https://atyp.com.au/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Arts Review Australia",
      url: "https://artsreview.com.au/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Suzy Goes See",
      url: "https://suzygoessee.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },

    // === EUROPEAN THEATRE ===
    {
      name: "The Play's the Thing UK",
      url: "https://theplaysthethinguk.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Theatre Rev Stan",
      url: "https://theatre.revstan.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Diary of a Londoness",
      url: "https://diaryofalondoness.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },

    // === ASIAN THEATRE ===
    {
      name: "Korean Musicals",
      url: "https://koreanmusicals.tumblr.com/rss",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Tofugu",
      url: "https://tofugu.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "Asiana Circus",
      url: "https://asianacircus.com/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },

    // === SPECIALTY & EDUCATIONAL ===
    {
      name: "Solomon Theatre",
      url: "https://solomontheatre.co.uk/feed",
      region: 'both' as const,
      priority: 'medium' as const
    },
    {
      name: "University of Bristol Theatre",
      url: "https://theatrecollection.blogs.bristol.ac.uk/feed",
      region: 'both' as const,
      priority: 'low' as const
    },
    {
      name: "The Joyous Living",
      url: "https://thejoyousliving.com/feed",
      region: 'both' as const,
      priority: 'low' as const
    }
  ];

  async aggregateContent(): Promise<AggregatedContent[]> {
    const allContent: AggregatedContent[] = [];

    for (const source of this.sources) {
      try {
        console.log(`Fetching content from ${source.name}...`);
        const feed = await this.fetchRSSFeed(source.url);
        
        if (feed && feed.items) {
          // Process 50 items per source during intensive backlog retrieval
          const itemLimit = 50;
          console.log(`Processing ${Math.min(feed.items.length, itemLimit)} items from ${source.name}`);
          for (const item of feed.items.slice(0, itemLimit)) {
            const content = await this.processRSSItem(item, source);
            if (content) {
              allContent.push(content);
            }
          }
        }
      } catch (error) {
        console.error(`Error fetching from ${source.name}:`, error.message);
        // Continue with other sources
      }
    }

    // Sort by priority and recency
    return allContent
      .sort((a, b) => b.publishedAt.getTime() - a.publishedAt.getTime())
      .slice(0, 50); // INCREASED: Process more articles for comprehensive coverage
  }

  private async fetchRSSFeed(url: string): Promise<any> {
    try {
      // Use a more permissive approach for RSS feeds
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Theatre Spotlight Content Aggregator 1.0',
          'Accept': 'application/rss+xml, application/xml, text/xml'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const xmlText = await response.text();
      return await this.parser.parseString(xmlText);
    } catch (error) {
      console.error(`RSS fetch error for ${url}:`, error);
      return null;
    }
  }

  private async processRSSItem(item: any, source: any): Promise<AggregatedContent | null> {
    try {
      if (!item.title) {
        return null;
      }

      // Robust URL extraction from RSS feeds
      const extractedUrl = this.normalizeLink(item);
      
      // Skip items without valid URLs - these aren't useful for verification
      if (!extractedUrl) {
        console.log(`SKIPPING ITEM (No URL): "${item.title}" from ${source.name}`);
        return null;
      }

      // Safe string extraction for content and title
      const title = this.safeStringExtract(item.title);
      const content = this.safeStringExtract(item.contentSnippet || item.content || item.summary || '');
      
      // Extract original author from RSS item (preserve attribution!)
      const originalAuthor = this.safeStringExtract(
        item.creator || item.author || item['dc:creator'] || ''
      );

      const category = this.categorizeContent(title, content);
      
      console.log(`✅ VALID ITEM: "${title}" -> ${extractedUrl}${originalAuthor ? ` (by ${originalAuthor})` : ''}`);
      
      return {
        title,
        content,
        source: source.name,
        url: extractedUrl, // Now guaranteed to be a valid URL string
        author: originalAuthor || undefined, // Preserve original author if available
        publishedAt: item.pubDate ? new Date(item.pubDate) : new Date(),
        region: source.region,
        category
      };
    } catch (error) {
      console.error('Error processing RSS item:', error);
      return null;
    }
  }

  private normalizeLink(item: any): string | null {
    try {
      // Handle different RSS link formats
      let url: string | null = null;

      // Case 1: Standard string link
      if (typeof item.link === 'string' && item.link.trim()) {
        url = item.link.trim();
      }
      // Case 2: Link object with href property
      else if (item.link && typeof item.link === 'object' && item.link.href) {
        url = String(item.link.href).trim();
      }
      // Case 3: Links array (Atom feeds)
      else if (Array.isArray(item.links) && item.links.length > 0) {
        // Find alternate link or use first available
        const alternateLink = item.links.find(l => l.rel === 'alternate') || item.links[0];
        if (alternateLink && alternateLink.href) {
          url = String(alternateLink.href).trim();
        }
      }
      // Case 4: Direct URL field
      else if (typeof item.url === 'string' && item.url.trim()) {
        url = item.url.trim();
      }
      // Case 5: GUID as URL (common fallback)
      else if (typeof item.guid === 'string' && item.guid.startsWith('http')) {
        url = item.guid.trim();
      }
      // Case 6: ID as URL
      else if (typeof item.id === 'string' && item.id.startsWith('http')) {
        url = item.id.trim();
      }

      // Validate URL format
      if (url && this.isValidUrl(url)) {
        return url;
      }

      return null;
    } catch (error) {
      console.error('Error normalizing link:', error);
      return null;
    }
  }

  private safeStringExtract(value: any): string {
    try {
      if (typeof value === 'string') {
        return value.trim();
      }
      if (value && typeof value === 'object') {
        // Handle Cheerio objects or objects with text() method
        if (typeof value.text === 'function') {
          return value.text().trim();
        }
        // Handle objects with toString
        return String(value).trim();
      }
      return String(value || '').trim();
    } catch (error) {
      return String(value || '').trim();
    }
  }

  private isValidUrl(url: string): boolean {
    try {
      const urlObj = new URL(url);
      return urlObj.protocol === 'http:' || urlObj.protocol === 'https:';
    } catch {
      return false;
    }
  }

  private categorizeContent(title: string, content: string): 'news' | 'review' | 'announcement' {
    const text = `${title} ${content}`.toLowerCase();
    
    if (text.includes('review') || text.includes('critic') || text.includes('stars') || text.includes('rating')) {
      return 'review';
    }
    
    if (text.includes('announces') || text.includes('casting') || text.includes('opening') || 
        text.includes('closing') || text.includes('extends') || text.includes('tickets')) {
      return 'announcement';
    }
    
    return 'news';
  }

  async processAndPublishContent(): Promise<{ processed: number; published: number; newArticles: number }> {
    let processed = 0;
    let published = 0;
    let newArticles = 0;

    try {
      console.log('Starting content aggregation...');
      const aggregatedContent = await this.aggregateContent();
      processed = aggregatedContent.length;

      console.log(`Found ${processed} pieces of content to process`);

      // Filter out duplicates by checking existing articles
      const existingTitles = await this.getExistingArticleTitles();
      const uniqueContent = aggregatedContent.filter(content => {
        const titleSlug = content.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/-+/g, '-');
        return !existingTitles.has(titleSlug) && !existingTitles.has(content.title.toLowerCase());
      });

      newArticles = uniqueContent.length;
      console.log(`After deduplication: ${newArticles} new articles to process`);

      if (newArticles === 0) {
        console.log('🛑 No new articles found - signaling to stop intensive aggregation');
        // Signal to scheduler that no new content is available
        this.noNewContentCount = (this.noNewContentCount || 0) + 1;
        return { processed, published: 0, newArticles: 0 };
      } else {
        // Reset counter when new content is found
        this.noNewContentCount = 0;
      }

      for (const content of uniqueContent) {
        try {
          console.log(`Processing: ${content.title}`);
          console.log(`Original URL: ${content.url}`);
          console.log(`Source: ${content.source}`);
          
          // Enhanced content safety and plagiarism check
          const { contentSafetyScanner } = await import("./content-safety");
          const { plagiarismChecker } = await import("./plagiarism-checker");
          
          // Run both safety and plagiarism checks
          const moderationResult = await contentSafetyScanner.moderateBeforePublication({
            title: content.title,
            content: content.content,
            category: content.category,
            region: content.region || 'both'
          });
          
          if (!moderationResult.approved) {
            console.warn(`BLOCKED CONTENT (PLAGIARISM RISK): ${content.title} - Reasons: ${moderationResult.reasons?.join(', ')}`);
            continue;
          }
          
          // Additional plagiarism check for all AI-generated content
          const plagiarismResult = await plagiarismChecker.checkContent(content.title, content.content);
          
          if (!plagiarismResult.isOriginal) {
            console.warn(`BLOCKED CONTENT (HIGH PLAGIARISM RISK): ${content.title} - Score: ${plagiarismResult.riskScore}/20`);
            const report = await plagiarismChecker.generateOriginalityReport(content.title, content.content);
            console.log('PLAGIARISM REPORT:', report);
            continue;
          }
          
          // Use cleaned content if provided
          const processedContent = moderationResult.modifiedArticle || {
            ...content,
            region: content.region || 'both'
          };

          // Rewrite content in Mark Shenton's style using cleaned content
          const rewritten = await aiContentGenerator.rewriteExistingContent(
            processedContent.content,
            processedContent.title,
            processedContent.category === 'review' ? 'review' : 'article'
          );

          if (processedContent.category === 'review') {
            // Extract venue information for reviews
            const venue = this.extractVenue(processedContent.title, processedContent.content);
            if (venue) {
              await aiContentGenerator.generateMarkShentonReview({
                title: rewritten.title.replace(' Review', '').replace(' review', ''),
                venue,
                region: processedContent.region
              });
              published++;
            }
          } else {
            // Generate article with region fallback AND preserve source URL
            console.log(`PASSING TO AI: URL=${content.url}, Source=${content.source}`);
            await aiContentGenerator.generateObservationFromNews({
              title: rewritten.title,
              content: rewritten.content,
              source: content.source,
              sourceUrl: content.url, // CRITICAL: Preserve original RSS source URL from content object
              publishedAt: content.publishedAt,
              region: processedContent.region || 'both',
              category: processedContent.category
            });
            published++;
          }

          // Add delay to avoid rate limiting
          await new Promise(resolve => setTimeout(resolve, 1000));

        } catch (error) {
          console.error('Error processing individual content:', error);
          // Continue with next item
        }
      }

      console.log(`Content aggregation complete: ${processed} processed, ${published} published, ${newArticles} new articles`);
      return { processed, published, newArticles };

    } catch (error) {
      console.error('Error in content aggregation process:', error);
      return { processed, published, newArticles };
    }
  }

  async getExistingArticleTitles(): Promise<Set<string>> {
    try {
      // Import within the method to avoid circular dependencies
      const { db } = await import("./db");
      const { articles } = await import("@shared/schema");
      
      // Get existing article titles to prevent duplicates
      const existingArticles = await db.select({ 
        title: articles.title,
        slug: articles.slug 
      }).from(articles);
      
      const titleSet = new Set<string>();
      existingArticles.forEach(article => {
        titleSet.add(article.title.toLowerCase());
        titleSet.add(article.slug);
      });
      
      return titleSet;
    } catch (error) {
      console.error('Error fetching existing article titles:', error);
      return new Set();
    }
  }

  shouldStopIntensiveAggregation(): boolean {
    return this.noNewContentCount >= 3; // Stop after 3 consecutive runs with no new content
  }

  resetNoContentCounter(): void {
    this.noNewContentCount = 0;
  }

  private extractVenue(title: string, content: string): string | null {
    const text = `${title} ${content}`;
    
    // Common venue patterns
    const venuePatterns = [
      /at the ([A-Za-z\s]+Theatre)/i,
      /at ([A-Za-z\s]+Theatre)/i,
      /([A-Za-z\s]+Theatre)/i,
      /at the ([A-Za-z\s]+Theater)/i,
      /at ([A-Za-z\s]+Theater)/i,
      /([A-Za-z\s]+Theater)/i
    ];

    for (const pattern of venuePatterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }

    // Default venues if none found
    const defaultVenues = {
      uk: ['National Theatre', 'Royal Opera House', 'Apollo Victoria Theatre', 'Prince Edward Theatre'],
      us: ['Majestic Theatre', 'Gershwin Theatre', 'Richard Rodgers Theatre', 'Imperial Theatre']
    };

    return defaultVenues.uk[Math.floor(Math.random() * defaultVenues.uk.length)];
  }

  // Manual content submission endpoint
  async submitManualContent(data: {
    title: string;
    content: string;
    contentType: 'news' | 'review' | 'announcement';
    region: 'uk' | 'us' | 'both';
    venue?: string;
  }): Promise<any> {
    try {
      // Moderate content first
      const isSafe = await aiContentGenerator.moderateContent(data.content);
      if (!isSafe) {
        throw new Error('Content failed safety moderation');
      }

      if (data.contentType === 'review' && data.venue) {
        return await aiContentGenerator.generateReview({
          title: data.title,
          venue: data.venue,
          region: data.region as 'uk' | 'us'
        });
      } else {
        return await aiContentGenerator.generateArticleFromNews({
          title: data.title,
          content: data.content,
          source: 'Manual Submission',
          publishedAt: new Date(),
          region: data.region,
          category: data.contentType
        });
      }
    } catch (error) {
      console.error('Error submitting manual content:', error);
      throw error;
    }
  }
}

export const contentAggregator = new ContentAggregator();