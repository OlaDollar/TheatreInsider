import cron from 'node-cron';
import { aiContentGenerator } from './ai-content';
import { contentAggregator } from './content-aggregator';

export class ContentScheduler {
  private jobs: cron.ScheduledTask[] = [];

  start() {
    console.log('Starting content scheduler...');

    // Generate daily content at 6 AM GMT
    const dailyContentJob = cron.schedule('0 6 * * *', async () => {
      console.log('Starting daily content generation...');
      try {
        await aiContentGenerator.generateDailyContent();
        console.log('Daily content generation completed');
      } catch (error) {
        console.error('Daily content generation failed:', error);
      }
    }, {
      scheduled: false,
      timezone: "Europe/London"
    });

    // Aggregate content from external sources every 2 hours
    const aggregationJob = cron.schedule('0 */2 * * *', async () => {
      console.log('Starting content aggregation...');
      try {
        await contentAggregator.processAndPublishContent();
        console.log('Content aggregation completed');
      } catch (error) {
        console.error('Content aggregation failed:', error);
      }
    }, {
      scheduled: false,
      timezone: "Europe/London"
    });

    // Breaking news check every 30 minutes during business hours (9 AM - 6 PM GMT)
    const breakingNewsJob = cron.schedule('*/30 9-18 * * *', async () => {
      console.log('Checking for breaking news...');
      try {
        const result = await contentAggregator.processAndPublishContent();
        if (result.published > 0) {
          console.log(`Published ${result.published} breaking news items`);
        }
      } catch (error) {
        console.error('Breaking news check failed:', error);
      }
    }, {
      scheduled: false,
      timezone: "Europe/London"
    });

    this.jobs = [dailyContentJob, aggregationJob, breakingNewsJob];

    // Start all jobs
    this.jobs.forEach(job => job.start());
    
    const intensiveEndTime = Date.now() + (5 * 60 * 60 * 1000); // 5 hours from now
    
    // Add intensive aggregation job (every 5 minutes for 5 hours OR until no new content)
    const intensiveJob = cron.schedule('*/5 * * * *', async () => {
      if (Date.now() < intensiveEndTime) {
        console.log('Running INTENSIVE content aggregation (backlog retrieval)...');
        const { shouldStop } = await this.triggerAggregation();
        
        if (shouldStop) {
          console.log('🎯 SMART STOP: No new articles available - ending intensive mode early');
          console.log('💰 Cost savings: Stopped before time limit to prevent unnecessary API calls');
          intensiveJob.destroy();
          
          // Start normal 2-hour aggregation schedule
          const normalJob = cron.schedule('0 */2 * * *', async () => {
            console.log('Running normal content aggregation (2-hour schedule)...');
            await this.triggerAggregation();
          }, { scheduled: true });
          
          this.jobs.push(normalJob);
          console.log('✅ SMART RESET COMPLETE: Now running normal 2-hour aggregation schedule');
        }
      } else {
        console.log('Intensive period ended - switching to normal 2-hour schedule');
        intensiveJob.destroy();
        
        // Start normal 2-hour aggregation schedule
        const normalJob = cron.schedule('0 */2 * * *', async () => {
          console.log('Running normal content aggregation (2-hour schedule)...');
          await this.triggerAggregation();
        }, { scheduled: true });
        
        this.jobs.push(normalJob);
        console.log('✅ TIME RESET COMPLETE: Now running normal 2-hour aggregation schedule');
      }
    }, { scheduled: false });

    // Safety timeout to ensure reset happens (backup mechanism)
    setTimeout(() => {
      if (intensiveJob && !intensiveJob.destroyed) {
        console.log('⚠️ Safety timeout triggered - forcing reset to normal schedule');
        intensiveJob.destroy();
        
        const normalJob = cron.schedule('0 */2 * * *', async () => {
          console.log('Running normal content aggregation (2-hour schedule)...');
          await this.triggerAggregation();
        }, { scheduled: true });
        
        this.jobs.push(normalJob);
        console.log('✅ SAFETY RESET COMPLETE: Now running normal 2-hour aggregation schedule');
      }
    }, 5 * 60 * 60 * 1000 + 5000); // 5 hours + 5 seconds buffer

    // Schedule theatre data updates (every hour)
    cron.schedule('0 * * * *', async () => {
      console.log('🎭 Starting hourly theatre data update...');
      try {
        const { theatreDataScraper } = await import('./theatre-data-scraper');
        const result = await theatreDataScraper.scrapeAllTheatres();
        console.log(`🎭 Theatre data update complete: ${result.scraped} scraped, ${result.updated} updated, ${result.newShows} new shows`);
      } catch (error) {
        console.error('Theatre data update error:', error);
      }
    });

    this.jobs.push(intensiveJob);
    intensiveJob.start();
    
    console.log('Content scheduler started with INTENSIVE BACKLOG RETRIEVAL:');
    
    // Schedule comprehensive Mark Shenton content scraping - daily
    cron.schedule('0 3 * * *', async () => {
      console.log('🎭 Running daily Mark Shenton content scraping from all sources...');
      try {
        const { markShentonContentScraper } = await import("./mark-shenton-content-scraper");
        const result = await markShentonContentScraper.scrapeAllMarkShentonContent();
        console.log(`Mark Shenton scraping completed: ${result.processed} processed, ${result.shentonAICreated} created, ${result.duplicatesSkipped} duplicates skipped`);
      } catch (error) {
        console.error('Error in scheduled Mark Shenton scraping:', error);
      }
    }, { scheduled: true, timezone: "Europe/London" });
    console.log('- Daily content generation: 6:00 AM GMT');
    console.log('- INTENSIVE aggregation: Every 5 minutes for next 5 hours');
    console.log('- Breaking news check: Every 30 minutes (9 AM - 6 PM GMT)');
    console.log(`- Intensive mode ends at: ${new Date(intensiveEndTime).toISOString()}`);
    
    // TESTING URL FIXES: Content aggregation re-enabled for verification
    console.log('🔄 TESTING URL FIXES: Content aggregation enabled for verification...');
  }

  stop() {
    console.log('Stopping content scheduler...');
    this.jobs.forEach(job => job.stop());
    this.jobs = [];
  }

  // Manual trigger for testing
  async triggerDailyContent() {
    console.log('Manual trigger: Daily content generation');
    return await aiContentGenerator.generateDailyContent();
  }

  async triggerAggregation() {
    console.log('Manual trigger: Content aggregation (TESTING URL FIXES)');
    try {
      const result = await contentAggregator.processAndPublishContent();
      // Stop if no new content to avoid excessive API calls
      const shouldStop = result.newArticles === 0;
      return { ...result, shouldStop };
    } catch (error) {
      console.error('Content aggregation error:', error);
      return { processed: 0, published: 0, shouldStop: true };
    }
  }

  getStatus() {
    return {
      active: this.jobs.length > 0,
      jobCount: this.jobs.length,
      nextRuns: this.jobs.map(job => ({
        scheduled: job.scheduled,
        nextRun: job.nextRun
      }))
    };
  }
}

export const contentScheduler = new ContentScheduler();