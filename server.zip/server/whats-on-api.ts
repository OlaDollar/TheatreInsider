/**
 * What's On API Handler
 * Real-time theatre data from scraped major venues
 */

import { storage } from './storage';

export async function getWhatsOnShows(filters: any) {
  console.log('What\'s On API called with filters:', filters);
  
  const { region, venue_type, genre, status, search, min_price, max_price } = filters;
  
  // Get current shows from database (updated hourly by scraper)
  const dbShows = await storage.getShows({
    region: region as string,
    status: status as string
  });
  
  // Transform database shows to API format
  let shows = dbShows.map(show => ({
    id: show.id,
    title: show.title,
    venue: show.venue,
    region: show.region,
    venueType: categorizeVenueType(show.venue, show.region),
    genre: show.category || 'musical',
    status: show.status,
    description: show.description || `${show.title} at ${show.venue}`,
    ticketUrl: show.ticketUrl || `https://example.com/tickets/${show.slug}`,
    officialWebsite: show.officialWebsite || show.ticketUrl || `https://example.com/show/${show.slug}`,
    imageUrl: show.imageUrl || '/images/placeholder-show.jpg',
    director: show.director,
    composer: show.composer,
    cast: show.cast || [],
    duration: show.duration || '2h 30m',
    ageRating: show.ageRating || 'PG',
    popularity: show.popularity || 75,
    openingDate: show.openingDate?.toISOString().split('T')[0],
    closingDate: show.closingDate?.toISOString().split('T')[0],
    priceRange: estimatePriceRange(show.region, show.category),
    ticketAvailability: inferTicketAvailability(show.status),
    lastUpdated: show.lastUpdated?.toISOString() || new Date().toISOString()
  }));
  
  // Apply additional filters
  if (genre) {
    const genres = genre.split(',');
    shows = shows.filter(show => genres.includes(show.genre));
  }
  
  if (venue_type) {
    const venueTypes = venue_type.split(',');
    shows = shows.filter(show => venueTypes.includes(show.venueType));
  }
  
  if (search) {
    const term = search.toLowerCase();
    shows = shows.filter(show => 
      show.title.toLowerCase().includes(term) ||
      show.venue.toLowerCase().includes(term) ||
      show.description.toLowerCase().includes(term) ||
      (show.cast && show.cast.some((actor: string) => actor.toLowerCase().includes(term)))
    );
  }
  
  if (min_price || max_price) {
    shows = shows.filter(show => {
      if (!show.priceRange) return true;
      if (min_price && show.priceRange.min < parseFloat(min_price)) return false;
      if (max_price && show.priceRange.max > parseFloat(max_price)) return false;
      return true;
    });
  }
  
  // Sort by popularity and update time
  shows.sort((a, b) => {
    if (a.popularity !== b.popularity) {
      return b.popularity - a.popularity;
    }
    return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
  });
  
  console.log(`Returning ${shows.length} live theatre shows`);
  return shows;
}

// Helper functions
function categorizeVenueType(venue: string, region: string): string {
  const westEndVenues = [
    'lyceum theatre', 'apollo victoria', 'his majesty\'s theatre', 'victoria palace',
    'phoenix theatre', 'cambridge theatre', 'prince of wales theatre', 'gielgud theatre'
  ];
  
  const broadwayVenues = [
    'richard rodgers', 'minskoff', 'gershwin', 'majestic', 'broadhurst', 'imperial'
  ];
  
  const venueLower = venue.toLowerCase();
  
  if (region === 'uk') {
    if (westEndVenues.some(v => venueLower.includes(v))) return 'west_end';
    if (venueLower.includes('royal') || venueLower.includes('national')) return 'regional';
    return 'off_west_end';
  }
  
  if (region === 'us') {
    if (broadwayVenues.some(v => venueLower.includes(v))) return 'broadway';
    return 'off_broadway';
  }
  
  return 'regional';
}

function estimatePriceRange(region: string, category?: string): { min: number; max: number; currency: 'GBP' | 'USD' } {
  const ranges = {
    uk: { min: 20, max: 125, currency: 'GBP' as const },
    us: { min: 30, max: 150, currency: 'USD' as const }
  };
  return ranges[region as keyof typeof ranges] || ranges.uk;
}

function inferTicketAvailability(status: string): 'available' | 'limited' | 'sold_out' | 'not_on_sale' {
  if (status === 'running') return 'available';
  if (status === 'preview') return 'limited';
  if (status === 'announced') return 'not_on_sale';
  return 'available';
}