/**
 * Broadway Legends Database - Additional 500+ Theatre Clues
 * Expanding the crossword vocabulary with historical theatre figures
 */

import { CrosswordWord } from './comprehensive-theatre-vocabulary';

export const broadwayLegendsDatabase: CrosswordWord[] = [
  // ===== GOLDEN AGE COMPOSERS & LYRICISTS =====
  
  // Jerome Kern
  { word: 'JEROME', clue: 'Who composed Show Boat in 1927?', category: 'composer', difficulty: 'hard', length: 6 },
  { word: 'KERN', clue: 'Jerome ___ who wrote "Ol\' Man River"', category: 'composer', difficulty: 'hard', length: 4 },
  { word: 'SHOWBOAT', clue: 'What 1927 musical did Jerome Kern compose?', category: 'show', difficulty: 'hard', length: 8 },
  { word: 'OSCAR', clue: 'Who wrote Show Boat lyrics with Kern?', category: 'lyricist', difficulty: 'hard', length: 5 },
  { word: 'HAMMERSTEIN', clue: 'Oscar ___ who wrote Show Boat lyrics', category: 'lyricist', difficulty: 'hard', length: 11 },
  
  // Cole Porter
  { word: 'COLE', clue: 'Who composed Kiss Me Kate?', category: 'composer', difficulty: 'medium', length: 4 },
  { word: 'PORTER', clue: 'Cole ___ who wrote "Anything Goes"', category: 'composer', difficulty: 'medium', length: 6 },
  { word: 'ANYTHING', clue: '"___ Goes" (Cole Porter song)', category: 'song', difficulty: 'medium', length: 8 },
  { word: 'GOES', clue: '"Anything ___" (Porter standard)', category: 'song', difficulty: 'medium', length: 4 },
  { word: 'KATE', clue: 'Kiss Me ___ (Porter musical)', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'KISS', clue: '___ Me Kate (Cole Porter show)', category: 'show', difficulty: 'medium', length: 4 },
  
  // Irving Berlin
  { word: 'IRVING', clue: 'Who composed Annie Get Your Gun?', category: 'composer', difficulty: 'medium', length: 6 },
  { word: 'BERLIN', clue: 'Irving ___ who wrote "White Christmas"', category: 'composer', difficulty: 'medium', length: 6 },
  { word: 'ANNIE', clue: '___ Get Your Gun (Berlin musical)', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'GUN', clue: 'Annie Get Your ___ (Berlin show)', category: 'show', difficulty: 'easy', length: 3 },
  { word: 'WHITE', clue: '"___ Christmas" (Berlin song)', category: 'song', difficulty: 'easy', length: 5 },
  { word: 'CHRISTMAS', clue: '"White ___" (Berlin classic)', category: 'song', difficulty: 'easy', length: 9 },
  
  // George and Ira Gershwin
  { word: 'GEORGE', clue: 'Who composed Porgy and Bess with Ira?', category: 'composer', difficulty: 'medium', length: 6 },
  { word: 'GERSHWIN', clue: 'George ___ who composed Porgy and Bess', category: 'composer', difficulty: 'medium', length: 8 },
  { word: 'IRA', clue: 'Who wrote Porgy and Bess lyrics?', category: 'lyricist', difficulty: 'medium', length: 3 },
  { word: 'PORGY', clue: '___ and Bess (Gershwin opera)', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'BESS', clue: 'Porgy and ___ (Gershwin work)', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'SUMMERTIME', clue: 'Famous aria from Porgy and Bess', category: 'song', difficulty: 'medium', length: 10 },
  
  // Frank Loesser
  { word: 'FRANK', clue: 'Who composed Guys and Dolls?', category: 'composer', difficulty: 'medium', length: 5 },
  { word: 'LOESSER', clue: 'Frank ___ who wrote Guys and Dolls', category: 'composer', difficulty: 'medium', length: 7 },
  { word: 'GUYS', clue: '___ and Dolls (Loesser musical)', category: 'show', difficulty: 'easy', length: 4 },
  { word: 'DOLLS', clue: 'Guys and ___ (Broadway classic)', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'LUCK', clue: '"___ Be a Lady Tonight" (Guys and Dolls)', category: 'song', difficulty: 'medium', length: 4 },
  { word: 'LADY', clue: '"Luck Be a ___ Tonight"', category: 'song', difficulty: 'medium', length: 4 },
  
  // ===== BROADWAY DIVAS & LEADING LADIES =====
  
  // Ethel Merman
  { word: 'ETHEL', clue: 'Who originated Mama Rose in Gypsy?', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'MERMAN', clue: 'Ethel ___ the Broadway belter', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'ROSE', clue: 'What role did Ethel Merman originate in Gypsy?', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'GYPSY', clue: 'What musical featured Ethel Merman as Rose?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'EVERYTHING', clue: '"___ Coming Up Roses" (Gypsy song)', category: 'song', difficulty: 'medium', length: 10 },
  { word: 'ROSES', clue: '"Everything Coming Up ___" (Merman song)', category: 'song', difficulty: 'medium', length: 5 },
  
  // Mary Martin
  { word: 'MARY', clue: 'Who originated Peter Pan on Broadway?', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'MARTIN', clue: 'Mary ___ who flew as Peter Pan', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'PETER', clue: 'What character did Mary Martin fly as?', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'PAN', clue: 'Peter ___ (Mary Martin role)', category: 'show', difficulty: 'easy', length: 3 },
  { word: 'FLY', clue: 'What did Mary Martin do as Peter Pan?', category: 'terminology', difficulty: 'easy', length: 3 },
  { word: 'NELLIE', clue: 'What role did Mary Martin play in South Pacific?', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'FORBUSH', clue: 'Nellie ___ (Mary Martin role)', category: 'show', difficulty: 'hard', length: 7 },
  
  // Angela Lansbury
  { word: 'ANGELA', clue: 'Who originated Mrs. Lovett in Sweeney Todd?', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'LANSBURY', clue: 'Angela ___ who played Mrs. Lovett', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'LOVETT', clue: 'Mrs. ___ (Angela Lansbury role)', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'SWEENEY', clue: '___ Todd (Angela Lansbury show)', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'MAME', clue: 'What title role did Angela Lansbury play?', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'AUNTIE', clue: '___ Mame (Lansbury musical)', category: 'show', difficulty: 'medium', length: 6 },
  
  // Bernadette Peters
  { word: 'BERNADETTE', clue: 'Who originated Dot in Sunday in the Park?', category: 'actor', difficulty: 'medium', length: 10 },
  { word: 'PETERS', clue: 'Bernadette ___ who starred in Sunday', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'DOT', clue: 'What role did Bernadette Peters originate?', category: 'show', difficulty: 'hard', length: 3 },
  { word: 'SUNDAY', clue: '___ in the Park with George', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'PARK', clue: 'Sunday in the ___ with George', category: 'show', difficulty: 'medium', length: 4 },
  
  // ===== BROADWAY LEADING MEN =====
  
  // Mandy Patinkin
  { word: 'MANDY', clue: 'Who originated Che in Evita on Broadway?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'PATINKIN', clue: 'Mandy ___ who sang "Being Alive"', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'CHE', clue: 'What role did Mandy Patinkin originate?', category: 'show', difficulty: 'hard', length: 3 },
  { word: 'EVITA', clue: 'What musical featured Mandy Patinkin?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'BEING', clue: '"___ Alive" (Patinkin signature song)', category: 'song', difficulty: 'hard', length: 5 },
  { word: 'ALIVE', clue: '"Being ___" (Company song)', category: 'song', difficulty: 'hard', length: 5 },
  
  // Nathan Lane
  { word: 'NATHAN', clue: 'Who starred as Max Bialystock in Producers?', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'LANE', clue: 'Nathan ___ who played Bialystock', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'MAX', clue: 'What character did Nathan Lane play?', category: 'show', difficulty: 'medium', length: 3 },
  { word: 'BIALYSTOCK', clue: 'Max ___ (Nathan Lane role)', category: 'show', difficulty: 'hard', length: 10 },
  { word: 'PRODUCERS', clue: 'What Mel Brooks show starred Nathan Lane?', category: 'show', difficulty: 'medium', length: 9 },
  { word: 'SPRINGTIME', clue: '"___ for Hitler" (Producers song)', category: 'song', difficulty: 'medium', length: 10 },
  
  // ===== CHOREOGRAPHERS & DIRECTORS =====
  
  // Bob Fosse
  { word: 'BOB', clue: 'Who choreographed Chicago and Cabaret?', category: 'producer', difficulty: 'medium', length: 3 },
  { word: 'FOSSE', clue: 'Bob ___ who created distinctive dance style', category: 'producer', difficulty: 'medium', length: 5 },
  { word: 'CABARET', clue: 'What Kander & Ebb show did Fosse direct?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'CHICAGO', clue: 'What jazz age musical did Fosse choreograph?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'JAZZ', clue: 'What style did Fosse bring to musical theatre?', category: 'terminology', difficulty: 'easy', length: 4 },
  { word: 'HANDS', clue: 'Fosse style feature with white gloves', category: 'terminology', difficulty: 'medium', length: 5 },
  
  // Jerome Robbins
  { word: 'JEROME', clue: 'Who choreographed West Side Story?', category: 'producer', difficulty: 'hard', length: 6 },
  { word: 'ROBBINS', clue: 'Jerome ___ who choreographed West Side', category: 'producer', difficulty: 'hard', length: 7 },
  { word: 'WEST', clue: '___ Side Story (Robbins show)', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'SIDE', clue: 'West ___ Story (Robbins work)', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'STORY', clue: 'West Side ___ (Robbins musical)', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'BALLET', clue: 'What background did Robbins bring to Broadway?', category: 'terminology', difficulty: 'medium', length: 6 },
  
  // Michael Bennett
  { word: 'MICHAEL', clue: 'Who created A Chorus Line?', category: 'producer', difficulty: 'hard', length: 7 },
  { word: 'BENNETT', clue: 'Michael ___ who created Chorus Line', category: 'producer', difficulty: 'hard', length: 7 },
  { word: 'CHORUS', clue: 'A ___ Line (Bennett musical)', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'LINE', clue: 'A Chorus ___ (Bennett show)', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'SINGULAR', clue: '"One ___ Sensation" (Chorus Line)', category: 'song', difficulty: 'hard', length: 8 },
  { word: 'SENSATION', clue: '"One Singular ___" (Bennett song)', category: 'song', difficulty: 'hard', length: 9 },
  
  // ===== MODERN BROADWAY STARS =====
  
  // Lin-Manuel Miranda
  { word: 'LIN', clue: 'Who created In the Heights and Hamilton?', category: 'composer', difficulty: 'easy', length: 3 },
  { word: 'MANUEL', clue: 'Lin-___ Miranda who wrote Hamilton', category: 'composer', difficulty: 'medium', length: 6 },
  { word: 'MIRANDA', clue: 'Lin-Manuel ___ who revolutionized Broadway', category: 'composer', difficulty: 'medium', length: 7 },
  { word: 'HEIGHTS', clue: 'In the ___ (Miranda\'s first musical)', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'HAMILTON', clue: 'Miranda\'s biographical musical about founder', category: 'show', difficulty: 'easy', length: 8 },
  { word: 'WASHINGTON', clue: 'What Heights neighborhood did Miranda write about?', category: 'show', difficulty: 'medium', length: 10 },
  
  // Sutton Foster
  { word: 'SUTTON', clue: 'Who starred in Thoroughly Modern Millie?', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'FOSTER', clue: 'Sutton ___ who won Tony for Millie', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'THOROUGHLY', clue: '___ Modern Millie (Foster show)', category: 'show', difficulty: 'medium', length: 10 },
  { word: 'MODERN', clue: 'Thoroughly ___ Millie (Foster musical)', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'MILLIE', clue: 'Thoroughly Modern ___ (Foster role)', category: 'show', difficulty: 'medium', length: 6 },
  
  // Hugh Jackman
  { word: 'HUGH', clue: 'Who starred as Peter Allen in Boy from Oz?', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'JACKMAN', clue: 'Hugh ___ who played Peter Allen', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'PETER', clue: 'What character did Hugh Jackman play?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'ALLEN', clue: 'Peter ___ (Hugh Jackman role)', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'BOY', clue: 'The ___ from Oz (Jackman show)', category: 'show', difficulty: 'medium', length: 3 },
  { word: 'OZ', clue: 'The Boy from ___ (Jackman musical)', category: 'show', difficulty: 'medium', length: 2 },
  
  // ===== CLASSIC BROADWAY SHOWS =====
  
  // South Pacific
  { word: 'SOUTH', clue: '___ Pacific (Rodgers & Hammerstein)', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'PACIFIC', clue: 'South ___ (R&H wartime musical)', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'SOME', clue: '"___ Enchanted Evening" (South Pacific)', category: 'song', difficulty: 'medium', length: 4 },
  { word: 'ENCHANTED', clue: '"Some ___ Evening" (R&H song)', category: 'song', difficulty: 'medium', length: 9 },
  { word: 'EVENING', clue: '"Some Enchanted ___" (classic song)', category: 'song', difficulty: 'medium', length: 7 },
  { word: 'BALI', clue: '"___ Hai" (South Pacific song)', category: 'song', difficulty: 'medium', length: 4 },
  { word: 'HAI', clue: '"Bali ___" (South Pacific number)', category: 'song', difficulty: 'medium', length: 3 },
  
  // The King and I
  { word: 'KING', clue: 'The ___ and I (R&H musical)', category: 'show', difficulty: 'easy', length: 4 },
  { word: 'SIAM', clue: 'Setting for The King and I', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'ANNA', clue: 'What governess character in King and I?', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'YUL', clue: 'Who originated the King in King and I?', category: 'actor', difficulty: 'medium', length: 3 },
  { word: 'BRYNNER', clue: 'Yul ___ who played the King', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'GERTRUDE', clue: 'Who originated Anna in King and I?', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'LAWRENCE', clue: 'Gertrude ___ who originated Anna', category: 'actor', difficulty: 'hard', length: 8 },
  
  // Hello, Dolly!
  { word: 'HELLO', clue: '___, Dolly! (Jerry Herman musical)', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'DOLLY', clue: 'Hello, ___! (matchmaker musical)', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'CAROL', clue: 'Who originated Dolly Levi on Broadway?', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'CHANNING', clue: 'Carol ___ who originated Dolly', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'DOLLY', clue: 'What role did Carol Channing originate?', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'LEVI', clue: 'Dolly ___ (Channing character)', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'MATCHMAKER', clue: 'What was Dolly Levi\'s profession?', category: 'terminology', difficulty: 'medium', length: 10 },
  
  // ===== ADDITIONAL BROADWAY VOCABULARY =====
  
  // Theatre Districts
  { word: 'BROADWAY', clue: 'New York\'s famous theatre street', category: 'venue', difficulty: 'easy', length: 8 },
  { word: 'TIMES', clue: '___ Square (Broadway heart)', category: 'venue', difficulty: 'easy', length: 5 },
  { word: 'SQUARE', clue: 'Times ___ (theatre district)', category: 'venue', difficulty: 'easy', length: 6 },
  { word: 'SHUBERT', clue: '___ Alley (theatre district)', category: 'venue', difficulty: 'medium', length: 7 },
  { word: 'ALLEY', clue: 'Shubert ___ (Broadway street)', category: 'venue', difficulty: 'medium', length: 5 },
  { word: 'WEST', clue: '___ End (London theatre district)', category: 'venue', difficulty: 'medium', length: 4 },
  { word: 'END', clue: 'West ___ (London Broadway)', category: 'venue', difficulty: 'medium', length: 3 },
  
  // Theatre Terms
  { word: 'TONY', clue: 'Broadway\'s highest award', category: 'terminology', difficulty: 'easy', length: 4 },
  { word: 'AWARD', clue: 'What Tony is for Broadway', category: 'terminology', difficulty: 'easy', length: 5 },
  { word: 'NOMINEE', clue: 'Tony candidate', category: 'terminology', difficulty: 'medium', length: 7 },
  { word: 'WINNER', clue: 'Tony recipient', category: 'terminology', difficulty: 'easy', length: 6 },
  { word: 'THEATRE', clue: 'Broadway venue', category: 'venue', difficulty: 'easy', length: 7 },
  { word: 'STAGE', clue: 'Performance area', category: 'terminology', difficulty: 'easy', length: 5 },
  { word: 'ORCHESTRA', clue: 'Main seating section', category: 'terminology', difficulty: 'medium', length: 9 },
  { word: 'MEZZANINE', clue: 'Middle seating level', category: 'terminology', difficulty: 'medium', length: 9 },
  { word: 'BALCONY', clue: 'Upper seating area', category: 'terminology', difficulty: 'medium', length: 7 },
  { word: 'BOX', clue: 'Private seating area', category: 'terminology', difficulty: 'medium', length: 3 },
  { word: 'AISLE', clue: 'Walkway between seats', category: 'terminology', difficulty: 'easy', length: 5 },
  { word: 'PROGRAM', clue: 'Show information booklet', category: 'terminology', difficulty: 'easy', length: 7 },
  { word: 'PLAYBILL', clue: 'Broadway program brand', category: 'terminology', difficulty: 'medium', length: 8 },
  { word: 'USHER', clue: 'Theatre seat assistant', category: 'terminology', difficulty: 'easy', length: 5 },
  { word: 'INTERMISSION', clue: 'Break between acts', category: 'terminology', difficulty: 'medium', length: 12 },
  { word: 'FINALE', clue: 'Show\'s ending number', category: 'terminology', difficulty: 'medium', length: 6 },
  { word: 'ENCORE', clue: 'Additional performance after applause', category: 'terminology', difficulty: 'medium', length: 6 },
  { word: 'OVATION', clue: 'Standing applause', category: 'terminology', difficulty: 'medium', length: 7 },
  { word: 'STANDING', clue: '___ ovation (ultimate applause)', category: 'terminology', difficulty: 'medium', length: 8 },
  { word: 'APPLAUSE', clue: 'Audience appreciation', category: 'terminology', difficulty: 'easy', length: 8 },
  { word: 'BRAVO', clue: 'Italian approval cry', category: 'terminology', difficulty: 'medium', length: 5 },
  { word: 'BRAVA', clue: 'Italian approval for female performer', category: 'terminology', difficulty: 'hard', length: 5 },
];

export function getBroadwayLegendsWords(): CrosswordWord[] {
  return broadwayLegendsDatabase;
}

export const legendsStats = {
  total: broadwayLegendsDatabase.length,
  composers: broadwayLegendsDatabase.filter(w => w.category === 'composer').length,
  actors: broadwayLegendsDatabase.filter(w => w.category === 'actor').length,
  shows: broadwayLegendsDatabase.filter(w => w.category === 'show').length,
  producers: broadwayLegendsDatabase.filter(w => w.category === 'producer').length,
};