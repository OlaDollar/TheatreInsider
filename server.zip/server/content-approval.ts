import { db } from "./db";
import { storage } from "./storage";

interface PendingContent {
  id: string;
  type: 'article' | 'review' | 'news';
  title: string;
  content: string;
  excerpt: string;
  category: string;
  region: string;
  source: string;
  aiGenerated: boolean;
  riskLevel: 'low' | 'medium' | 'high';
  flaggedTerms: string[];
  submittedAt: Date;
  status: 'pending' | 'approved' | 'revision' | 'rejected';
  approvalCode?: string;
  responseDeadline: Date;
}

interface ApprovalResponse {
  contentId: string;
  decision: 'publish' | 'revision' | 'reject';
  feedback?: string;
  respondedAt: Date;
}

export class ContentApprovalSystem {
  private pendingContent: Map<string, PendingContent> = new Map();
  private approvalCodes: Map<string, string> = new Map(); // code -> contentId
  private userPhoneNumber: string = '+44 7123 456789'; // Replace with actual number

  async submitForApproval(content: any): Promise<{ requiresApproval: boolean; contentId?: string }> {
    // Analyze content for risk factors
    const riskAnalysis = await this.analyzeContentRisk(content);
    
    if (riskAnalysis.riskLevel === 'low' && !riskAnalysis.hasLegalRisks) {
      // Auto-approve low-risk content
      await storage.createArticle(content);
      console.log(`Auto-approved low-risk content: ${content.title}`);
      return { requiresApproval: false };
    }

    // Generate unique approval code
    const contentId = `pending-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const approvalCode = Math.random().toString(36).substr(2, 6).toUpperCase();
    
    // Store pending content
    const pendingItem: PendingContent = {
      id: contentId,
      type: content.category === 'review' ? 'review' : 'article',
      title: content.title,
      content: content.content,
      excerpt: content.excerpt,
      category: content.category,
      region: content.region,
      source: content.source || 'AI Generated',
      aiGenerated: true,
      riskLevel: riskAnalysis.riskLevel,
      flaggedTerms: riskAnalysis.flaggedTerms,
      submittedAt: new Date(),
      status: 'pending',
      approvalCode,
      responseDeadline: new Date(Date.now() + 2 * 60 * 60 * 1000) // 2 hours
    };

    this.pendingContent.set(contentId, pendingItem);
    this.approvalCodes.set(approvalCode, contentId);

    // Send mobile alert
    await this.sendMobileAlert(pendingItem);

    console.log(`Content submitted for approval: ${content.title} (Code: ${approvalCode})`);
    return { requiresApproval: true, contentId };
  }

  private async analyzeContentRisk(content: any): Promise<{
    riskLevel: 'low' | 'medium' | 'high';
    flaggedTerms: string[];
    hasLegalRisks: boolean;
    reasoning: string;
  }> {
    const text = `${content.title} ${content.content}`.toLowerCase();
    
    // High-risk terms that could be libelous
    const highRiskTerms = [
      'lawsuit', 'sued', 'fraud', 'criminal', 'illegal', 'scandal', 'corrupt', 
      'embezzlement', 'harassment', 'abuse', 'addiction', 'affair', 'divorce',
      'bankruptcy', 'fired', 'terminated', 'investigation', 'charges'
    ];

    // Medium-risk terms requiring review
    const mediumRiskTerms = [
      'controversy', 'dispute', 'conflict', 'criticism', 'negative', 'poor',
      'disappointing', 'failure', 'problem', 'issue', 'concern', 'troubled'
    ];

    const flaggedTerms: string[] = [];
    let riskLevel: 'low' | 'medium' | 'high' = 'low';
    let hasLegalRisks = false;

    // Check for high-risk terms
    for (const term of highRiskTerms) {
      if (text.includes(term)) {
        flaggedTerms.push(term);
        riskLevel = 'high';
        hasLegalRisks = true;
      }
    }

    // Check for medium-risk terms (only if not already high risk)
    if (riskLevel === 'low') {
      for (const term of mediumRiskTerms) {
        if (text.includes(term)) {
          flaggedTerms.push(term);
          riskLevel = 'medium';
        }
      }
    }

    // Additional checks for named individuals
    const hasPersonalNames = /\b[A-Z][a-z]+ [A-Z][a-z]+\b/.test(content.content);
    if (hasPersonalNames && flaggedTerms.length > 0) {
      riskLevel = 'high';
      hasLegalRisks = true;
    }

    return {
      riskLevel,
      flaggedTerms,
      hasLegalRisks,
      reasoning: `Found ${flaggedTerms.length} flagged terms: ${flaggedTerms.join(', ')}`
    };
  }

  private async sendMobileAlert(content: PendingContent): Promise<void> {
    const message = this.formatAlertMessage(content);
    
    // In production, integrate with SMS service (Twilio, AWS SNS, etc.)
    console.log('\n🚨 MOBILE ALERT SENT 🚨');
    console.log('═══════════════════════════════════════');
    console.log(`TO: ${this.userPhoneNumber}`);
    console.log(`SUBJECT: Content Approval Required`);
    console.log('MESSAGE:');
    console.log(message);
    console.log('═══════════════════════════════════════');
    
    // Simulate SMS sending
    await this.sendSMS(this.userPhoneNumber, message);
  }

  private formatAlertMessage(content: PendingContent): string {
    const riskEmoji = content.riskLevel === 'high' ? '🚨' : content.riskLevel === 'medium' ? '⚠️' : 'ℹ️';
    
    return `${riskEmoji} THEATRE SPOTLIGHT - Content Approval Required

TITLE: ${content.title}
RISK: ${content.riskLevel.toUpperCase()}
CODE: ${content.approvalCode}

${content.flaggedTerms.length > 0 ? `FLAGGED: ${content.flaggedTerms.join(', ')}` : ''}

EXCERPT: ${content.excerpt.substring(0, 100)}...

RESPOND:
Reply "${content.approvalCode} PUBLISH" to approve
Reply "${content.approvalCode} REVISION" for changes  
Reply "${content.approvalCode} REJECT" if libelous

Expires: ${content.responseDeadline.toLocaleString()}

Review: ${process.env.REPLIT_DOMAIN || 'localhost:5000'}/admin/approve/${content.id}`;
  }

  private async sendSMS(phoneNumber: string, message: string): Promise<void> {
    // Production implementation would use Twilio or similar
    try {
      // Example Twilio integration:
      /*
      const client = require('twilio')(accountSid, authToken);
      await client.messages.create({
        body: message,
        from: '+1234567890', // Your Twilio number
        to: phoneNumber
      });
      */
      
      console.log(`SMS would be sent to ${phoneNumber}`);
      console.log(`Message length: ${message.length} characters`);
      
    } catch (error) {
      console.error('Failed to send SMS:', error);
    }
  }

  async processApprovalResponse(code: string, decision: 'publish' | 'revision' | 'reject', feedback?: string): Promise<{
    success: boolean;
    message: string;
  }> {
    const contentId = this.approvalCodes.get(code.toUpperCase());
    
    if (!contentId) {
      return { success: false, message: 'Invalid approval code' };
    }

    const content = this.pendingContent.get(contentId);
    if (!content) {
      return { success: false, message: 'Content not found' };
    }

    if (content.responseDeadline < new Date()) {
      return { success: false, message: 'Approval deadline expired' };
    }

    const response: ApprovalResponse = {
      contentId,
      decision,
      feedback,
      respondedAt: new Date()
    };

    switch (decision) {
      case 'publish':
        content.status = 'approved';
        await this.publishContent(content);
        break;
      
      case 'revision':
        content.status = 'revision';
        await this.sendForRevision(content, feedback);
        break;
      
      case 'reject':
        content.status = 'rejected';
        console.log(`Content rejected: ${content.title}`);
        break;
    }

    // Clean up
    this.approvalCodes.delete(code.toUpperCase());
    
    return { 
      success: true, 
      message: `Content ${decision} successfully: ${content.title}` 
    };
  }

  private async publishContent(content: PendingContent): Promise<void> {
    const article = {
      title: content.title,
      content: content.content,
      excerpt: content.excerpt,
      category: content.category,
      region: content.region,
      isFeatured: false,
      tags: [],
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&h=400',
      source: content.source,
      approvedAt: new Date()
    };

    await storage.createArticle(article);
    console.log(`✅ Published approved content: ${content.title}`);
  }

  private async sendForRevision(content: PendingContent, feedback?: string): Promise<void> {
    // In production, would trigger AI rewrite with feedback
    console.log(`📝 Content sent for revision: ${content.title}`);
    if (feedback) {
      console.log(`Feedback: ${feedback}`);
    }
    
    // Could implement automatic AI revision here
    // Then resubmit for approval
  }

  // SMS webhook handler for responses
  async handleSMSResponse(from: string, body: string): Promise<void> {
    if (from !== this.userPhoneNumber) {
      return; // Ignore messages from unknown numbers
    }

    const parts = body.trim().toUpperCase().split(' ');
    if (parts.length < 2) {
      return;
    }

    const [code, decision] = parts;
    const feedback = parts.slice(2).join(' ');

    let mappedDecision: 'publish' | 'revision' | 'reject';
    switch (decision) {
      case 'PUBLISH':
        mappedDecision = 'publish';
        break;
      case 'REVISION':
        mappedDecision = 'revision';
        break;
      case 'REJECT':
        mappedDecision = 'reject';
        break;
      default:
        console.log(`Invalid decision: ${decision}`);
        return;
    }

    const result = await this.processApprovalResponse(code, mappedDecision, feedback);
    console.log('SMS Response processed:', result);

    // Send confirmation SMS
    const confirmationMessage = result.success 
      ? `✅ ${result.message}`
      : `❌ ${result.message}`;
    
    await this.sendSMS(this.userPhoneNumber, confirmationMessage);
  }

  // Web interface for approvals
  async getPendingContent(): Promise<PendingContent[]> {
    return Array.from(this.pendingContent.values())
      .filter(content => content.status === 'pending')
      .sort((a, b) => a.submittedAt.getTime() - b.submittedAt.getTime());
  }

  async getContentForApproval(contentId: string): Promise<PendingContent | null> {
    return this.pendingContent.get(contentId) || null;
  }

  // Cleanup expired content
  async cleanupExpiredContent(): Promise<void> {
    const now = new Date();
    for (const [id, content] of this.pendingContent) {
      if (content.responseDeadline < now && content.status === 'pending') {
        console.log(`⏰ Expired content auto-rejected: ${content.title}`);
        content.status = 'rejected';
        this.approvalCodes.delete(content.approvalCode || '');
      }
    }
  }
}

export const contentApprovalSystem = new ContentApprovalSystem();