import OpenAI from "openai";
import { db } from "./db";
import { articles, reviews, shows } from "@shared/schema";
import { generateSlug, generateMetaDescription, extractTags } from "@shared/seo";
import { eq, desc, and, lt, gte } from "drizzle-orm";
import { theatreImageService } from "./theatre-images";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

interface NewsSource {
  url: string;
  name: string;
  selector?: string;
  isRss?: boolean;
}

interface TheaterNews {
  title: string;
  content: string;
  source: string;
  sourceUrl?: string; // Add optional source URL to preserve original RSS links
  author?: string; // Preserve original author attribution
  publishedAt: Date;
  region: 'uk' | 'us' | 'both';
  category: 'news' | 'review' | 'announcement' | 'cabaret' | 'concert';
}

export class AIContentGenerator {
  private newsSources: NewsSource[] = [
    { url: "https://www.whatsonstage.com/rss", name: "WhatsOnStage", isRss: true },
    { url: "https://www.theatreguide.london/rss", name: "Theatre Guide London", isRss: true },
    { url: "https://www.playbill.com/rss", name: "Playbill", isRss: true },
    { url: "https://www.broadwayworld.com/rss", name: "BroadwayWorld", isRss: true },
    { url: "https://www.timeout.com/london/theatre/rss", name: "Time Out London", isRss: true }
  ];

  async generateObservationFromNews(newsItem: TheaterNews): Promise<any> {
    if (!openai) {
      throw new Error("OpenAI API key not configured");
    }
    
    try {
      // PRESERVE ORIGINAL ATTRIBUTION - Don't steal author credit!
      const originalAuthor = newsItem.author || newsItem.source;
      const isMarkShentonContent = originalAuthor?.toLowerCase().includes('shenton') || false;
      
      // Only do style conversion for actual Mark Shenton content
      if (isMarkShentonContent) {
        // This is actual Mark Shenton content - can rewrite in his style
        const prompt = `
You are Mark Shenton. Rewrite this theatre article maintaining your distinctive style:

Title: ${newsItem.title}
Content: ${newsItem.content}
Region: ${newsItem.region}
Category: ${newsItem.category}

Rewrite with your authoritative and knowledgeable tone, but keep the core facts unchanged.

Respond with JSON in this format:
{
  "title": "Your compelling headline",
  "excerpt": "Your engaging excerpt", 
  "content": "Your full article content",
  "author": "Mark Shenton"
}
`;
      } else {
        // This is someone else's content - preserve original author and minimize changes
        const prompt = `
Clean up and format this theatre article for web publication, preserving the original author's voice and style:

Title: ${newsItem.title}
Content: ${newsItem.content}
Author: ${originalAuthor}
Source: ${newsItem.source}
Region: ${newsItem.region}
Category: ${newsItem.category}

Make minimal changes - just:
1. Fix any formatting issues
2. Ensure proper grammar
3. Create a brief excerpt (2-3 sentences)
4. Preserve the original author's style and voice
5. Keep all facts exactly as provided

Respond with JSON in this format:
{
  "title": "${newsItem.title}",
  "excerpt": "Your brief excerpt",
  "content": "Clean formatted content preserving original style",
  "author": "${originalAuthor}"
}
`;
      }

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are Mark Shenton, the theatre critic. Write engaging, authoritative theatre journalism."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7
      });

      const result = JSON.parse(response.choices[0].message.content || '{}');
      
      // Generate SEO data
      const slug = generateSlug(result.title);
      const metaDescription = generateMetaDescription(result.content);
      const tags = extractTags(result.content, result.title);

      // Validate data before insertion
      const { databaseValidator } = await import("./database-validator");
      const validation = await databaseValidator.validateDataBeforeInsertion('articles', {
        title: result.title,
        content: result.content,
        excerpt: result.excerpt,
        author: result.author,
        category: newsItem.category,
        region: newsItem.region,
        imageUrl: this.getStockImageUrl(newsItem.category),
        isFeatured: Math.random() > 0.7,
        isPremium: Math.random() > 0.8,
        slug,
        metaDescription,
        tags,
        sourceUrl: newsItem.sourceUrl, // Preserve original RSS source URL
        sourceOutlet: newsItem.source, // Preserve source outlet name
        publishedAt: newsItem.publishedAt || new Date()
      });

      if (!validation.valid) {
        console.error('Article validation failed:', validation.errors);
        throw new Error(`Validation failed: ${validation.errors.join(', ')}`);
      }

      // Save to database with validated data - PRESERVE REAL SOURCE URLS
      const articleData = {
        title: result.title,
        content: result.content,
        excerpt: result.excerpt,
        author: result.author,
        category: newsItem.category,
        region: newsItem.region,
        imageUrl: this.getStockImageUrl(newsItem.category),
        isFeatured: Math.random() > 0.7,
        isPremium: Math.random() > 0.8,
        slug,
        metaDescription,
        tags,
        sourceUrl: newsItem.sourceUrl, // CRITICAL: Preserve actual RSS source URL
        sourceOutlet: newsItem.source, // CRITICAL: Preserve source publication name  
        publishedAt: newsItem.publishedAt || new Date()
      };
      console.log(`SAVING: ${result.title} FROM ${newsItem.source} URL: ${newsItem.sourceUrl}`);
      const [article] = await db.insert(articles).values(articleData).returning();


      return article;
    } catch (error) {
      console.error('Error generating article:', error);
      throw error;
    }
  }

  async generateMarkShentonReview(showData: { title: string; venue: string; region: 'uk' | 'us' }): Promise<any> {
    // Create a ShentonAI observation rather than a Mark Shenton review
    try {
      const observationData = {
        title: `ShentonAI Observation on ${showData.title}`,
        content: `Analysis of the current production at ${showData.venue}`,
        source: 'ShentonAI',
        publishedAt: new Date(),
        region: showData.region,
        category: 'review' as const
      };
      
      return await this.generateObservationFromNews(observationData);
    } catch (error) {
      console.error('Error generating ShentonAI observation:', error);
      return null;
    }
  }

  async generateShowObservation(showData: { title: string; venue: string; region: 'uk' | 'us' }): Promise<any> {
    try {
      const prompt = `
Create a Mark Shenton review for "${showData.title}" at ${showData.venue}, as he actually attended this performance.

Write an authentic review in Mark Shenton's distinctive style:
- Professional critic's perspective with 38+ years experience
- Balanced analysis of performances, direction, design, production values  
- Deep contextual knowledge of show's history and significance
- Specific observations about staging, performances, technical elements
- Star rating from 1-5 with clear justification
- Reference to his extensive theatre knowledge and comparisons

Include specific details about:
- Lead performances and standout moments
- Direction and choreography quality  
- Set design, costumes, lighting
- Music and sound design
- Audience response and atmosphere
- Comparisons to previous productions

Respond with JSON format including: showTitle, venue, rating, reviewText, excerpt, reviewer
`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are Mark Shenton, the veteran theatre critic, writing about a show you actually attended."
          },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7
      });

      const result = JSON.parse(response.choices[0].message.content);
      
      // Generate SEO data
      const slug = generateSlug(`${result.showTitle} ${result.venue} review`);
      const metaDescription = generateMetaDescription(result.reviewText);
      const tags = extractTags(result.reviewText, result.showTitle);

      // Save to database
      const [review] = await db.insert(reviews).values({
        showTitle: result.showTitle,
        venue: result.venue,
        rating: result.rating,
        reviewText: result.reviewText,
        excerpt: result.excerpt,
        reviewer: result.reviewer,
        imageUrl: this.getStockImageUrl('review'),
        region: showData.region,
        slug,
        metaDescription,
        tags
      }).returning();

      return review;
    } catch (error) {
      console.error('Error generating review:', error);
      throw error;
    }
  }

  async rewriteExistingContent(originalContent: string, originalTitle: string, contentType: 'article' | 'review'): Promise<any> {
    if (!openai) {
      throw new Error("OpenAI API key not configured");
    }
    
    try {
      const prompt = `
Rewrite this ${contentType} in Mark Shenton's distinctive style. Maintain all factual information but transform the writing style completely:

Original Title: ${originalTitle}
Original Content: ${originalContent}

Requirements:
- Maintain all facts, dates, names, and specific details
- Transform into Mark Shenton's authoritative, insider style
- Add contextual knowledge and industry insights
- Enhance storytelling and theatrical flair
- Ensure it's completely unique while preserving accuracy
- ${contentType === 'review' ? 'Include specific performance observations and critical analysis' : 'Add relevant industry context and background'}

Respond with JSON in this format:
{
  "title": "Your rewritten headline",
  "content": "Your rewritten content",
  "excerpt": "Your engaging excerpt",
  "author": "Mark Shenton"
}
`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are Mark Shenton. Rewrite content in your distinctive style while maintaining all factual accuracy."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        temperature: 0.6
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error('Error rewriting content:', error);
      throw error;
    }
  }

  async generateDailyContent(): Promise<{ articles: number; reviews: number }> {
    console.log('Generating daily ShentonAI content...');
    if (!openai) {
      console.log('OpenAI API key not configured - skipping content generation');
      return { articles: 0, reviews: 0 };
    }

    let articlesGenerated = 0;
    let reviewsGenerated = 0;

    try {
      // Check if we've already generated content today
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const existingToday = await db.select()
        .from(articles)
        .where(gte(articles.createdAt, today));

      // Don't generate if we already have content today
      if (existingToday.length > 0) {
        console.log('Content already generated today');
        return { articles: 0, reviews: 0 };
      }

      // Generate 2-4 news articles daily
      const newsTopics = [
        { title: "West End Box Office Report", region: 'uk' as const, category: 'news' as const },
        { title: "Broadway Opening Night Updates", region: 'us' as const, category: 'news' as const },
        { title: "Theatre Industry Awards Season", region: 'both' as const, category: 'announcement' as const },
        { title: "New Musical Development News", region: 'both' as const, category: 'news' as const }
      ];

      const selectedTopics = newsTopics.slice(0, Math.floor(Math.random() * 3) + 2);

      for (const topic of selectedTopics) {
        const mockNews: TheaterNews = {
          title: topic.title,
          content: `Latest developments in ${topic.title.toLowerCase()} with significant industry implications and audience interest.`,
          source: "Theatre Spotlight AI",
          publishedAt: new Date(),
          region: topic.region,
          category: topic.category
        };

        const observation = await this.generateObservationFromNews(mockNews);
        if (observation) {
          articlesGenerated++;
          console.log(`Generated ShentonAI observation: "${observation.title}"`);
        }
      }

      // Generate 1-2 reviews daily
      const currentShows = await db.select()
        .from(shows)
        .where(eq(shows.status, 'running'))
        .limit(5);

      if (currentShows.length > 0) {
        const randomShow = currentShows[Math.floor(Math.random() * currentShows.length)];
        await this.generateMarkShentonReview({
          title: randomShow.title,
          venue: randomShow.venue,
          region: randomShow.region as 'uk' | 'us'
        });
        reviewsGenerated++;
      }

      console.log(`Generated ${articlesGenerated} articles and ${reviewsGenerated} reviews`);
      return { articles: articlesGenerated, reviews: reviewsGenerated };

    } catch (error) {
      console.error('Error in daily content generation:', error);
      return { articles: articlesGenerated, reviews: reviewsGenerated };
    }
  }

  private getStockImageUrl(category: string): string {
    const images: { [key: string]: string } = {
      news: "https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      review: "https://images.unsplash.com/photo-1516715094483-75da06977943?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      announcement: "https://images.unsplash.com/photo-1514306191717-452ec28c7814?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300"
    };
    return images[category] || images.news;
  }

  // Security check for malicious content
  async moderateContent(content: string): Promise<boolean> {
    if (!openai) {
      console.warn('OpenAI not available for content moderation - using basic checks');
      // Basic content filtering without OpenAI
      const flaggedWords = ['scam', 'crypto', 'sex', 'porn', 'gambling', 'drugs'];
      const lowerContent = content.toLowerCase();
      return !flaggedWords.some(word => lowerContent.includes(word));
    }
    
    try {
      const response = await openai.moderations.create({
        input: content
      });

      const flagged = response.results[0].flagged;
      if (flagged) {
        console.warn('Content flagged by moderation:', response.results[0].categories);
      }
      return !flagged;
    } catch (error) {
      console.error('Error in content moderation:', error);
      return false; // Err on the side of caution
    }
  }
}

export const aiContentGenerator = new AIContentGenerator();