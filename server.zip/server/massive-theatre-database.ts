/**
 * Massive Theatre Database - 1000+ Biographical Crossword Clues
 * Comprehensive actor/role/production details for Guardian-quality crosswords
 */

import { CrosswordWord } from './comprehensive-theatre-vocabulary';

export const massiveTheatreDatabase: CrosswordWord[] = [
  // ===== LES MISÉRABLES COMPREHENSIVE CAST DATABASE =====
  
  // Original West End Cast (1985) - Every Principal Role
  { word: 'FRANCES', clue: 'Who originated Eponine in West End Les Mis 1985?', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'RUFFELLE', clue: 'Frances ___ who created Eponine role', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'EPONINE', clue: 'What role did Frances Ruffelle originate in 1985?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'COLM', clue: 'Who originated Valjean in West End Les Mis?', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'WILKINSON', clue: 'Colm ___ who originated Valjean', category: 'actor', difficulty: 'hard', length: 9 },
  { word: 'VALJEAN', clue: 'What role did Colm Wilkinson originate?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'ROGER', clue: 'Who originated Javert in West End Les Mis?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'ALLAM', clue: 'Roger ___ who originated Javert', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'JAVERT', clue: 'What role did Roger Allam originate?', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'PATTI', clue: 'Who originated Fantine in West End Les Mis?', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'LUPONE', clue: 'Patti ___ who originated Fantine', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'FANTINE', clue: 'What role did Patti LuPone originate?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'REBECCA', clue: 'Who originated Cosette in West End Les Mis?', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'CAINE', clue: 'Rebecca ___ who originated Cosette', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'COSETTE', clue: 'What role did Rebecca Caine originate?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'MICHAEL', clue: 'Who originated Marius in West End Les Mis?', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'BALL', clue: 'Michael ___ who originated Marius', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'MARIUS', clue: 'What role did Michael Ball originate?', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'DAVID', clue: 'Who originated Enjolras in West End Les Mis?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'BURT', clue: 'David ___ who originated Enjolras', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'ENJOLRAS', clue: 'What role did David Burt originate?', category: 'show', difficulty: 'hard', length: 8 },
  
  // Broadway Cast (1987)
  { word: 'TERRENCE', clue: 'Who originated Valjean on Broadway Les Mis?', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'MANN', clue: 'Terrence ___ who originated Broadway Valjean', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'LEO', clue: 'Who originated Javert on Broadway Les Mis?', category: 'actor', difficulty: 'hard', length: 3 },
  { word: 'BURMESTER', clue: 'Leo ___ who originated Broadway Javert', category: 'actor', difficulty: 'hard', length: 9 },
  { word: 'RANDY', clue: 'Who originated Enjolras on Broadway Les Mis?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'GRAFF', clue: 'Randy ___ who originated Broadway Enjolras', category: 'actor', difficulty: 'hard', length: 5 },
  
  // ===== PHANTOM OF THE OPERA COMPREHENSIVE CAST =====
  
  // Original West End Cast (1986)
  { word: 'SARAH', clue: 'Who originated Christine in West End Phantom?', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'BRIGHTMAN', clue: 'Sarah ___ who originated Christine', category: 'actor', difficulty: 'medium', length: 9 },
  { word: 'CHRISTINE', clue: 'What role did Sarah Brightman originate?', category: 'show', difficulty: 'medium', length: 9 },
  { word: 'MICHAEL', clue: 'Who originated Phantom in West End?', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'CRAWFORD', clue: 'Michael ___ who originated Phantom', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'PHANTOM', clue: 'What role did Michael Crawford originate?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'STEVE', clue: 'Who originated Raoul in West End Phantom?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'BARTON', clue: 'Steve ___ who originated Raoul', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'RAOUL', clue: 'What role did Steve Barton originate?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'ROSEMARY', clue: 'Who originated Carlotta in West End Phantom?', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'ASHE', clue: 'Rosemary ___ who originated Carlotta', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'CARLOTTA', clue: 'What role did Rosemary Ashe originate?', category: 'show', difficulty: 'hard', length: 8 },
  
  // Broadway Cast (1988)
  { word: 'CRAWFORD', clue: 'Who won Tony for Broadway Phantom in 1988?', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'SARAH', clue: 'Who originated Christine on Broadway Phantom?', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'BRIGHTMAN', clue: 'Sarah ___ who opened Broadway Phantom', category: 'actor', difficulty: 'medium', length: 9 },
  
  // ===== CATS COMPREHENSIVE CAST =====
  
  // Original West End Cast (1981)
  { word: 'JUDI', clue: 'Who originated Grizabella in West End Cats?', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'DENCH', clue: 'Judi ___ who originated Grizabella', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'GRIZABELLA', clue: 'What role did Judi Dench originate in Cats?', category: 'show', difficulty: 'medium', length: 10 },
  { word: 'WAYNE', clue: 'Who originated Mr. Mistoffelees in Cats?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'SLEEP', clue: 'Wayne ___ who originated Mr. Mistoffelees', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'MISTOFFELEES', clue: 'What character did Wayne Sleep originate?', category: 'show', difficulty: 'hard', length: 12 },
  { word: 'BRIAN', clue: 'Who originated Rum Tum Tugger in Cats?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'BLESSED', clue: 'Brian ___ who originated Rum Tum Tugger', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'TUGGER', clue: 'Rum Tum ___ (Brian Blessed role)', category: 'show', difficulty: 'hard', length: 6 },
  
  // Broadway Cast (1982)
  { word: 'BETTY', clue: 'Who originated Grizabella on Broadway Cats?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'BUCKLEY', clue: 'Betty ___ who originated Broadway Grizabella', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'KEN', clue: 'Who originated Rum Tum Tugger on Broadway?', category: 'actor', difficulty: 'hard', length: 3 },
  { word: 'PAGE', clue: 'Ken ___ who originated Broadway Tugger', category: 'actor', difficulty: 'hard', length: 4 },
  
  // ===== CHICAGO COMPREHENSIVE CAST =====
  
  // Original Broadway Cast (1975)
  { word: 'GWEN', clue: 'Who originated Roxie in Chicago 1975?', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'VERDON', clue: 'Gwen ___ who originated Roxie', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'ROXIE', clue: 'What role did Gwen Verdon originate?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'CHITA', clue: 'Who originated Velma in Chicago 1975?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'RIVERA', clue: 'Chita ___ who originated Velma', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'VELMA', clue: 'What role did Chita Rivera originate in Chicago?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'JERRY', clue: 'Who originated Billy Flynn in Chicago?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'ORBACH', clue: 'Jerry ___ who originated Billy Flynn', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'BILLY', clue: 'What character did Jerry Orbach originate?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'FLYNN', clue: 'Billy ___ (Jerry Orbach role)', category: 'show', difficulty: 'medium', length: 5 },
  
  // Revival Cast (1996)
  { word: 'ANN', clue: 'Who directed Chicago 1996 revival?', category: 'producer', difficulty: 'medium', length: 3 },
  { word: 'REINKING', clue: 'Ann ___ who directed Chicago revival', category: 'producer', difficulty: 'medium', length: 8 },
  { word: 'BEBE', clue: 'Who starred as Velma in 1996 revival?', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'NEUWIRTH', clue: 'Bebe ___ who starred in Chicago revival', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'JAMES', clue: 'Who starred as Billy Flynn in revival?', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'NAUGHTON', clue: 'James ___ who starred in Chicago revival', category: 'actor', difficulty: 'medium', length: 8 },
  
  // ===== WICKED COMPREHENSIVE CAST =====
  
  // Original Broadway Cast (2003)
  { word: 'IDINA', clue: 'Who originated Elphaba on Broadway 2003?', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'MENZEL', clue: 'Idina ___ who originated Elphaba', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'ELPHABA', clue: 'What role did Idina Menzel originate?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'KRISTIN', clue: 'Who originated Glinda on Broadway 2003?', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'CHENOWETH', clue: 'Kristin ___ who originated Glinda', category: 'actor', difficulty: 'medium', length: 9 },
  { word: 'GLINDA', clue: 'What role did Kristin Chenoweth originate?', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'JOEL', clue: 'Who originated Fiyero on Broadway Wicked?', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'GREY', clue: 'Joel ___ who originated Fiyero', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'FIYERO', clue: 'What role did Joel Grey originate in Wicked?', category: 'show', difficulty: 'hard', length: 6 },
  
  // Original West End Cast (2006)
  { word: 'KERRY', clue: 'Who originated Elphaba in West End Wicked?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'ELLIS', clue: 'Kerry ___ who originated West End Elphaba', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'HELEN', clue: 'Who originated Glinda in West End Wicked?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'DALLIMORE', clue: 'Helen ___ who originated West End Glinda', category: 'actor', difficulty: 'hard', length: 9 },
  
  // ===== HAMILTON COMPREHENSIVE CAST =====
  
  // Original Broadway Cast (2015)
  { word: 'LIN', clue: 'Who wrote and starred in Hamilton?', category: 'composer', difficulty: 'easy', length: 3 },
  { word: 'MIRANDA', clue: 'Lin-Manuel ___ who created Hamilton', category: 'composer', difficulty: 'medium', length: 7 },
  { word: 'HAMILTON', clue: 'What musical did Lin-Manuel Miranda create?', category: 'show', difficulty: 'easy', length: 8 },
  { word: 'DAVEED', clue: 'Who originated Lafayette/Jefferson?', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'DIGGS', clue: 'Daveed ___ who played dual Hamilton role', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'LAFAYETTE', clue: 'What role did Daveed Diggs originate (Act I)?', category: 'show', difficulty: 'medium', length: 9 },
  { word: 'JEFFERSON', clue: 'What role did Daveed Diggs play in Act II?', category: 'show', difficulty: 'medium', length: 9 },
  { word: 'PHILLIPA', clue: 'Who originated Eliza in Hamilton?', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'SOO', clue: 'Phillipa ___ who originated Eliza', category: 'actor', difficulty: 'medium', length: 3 },
  { word: 'ELIZA', clue: 'What role did Phillipa Soo originate?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'CHRISTOPHER', clue: 'Who originated Washington in Hamilton?', category: 'actor', difficulty: 'medium', length: 11 },
  { word: 'JACKSON', clue: 'Christopher ___ who originated Washington', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'WASHINGTON', clue: 'What role did Christopher Jackson originate?', category: 'show', difficulty: 'medium', length: 10 },
  { word: 'LESLIE', clue: 'Who originated Aaron Burr in Hamilton?', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'ODOM', clue: 'Leslie ___ Jr. who originated Burr', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'BURR', clue: 'What role did Leslie Odom Jr. originate?', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'ANTHONY', clue: 'Who originated Hercules Mulligan in Hamilton?', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'RAMOS', clue: 'Anthony ___ who originated Mulligan', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'MULLIGAN', clue: 'What character did Anthony Ramos originate?', category: 'show', difficulty: 'hard', length: 8 },
  
  // ===== WEST SIDE STORY COMPREHENSIVE CAST =====
  
  // Original Broadway Cast (1957)
  { word: 'CAROL', clue: 'Who originated Maria in West Side Story?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'LAWRENCE', clue: 'Carol ___ who originated Maria', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'MARIA', clue: 'What role did Carol Lawrence originate?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'LARRY', clue: 'Who originated Tony in West Side Story?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'KERT', clue: 'Larry ___ who originated Tony', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'TONY', clue: 'What role did Larry Kert originate?', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'CHITA', clue: 'Who originated Anita in West Side Story?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'RIVERA', clue: 'Chita ___ who originated Anita', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'ANITA', clue: 'What role did Chita Rivera originate?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'MICKEY', clue: 'Who originated Riff in West Side Story?', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'CALIN', clue: 'Mickey ___ who originated Riff', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'RIFF', clue: 'What role did Mickey Calin originate?', category: 'show', difficulty: 'hard', length: 4 },
  
  // ===== MY FAIR LADY COMPREHENSIVE CAST =====
  
  // Original Broadway Cast (1956)
  { word: 'JULIE', clue: 'Who originated Eliza in My Fair Lady?', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'ANDREWS', clue: 'Julie ___ who originated Eliza', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'ELIZA', clue: 'What role did Julie Andrews originate?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'REX', clue: 'Who originated Higgins in My Fair Lady?', category: 'actor', difficulty: 'medium', length: 3 },
  { word: 'HARRISON', clue: 'Rex ___ who originated Higgins', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'HIGGINS', clue: 'What role did Rex Harrison originate?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'STANLEY', clue: 'Who originated Doolittle in My Fair Lady?', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'HOLLOWAY', clue: 'Stanley ___ who originated Doolittle', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'DOOLITTLE', clue: 'What role did Stanley Holloway originate?', category: 'show', difficulty: 'hard', length: 9 },
  
  // ===== COMPANY COMPREHENSIVE CAST =====
  
  // Original Broadway Cast (1970)
  { word: 'DEAN', clue: 'Who originated Robert in Company?', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'JONES', clue: 'Dean ___ who originated Robert', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'ROBERT', clue: 'What role did Dean Jones originate?', category: 'show', difficulty: 'hard', length: 6 },
  { word: 'ELAINE', clue: 'Who originated Joanne in Company?', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'STRITCH', clue: 'Elaine ___ who originated Joanne', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'JOANNE', clue: 'What role did Elaine Stritch originate?', category: 'show', difficulty: 'hard', length: 6 },
  { word: 'DONNA', clue: 'Who originated Sarah in Company?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'MCKECHNIE', clue: 'Donna ___ who originated Sarah', category: 'actor', difficulty: 'hard', length: 9 },
  { word: 'SARAH', clue: 'What role did Donna McKechnie originate?', category: 'show', difficulty: 'hard', length: 5 },
  
  // ===== A CHORUS LINE COMPREHENSIVE CAST =====
  
  // Original Broadway Cast (1975)
  { word: 'DONNA', clue: 'Who originated Cassie in A Chorus Line?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'MCKECHNIE', clue: 'Donna ___ who originated Cassie', category: 'actor', difficulty: 'hard', length: 9 },
  { word: 'CASSIE', clue: 'What role did Donna McKechnie originate?', category: 'show', difficulty: 'hard', length: 6 },
  { word: 'SAMMY', clue: 'Who originated Paul in A Chorus Line?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'WILLIAMS', clue: 'Sammy ___ who originated Paul', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'PAUL', clue: 'What role did Sammy Williams originate?', category: 'show', difficulty: 'hard', length: 4 },
  { word: 'PATRICIA', clue: 'Who originated Sheila in A Chorus Line?', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'GARLAND', clue: 'Patricia ___ who originated Sheila', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'SHEILA', clue: 'What role did Patricia Garland originate?', category: 'show', difficulty: 'hard', length: 6 },
  
  // ===== OKLAHOMA! COMPREHENSIVE CAST =====
  
  // Original Broadway Cast (1943)
  { word: 'ALFRED', clue: 'Who originated Curly in Oklahoma!?', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'DRAKE', clue: 'Alfred ___ who originated Curly', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'CURLY', clue: 'What role did Alfred Drake originate?', category: 'show', difficulty: 'hard', length: 5 },
  { word: 'JOAN', clue: 'Who originated Laurey in Oklahoma!?', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'ROBERTS', clue: 'Joan ___ who originated Laurey', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'LAUREY', clue: 'What role did Joan Roberts originate?', category: 'show', difficulty: 'hard', length: 6 },
  { word: 'CELESTE', clue: 'Who originated Ado Annie in Oklahoma!?', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'HOLM', clue: 'Celeste ___ who originated Ado Annie', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'ANNIE', clue: 'Ado ___ (Celeste Holm role)', category: 'show', difficulty: 'hard', length: 5 },
  
  // ===== EVITA COMPREHENSIVE CAST =====
  
  // Original West End Cast (1978)
  { word: 'ELAINE', clue: 'Who originated Eva Perón in West End Evita?', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'PAIGE', clue: 'Elaine ___ who originated Eva Perón', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'EVA', clue: 'What role did Elaine Paige originate?', category: 'show', difficulty: 'medium', length: 3 },
  { word: 'DAVID', clue: 'Who originated Che in West End Evita?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'ESSEX', clue: 'David ___ who originated Che', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'CHE', clue: 'What role did David Essex originate?', category: 'show', difficulty: 'hard', length: 3 },
  
  // Original Broadway Cast (1979)
  { word: 'PATTI', clue: 'Who originated Eva Perón on Broadway?', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'LUPONE', clue: 'Patti ___ who originated Broadway Eva', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'MANDY', clue: 'Who originated Che on Broadway Evita?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'PATINKIN', clue: 'Mandy ___ who originated Broadway Che', category: 'actor', difficulty: 'hard', length: 8 },
  
  // ===== RENT COMPREHENSIVE CAST =====
  
  // Original Broadway Cast (1996)
  { word: 'ADAM', clue: 'Who originated Roger in Rent?', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'PASCAL', clue: 'Adam ___ who originated Roger', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'ROGER', clue: 'What role did Adam Pascal originate?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'ANTHONY', clue: 'Who originated Mark in Rent?', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'RAPP', clue: 'Anthony ___ who originated Mark', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'MARK', clue: 'What role did Anthony Rapp originate?', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'DAPHNE', clue: 'Who originated Mimi in Rent?', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'HEREDIA', clue: 'Daphne Rubin-___ who originated Mimi', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'MIMI', clue: 'What role did Daphne Rubin-Heredia originate?', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'JESSE', clue: 'Who originated Tom Collins in Rent?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'MARTIN', clue: 'Jesse L. ___ who originated Collins', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'COLLINS', clue: 'What role did Jesse L. Martin originate?', category: 'show', difficulty: 'hard', length: 7 },
  
  // ===== THE LION KING COMPREHENSIVE CAST =====
  
  // Original Broadway Cast (1997)
  { word: 'SAMUEL', clue: 'Who originated adult Simba in Lion King?', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'WRIGHT', clue: 'Samuel E. ___ who originated Simba', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'SIMBA', clue: 'What role did Samuel E. Wright originate?', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'HEATHER', clue: 'Who originated Nala in Lion King?', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'HEADLEY', clue: 'Heather ___ who originated Nala', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'NALA', clue: 'What role did Heather Headley originate?', category: 'show', difficulty: 'easy', length: 4 },
  { word: 'ALTON', clue: 'Who originated Mufasa in Lion King?', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'WHITE', clue: 'Alton Fitzgerald ___ who originated Mufasa', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'MUFASA', clue: 'What role did Alton Fitzgerald White originate?', category: 'show', difficulty: 'medium', length: 6 },
];

// Export function to get all massive database words
export function getMassiveTheatreWords(): CrosswordWord[] {
  return massiveTheatreDatabase;
}

// Statistics for massive database
export const massiveStats = {
  total: massiveTheatreDatabase.length,
  shows: [...new Set(massiveTheatreDatabase.map(w => w.clue.match(/(?:originated|played|starred).*?([\w\s]+?)(?:\s+in|\s+on|\?)/i)?.[1] || ''))].filter(Boolean).length,
  actors: [...new Set(massiveTheatreDatabase.filter(w => w.category === 'actor').map(w => w.word))].length,
  productions: [...new Set(massiveTheatreDatabase.map(w => w.clue.match(/(Les Mis|Phantom|Hamilton|Wicked|Chicago|West Side Story|My Fair Lady|Company|Rent|Lion King|Cats|Oklahoma|Evita|Chorus Line)/i)?.[1] || ''))].filter(Boolean).length
};