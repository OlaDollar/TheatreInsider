/**
 * Major West End Theatres with Current Shows
 * Real data from major London theatre venues
 */

export const westEndTheatres = [
  {
    name: "Lyceum Theatre",
    currentShow: "The Lion King",
    capacity: 2100,
    address: "21 Wellington Street, London WC2E 7RQ",
    yearBuilt: 1765
  },
  {
    name: "Her Majesty's Theatre",
    currentShow: "The Phantom of the Opera",
    capacity: 1216,
    address: "Haymarket, London SW1Y 4QL",
    yearBuilt: 1897
  },
  {
    name: "Apollo Victoria Theatre",
    currentShow: "Wicked",
    capacity: 2304,
    address: "17 Wilton Road, London SW1V 1LG",
    yearBuilt: 1930
  },
  {
    name: "Victoria Palace Theatre",
    currentShow: "Hamilton",
    capacity: 1550,
    address: "Victoria Street, London SW1E 5EA",
    yearBuilt: 1911
  },
  {
    name: "Phoenix Theatre",
    currentShow: "Chicago",
    capacity: 1012,
    address: "110 Charing Cross Road, London WC2H 0JP",
    yearBuilt: 1930
  },
  {
    name: "Prince of Wales Theatre",
    currentShow: "The Book of Mormon",
    capacity: 1160,
    address: "Coventry Street, London W1D 6AS",
    yearBuilt: 1884
  },
  {
    name: "Palace Theatre",
    currentShow: "Harry Potter and the Cursed Child",
    capacity: 1400,
    address: "113 Shaftesbury Avenue, London W1D 5AY",
    yearBuilt: 1891
  },
  {
    name: "Gielgud Theatre",
    currentShow: "Dear England",
    capacity: 986,
    address: "35 Shaftesbury Avenue, London W1D 6AR",
    yearBuilt: 1906
  },
  {
    name: "Piccadilly Theatre",
    currentShow: "Moulin Rouge! The Musical",
    capacity: 1232,
    address: "16 Denman Street, London W1D 7DY",
    yearBuilt: 1928
  },
  {
    name: "Cambridge Theatre",
    currentShow: "Matilda The Musical",
    capacity: 1232,
    address: "Earlham Street, London WC2H 9HU",
    yearBuilt: 1930
  }
];

export function getWestEndTheatreCount(): number {
  return westEndTheatres.length;
}

export function getWestEndShows(): string[] {
  return westEndTheatres.map(theatre => theatre.currentShow);
}