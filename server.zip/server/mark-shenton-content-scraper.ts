import * as cheerio from "cheerio";
import { aiContentGenerator } from "./ai-content";
import { db } from "./db";
import { articles } from "@shared/schema";
import { eq } from "drizzle-orm";

interface MarkShentonArticle {
  title: string;
  content: string;
  url: string;
  author: string;
  publishedDate: string;
  source: string;
  region: 'uk' | 'us' | 'both';
  category: 'news' | 'review' | 'announcement';
}

export class MarkShentonContentScraper {
  private processedCount = 0;
  private shentonAICreated = 0;
  private duplicatesSkipped = 0;
  private existingTitles = new Set<string>();

  async scrapeAllMarkShentonContent(): Promise<{ 
    processed: number; 
    shentonAICreated: number; 
    duplicatesSkipped: number 
  }> {
    console.log('🎭 Starting comprehensive Mark Shenton content scraping from all sources...');
    
    // Load existing article titles to prevent duplicates
    await this.loadExistingTitles();
    
    const sources = [
      { name: 'TheStage', scraper: this.scrapeTheStage.bind(this) },
      { name: 'Playbill', scraper: this.scrapePlaybill.bind(this) },
      { name: 'WhatsOnStage', scraper: this.scrapeWhatsOnStage.bind(this) },
      { name: 'Express', scraper: this.scrapeExpress.bind(this) },
      { name: 'PlaysInternational', scraper: this.scraplePlaysInternational.bind(this) }
    ];

    for (const source of sources) {
      try {
        console.log(`Scraping Mark Shenton content from ${source.name}...`);
        await source.scraper();
        
        // Delay between sources
        await new Promise(resolve => setTimeout(resolve, 3000));
      } catch (error) {
        console.error(`Error scraping ${source.name}:`, error);
      }
    }

    console.log(`Scraping complete: ${this.processedCount} articles processed, ${this.shentonAICreated} ShentonAI observations created, ${this.duplicatesSkipped} duplicates skipped`);
    
    return {
      processed: this.processedCount,
      shentonAICreated: this.shentonAICreated,
      duplicatesSkipped: this.duplicatesSkipped
    };
  }

  private async loadExistingTitles(): Promise<void> {
    try {
      const existingArticles = await db.select({ title: articles.title }).from(articles);
      this.existingTitles = new Set(existingArticles.map(a => a.title.toLowerCase().trim()));
      console.log(`Loaded ${this.existingTitles.size} existing article titles for duplicate detection`);
    } catch (error) {
      console.error('Error loading existing titles:', error);
    }
  }

  private async scrapeTheStage(): Promise<void> {
    const baseUrl = 'https://www.thestage.co.uk';
    
    // Search for Mark Shenton articles with multiple approaches
    const searchUrls = [
      '/search?q=mark+shenton',
      '/search?q="mark+shenton"',
      '/author/mark-shenton',
      '/contributors/mark-shenton',
      '/news?author=mark-shenton',
      '/reviews?author=mark-shenton'
    ];

    for (const searchPath of searchUrls) {
      try {
        const articles = await this.scrapeSourcePages(`${baseUrl}${searchPath}`, 'TheStage');
        await this.processArticles(articles);
      } catch (error) {
        console.error(`Error scraping TheStage ${searchPath}:`, error);
      }
    }
  }

  private async scrapePlaybill(): Promise<void> {
    const baseUrl = 'https://www.playbill.com';
    
    // Mark Shenton has extensive coverage on Playbill
    const searchUrls = [
      '/person/mark-shenton',
      '/search?q=mark+shenton',
      '/search?q="mark+shenton"',
      '/author/mark-shenton',
      '/news?q=mark+shenton',
      '/article/search?q=mark+shenton'
    ];

    for (const searchPath of searchUrls) {
      try {
        const articles = await this.scrapeSourcePages(`${baseUrl}${searchPath}`, 'Playbill');
        await this.processArticles(articles);
      } catch (error) {
        console.error(`Error scraping Playbill ${searchPath}:`, error);
      }
    }
  }

  private async scrapeWhatsOnStage(): Promise<void> {
    const baseUrl = 'https://www.whatsonstage.com';
    
    // WhatsOnStage may have unattributed content - search comprehensively
    const searchUrls = [
      '/search?q=mark+shenton',
      '/search?q="mark+shenton"',
      '/author/mark-shenton',
      '/london-theatre/news',
      '/west-end/news',
      '/broadway/news',
      '/reviews',
      '/features'
    ];

    for (const searchPath of searchUrls) {
      try {
        const articles = await this.scrapeSourcePages(`${baseUrl}${searchPath}`, 'WhatsOnStage');
        
        // For WhatsOnStage, also check writing style for unattributed articles
        const filteredArticles = await this.filterByWritingStyle(articles);
        await this.processArticles(filteredArticles);
      } catch (error) {
        console.error(`Error scraping WhatsOnStage ${searchPath}:`, error);
      }
    }
  }

  private async scrapeExpress(): Promise<void> {
    const baseUrl = 'https://www.express.co.uk';
    
    // Express.co.uk entertainment and theatre coverage
    const searchUrls = [
      '/search?q=mark+shenton',
      '/search?q="mark+shenton"',
      '/entertainment/theatre',
      '/entertainment/music',
      '/author/mark-shenton',
      '/life-style/entertainment',
      '/showbiz/theatre'
    ];

    for (const searchPath of searchUrls) {
      try {
        const articles = await this.scrapeSourcePages(`${baseUrl}${searchPath}`, 'Express');
        await this.processArticles(articles);
      } catch (error) {
        console.error(`Error scraping Express ${searchPath}:`, error);
      }
    }
  }

  private async scraplePlaysInternational(): Promise<void> {
    const baseUrl = 'https://playsinternational.org.uk';
    
    const searchUrls = [
      '/search?q=mark+shenton',
      '/contributors',
      '/news',
      '/reviews'
    ];

    for (const searchPath of searchUrls) {
      try {
        const articles = await this.scrapeSourcePages(`${baseUrl}${searchPath}`, 'PlaysInternational');
        await this.processArticles(articles);
      } catch (error) {
        console.error(`Error scraping PlaysInternational ${searchPath}:`, error);
      }
    }
  }

  private async scrapeSourcePages(url: string, sourceName: string): Promise<MarkShentonArticle[]> {
    const articles: MarkShentonArticle[] = [];
    
    try {
      // Scrape multiple pages
      for (let page = 1; page <= 10; page++) {
        const pageUrl = page === 1 ? url : `${url}?page=${page}`;
        
        const response = await fetch(pageUrl, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (compatible; Theatre Spotlight Bot)',
            'Accept': 'text/html,application/xhtml+xml'
          }
        });

        if (!response.ok) {
          if (page === 1) {
            console.log(`${sourceName}: Trying alternative URL structure for ${url}`);
            // Try alternative URL patterns
            const altUrls = this.getAlternativeUrls(url, sourceName);
            for (const altUrl of altUrls) {
              try {
                const altResponse = await fetch(altUrl, {
                  headers: {
                    'User-Agent': 'Mozilla/5.0 (compatible; Theatre Spotlight Bot)',
                    'Accept': 'text/html,application/xhtml+xml'
                  }
                });
                if (altResponse.ok) {
                  const altHtml = await altResponse.text();
                  const altArticles = await this.extractMarkShentonArticles(altHtml, sourceName, altUrl);
                  if (altArticles.length > 0) {
                    console.log(`${sourceName}: Found content at alternative URL ${altUrl}`);
                    return altArticles;
                  }
                }
              } catch (error) {
                // Continue to next alternative
              }
            }
          }
          break;
        }

        const html = await response.text();
        const pageArticles = await this.extractMarkShentonArticles(html, sourceName, url);
        
        if (pageArticles.length === 0) break;
        
        articles.push(...pageArticles);
        console.log(`Found ${pageArticles.length} potential Mark Shenton articles on ${sourceName} page ${page}`);
        
        // Rate limiting
        await new Promise(resolve => setTimeout(resolve, 1500));
      }
    } catch (error) {
      console.error(`Error scraping ${sourceName} at ${url}:`, error);
    }
    
    return articles;
  }

  private async extractMarkShentonArticles(html: string, sourceName: string, baseUrl: string): Promise<MarkShentonArticle[]> {
    const articles: MarkShentonArticle[] = [];
    
    try {
      const $ = cheerio.load(html);
      
      // Multiple selectors for different site structures
      const articleSelectors = [
        'article',
        '.article',
        '.post',
        '.news-item',
        '.review-item',
        '.content-item',
        '.story'
      ];

      articleSelectors.forEach(selector => {
        $(selector).each((index, element) => {
          const $article = $(element);
          
          const title = this.extractTitle($article);
          const content = this.extractContent($article);
          const author = this.extractAuthor($article);
          const url = this.extractUrl($article, baseUrl);
          const publishedDate = this.extractDate($article);
          
          // Check if this is a Mark Shenton article
          if (this.isMarkShentonArticle(title, content, author)) {
            articles.push({
              title,
              content: content.substring(0, 3000), // Limit content length
              url,
              author: 'Mark Shenton',
              publishedDate,
              source: sourceName,
              region: this.determineRegion(content),
              category: this.determineCategory(title, content)
            });
          }
        });
      });
      
    } catch (error) {
      console.error(`Error extracting articles from ${sourceName}:`, error);
    }
    
    return articles;
  }

  private extractTitle($article: cheerio.Cheerio<cheerio.Element>): string {
    const titleSelectors = ['h1', 'h2', 'h3', '.title', '.headline', '.entry-title', '.article-title'];
    
    for (const selector of titleSelectors) {
      const title = $article.find(selector).first().text().trim();
      if (title && title.length > 10) return title;
    }
    
    return '';
  }

  private extractContent($article: cheerio.Cheerio<cheerio.Element>): string {
    const contentSelectors = ['.content', '.body', '.article-body', '.entry-content', '.text', 'p'];
    
    let bestContent = '';
    for (const selector of contentSelectors) {
      const content = $article.find(selector).text().trim();
      if (content.length > bestContent.length) {
        bestContent = content;
      }
    }
    
    return bestContent;
  }

  private extractAuthor($article: cheerio.Cheerio<cheerio.Element>): string {
    const authorSelectors = ['.author', '.byline', '.writer', '.by', '.article-author'];
    
    for (const selector of authorSelectors) {
      const author = $article.find(selector).text().trim();
      if (author) return author;
    }
    
    return '';
  }

  private extractUrl($article: cheerio.Cheerio<cheerio.Element>, baseUrl: string): string {
    const link = $article.find('a').first().attr('href') || '';
    return link.startsWith('http') ? link : `${baseUrl}${link}`;
  }

  private extractDate($article: cheerio.Cheerio<cheerio.Element>): string {
    const dateSelectors = ['.date', 'time', '.published', '.post-date'];
    
    for (const selector of dateSelectors) {
      const date = $article.find(selector).attr('datetime') || $article.find(selector).text().trim();
      if (date) return date;
    }
    
    return new Date().toISOString();
  }

  private isMarkShentonArticle(title: string, content: string, author: string): boolean {
    // Direct author attribution (various formats)
    const authorLower = author.toLowerCase();
    if (authorLower.includes('mark shenton') || 
        authorLower.includes('m. shenton') || 
        authorLower.includes('shenton')) {
      return true;
    }
    
    // Check if content mentions Mark Shenton as the writer
    const contentLower = content.toLowerCase();
    if (contentLower.includes('by mark shenton') || 
        contentLower.includes('mark shenton writes') ||
        contentLower.includes('mark shenton reports')) {
      return true;
    }
    
    // Style-based detection for unattributed articles
    return this.matchesMarkShentonStyle(title, content);
  }

  private matchesMarkShentonStyle(title: string, content: string): boolean {
    const combinedText = `${title} ${content}`.toLowerCase();
    
    // Mark Shenton's distinctive phrases and professional theatre terminology
    const shentonMarkers = [
      'west end', 'broadway', 'theatre review', 'stage adaptation', 'musical theatre',
      'olivier award', 'tony award', 'london theatre', 'theatre critic', 'stage production',
      'theatrical', 'performance', 'cast recording', 'opening night', 'theatre world',
      'curtain up', 'box office', 'theatre district', 'rehearsal', 'preview',
      'gala night', 'star-studded', 'acclaimed', 'dazzling', 'electrifying',
      'transformative', 'brilliant', 'spectacular', 'outstanding', 'captivating',
      'luminous', 'powerful', 'moving', 'triumphant', 'exceptional'
    ];
    
    // Advanced style detection for unattributed content
    const markerCount = shentonMarkers.filter(marker => combinedText.includes(marker)).length;
    const hasTheatreDepth = content.length > 300 && combinedText.includes('theatre');
    const hasReviewLanguage = /review|stars|rating|performance|cast|production/i.test(combinedText);
    const hasIndustryTerms = /curtain|stage|audience|applause|ovation|intermission/i.test(combinedText);
    
    return markerCount >= 2 && hasTheatreDepth && (hasReviewLanguage || hasIndustryTerms);
  }

  private async filterByWritingStyle(articles: MarkShentonArticle[]): Promise<MarkShentonArticle[]> {
    // For sources like WhatsOnStage where attribution might be missing
    return articles.filter(article => 
      article.author.toLowerCase().includes('mark shenton') || 
      this.matchesMarkShentonStyle(article.title, article.content)
    );
  }

  private determineRegion(content: string): 'uk' | 'us' | 'both' {
    const lowerContent = content.toLowerCase();
    
    const ukTerms = ['west end', 'london', 'uk', 'britain', 'british', 'olivier', 'national theatre'];
    const usTerms = ['broadway', 'new york', 'tony', 'off-broadway', 'manhattan'];
    
    const ukCount = ukTerms.filter(term => lowerContent.includes(term)).length;
    const usCount = usTerms.filter(term => lowerContent.includes(term)).length;
    
    if (ukCount > usCount) return 'uk';
    if (usCount > ukCount) return 'us';
    return 'both';
  }

  private determineCategory(title: string, content: string): 'news' | 'review' | 'announcement' {
    const combinedText = `${title} ${content}`.toLowerCase();
    
    if (combinedText.includes('review') || combinedText.includes('★') || combinedText.includes('star')) {
      return 'review';
    }
    
    if (combinedText.includes('announces') || combinedText.includes('casting') || combinedText.includes('opening')) {
      return 'announcement';
    }
    
    return 'news';
  }

  private async processArticles(articles: MarkShentonArticle[]): Promise<void> {
    for (const article of articles) {
      try {
        // Check for duplicates
        const titleKey = article.title.toLowerCase().trim();
        if (this.existingTitles.has(titleKey)) {
          this.duplicatesSkipped++;
          continue;
        }
        
        // Add to existing titles to prevent future duplicates
        this.existingTitles.add(titleKey);
        
        // Process through ShentonAI to create observation
        await aiContentGenerator.generateObservationFromNews({
          title: article.title,
          content: article.content,
          source: article.source,
          publishedAt: new Date(),
          region: article.region,
          category: article.category
        });
        
        this.processedCount++;
        this.shentonAICreated++;
        
        console.log(`✓ Created ShentonAI observation from ${article.source}: "${article.title}"`);
        
        // Rate limiting to avoid overwhelming servers
        await new Promise(resolve => setTimeout(resolve, 800));
        
      } catch (error) {
        console.error(`Error processing article "${article.title}":`, error);
      }
    }
  }
}

  private getAlternativeUrls(originalUrl: string, sourceName: string): string[] {
    const alternatives: string[] = [];
    
    switch (sourceName) {
      case 'TheStage':
        alternatives.push(
          'https://www.thestage.co.uk/news',
          'https://www.thestage.co.uk/reviews',
          'https://www.thestage.co.uk/opinion',
          'https://www.thestage.co.uk/features'
        );
        break;
        
      case 'Playbill':
        alternatives.push(
          'https://www.playbill.com/news',
          'https://www.playbill.com/article',
          'https://www.playbill.com/theatre-news',
          'https://www.playbill.com/broadway'
        );
        break;
        
      case 'WhatsOnStage':
        alternatives.push(
          'https://www.whatsonstage.com/london-theatre/news',
          'https://www.whatsonstage.com/west-end/news',
          'https://www.whatsonstage.com/reviews',
          'https://www.whatsonstage.com/features'
        );
        break;
        
      case 'Express':
        alternatives.push(
          'https://www.express.co.uk/entertainment/theatre',
          'https://www.express.co.uk/entertainment/music',
          'https://www.express.co.uk/showbiz',
          'https://www.express.co.uk/life-style/entertainment'
        );
        break;
        
      case 'PlaysInternational':
        alternatives.push(
          'https://playsinternational.org.uk/news',
          'https://playsinternational.org.uk/reviews',
          'https://playsinternational.org.uk/features',
          'https://playsinternational.org.uk/articles'
        );
        break;
    }
    
    return alternatives;
  }
}

export const markShentonContentScraper = new MarkShentonContentScraper();