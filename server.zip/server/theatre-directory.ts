import { db } from "./db";
import { eq, like, and } from "drizzle-orm";

interface Theatre {
  id: number;
  name: string;
  address: string;
  city: string;
  region: 'uk' | 'us';
  state_province: string;
  postcode: string;
  country: string;
  venue_type: 'west_end' | 'off_west_end' | 'broadway' | 'off_broadway' | 'national' | 'regional' | 'touring';
  capacity: number;
  opened_year: number;
  architect?: string;
  description: string;
  history: string;
  
  // Images
  exterior_image: string;
  interior_image: string;
  auditorium_image?: string;
  foyer_image?: string;
  
  // Current shows
  current_shows: Array<{
    title: string;
    dates: string;
    ticket_url: string;
  }>;
  
  // Amenities
  amenities: {
    accessibility: {
      wheelchair_access: boolean;
      hearing_loop: boolean;
      audio_description: boolean;
      sign_language: boolean;
      accessible_toilets: boolean;
    };
    facilities: {
      bar: boolean;
      restaurant: boolean;
      gift_shop: boolean;
      cloakroom: boolean;
      parking: boolean;
      air_conditioning: boolean;
    };
    seating: {
      stalls: number;
      dress_circle?: number;
      upper_circle?: number;
      balcony?: number;
      boxes?: number;
      total_capacity: number;
    };
  };
  
  // Practical info
  contact: {
    phone: string;
    email: string;
    website: string;
    box_office_hours: string;
  };
  
  transport: {
    nearest_tube?: string;
    nearest_subway?: string;
    bus_routes: string[];
    parking_info: string;
    walking_directions: string;
  };
  
  // Location coordinates
  coordinates: {
    latitude: number;
    longitude: number;
  };
  
  // Meta
  last_updated: Date;
  featured: boolean;
  rating: number;
  review_count: number;
}

interface TheatreFilters {
  region?: 'uk' | 'us' | 'both';
  venue_type?: string[];
  capacity_range?: { min?: number; max?: number };
  amenities?: string[];
  search_term?: string;
  city?: string;
  state_province?: string;
}

export class TheatreDirectory {
  
  private sampleTheatres: Theatre[] = [
    // UK Theatres
    {
      id: 1,
      name: "Lyceum Theatre",
      address: "21 Wellington Street",
      city: "London",
      region: "uk",
      state_province: "England",
      postcode: "WC2E 7RQ",
      country: "United Kingdom",
      venue_type: "west_end",
      capacity: 2100,
      opened_year: 1834,
      architect: "Samuel Beazley",
      description: "Historic West End theatre in Covent Garden, home to Disney's The Lion King since 1999. Known for its stunning Victorian architecture and state-of-the-art technical capabilities.",
      history: "Originally built in 1834, the Lyceum has a rich theatrical history including performances by Henry Irving and Ellen Terry. Reconstructed in 1904 and extensively renovated in the 1990s for The Lion King.",
      exterior_image: "https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      interior_image: "https://images.unsplash.com/photo-1489549132488-d00b7eee80f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      auditorium_image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      current_shows: [
        {
          title: "The Lion King",
          dates: "Open run",
          ticket_url: "https://lionking.co.uk"
        }
      ],
      amenities: {
        accessibility: {
          wheelchair_access: true,
          hearing_loop: true,
          audio_description: true,
          sign_language: true,
          accessible_toilets: true
        },
        facilities: {
          bar: true,
          restaurant: false,
          gift_shop: true,
          cloakroom: true,
          parking: false,
          air_conditioning: true
        },
        seating: {
          stalls: 1096,
          dress_circle: 394,
          upper_circle: 610,
          total_capacity: 2100
        }
      },
      contact: {
        phone: "0207 492 0810",
        email: "info@lyceum-theatre.co.uk",
        website: "https://lyceum-theatre.co.uk",
        box_office_hours: "Monday-Saturday 10am-8pm, Sunday 12pm-6pm"
      },
      transport: {
        nearest_tube: "Covent Garden (Piccadilly line)",
        bus_routes: ["1", "4", "26", "59", "68", "76", "168", "188"],
        parking_info: "No dedicated parking. Nearest: NCP Covent Garden (5 min walk)",
        walking_directions: "Exit Covent Garden station, head east on Long Acre, turn left onto Wellington Street"
      },
      coordinates: {
        latitude: 51.5120,
        longitude: -0.1200
      },
      last_updated: new Date(),
      featured: true,
      rating: 4.7,
      review_count: 2847
    },
    
    {
      id: 2,
      name: "Gielgud Theatre",
      address: "35 Shaftesbury Avenue",
      city: "London",
      region: "uk",
      state_province: "England",
      postcode: "W1D 6AR",
      country: "United Kingdom",
      venue_type: "west_end",
      capacity: 986,
      opened_year: 1906,
      architect: "W.G.R. Sprague",
      description: "Intimate West End theatre known for prestigious productions and star-studded casts. Named after Sir John Gielgud in 1994.",
      history: "Opened as the Hicks Theatre in 1906, renamed Globe Theatre in 1909, and finally Gielgud Theatre in 1994 to honor the legendary actor.",
      exterior_image: "https://images.unsplash.com/photo-1514306191717-452ec28c7814?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      interior_image: "https://images.unsplash.com/photo-1503095396549-807759245b35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      current_shows: [
        {
          title: "Various Productions",
          dates: "Check website",
          ticket_url: "https://delfont-mackintosh.com"
        }
      ],
      amenities: {
        accessibility: {
          wheelchair_access: true,
          hearing_loop: true,
          audio_description: true,
          sign_language: false,
          accessible_toilets: true
        },
        facilities: {
          bar: true,
          restaurant: false,
          gift_shop: false,
          cloakroom: true,
          parking: false,
          air_conditioning: false
        },
        seating: {
          stalls: 483,
          dress_circle: 284,
          upper_circle: 219,
          total_capacity: 986
        }
      },
      contact: {
        phone: "0207 494 5065",
        email: "info@gielgudtheatre.co.uk", 
        website: "https://gielgudtheatre.co.uk",
        box_office_hours: "Monday-Saturday 10am-8pm"
      },
      transport: {
        nearest_tube: "Piccadilly Circus (Piccadilly/Bakerloo lines)",
        bus_routes: ["14", "19", "38"],
        parking_info: "No dedicated parking. Nearest: Q-Park Chinatown",
        walking_directions: "5 minute walk from Piccadilly Circus via Shaftesbury Avenue"
      },
      coordinates: {
        latitude: 51.5118,
        longitude: -0.1319
      },
      last_updated: new Date(),
      featured: false,
      rating: 4.5,
      review_count: 1534
    },

    // US Theatres
    {
      id: 3,
      name: "Richard Rodgers Theatre",
      address: "226 West 46th Street",
      city: "New York",
      region: "us", 
      state_province: "New York",
      postcode: "10036",
      country: "United States",
      venue_type: "broadway",
      capacity: 1319,
      opened_year: 1924,
      architect: "Herbert J. Krapp",
      description: "Historic Broadway theatre, current home to Hamilton. Known for its excellent acoustics and intimate atmosphere despite its size.",
      history: "Originally opened as the 46th Street Theatre, renamed in 1990 to honor composer Richard Rodgers. Previous long-running shows include How to Succeed in Business and Crazy for You.",
      exterior_image: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      interior_image: "https://images.unsplash.com/photo-1514306191717-452ec28c7814?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      auditorium_image: "https://images.unsplash.com/photo-1503095396549-807759245b35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
      current_shows: [
        {
          title: "Hamilton",
          dates: "Open run",
          ticket_url: "https://hamiltonmusical.com"
        }
      ],
      amenities: {
        accessibility: {
          wheelchair_access: true,
          hearing_loop: true,
          audio_description: true,
          sign_language: true,
          accessible_toilets: true
        },
        facilities: {
          bar: true,
          restaurant: false,
          gift_shop: true,
          cloakroom: true,
          parking: false,
          air_conditioning: true
        },
        seating: {
          stalls: 725,
          dress_circle: 594,
          total_capacity: 1319
        }
      },
      contact: {
        phone: "(212) 307-4100",
        email: "info@richardrodgerstheatre.com",
        website: "https://richardrodgerstheatre.com",
        box_office_hours: "Monday-Saturday 10am-8pm, Sunday 12pm-6pm"
      },
      transport: {
        nearest_subway: "Times Sq-42 St (N,Q,R,W,S,1,2,3,7)",
        bus_routes: ["M7", "M20", "M42", "M104"],
        parking_info: "Times Square Tower Parking (3 blocks), Icon Parking (2 blocks)",
        walking_directions: "4 blocks north from Times Square subway station"
      },
      coordinates: {
        latitude: 40.7589,
        longitude: -73.9851
      },
      last_updated: new Date(),
      featured: true,
      rating: 4.8,
      review_count: 4521
    }
  ];

  async getTheatres(filters: TheatreFilters = {}): Promise<{
    uk: Theatre[];
    us: Theatre[];
    total: number;
    featured: Theatre[];
    lastUpdated: Date;
  }> {
    console.log('🎭 Fetching theatre directory...');
    
    let filteredTheatres = [...this.sampleTheatres];
    
    // Apply filters
    if (filters.region && filters.region !== 'both') {
      filteredTheatres = filteredTheatres.filter(t => t.region === filters.region);
    }
    
    if (filters.venue_type && filters.venue_type.length > 0) {
      filteredTheatres = filteredTheatres.filter(t => 
        filters.venue_type!.includes(t.venue_type)
      );
    }
    
    if (filters.capacity_range) {
      if (filters.capacity_range.min) {
        filteredTheatres = filteredTheatres.filter(t => t.capacity >= filters.capacity_range!.min!);
      }
      if (filters.capacity_range.max) {
        filteredTheatres = filteredTheatres.filter(t => t.capacity <= filters.capacity_range!.max!);
      }
    }
    
    if (filters.search_term) {
      const term = filters.search_term.toLowerCase();
      filteredTheatres = filteredTheatres.filter(t => 
        t.name.toLowerCase().includes(term) ||
        t.city.toLowerCase().includes(term) ||
        t.description.toLowerCase().includes(term)
      );
    }
    
    if (filters.city) {
      filteredTheatres = filteredTheatres.filter(t => 
        t.city.toLowerCase() === filters.city!.toLowerCase()
      );
    }
    
    // Separate by region
    const ukTheatres = filteredTheatres.filter(t => t.region === 'uk');
    const usTheatres = filteredTheatres.filter(t => t.region === 'us');
    const featured = filteredTheatres.filter(t => t.featured);
    
    return {
      uk: ukTheatres,
      us: usTheatres,
      total: filteredTheatres.length,
      featured,
      lastUpdated: new Date()
    };
  }

  async getTheatreById(id: number): Promise<Theatre | null> {
    return this.sampleTheatres.find(t => t.id === id) || null;
  }

  async getTheatresByCity(city: string, region: 'uk' | 'us'): Promise<Theatre[]> {
    return this.sampleTheatres.filter(t => 
      t.city.toLowerCase() === city.toLowerCase() && t.region === region
    );
  }

  async searchTheatres(searchTerm: string): Promise<Theatre[]> {
    const term = searchTerm.toLowerCase();
    return this.sampleTheatres.filter(t => 
      t.name.toLowerCase().includes(term) ||
      t.city.toLowerCase().includes(term) ||
      t.current_shows.some(show => show.title.toLowerCase().includes(term))
    );
  }

  getVenueTypeOptions(region: 'uk' | 'us'): Array<{ value: string; label: string }> {
    if (region === 'uk') {
      return [
        { value: 'west_end', label: 'West End' },
        { value: 'off_west_end', label: 'Off-West End' },
        { value: 'national', label: 'National Theatres' },
        { value: 'regional', label: 'Regional Theatres' },
        { value: 'touring', label: 'Touring Venues' }
      ];
    } else {
      return [
        { value: 'broadway', label: 'Broadway' },
        { value: 'off_broadway', label: 'Off-Broadway' },
        { value: 'regional', label: 'Regional Theatres' },
        { value: 'touring', label: 'Touring Venues' }
      ];
    }
  }

  getCityOptions(region: 'uk' | 'us'): Array<{ value: string; label: string }> {
    if (region === 'uk') {
      return [
        { value: 'london', label: 'London' },
        { value: 'manchester', label: 'Manchester' },
        { value: 'birmingham', label: 'Birmingham' },
        { value: 'bristol', label: 'Bristol' },
        { value: 'edinburgh', label: 'Edinburgh' },
        { value: 'glasgow', label: 'Glasgow' }
      ];
    } else {
      return [
        { value: 'new york', label: 'New York' },
        { value: 'chicago', label: 'Chicago' },
        { value: 'los angeles', label: 'Los Angeles' },
        { value: 'boston', label: 'Boston' },
        { value: 'philadelphia', label: 'Philadelphia' },
        { value: 'washington', label: 'Washington DC' }
      ];
    }
  }
}

export const theatreDirectory = new TheatreDirectory();