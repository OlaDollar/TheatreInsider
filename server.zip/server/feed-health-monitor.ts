import cron from "node-cron";
import { contentAggregator } from "./content-aggregator";

interface FeedHealth {
  url: string;
  name: string;
  status: 'healthy' | 'warning' | 'failed';
  lastSuccessful: Date | null;
  lastChecked: Date;
  errorCount: number;
  errorMessages: string[];
  responseTime?: number;
}

interface HealthReport {
  timestamp: Date;
  totalFeeds: number;
  healthyFeeds: number;
  failedFeeds: number;
  warnings: number;
  details: FeedHealth[];
  overallStatus: 'healthy' | 'degraded' | 'critical';
}

export class FeedHealthMonitor {
  private feedHealth: Map<string, FeedHealth> = new Map();
  private healthHistory: HealthReport[] = [];
  
  private feeds = [
    { url: 'https://www.playbill.com/rss/news', name: 'Playbill News' },
    { url: 'https://www.broadwayworld.com/rss/news.xml', name: 'BroadwayWorld' },
    { url: 'https://www.broadwayworld.com/uk/rss/news.xml', name: 'BroadwayWorld UK' },
    { url: 'https://www.americantheatre.org/feed/', name: 'American Theatre' },
    { url: 'https://theatreweekly.com/feed/', name: 'Theatre Weekly' },
    // Alternative feeds for failed sources
    { url: 'https://variety.com/c/film/news/feed/', name: 'Variety Entertainment' },
    { url: 'https://deadline.com/category/news/feed/', name: 'Deadline News' }
  ];

  constructor() {
    this.initializeFeeds();
    this.startMonitoring();
  }

  private initializeFeeds(): void {
    this.feeds.forEach(feed => {
      this.feedHealth.set(feed.url, {
        url: feed.url,
        name: feed.name,
        status: 'healthy',
        lastSuccessful: null,
        lastChecked: new Date(),
        errorCount: 0,
        errorMessages: []
      });
    });
  }

  private startMonitoring(): void {
    // Check feed health every hour
    cron.schedule('0 * * * *', async () => {
      console.log('🔍 Running hourly feed health check...');
      await this.performHealthCheck();
    });

    // Daily comprehensive report at 7:00 AM GMT
    cron.schedule('0 7 * * *', async () => {
      console.log('📊 Generating daily health report...');
      await this.generateDailyReport();
    });

    // Weekly cleanup of old health data
    cron.schedule('0 0 * * 0', () => {
      this.cleanupOldHealthData();
    });
  }

  async performHealthCheck(): Promise<HealthReport> {
    console.log('⚡ Performing comprehensive feed health check...');
    
    const healthPromises = this.feeds.map(feed => this.checkFeedHealth(feed));
    const results = await Promise.allSettled(healthPromises);
    
    const healthDetails: FeedHealth[] = [];
    let healthyCount = 0;
    let failedCount = 0;
    let warningCount = 0;

    results.forEach((result, index) => {
      const feed = this.feeds[index];
      const health = this.feedHealth.get(feed.url)!;
      
      if (result.status === 'fulfilled') {
        const checkResult = result.value;
        Object.assign(health, checkResult);
        this.feedHealth.set(feed.url, health);
      } else {
        // Mark as failed if health check itself failed
        health.status = 'failed';
        health.errorCount++;
        health.errorMessages.push(`Health check failed: ${result.reason}`);
        health.lastChecked = new Date();
      }

      healthDetails.push({ ...health });
      
      switch (health.status) {
        case 'healthy': healthyCount++; break;
        case 'warning': warningCount++; break;
        case 'failed': failedCount++; break;
      }
    });

    const report: HealthReport = {
      timestamp: new Date(),
      totalFeeds: this.feeds.length,
      healthyFeeds: healthyCount,
      failedFeeds: failedCount,
      warnings: warningCount,
      details: healthDetails,
      overallStatus: this.determineOverallStatus(healthyCount, warningCount, failedCount)
    };

    this.healthHistory.push(report);
    await this.handleUnhealthyFeeds(report);
    
    return report;
  }

  private async checkFeedHealth(feed: { url: string; name: string }): Promise<Partial<FeedHealth>> {
    const startTime = Date.now();
    
    try {
      const response = await fetch(feed.url, {
        method: 'HEAD',
        headers: {
          'User-Agent': 'Theatre-Spotlight-Health-Monitor/1.0',
          'Accept': 'application/rss+xml, application/xml, text/xml'
        },
        signal: AbortSignal.timeout(10000) // 10 second timeout
      });

      const responseTime = Date.now() - startTime;
      
      if (response.ok) {
        return {
          status: 'healthy',
          lastSuccessful: new Date(),
          lastChecked: new Date(),
          errorCount: 0,
          errorMessages: [],
          responseTime
        };
      } else {
        return {
          status: 'warning',
          lastChecked: new Date(),
          errorCount: 1,
          errorMessages: [`HTTP ${response.status}: ${response.statusText}`],
          responseTime
        };
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      // Determine if this is a temporary or permanent failure
      const isTemporary = errorMessage.includes('timeout') || 
                         errorMessage.includes('ENOTFOUND') ||
                         errorMessage.includes('ECONNREFUSED');
      
      return {
        status: isTemporary ? 'warning' : 'failed',
        lastChecked: new Date(),
        errorCount: 1,
        errorMessages: [errorMessage],
        responseTime: Date.now() - startTime
      };
    }
  }

  private determineOverallStatus(healthy: number, warning: number, failed: number): HealthReport['overallStatus'] {
    const total = healthy + warning + failed;
    const healthyPercentage = (healthy / total) * 100;
    
    if (healthyPercentage >= 80) return 'healthy';
    if (healthyPercentage >= 50) return 'degraded';
    return 'critical';
  }

  private async handleUnhealthyFeeds(report: HealthReport): Promise<void> {
    const failedFeeds = report.details.filter(feed => feed.status === 'failed');
    
    if (failedFeeds.length > 0) {
      console.log(`⚠️ ${failedFeeds.length} feeds are failing:`);
      failedFeeds.forEach(feed => {
        console.log(`  - ${feed.name}: ${feed.errorMessages.join(', ')}`);
      });
      
      // Attempt to use alternative sources
      await this.activateBackupSources(failedFeeds);
    }

    if (report.overallStatus === 'critical') {
      console.log('🚨 CRITICAL: Feed health is severely degraded');
      await this.triggerEmergencyFallback();
    }
  }

  private async activateBackupSources(failedFeeds: FeedHealth[]): Promise<void> {
    console.log('🔄 Activating backup content sources...');
    
    // Use working feeds more frequently
    const healthyFeeds = Array.from(this.feedHealth.values())
      .filter(feed => feed.status === 'healthy');
    
    if (healthyFeeds.length > 0) {
      console.log(`✅ Increasing frequency for ${healthyFeeds.length} healthy feeds`);
      // Trigger additional content aggregation from healthy sources
      try {
        await contentAggregator.processAndPublishContent();
      } catch (error) {
        console.error('Failed to process backup content:', error);
      }
    }
  }

  private async triggerEmergencyFallback(): Promise<void> {
    console.log('🆘 Triggering emergency content fallback...');
    
    // Generate more AI content to compensate for failed feeds
    try {
      const { aiContentGenerator } = await import('./ai-content');
      await aiContentGenerator.generateDailyContent();
      console.log('✅ Emergency AI content generation completed');
    } catch (error) {
      console.error('Emergency fallback failed:', error);
    }
  }

  private async generateDailyReport(): Promise<void> {
    const latest = this.healthHistory[this.healthHistory.length - 1];
    if (!latest) return;

    const report = {
      date: new Date().toISOString().split('T')[0],
      summary: {
        overallStatus: latest.overallStatus,
        healthyFeeds: latest.healthyFeeds,
        totalFeeds: latest.totalFeeds,
        uptime: ((latest.healthyFeeds / latest.totalFeeds) * 100).toFixed(1) + '%'
      },
      issues: latest.details
        .filter(feed => feed.status !== 'healthy')
        .map(feed => ({
          name: feed.name,
          status: feed.status,
          lastError: feed.errorMessages[feed.errorMessages.length - 1] || 'Unknown',
          daysSinceSuccess: feed.lastSuccessful 
            ? Math.floor((Date.now() - feed.lastSuccessful.getTime()) / (1000 * 60 * 60 * 24))
            : null
        })),
      recommendations: this.generateRecommendations(latest)
    };

    console.log('📊 Daily Feed Health Report:');
    console.log(JSON.stringify(report, null, 2));
  }

  private generateRecommendations(report: HealthReport): string[] {
    const recommendations: string[] = [];
    
    if (report.overallStatus === 'critical') {
      recommendations.push('Immediately investigate failed feeds and consider alternative sources');
    }
    
    const staleFeeeds = report.details.filter(feed => 
      feed.lastSuccessful && 
      (Date.now() - feed.lastSuccessful.getTime()) > (48 * 60 * 60 * 1000) // 48 hours
    );
    
    if (staleFeeeds.length > 0) {
      recommendations.push(`${staleFeeeds.length} feeds haven't been successful in 48+ hours`);
    }
    
    const slowFeeds = report.details.filter(feed => 
      feed.responseTime && feed.responseTime > 5000
    );
    
    if (slowFeeds.length > 0) {
      recommendations.push(`${slowFeeds.length} feeds are responding slowly (>5s)`);
    }
    
    if (recommendations.length === 0) {
      recommendations.push('All feeds are operating normally');
    }
    
    return recommendations;
  }

  private cleanupOldHealthData(): void {
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    this.healthHistory = this.healthHistory.filter(report => report.timestamp > oneWeekAgo);
    
    console.log(`🧹 Cleaned up health history, kept ${this.healthHistory.length} recent reports`);
  }

  // Public API methods
  getCurrentHealth(): HealthReport | null {
    return this.healthHistory[this.healthHistory.length - 1] || null;
  }

  getFeedStatus(url: string): FeedHealth | null {
    return this.feedHealth.get(url) || null;
  }

  async forceHealthCheck(): Promise<HealthReport> {
    console.log('🔧 Manual health check triggered...');
    return this.performHealthCheck();
  }
}

export const feedHealthMonitor = new FeedHealthMonitor();