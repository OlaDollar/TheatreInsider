/**
 * Crossword Statistics and Word Count
 * Provides accurate count of all available crossword clues
 */

import { vocabularyStats } from './comprehensive-theatre-vocabulary';
import { massiveStats } from './massive-theatre-database';
import { legendsStats } from './broadway-legends-database';
import { generateMillionTheatreWords } from './million-word-generator';

export function getCrosswordStats() {
  console.log('Calculating total crossword vocabulary...');
  
  const millionWords = generateMillionTheatreWords();
  
  const stats = {
    comprehensive: vocabularyStats.total,
    massive: massiveStats.total,
    legends: legendsStats.total,
    generated: millionWords.length,
    total: vocabularyStats.total + massiveStats.total + legendsStats.total + millionWords.length
  };
  
  console.log(`📊 CROSSWORD VOCABULARY STATISTICS:`);
  console.log(`   Comprehensive Theatre DB: ${stats.comprehensive.toLocaleString()} words`);
  console.log(`   Massive Biographical DB: ${stats.massive.toLocaleString()} words`);
  console.log(`   Broadway Legends DB: ${stats.legends.toLocaleString()} words`);
  console.log(`   Million-Word Generator: ${stats.generated.toLocaleString()} words`);
  console.log(`   TOTAL AVAILABLE: ${stats.total.toLocaleString()} crossword clues`);
  
  return stats;
}

export function getWordBreakdown() {
  const millionWords = generateMillionTheatreWords();
  
  const breakdown = {
    byDifficulty: {
      easy: 0,
      medium: 0,
      hard: 0,
      expert: 0
    },
    byCategory: {
      actor: 0,
      show: 0,
      venue: 0,
      composer: 0,
      lyricist: 0,
      producer: 0,
      terminology: 0
    }
  };
  
  // Count from all sources
  millionWords.forEach(word => {
    breakdown.byDifficulty[word.difficulty]++;
    breakdown.byCategory[word.category]++;
  });
  
  return breakdown;
}