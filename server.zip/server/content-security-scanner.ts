import { db } from "./db";
import { articles, reviews } from "../shared/schema";
import { gte } from "drizzle-orm";
import fs from "fs/promises";
import path from "path";

interface SecurityThreat {
  severity: 'critical' | 'high' | 'medium' | 'low';
  type: 'code_injection' | 'malicious_link' | 'content_manipulation' | 'xss_attempt' | 'sql_injection' | 'suspicious_content';
  description: string;
  location: string;
  content: string;
  recommendation: string;
  detectedAt: Date;
}

interface SecurityScanResult {
  clean: boolean;
  threatsFound: SecurityThreat[];
  summary: {
    critical: number;
    high: number;
    medium: number;
    low: number;
  };
  lastScan: Date;
  contentScanned: number;
}

export class ContentSecurityScanner {
  private maliciousPatterns = {
    // Code injection patterns
    codeInjection: [
      /<script[^>]*>.*?<\/script>/gis,
      /javascript:/gi,
      /vbscript:/gi,
      /onload\s*=/gi,
      /onclick\s*=/gi,
      /onerror\s*=/gi,
      /onmouseover\s*=/gi,
      /eval\s*\(/gi,
      /document\.write/gi,
      /innerHTML\s*=.*<script/gi,
      /src\s*=\s*["']javascript:/gi
    ],
    
    // SQL injection patterns
    sqlInjection: [
      /(\bUNION\b.*\bSELECT\b)/gi,
      /(\bDROP\b.*\bTABLE\b)/gi,
      /(\bINSERT\b.*\bINTO\b.*\bVALUES\b)/gi,
      /(\bDELETE\b.*\bFROM\b)/gi,
      /(\bUPDATE\b.*\bSET\b)/gi,
      /('.*OR.*'.*=.*')/gi,
      /(--\s)/gi,
      /(\bEXEC\b|\bEXECUTE\b)/gi
    ],
    
    // XSS patterns
    xssAttempts: [
      /<iframe[^>]*src\s*=/gi,
      /<embed[^>]*>/gi,
      /<object[^>]*>/gi,
      /<applet[^>]*>/gi,
      /<meta[^>]*http-equiv/gi,
      /data:\s*text\/html/gi,
      /<img[^>]*src\s*=\s*["']javascript:/gi,
      /<svg[^>]*onload/gi
    ]
  };

  private suspiciousLinks = {
    // Gambling domains
    gambling: [
      'bet365.com', 'pokerstars.com', 'williamhill.com', 'paddy-power.com',
      'betfair.com', 'coral.co.uk', 'ladbrokes.com', 'skybet.com',
      'unibet.com', 'bwin.com', 'casino.com', 'betway.com',
      'gambling', 'poker', 'casino', 'slots', 'betting'
    ],
    
    // Adult content domains
    adult: [
      'pornhub.com', 'xvideos.com', 'xhamster.com', 'redtube.com',
      'tube8.com', 'youporn.com', 'porn.com', 'sex.com',
      'xxx', 'adult', 'porn', 'sex', 'nude', 'webcam'
    ],
    
    // Suspicious domains
    suspicious: [
      'bit.ly', 'tinyurl.com', 'goo.gl', 't.co', 'ow.ly',
      'adf.ly', 'bc.vc', 'tiny.cc', 'rebrand.ly',
      'clickbank', 'commission', 'affiliate'
    ],
    
    // Malware/phishing domains
    malware: [
      'dropbox.com/s/', 'docs.google.com/document/d/',
      'drive.google.com/file/d/', 'mega.nz',
      'mediafire.com', 'sendspace.com', '4shared.com'
    ]
  };

  private contentIntegrityPatterns = [
    // Cryptocurrency/investment scams
    /(?:bitcoin|crypto|investment|trading).*(?:profit|guarantee|return)/gi,
    /(?:make|earn).*(?:\$|\£|\€)[0-9,]+.*(?:day|week|month)/gi,
    /(?:click here|limited time|act now|urgent|expires)/gi,
    
    // Pharmaceutical spam
    /(?:viagra|cialis|pharmacy|prescription|pills).*(?:cheap|discount|online)/gi,
    
    // Fake reviews/testimonials
    /(?:i made|i earned|changed my life|miracle|amazing results)/gi,
    
    // Political manipulation
    /(?:vote|election|candidate).*(?:must|should|don't)/gi
  ];

  async runDailySecurityScan(): Promise<SecurityScanResult> {
    console.log('Starting daily content security scan...');
    
    const threats: SecurityThreat[] = [];
    
    try {
      // Scan recent content (last 24 hours)
      const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      
      const recentArticles = await db
        .select()
        .from(articles)
        .where(gte(articles.createdAt, oneDayAgo));
      
      const recentReviews = await db
        .select()
        .from(reviews)
        .where(gte(reviews.createdAt, oneDayAgo));
      
      let contentScanned = 0;
      
      // Scan articles
      for (const article of recentArticles) {
        const articleThreats = await this.scanContent(article, 'article');
        threats.push(...articleThreats);
        contentScanned++;
      }
      
      // Scan reviews
      for (const review of recentReviews) {
        const reviewThreats = await this.scanContent(review, 'review');
        threats.push(...reviewThreats);
        contentScanned++;
      }
      
      // Scan source files for any modifications
      const fileThreats = await this.scanSourceFiles();
      threats.push(...fileThreats);
      
      // Generate summary
      const summary = this.generateThreatSummary(threats);
      
      const result: SecurityScanResult = {
        clean: threats.length === 0,
        threatsFound: threats,
        summary,
        lastScan: new Date(),
        contentScanned
      };
      
      // Alert if threats found
      if (threats.length > 0) {
        await this.sendSecurityAlert(threats);
      }
      
      console.log(`Security scan completed: ${threats.length} threats found in ${contentScanned} items`);
      return result;
      
    } catch (error) {
      console.error('Security scan failed:', error);
      return {
        clean: false,
        threatsFound: [{
          severity: 'critical',
          type: 'content_manipulation',
          description: 'Security scan system failure',
          location: 'Scanner',
          content: 'System error',
          recommendation: 'Investigate scanner system immediately',
          detectedAt: new Date()
        }],
        summary: { critical: 1, high: 0, medium: 0, low: 0 },
        lastScan: new Date(),
        contentScanned: 0
      };
    }
  }

  private async scanContent(content: any, type: 'article' | 'review'): Promise<SecurityThreat[]> {
    const threats: SecurityThreat[] = [];
    const fullContent = `${content.title} ${content.content} ${content.excerpt || ''}`;
    const location = `${type}:${content.id}:${content.slug}`;
    
    // Check for code injection
    for (const pattern of this.maliciousPatterns.codeInjection) {
      const matches = fullContent.match(pattern);
      if (matches) {
        threats.push({
          severity: 'critical',
          type: 'code_injection',
          description: `Code injection attempt detected: ${matches[0].substring(0, 100)}`,
          location,
          content: matches[0],
          recommendation: 'Remove malicious code immediately and investigate content source',
          detectedAt: new Date()
        });
      }
    }
    
    // Check for SQL injection
    for (const pattern of this.maliciousPatterns.sqlInjection) {
      const matches = fullContent.match(pattern);
      if (matches) {
        threats.push({
          severity: 'high',
          type: 'sql_injection',
          description: `SQL injection attempt detected: ${matches[0].substring(0, 100)}`,
          location,
          content: matches[0],
          recommendation: 'Remove SQL injection code and review content submission process',
          detectedAt: new Date()
        });
      }
    }
    
    // Check for XSS attempts
    for (const pattern of this.maliciousPatterns.xssAttempts) {
      const matches = fullContent.match(pattern);
      if (matches) {
        threats.push({
          severity: 'high',
          type: 'xss_attempt',
          description: `XSS attempt detected: ${matches[0].substring(0, 100)}`,
          location,
          content: matches[0],
          recommendation: 'Remove XSS code and sanitize all user inputs',
          detectedAt: new Date()
        });
      }
    }
    
    // Check for malicious links
    const linkThreats = this.scanForMaliciousLinks(fullContent, location);
    threats.push(...linkThreats);
    
    // Check content integrity
    const integrityThreats = this.scanContentIntegrity(fullContent, location);
    threats.push(...integrityThreats);
    
    // Check for AI content manipulation
    if (content.isAiGenerated && content.author && !content.author.includes('Theatre Spotlight')) {
      threats.push({
        severity: 'medium',
        type: 'content_manipulation',
        description: 'AI-generated content with external author attribution',
        location,
        content: `Author: ${content.author}`,
        recommendation: 'Verify author attribution for AI-generated content',
        detectedAt: new Date()
      });
    }
    
    return threats;
  }

  private scanForMaliciousLinks(content: string, location: string): SecurityThreat[] {
    const threats: SecurityThreat[] = [];
    
    // Extract all URLs from content
    const urlPattern = /https?:\/\/[^\s<>"]+/gi;
    const urls = content.match(urlPattern) || [];
    
    for (const url of urls) {
      const domain = this.extractDomain(url);
      
      // Check gambling sites
      for (const gamblingDomain of this.suspiciousLinks.gambling) {
        if (domain.includes(gamblingDomain) || url.toLowerCase().includes(gamblingDomain)) {
          threats.push({
            severity: 'critical',
            type: 'malicious_link',
            description: `Gambling site link detected: ${domain}`,
            location,
            content: url,
            recommendation: 'Remove gambling link immediately - violates content policy',
            detectedAt: new Date()
          });
        }
      }
      
      // Check adult content sites
      for (const adultDomain of this.suspiciousLinks.adult) {
        if (domain.includes(adultDomain) || url.toLowerCase().includes(adultDomain)) {
          threats.push({
            severity: 'critical',
            type: 'malicious_link',
            description: `Adult content link detected: ${domain}`,
            location,
            content: url,
            recommendation: 'Remove adult content link immediately - violates content policy',
            detectedAt: new Date()
          });
        }
      }
      
      // Check suspicious domains
      for (const suspiciousDomain of this.suspiciousLinks.suspicious) {
        if (domain.includes(suspiciousDomain)) {
          threats.push({
            severity: 'medium',
            type: 'malicious_link',
            description: `Suspicious link detected: ${domain}`,
            location,
            content: url,
            recommendation: 'Review link destination and replace with direct links if legitimate',
            detectedAt: new Date()
          });
        }
      }
      
      // Check for non-theatre related domains
      if (!this.isTheatreRelatedDomain(domain)) {
        threats.push({
          severity: 'low',
          type: 'suspicious_content',
          description: `Non-theatre external link: ${domain}`,
          location,
          content: url,
          recommendation: 'Verify link relevance to theatre content',
          detectedAt: new Date()
        });
      }
    }
    
    return threats;
  }

  private scanContentIntegrity(content: string, location: string): SecurityThreat[] {
    const threats: SecurityThreat[] = [];
    
    for (const pattern of this.contentIntegrityPatterns) {
      const matches = content.match(pattern);
      if (matches) {
        threats.push({
          severity: 'medium',
          type: 'suspicious_content',
          description: `Suspicious content pattern detected: ${matches[0].substring(0, 100)}`,
          location,
          content: matches[0],
          recommendation: 'Review content for spam or inappropriate material',
          detectedAt: new Date()
        });
      }
    }
    
    return threats;
  }

  private async scanSourceFiles(): Promise<SecurityThreat[]> {
    const threats: SecurityThreat[] = [];
    
    try {
      // Check critical server files for modifications
      const criticalFiles = [
        'server/routes.ts',
        'server/index.ts',
        'server/db.ts',
        'shared/schema.ts'
      ];
      
      for (const file of criticalFiles) {
        try {
          const content = await fs.readFile(file, 'utf-8');
          
          // Check for suspicious additions
          const suspiciousPatterns = [
            /eval\s*\(/gi,
            /exec\s*\(/gi,
            /child_process/gi,
            /fs\.writeFile/gi,
            /process\.exit/gi,
            /console\.log.*password/gi,
            /console\.log.*secret/gi
          ];
          
          for (const pattern of suspiciousPatterns) {
            const matches = content.match(pattern);
            if (matches) {
              threats.push({
                severity: 'high',
                type: 'code_injection',
                description: `Suspicious code detected in ${file}`,
                location: file,
                content: matches[0],
                recommendation: 'Review code changes and remove suspicious modifications',
                detectedAt: new Date()
              });
            }
          }
        } catch (error) {
          // File might not exist or be readable
        }
      }
    } catch (error) {
      console.error('Error scanning source files:', error);
    }
    
    return threats;
  }

  private extractDomain(url: string): string {
    try {
      const urlObj = new URL(url);
      return urlObj.hostname.toLowerCase();
    } catch {
      return url.toLowerCase();
    }
  }

  private isTheatreRelatedDomain(domain: string): boolean {
    const theatreDomains = [
      'theatrespotlight.com', 'broadway.com', 'playbill.com', 'whatsonstage.com',
      'broadwayworld.com', 'theatermania.com', 'thestage.co.uk', 'timeout.com',
      'theatrespotlight.com', 'nytimes.com', 'variety.com', 'hollywoodreporter.com',
      'telegraph.co.uk', 'thetimes.co.uk', 'ft.com', 'bbc.co.uk', 'cnn.com',
      'ticketmaster.com', 'seetickets.com', 'atgtickets.com', 'delfontmackintosh.co.uk',
      'cameronmackintosh.com', 'nationaltheatre.org.uk', 'rsc.org.uk',
      'youtube.com', 'twitter.com', 'instagram.com', 'facebook.com'
    ];
    
    return theatreDomains.some(theatreDomain => 
      domain.includes(theatreDomain) || theatreDomain.includes(domain)
    );
  }

  private generateThreatSummary(threats: SecurityThreat[]): SecurityScanResult['summary'] {
    const summary = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0
    };
    
    threats.forEach(threat => {
      summary[threat.severity]++;
    });
    
    return summary;
  }

  private async sendSecurityAlert(threats: SecurityThreat[]): Promise<void> {
    const criticalThreats = threats.filter(t => t.severity === 'critical');
    const highThreats = threats.filter(t => t.severity === 'high');
    
    if (criticalThreats.length > 0 || highThreats.length > 0) {
      const subject = `SECURITY ALERT: ${criticalThreats.length} Critical, ${highThreats.length} High Threats Detected`;
      
      const message = `
THEATRE SPOTLIGHT SECURITY ALERT

IMMEDIATE ACTION REQUIRED:

${criticalThreats.map(threat => `
🚨 CRITICAL: ${threat.description}
Location: ${threat.location}
Content: ${threat.content.substring(0, 200)}
Action: ${threat.recommendation}
`).join('\n')}

${highThreats.map(threat => `
⚠️ HIGH: ${threat.description}
Location: ${threat.location}
Content: ${threat.content.substring(0, 200)}
Action: ${threat.recommendation}
`).join('\n')}

NEXT STEPS:
1. Review and remove malicious content immediately
2. Investigate content source and submission process
3. Update security measures to prevent future incidents
4. Run manual content review for past 7 days

Security Dashboard: /admin/security
      `.trim();
      
      console.log(`SECURITY ALERT SENT: ${subject}`);
      console.log(message);
    }
  }

  async generateSecurityReport(scanResult: SecurityScanResult): Promise<string> {
    return `
# Daily Security Scan Report
**Scan Time:** ${scanResult.lastScan.toISOString()}
**Status:** ${scanResult.clean ? '✅ CLEAN' : '❌ THREATS DETECTED'}
**Content Scanned:** ${scanResult.contentScanned} items

## Threat Summary
- **Critical:** ${scanResult.summary.critical}
- **High:** ${scanResult.summary.high}
- **Medium:** ${scanResult.summary.medium}
- **Low:** ${scanResult.summary.low}

## Threats Detected
${scanResult.threatsFound.length > 0 ? 
  scanResult.threatsFound.map(threat => `
### ${threat.severity.toUpperCase()}: ${threat.description}
**Type:** ${threat.type}
**Location:** ${threat.location}
**Content:** ${threat.content.substring(0, 200)}${threat.content.length > 200 ? '...' : ''}
**Action Required:** ${threat.recommendation}
**Detected:** ${threat.detectedAt.toISOString()}
`).join('\n') : 
  'No security threats detected in this scan.'
}

## Security Health
${scanResult.clean ? 
  '✅ All content is clean and secure' : 
  `❌ ${scanResult.threatsFound.length} security issues require attention`
}

## Recommendations
- Run security scans after each content import
- Monitor external links in all content
- Implement stronger content validation
- Regular review of AI-generated content
    `.trim();
  }
}

export const contentSecurityScanner = new ContentSecurityScanner();