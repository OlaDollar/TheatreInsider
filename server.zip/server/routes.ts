import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertNewsletterSchema, insertPerformerSchema, insertProductionSchema, insertPerformerRoleSchema, insertPerformerMediaSchema } from "@shared/schema";
import { z } from "zod";
import { aiContentGenerator } from "./ai-content";
import { contentAggregator } from "./content-aggregator";
import { markShentonScraper } from "./mark-shenton-scraper";
import { mediaUploadManager } from "./media-upload-manager";
import { getWhatsOnShows } from "./whats-on-api";
import { theatreDirectory } from "./theatre-directory";
import { feedHealthMonitor } from "./feed-health-monitor";
import { crosswordGenerator } from "./crossword-generator";
import { theatreFactsGenerator } from "./theatre-facts";
import { artsEducationScraper } from "./arts-education-scraper";
import { awardsCeremonyScraper } from "./awards-ceremony-scraper";
import { scraperLogs, dataValidation } from "@shared/schema";
import { eq, desc } from "drizzle-orm";
import { db } from "./db";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Articles endpoints
  app.get("/api/articles", async (req, res) => {
    try {
      const { category, region, featured, limit } = req.query;
      const articles = await storage.getArticles({
        category: category as string,
        region: region as string,
        featured: featured === 'true',
        limit: limit ? parseInt(limit as string) : undefined
      });
      res.json(articles);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch articles" });
    }
  });

  app.get("/api/articles/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string') {
        return res.status(400).json({ error: "Search query is required" });
      }
      const articles = await storage.searchArticles(q);
      res.json(articles);
    } catch (error) {
      res.status(500).json({ error: "Failed to search articles" });
    }
  });

  app.get("/api/articles/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const article = await storage.getArticle(id);
      if (!article) {
        return res.status(404).json({ error: "Article not found" });
      }
      res.json(article);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch article" });
    }
  });

  // Reviews endpoints
  app.get("/api/reviews", async (req, res) => {
    try {
      const { region, limit } = req.query;
      const reviews = await storage.getReviews({
        region: region as string,
        limit: limit ? parseInt(limit as string) : undefined
      });
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch reviews" });
    }
  });

  app.get("/api/reviews/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const review = await storage.getReview(id);
      if (!review) {
        return res.status(404).json({ error: "Review not found" });
      }
      res.json(review);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch review" });
    }
  });

  // Shows endpoints
  app.get("/api/shows", async (req, res) => {
    try {
      const { region, status } = req.query;
      const shows = await storage.getShows({
        region: region as string,
        status: status as string
      });
      res.json(shows);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch shows" });
    }
  });

  app.get("/api/shows/trending", async (req, res) => {
    try {
      const { limit } = req.query;
      const shows = await storage.getTrendingShows(limit ? parseInt(limit as string) : 10);
      res.json(shows);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch trending shows" });
    }
  });

  // Newsletter endpoint
  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const validatedData = insertNewsletterSchema.parse(req.body);
      const newsletter = await storage.subscribeNewsletter(validatedData);
      res.status(201).json({ message: "Successfully subscribed to newsletter" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid email format" });
      }
      res.status(500).json({ error: "Failed to subscribe to newsletter" });
    }
  });

  // Analytics endpoints for tracking content performance
  app.post("/api/articles/:id/view", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.incrementArticleViews(id);
      res.status(200).json({ message: "View tracked" });
    } catch (error) {
      res.status(500).json({ error: "Failed to track view" });
    }
  });

  app.post("/api/reviews/:id/view", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.incrementReviewViews(id);
      res.status(200).json({ message: "View tracked" });
    } catch (error) {
      res.status(500).json({ error: "Failed to track view" });
    }
  });

  // AI Content Generation endpoints
  app.post("/api/content/generate-daily", async (req, res) => {
    try {
      const result = await aiContentGenerator.generateDailyContent();
      res.json({
        message: "Daily content generated successfully",
        articles: result.articles,
        reviews: result.reviews
      });
    } catch (error) {
      console.error('Daily content generation error:', error);
      res.status(500).json({ error: "Failed to generate daily content" });
    }
  });

  app.post("/api/content/aggregate", async (req, res) => {
    try {
      const result = await contentAggregator.processAndPublishContent();
      res.json({
        message: "Content aggregation completed",
        processed: result.processed,
        published: result.published
      });
    } catch (error) {
      console.error('Content aggregation error:', error);
      res.status(500).json({ error: "Failed to aggregate content" });
    }
  });

  app.post("/api/content/submit", async (req, res) => {
    try {
      const { title, content, contentType, region, venue } = req.body;
      
      if (!title || !content || !contentType || !region) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const result = await contentAggregator.submitManualContent({
        title,
        content,
        contentType,
        region,
        venue
      });

      res.status(201).json({
        message: "Content submitted and published successfully",
        id: result.id
      });
    } catch (error) {
      console.error('Manual content submission error:', error);
      res.status(500).json({ error: "Failed to submit content" });
    }
  });

  app.post("/api/content/rewrite", async (req, res) => {
    try {
      const { originalContent, originalTitle, contentType } = req.body;
      
      if (!originalContent || !originalTitle || !contentType) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const result = await aiContentGenerator.rewriteExistingContent(
        originalContent,
        originalTitle,
        contentType
      );

      res.json({
        message: "Content rewritten successfully",
        result
      });
    } catch (error) {
      console.error('Content rewrite error:', error);
      res.status(500).json({ error: "Failed to rewrite content" });
    }
  });

  app.post("/api/content/scrape-mark-shenton", async (req, res) => {
    try {
      const result = await markShentonScraper.processAndPublishScrapedContent();
      res.json({
        message: "Mark Shenton content scraping completed",
        processed: result.processed,
        published: result.published
      });
    } catch (error) {
      console.error('Mark Shenton scraping error:', error);
      res.status(500).json({ error: "Failed to scrape Mark Shenton content" });
    }
  });

  // Performer routes
  app.get("/api/performers", async (req, res) => {
    try {
      const { nationality, status, featured, limit } = req.query;
      const performers = await storage.getPerformers({
        nationality: nationality as string,
        status: status as string,
        featured: featured === 'true',
        limit: limit ? parseInt(limit as string) : undefined
      });
      res.json(performers);
    } catch (error) {
      console.error('Get performers error:', error);
      res.status(500).json({ error: "Failed to fetch performers" });
    }
  });

  app.get("/api/performers/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q) {
        return res.status(400).json({ error: "Query parameter 'q' is required" });
      }
      const performers = await storage.searchPerformers(q as string);
      res.json(performers);
    } catch (error) {
      console.error('Search performers error:', error);
      res.status(500).json({ error: "Failed to search performers" });
    }
  });

  app.get("/api/performers/slug/:slug", async (req, res) => {
    try {
      const performer = await storage.getPerformerBySlug(req.params.slug);
      if (!performer) {
        return res.status(404).json({ error: "Performer not found" });
      }
      
      // Get performer's productions and media
      const productions = await storage.getPerformerProductions(performer.id);
      const media = await storage.getPerformerMedia(performer.id);
      
      res.json({ ...performer, productions, media });
    } catch (error) {
      console.error('Get performer by slug error:', error);
      res.status(500).json({ error: "Failed to fetch performer" });
    }
  });

  // Seat availability endpoint
  app.get("/api/shows/availability/:showTitle", async (req, res) => {
    try {
      const { showTitle } = req.params;
      const { seatAvailabilityChecker } = await import("./seat-availability");
      
      const availability = await seatAvailabilityChecker.checkSeatAvailability(showTitle);
      
      if (!availability) {
        return res.status(404).json({ error: "Show not found or no current production" });
      }
      
      res.json(availability);
    } catch (error) {
      console.error("Error checking seat availability:", error);
      res.status(500).json({ error: "Failed to check seat availability" });
    }
  });

  // Article booking integration
  app.get("/api/articles/:id/booking", async (req, res) => {
    try {
      const { id } = req.params;
      const { seatAvailabilityChecker } = await import("./seat-availability");
      
      // Get article to extract show information
      const article = await db.select().from(articles).where(eq(articles.id, parseInt(id))).limit(1);
      
      if (!article.length) {
        return res.status(404).json({ error: "Article not found" });
      }
      
      const availability = await seatAvailabilityChecker.getShowAvailabilityForArticle(
        article[0].title, 
        article[0].content
      );
      
      if (!availability) {
        return res.json({ bookingAvailable: false });
      }
      
      const trackingUrl = seatAvailabilityChecker.generateBookingTrackingUrl(
        availability.bookingUrl, 
        parseInt(id)
      );
      
      res.json({
        bookingAvailable: true,
        ...availability,
        trackingUrl
      });
    } catch (error) {
      console.error("Error getting article booking info:", error);
      res.status(500).json({ error: "Failed to get booking information" });
    }
  });

  // Database health check endpoint
  app.get("/api/admin/database/health", async (req, res) => {
    try {
      const { databaseValidator } = await import("./database-validator");
      const report = await databaseValidator.generateDatabaseHealthReport();
      res.json({ report });
    } catch (error) {
      console.error("Error generating database health report:", error);
      res.status(500).json({ error: "Failed to generate health report" });
    }
  });

  // Database fix endpoint
  app.post("/api/admin/database/fix", async (req, res) => {
    try {
      const { databaseValidator } = await import("./database-validator");
      const validation = await databaseValidator.validateAllTables();
      
      if (validation.valid) {
        return res.json({ message: "Database is healthy, no fixes needed" });
      }
      
      const result = await databaseValidator.applyAutomaticFixes(validation.fixes);
      res.json({
        message: "Database fixes applied",
        applied: result.applied,
        failed: result.failed,
        success: result.success
      });
    } catch (error) {
      console.error("Error applying database fixes:", error);
      res.status(500).json({ error: "Failed to apply fixes" });
    }
  });

  // Content priority report endpoint
  app.get("/api/admin/content/priority", async (req, res) => {
    try {
      const { contentPrioritizer } = await import("./content-prioritizer");
      const report = await contentPrioritizer.generateContentReport();
      res.json({ report });
    } catch (error) {
      console.error("Error generating content priority report:", error);
      res.status(500).json({ error: "Failed to generate priority report" });
    }
  });

  // Homepage content endpoint
  app.get("/api/homepage", async (req, res) => {
    try {
      const { contentPrioritizer } = await import("./content-prioritizer");
      const content = await contentPrioritizer.getHomepageContent();
      res.json(content);
    } catch (error) {
      console.error("Error fetching homepage content:", error);
      res.status(500).json({ error: "Failed to fetch homepage content" });
    }
  });

  // Subscription management endpoints
  app.get("/api/subscription/tiers", async (req, res) => {
    try {
      const { subscriptionManager } = await import("./subscription-manager");
      const tiers = subscriptionManager.getSubscriptionTiers();
      res.json(tiers);
    } catch (error) {
      console.error("Error fetching subscription tiers:", error);
      res.status(500).json({ error: "Failed to fetch subscription tiers" });
    }
  });

  app.post("/api/subscription/upgrade", async (req, res) => {
    try {
      const { userId, tier, paymentMethod } = req.body;
      const { subscriptionManager } = await import("./subscription-manager");
      const result = await subscriptionManager.upgradeSubscription(userId, tier, paymentMethod);
      res.json(result);
    } catch (error) {
      console.error("Error upgrading subscription:", error);
      res.status(500).json({ error: "Failed to upgrade subscription" });
    }
  });

  app.post("/api/subscription/trial", async (req, res) => {
    try {
      const { userId, tier } = req.body;
      const { subscriptionManager } = await import("./subscription-manager");
      const result = await subscriptionManager.startFreeTrial(userId, tier);
      res.json(result);
    } catch (error) {
      console.error("Error starting trial:", error);
      res.status(500).json({ error: "Failed to start trial" });
    }
  });

  app.get("/api/subscription/user/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      const { subscriptionManager } = await import("./subscription-manager");
      const subscription = await subscriptionManager.getUserSubscription(parseInt(userId));
      const usage = await subscriptionManager.getUsageStats(parseInt(userId));
      res.json({ subscription, usage });
    } catch (error) {
      console.error("Error fetching user subscription:", error);
      res.status(500).json({ error: "Failed to fetch subscription" });
    }
  });

  // Industry database endpoints (Premium feature)
  app.get("/api/industry/contacts", async (req, res) => {
    try {
      // Check user subscription level here
      const { type, region, company, specialty, tier } = req.query;
      const { industryDatabase } = await import("./industry-database");
      
      const contacts = await industryDatabase.searchContacts({
        type: type as any,
        region: region as string,
        company: company as string,
        specialty: specialty as string,
        tier: tier as any
      });
      
      res.json(contacts);
    } catch (error) {
      console.error("Error fetching industry contacts:", error);
      res.status(500).json({ error: "Failed to fetch contacts" });
    }
  });

  app.get("/api/industry/casting", async (req, res) => {
    try {
      const { region } = req.query;
      const { industryDatabase } = await import("./industry-database");
      const opportunities = await industryDatabase.getCurrentCastingOpportunities(region as string);
      res.json(opportunities);
    } catch (error) {
      console.error("Error fetching casting opportunities:", error);
      res.status(500).json({ error: "Failed to fetch casting opportunities" });
    }
  });

  app.get("/api/industry/pipeline", async (req, res) => {
    try {
      const { status } = req.query;
      const { industryDatabase } = await import("./industry-database");
      const pipeline = await industryDatabase.getProductionPipeline(status as any);
      res.json(pipeline);
    } catch (error) {
      console.error("Error fetching production pipeline:", error);
      res.status(500).json({ error: "Failed to fetch pipeline" });
    }
  });

  // Theatre jobs endpoints
  app.get("/api/jobs", async (req, res) => {
    try {
      const { category } = req.query;
      const { theatreJobsGenerator } = await import("./theatre-jobs");
      
      let jobs;
      if (category && category !== 'all') {
        jobs = theatreJobsGenerator.getJobsByCategory(category as any);
      } else {
        jobs = theatreJobsGenerator.getJobRoles();
      }
      
      res.json(jobs);
    } catch (error) {
      console.error("Error fetching theatre jobs:", error);
      res.status(500).json({ error: "Failed to fetch jobs" });
    }
  });

  app.get("/api/jobs/:jobId", async (req, res) => {
    try {
      const { jobId } = req.params;
      const { theatreJobsGenerator } = await import("./theatre-jobs");
      const job = theatreJobsGenerator.getJobRole(jobId);
      
      if (!job) {
        return res.status(404).json({ error: "Job role not found" });
      }
      
      res.json(job);
    } catch (error) {
      console.error("Error fetching job role:", error);
      res.status(500).json({ error: "Failed to fetch job role" });
    }
  });

  app.post("/api/jobs/create-content", async (req, res) => {
    try {
      const { theatreJobsGenerator } = await import("./theatre-jobs");
      const result = await theatreJobsGenerator.createJobsSection();
      
      // Save generated articles to database
      const { db } = await import("./db");
      const { articles } = await import("@shared/schema");
      const { generateSlug, generateMetaDescription, extractTags } = await import("./ai-content");
      
      const savedArticles = [];
      for (const article of result.articles) {
        const slug = generateSlug(article.title);
        const metaDescription = generateMetaDescription(article.content);
        const tags = extractTags(article.content, article.title);
        
        const [savedArticle] = await db.insert(articles).values({
          title: article.title,
          content: article.content,
          excerpt: article.excerpt,
          author: article.author,
          category: article.category,
          region: article.region,
          imageUrl: article.imageUrl,
          slug,
          metaDescription,
          tags,
          isFeatured: true,
          isPremium: false
        }).returning();
        
        savedArticles.push(savedArticle);
      }
      
      res.json({
        message: "Theatre jobs content created successfully",
        articles: savedArticles.length,
        careerGuides: result.careerGuides.length,
        guides: result.careerGuides.map(g => ({ jobId: g.jobId, wordCount: g.guide.length }))
      });
    } catch (error) {
      console.error("Error creating jobs content:", error);
      res.status(500).json({ error: "Failed to create jobs content" });
    }
  });

  app.post("/api/jobs/interview-questions", async (req, res) => {
    try {
      const { jobTitle, intervieweeBackground } = req.body;
      const { theatreJobsGenerator } = await import("./theatre-jobs");
      const questions = await theatreJobsGenerator.generateInterviewQuestions(jobTitle, intervieweeBackground);
      res.json({ questions });
    } catch (error) {
      console.error("Error generating interview questions:", error);
      res.status(500).json({ error: "Failed to generate interview questions" });
    }
  });

  // Comprehensive Mark Shenton content scraping from all sources
  app.post('/api/admin/scrape-mark-shenton-content', async (req, res) => {
    try {
      console.log('Starting comprehensive Mark Shenton content scraping from all sources...');
      const { markShentonContentScraper } = await import("./mark-shenton-content-scraper");
      
      // Run scraping in background to avoid timeout
      setTimeout(async () => {
        const result = await markShentonContentScraper.scrapeAllMarkShentonContent();
        console.log(`Mark Shenton scraping completed: ${result.processed} processed, ${result.shentonAICreated} ShentonAI observations created, ${result.duplicatesSkipped} duplicates skipped`);
      }, 1000);
      
      res.json({
        message: 'Comprehensive Mark Shenton content scraping started',
        status: 'initiated',
        sources: ['TheStage', 'Playbill', 'WhatsOnStage', 'Express', 'PlaysInternational']
      });
    } catch (error) {
      console.error('Error starting Mark Shenton content scraping:', error);
      res.status(500).json({ 
        error: 'Failed to start Mark Shenton content scraping',
        message: error.message 
      });
    }
  });

  // Arts Education API routes
  app.get("/api/arts-education/schools", async (req, res) => {
    try {
      const { country } = req.query;
      let schools;
      if (country && country !== "all") {
        schools = await artsEducationScraper.getSchoolsByCountry(country as string);
      } else {
        const ukSchools = await artsEducationScraper.getSchoolsByCountry("UK");
        const usSchools = await artsEducationScraper.getSchoolsByCountry("US");
        schools = [...ukSchools, ...usSchools];
      }
      res.json(schools);
    } catch (error) {
      console.error("Error fetching arts education schools:", error);
      res.status(500).json({ message: "Failed to fetch schools" });
    }
  });

  app.get("/api/arts-education/schools/:id/courses", async (req, res) => {
    try {
      const schoolId = parseInt(req.params.id);
      const courses = await artsEducationScraper.getSchoolCourses(schoolId);
      res.json(courses);
    } catch (error) {
      console.error("Error fetching school courses:", error);
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.get("/api/arts-education/schools/:id/teachers", async (req, res) => {
    try {
      const schoolId = parseInt(req.params.id);
      const teachers = await artsEducationScraper.getSchoolTeachers(schoolId);
      res.json(teachers);
    } catch (error) {
      console.error("Error fetching school teachers:", error);
      res.status(500).json({ message: "Failed to fetch teachers" });
    }
  });

  // Awards API routes
  app.get("/api/awards/ceremonies", async (req, res) => {
    try {
      const { year } = req.query;
      const ceremonies = await awardsCeremonyScraper.getCeremoniesByYear(year ? parseInt(year as string) : undefined);
      res.json(ceremonies);
    } catch (error) {
      console.error("Error fetching awards ceremonies:", error);
      res.status(500).json({ message: "Failed to fetch ceremonies" });
    }
  });

  app.get("/api/awards/winners/:ceremony/:category", async (req, res) => {
    try {
      const { ceremony, category } = req.params;
      const { limit } = req.query;
      const winners = await awardsCeremonyScraper.getWinnersByCategory(
        ceremony,
        category,
        limit ? parseInt(limit as string) : undefined
      );
      res.json(winners);
    } catch (error) {
      console.error("Error fetching award winners:", error);
      res.status(500).json({ message: "Failed to fetch winners" });
    }
  });

  const httpServer = createServer(app);
  // ShentonAI Daily Crossword endpoints
  app.get("/api/crossword", async (req, res) => {
    try {
      const { date, difficulty } = req.query;
      const targetDifficulty = difficulty as 'easy' | 'medium' | 'hard' | 'expert' || 'medium';
      if (!['easy', 'medium', 'hard', 'expert'].includes(targetDifficulty)) {
        return res.status(400).json({ error: 'Invalid difficulty level' });
      }
      
      const targetDate = (date as string) || new Date().toISOString().split('T')[0];
      
      console.log(`🏗️ PROFESSIONAL CROSSWORD API: ${targetDifficulty} for ${targetDate}`);
      
      const { professionalCrosswordEngine } = await import('./professional-crossword-engine');
      const crossword = professionalCrosswordEngine.generateProfessionalCrossword(targetDifficulty, targetDate);
      
      res.json(crossword);
    } catch (error) {
      console.error("Professional crossword error:", error);
      res.status(500).json({ error: "Failed to generate professional crossword" });
    }
  });

  app.get("/api/crossword/today", async (req, res) => {
    try {
      const difficulty = (req.query.difficulty as 'easy' | 'medium' | 'hard' | 'expert') || 'medium';
      
      if (!['easy', 'medium', 'hard', 'expert'].includes(difficulty)) {
        return res.status(400).json({ error: 'Invalid difficulty level' });
      }
      
      const today = new Date().toISOString().split('T')[0];
      
      console.log(`🏗️ PROFESSIONAL CROSSWORD: ${difficulty} for ${today}`);
      
      // Use the professional crossword engine with authentic grids
      const { professionalCrosswordEngine } = await import('./professional-crossword-engine');
      const crossword = professionalCrosswordEngine.generateProfessionalCrossword(difficulty, today);
      
      res.json(crossword);
    } catch (error) {
      console.error("Error generating professional crossword:", error);
      res.status(500).json({ error: "Failed to generate professional crossword" });
    }
  });

  app.get("/api/crossword/solution-available", async (req, res) => {
    try {
      const now = new Date();
      const ukTime = new Date(now.toLocaleString("en-US", {timeZone: "Europe/London"}));
      const currentDate = ukTime.toISOString().split('T')[0];
      const currentTime = ukTime.getTime();
      
      // Solution available next day after 5:00 AM UK time
      const tomorrow = new Date(ukTime);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(5, 0, 0, 0);
      
      const available = currentTime >= tomorrow.getTime();
      
      if (!available) {
        res.json({
          available: false,
          message: "Solution available tomorrow after 5:00 AM UK time",
          nextAvailable: tomorrow.toISOString(),
          timeRemaining: Math.max(0, tomorrow.getTime() - currentTime)
        });
      } else {
        res.json({
          available: true,
          message: "Solution now available"
        });
      }
    } catch (error) {
      console.error("Error checking solution availability:", error);
      res.status(500).json({ error: "Failed to check solution availability" });
    }
  });

  app.get("/api/crossword/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const crossword = await crosswordGenerator.getCrosswordForDate(date);
      
      if (!crossword) {
        return res.status(404).json({ error: "Crossword not found for this date" });
      }
      
      res.json(crossword);
    } catch (error) {
      console.error("Crossword date error:", error);
      res.status(500).json({ error: "Failed to get crossword for date" });
    }
  });

  // Daily Theatre Facts endpoints
  app.get("/api/theatre-facts", async (req, res) => {
    try {
      const { date } = req.query;
      let fact;
      
      if (date) {
        fact = await theatreFactsGenerator.getFactForDate(date as string);
      } else {
        fact = await theatreFactsGenerator.getTodaysFact();
      }
      
      res.json(fact);
    } catch (error) {
      console.error("Theatre facts error:", error);
      res.status(500).json({ error: "Failed to get theatre fact" });
    }
  });

  app.get("/api/theatre-facts/recent/:days", async (req, res) => {
    try {
      const { days } = req.params;
      const numDays = parseInt(days) || 7;
      const facts = [];
      
      for (let i = 1; i <= numDays; i++) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dateString = date.toISOString().split('T')[0];
        const fact = await theatreFactsGenerator.getFactForDate(dateString);
        facts.push(fact);
      }
      
      res.json(facts);
    } catch (error) {
      console.error("Recent facts error:", error);
      res.status(500).json({ error: "Failed to get recent facts" });
    }
  });

  app.get("/api/theatre-facts/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const fact = await theatreFactsGenerator.getFactForDate(date);
      res.json(fact);
    } catch (error) {
      console.error("Theatre fact date error:", error);
      res.status(500).json({ error: "Failed to get fact for date" });
    }
  });

  // Save crossword answers with session-based retention
  app.post('/api/crossword/save-answers', async (req, res) => {
    try {
      const { date, answers, completedClues, completedAt } = req.body;
      const isAuthenticated = req.isAuthenticated && req.isAuthenticated();
      
      // Calculate expiry based on authentication status
      const now = new Date();
      const expiryDays = isAuthenticated ? 30 : 1; // 30 days for signed-in users, 1 day for anonymous
      const expiresAt = new Date(now.getTime() + (expiryDays * 24 * 60 * 60 * 1000));
      
      // Store in database with expiry
      await db.insert(crosswordAnswers).values({
        userId: isAuthenticated ? req.user?.claims?.sub : null,
        sessionId: isAuthenticated ? null : req.sessionID || 'anonymous',
        date,
        answers: JSON.stringify(answers),
        completedClues: JSON.stringify(completedClues),
        completedAt: completedAt ? new Date(completedAt) : null,
        expiresAt
      }).onConflictDoUpdate({
        target: isAuthenticated ? [crosswordAnswers.userId, crosswordAnswers.date] : [crosswordAnswers.sessionId, crosswordAnswers.date],
        set: {
          answers: JSON.stringify(answers),
          completedClues: JSON.stringify(completedClues),
          completedAt: completedAt ? new Date(completedAt) : null,
          expiresAt,
          updatedAt: now
        }
      });
      
      res.json({ 
        success: true, 
        saved: now.toISOString(),
        retentionDays: expiryDays,
        isAuthenticated 
      });
    } catch (error) {
      console.error('Error saving crossword answers:', error);
      res.status(500).json({ error: 'Failed to save answers' });
    }
  });

  // Get saved crossword answers
  app.get('/api/crossword/answers/:date', async (req, res) => {
    try {
      const { date } = req.params;
      const isAuthenticated = req.isAuthenticated && req.isAuthenticated();
      
      // Clean up expired answers first
      await db.delete(crosswordAnswers).where(
        sql`expires_at < ${new Date()}`
      );
      
      // Retrieve user's answers
      let savedAnswer;
      if (isAuthenticated) {
        [savedAnswer] = await db.select()
          .from(crosswordAnswers)
          .where(and(
            eq(crosswordAnswers.userId, req.user.claims.sub),
            eq(crosswordAnswers.date, date)
          ));
      } else {
        [savedAnswer] = await db.select()
          .from(crosswordAnswers)
          .where(and(
            eq(crosswordAnswers.sessionId, req.sessionID || 'anonymous'),
            eq(crosswordAnswers.date, date)
          ));
      }
      
      if (savedAnswer) {
        res.json({
          date: savedAnswer.date,
          answers: JSON.parse(savedAnswer.answers),
          completedClues: JSON.parse(savedAnswer.completedClues),
          completedAt: savedAnswer.completedAt
        });
      } else {
        res.json(null);
      }
    } catch (error) {
      console.error('Error retrieving crossword answers:', error);
      res.status(500).json({ error: 'Failed to retrieve answers' });
    }
  });

  // Theatre Directory endpoints
  app.get("/api/theatres", async (req, res) => {
    try {
      const { region, venueType, city, searchTerm, minCapacity, maxCapacity } = req.query;
      
      const filters = {
        region: region as 'uk' | 'us' | 'both',
        venue_type: venueType ? (venueType as string).split(',') : undefined,
        city: city as string,
        search_term: searchTerm as string,
        capacity_range: minCapacity || maxCapacity ? {
          min: minCapacity ? parseInt(minCapacity as string) : undefined,
          max: maxCapacity ? parseInt(maxCapacity as string) : undefined
        } : undefined
      };
      
      const result = await theatreDirectory.getTheatres(filters);
      res.json(result);
    } catch (error) {
      console.error("Theatre directory error:", error);
      res.status(500).json({ error: "Failed to fetch theatre directory" });
    }
  });

  app.get("/api/theatres/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const theatre = await theatreDirectory.getTheatreById(parseInt(id));
      
      if (!theatre) {
        return res.status(404).json({ error: "Theatre not found" });
      }
      
      res.json(theatre);
    } catch (error) {
      console.error("Theatre detail error:", error);
      res.status(500).json({ error: "Failed to fetch theatre details" });
    }
  });

  // Feed Health Monitoring endpoints
  app.get("/api/system/health", async (req, res) => {
    try {
      const health = feedHealthMonitor.getCurrentHealth();
      res.json(health);
    } catch (error) {
      console.error("Health check error:", error);
      res.status(500).json({ error: "Failed to get system health" });
    }
  });

  app.post("/api/system/health/check", async (req, res) => {
    try {
      const report = await feedHealthMonitor.forceHealthCheck();
      res.json(report);
    } catch (error) {
      console.error("Manual health check error:", error);
      res.status(500).json({ error: "Failed to perform health check" });
    }
  });

  // Manual theatre data refresh endpoint
  app.post("/api/admin/refresh-theatre-data", async (req, res) => {
    try {
      console.log('Manual theatre data refresh initiated...');
      const { theatreDataScraper } = await import('./theatre-data-scraper');
      
      // Run in background to avoid timeout
      setTimeout(async () => {
        const result = await theatreDataScraper.scrapeAllTheatres();
        console.log(`Manual refresh complete: ${result.scraped} scraped, ${result.updated} updated, ${result.newShows} new shows`);
      }, 1000);
      
      res.json({
        message: 'Theatre data refresh initiated',
        status: 'running',
        note: 'Scraping major UK and US theatres for current and upcoming shows'
      });
    } catch (error) {
      console.error('Error starting theatre data refresh:', error);
      res.status(500).json({ error: 'Failed to start theatre data refresh' });
    }
  });

  // What's On endpoints - Real-time theatre data
  app.get("/api/whats-on", async (req, res) => {
    try {
      const shows = await getWhatsOnShows(req.query);
      res.json(shows);
    } catch (error) {
      console.error("Error fetching what's on shows:", error);
      res.status(500).json({ error: "Failed to fetch shows" });
    }
  });

  // Awards ceremony endpoints
  app.get("/api/awards/ceremonies", async (req, res) => {
    try {
      const { awardCeremonies } = await import("@shared/schema");
      const { db } = await import("./db");
      const ceremonies = await db.select().from(awardCeremonies).limit(20);
      res.json(ceremonies);
    } catch (error) {
      console.error('Get ceremonies error:', error);
      res.status(500).json({ error: "Failed to fetch ceremonies" });
    }
  });

  app.post("/api/awards/scrape", async (req, res) => {
    try {
      const { awardsCeremonyScraper } = await import("./awards-ceremony-scraper");
      const result = await awardsCeremonyScraper.scrapeAllAwardsCeremonies();
      res.json({ message: "Awards ceremony scraping completed", ...result });
    } catch (error) {
      console.error('Awards scraping error:', error);
      res.status(500).json({ error: "Failed to scrape awards data" });
    }
  });

  // Arts Education endpoints
  app.get("/api/arts-education/schools", async (req, res) => {
    try {
      const { artsEducationScraper } = await import("./arts-education-scraper");
      const { region, country } = req.query;
      
      if (region) {
        const schools = await artsEducationScraper.getSchoolsByRegion(region as string);
        res.json(schools);
      } else {
        const { artsEducationSchools } = await import("@shared/schema");
        const { db } = await import("./db");
        const { eq } = await import("drizzle-orm");
        
        let query = db.select().from(artsEducationSchools);
        if (country) {
          query = query.where(eq(artsEducationSchools.country, country as string));
        }
        
        const schools = await query;
        res.json(schools);
      }
    } catch (error) {
      console.error('Get arts education schools error:', error);
      res.status(500).json({ error: "Failed to fetch schools" });
    }
  });

  app.get("/api/arts-education/schools/:id/courses", async (req, res) => {
    try {
      const { artsEducationScraper } = await import("./arts-education-scraper");
      const schoolId = parseInt(req.params.id);
      const courses = await artsEducationScraper.getSchoolCourses(schoolId);
      res.json(courses);
    } catch (error) {
      console.error('Get school courses error:', error);
      res.status(500).json({ error: "Failed to fetch courses" });
    }
  });

  app.get("/api/arts-education/schools/:id/teachers", async (req, res) => {
    try {
      const { artsEducationScraper } = await import("./arts-education-scraper");
      const schoolId = parseInt(req.params.id);
      const teachers = await artsEducationScraper.getSchoolTeachers(schoolId);
      res.json(teachers);
    } catch (error) {
      console.error('Get school teachers error:', error);
      res.status(500).json({ error: "Failed to fetch teachers" });
    }
  });

  app.get("/api/arts-education/count", async (req, res) => {
    try {
      const { artsEducationScraper } = await import("./arts-education-scraper");
      const { country } = req.query;
      const count = await artsEducationScraper.getSchoolCount(country as string);
      res.json({ count, country: country || 'all' });
    } catch (error) {
      console.error('Get school count error:', error);
      res.status(500).json({ error: "Failed to get school count" });
    }
  });

  app.post("/api/arts-education/scrape", async (req, res) => {
    try {
      const { artsEducationScraper } = await import("./arts-education-scraper");
      const result = await artsEducationScraper.scrapeAllArtsEducationData();
      res.json({ message: "Arts education scraping completed", ...result });
    } catch (error) {
      console.error('Arts education scraping error:', error);
      res.status(500).json({ error: "Failed to scrape arts education data" });
    }
  });

  // Admin scraper monitoring endpoints
  app.get("/api/admin/scraper-logs", async (req, res) => {
    try {
      const { scraper, limit = '50', offset = '0' } = req.query;
      
      let query = db.select().from(scraperLogs);
      
      if (scraper && typeof scraper === 'string') {
        query = query.where(eq(scraperLogs.scraperName, scraper));
      }
      
      const logs = await query
        .orderBy(desc(scraperLogs.createdAt))
        .limit(parseInt(limit as string))
        .offset(parseInt(offset as string));
      
      res.json(logs);
    } catch (error) {
      console.error("Error fetching scraper logs:", error);
      res.status(500).json({ error: "Failed to fetch scraper logs" });
    }
  });

  app.get("/api/admin/scraper-summary", async (req, res) => {
    try {
      const logs = await db.select().from(scraperLogs);
      
      const summary = logs.reduce((acc, log) => {
        if (!acc[log.scraperName]) {
          acc[log.scraperName] = {
            total: 0,
            adds: 0,
            updates: 0,
            archived: 0,
            validationFailed: 0,
            lastRun: null
          };
        }
        
        acc[log.scraperName].total++;
        
        if (log.action === 'add') acc[log.scraperName].adds++;
        else if (log.action === 'update') acc[log.scraperName].updates++;
        else if (log.action === 'archived') acc[log.scraperName].archived++;
        else if (log.action === 'validation_failed') acc[log.scraperName].validationFailed++;
        
        if (!acc[log.scraperName].lastRun || new Date(log.createdAt) > new Date(acc[log.scraperName].lastRun)) {
          acc[log.scraperName].lastRun = log.createdAt;
        }
        
        return acc;
      }, {} as Record<string, any>);
      
      res.json(summary);
    } catch (error) {
      console.error("Error fetching scraper summary:", error);
      res.status(500).json({ error: "Failed to fetch scraper summary" });
    }
  });

  return httpServer;
}
