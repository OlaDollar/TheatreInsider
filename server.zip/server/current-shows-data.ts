/**
 * DEPRECATED - Current West End & Broadway Shows Data
 * Replaced by real-time theatre data scraper
 * This file will be removed after successful deployment
 */

export const currentShows = [
  {
    id: 1,
    title: "The Lion King",
    venue: "Lyceum Theatre",
    region: "uk",
    venueType: "west_end",
    genre: "musical",
    status: "running",
    description: "Disney's award-winning musical brings the African savanna to life with stunning costumes, puppetry, and music by Elton John and Tim Rice.",
    ticketUrl: "https://uk.lionking.com/tickets",
    officialWebsite: "https://uk.lionking.com",
    imageUrl: "/images/lion-king.jpg",
    director: "Julie Taymor",
    composer: "Elton John",
    cast: ["Shaun Escoffery", "Gugwana Dlamini", "Brown Lindiwe Mkhize"],
    duration: "2h 30m",
    ageRating: "U",
    popularity: 95,
    openingDate: "1999-10-19",
    priceRange: { min: 25, max: 125, currency: "GBP" },
    ticketAvailability: "available",
    lastUpdated: new Date().toISOString()
  },
  {
    id: 2,
    title: "The Phantom of the Opera",
    venue: "Her Majesty's Theatre",
    region: "uk",
    venueType: "west_end",
    genre: "musical",
    status: "running",
    description: "Andrew Lloyd Webber's haunting tale of love, obsession, and mystery beneath the Paris Opera House.",
    ticketUrl: "https://thephantomoftheopera.com/london",
    officialWebsite: "https://thephantomoftheopera.com",
    imageUrl: "/images/phantom.jpg",
    director: "Harold Prince",
    composer: "Andrew Lloyd Webber",
    cast: ["Killian Donnelly", "Lucy St. Louis", "Rhys Whitfield"],
    duration: "2h 45m",
    ageRating: "PG",
    popularity: 90,
    openingDate: "1986-10-09",
    priceRange: { min: 20, max: 135, currency: "GBP" },
    ticketAvailability: "available",
    lastUpdated: new Date().toISOString()
  },
  {
    id: 3,
    title: "Hamilton",
    venue: "Victoria Palace Theatre",
    region: "uk",
    venueType: "west_end",
    genre: "musical",
    status: "running",
    description: "Lin-Manuel Miranda's revolutionary musical about America's founding father, featuring hip-hop, R&B, and biographical storytelling.",
    ticketUrl: "https://hamiltonmusical.com/london",
    officialWebsite: "https://hamiltonmusical.com",
    imageUrl: "/images/hamilton.jpg",
    director: "Thomas Kail",
    composer: "Lin-Manuel Miranda",
    cast: ["Reuben Joseph", "Rachelle Ann Go", "Karl Queensborough"],
    duration: "2h 55m",
    ageRating: "12A",
    popularity: 98,
    openingDate: "2017-12-21",
    closingDate: "2025-06-30",
    priceRange: { min: 30, max: 200, currency: "GBP" },
    ticketAvailability: "limited",
    lastUpdated: new Date().toISOString()
  },
  {
    id: 4,
    title: "Wicked",
    venue: "Apollo Victoria Theatre",
    region: "uk",
    venueType: "west_end",
    genre: "musical",
    status: "running",
    description: "The untold story of the witches of Oz, featuring Stephen Schwartz's soaring melodies and spectacular staging.",
    ticketUrl: "https://wickedthemusical.co.uk",
    officialWebsite: "https://wickedthemusical.co.uk",
    imageUrl: "/images/wicked.jpg",
    director: "Joe Mantello",
    composer: "Stephen Schwartz",
    cast: ["Alexia Khadime", "Helen Woolf", "Aaron Sidwell"],
    duration: "2h 45m",
    ageRating: "PG",
    popularity: 92,
    openingDate: "2006-09-27",
    priceRange: { min: 25, max: 150, currency: "GBP" },
    ticketAvailability: "available",
    lastUpdated: new Date().toISOString()
  },
  {
    id: 5,
    title: "Chicago",
    venue: "Phoenix Theatre",
    region: "uk",
    venueType: "west_end",
    genre: "musical",
    status: "running",
    description: "The sultry musical about murder, greed, corruption, and all that jazz in 1920s Chicago.",
    ticketUrl: "https://chicagothemusical.com",
    officialWebsite: "https://chicagothemusical.com",
    imageUrl: "/images/chicago.jpg",
    director: "Walter Bobbie",
    composer: "John Kander",
    cast: ["Amra-Faye Wright", "Darren Day", "Sheila Ferguson"],
    duration: "2h 30m",
    ageRating: "12A",
    popularity: 85,
    openingDate: "1997-11-18",
    priceRange: { min: 20, max: 110, currency: "GBP" },
    ticketAvailability: "available",
    lastUpdated: new Date().toISOString()
  },
  {
    id: 6,
    title: "The Book of Mormon",
    venue: "Prince of Wales Theatre",
    region: "uk",
    venueType: "west_end",
    genre: "musical",
    status: "running",
    description: "Trey Parker and Matt Stone's irreverent comedy musical following two young missionaries in Uganda.",
    ticketUrl: "https://bookofmormonlondon.com",
    officialWebsite: "https://bookofmormonlondon.com",
    imageUrl: "/images/book-of-mormon.jpg",
    director: "Casey Nicholaw",
    composer: "Trey Parker",
    cast: ["Robert Colvin", "Conner Peirson", "Johnathan Tweedie"],
    duration: "2h 30m",
    ageRating: "18",
    popularity: 88,
    openingDate: "2013-03-21",
    priceRange: { min: 25, max: 125, currency: "GBP" },
    ticketAvailability: "available",
    lastUpdated: new Date().toISOString()
  }
];

export function filterShows(shows: typeof currentShows, filters: any) {
  let filteredShows = shows;
  
  if (filters.region && filters.region !== "both") {
    filteredShows = filteredShows.filter(show => show.region === filters.region);
  }
  
  if (filters.genre) {
    const genres = filters.genre.split(',');
    filteredShows = filteredShows.filter(show => genres.includes(show.genre));
  }
  
  if (filters.status) {
    const statuses = filters.status.split(',');
    filteredShows = filteredShows.filter(show => statuses.includes(show.status));
  }
  
  if (filters.search) {
    const term = filters.search.toLowerCase();
    filteredShows = filteredShows.filter(show => 
      show.title.toLowerCase().includes(term) ||
      show.venue.toLowerCase().includes(term) ||
      show.description.toLowerCase().includes(term)
    );
  }
  
  return filteredShows;
}