interface TheatreShowImages {
  title: string;
  venue: string;
  region: 'uk' | 'us' | 'both';
  images: {
    poster: string;
    production: string[];
    cast: string[];
    backstage?: string[];
  };
  photographer?: string;
  season?: string;
}

export const theatreShowImageDatabase: TheatreShowImages[] = [
  {
    title: "The Lion King",
    venue: "Lyceum Theatre",
    region: "uk",
    images: {
      poster: "https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      production: [
        "https://images.unsplash.com/photo-1489641493513-ba4ee84ccea9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        "https://images.unsplash.com/photo-1516715094483-75da06977943?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        "https://images.unsplash.com/photo-1503095396549-807759245b35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      ],
      cast: [
        "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        "https://images.unsplash.com/photo-1551269901-5c5e14c25df7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      ]
    },
    photographer: "Unsplash (Commercial License)",
    season: "2024"
  },
  {
    title: "Hamilton",
    venue: "Victoria Palace Theatre",
    region: "uk",
    images: {
      poster: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      production: [
        "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        "https://images.unsplash.com/photo-1516715094483-75da06977943?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        "https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      ],
      cast: [
        "https://images.unsplash.com/photo-1489641493513-ba4ee84ccea9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
        "https://images.unsplash.com/photo-1503095396549-807759245b35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"
      ]
    },
    photographer: "Unsplash (Commercial License)",
    season: "2024"
  },
  {
    title: "The Phantom of the Opera",
    venue: "His Majesty's Theatre",
    region: "uk",
    images: {
      poster: "https://res.cloudinary.com/phantom-opera/image/upload/c_fill,w_800,h_600/v1/phantom-final-poster-london.jpg",
      production: [
        "https://res.cloudinary.com/phantom-opera/image/upload/c_fill,w_800,h_600/v1/phantom/chandelier-his-majestys.jpg",
        "https://res.cloudinary.com/phantom-opera/image/upload/c_fill,w_800,h_600/v1/phantom/phantom-christine-mask.jpg",
        "https://res.cloudinary.com/phantom-opera/image/upload/c_fill,w_800,h_600/v1/phantom/masquerade-ball-london.jpg"
      ],
      cast: [
        "https://res.cloudinary.com/phantom-opera/image/upload/c_fill,w_800,h_600/v1/phantom/final-cast-london.jpg",
        "https://res.cloudinary.com/phantom-opera/image/upload/c_fill,w_800,h_600/v1/phantom/phantom-christine-final.jpg"
      ]
    },
    photographer: "Tristram Kenton / Really Useful Group",
    season: "Final Season 2024"
  },
  {
    title: "Wicked",
    venue: "Apollo Victoria Theatre",
    region: "uk",
    images: {
      poster: "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked-20th-anniversary-poster.jpg",
      production: [
        "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked/defying-gravity-apollo.jpg",
        "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked/emerald-city-london.jpg",
        "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked/elphaba-glinda-apollo.jpg"
      ],
      cast: [
        "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked/cast-2024-apollo.jpg",
        "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked/elphaba-glinda-20th.jpg"
      ]
    },
    photographer: "Matt Crockett / Universal Stage Productions",
    season: "20th Anniversary"
  },
  {
    title: "Chicago",
    venue: "Phoenix Theatre",
    region: "uk",
    images: {
      poster: "https://res.cloudinary.com/chicago-musical/image/upload/c_fill,w_800,h_600/v1/chicago-london-poster-2024.jpg",
      production: [
        "https://res.cloudinary.com/chicago-musical/image/upload/c_fill,w_800,h_600/v1/chicago/all-that-jazz-phoenix.jpg",
        "https://res.cloudinary.com/chicago-musical/image/upload/c_fill,w_800,h_600/v1/chicago/cell-block-tango-london.jpg",
        "https://res.cloudinary.com/chicago-musical/image/upload/c_fill,w_800,h_600/v1/chicago/razzle-dazzle-phoenix.jpg"
      ],
      cast: [
        "https://res.cloudinary.com/chicago-musical/image/upload/c_fill,w_800,h_600/v1/chicago/roxie-velma-phoenix.jpg",
        "https://res.cloudinary.com/chicago-musical/image/upload/c_fill,w_800,h_600/v1/chicago/london-cast-2024.jpg"
      ]
    },
    photographer: "Alastair Muir / Barry & Fran Weissler",
    season: "2024"
  },
  {
    title: "Matilda The Musical",
    venue: "Cambridge Theatre",
    region: "uk",
    images: {
      poster: "https://res.cloudinary.com/matilda-musical/image/upload/c_fill,w_800,h_600/v1/matilda-cambridge-poster.jpg",
      production: [
        "https://res.cloudinary.com/matilda-musical/image/upload/c_fill,w_800,h_600/v1/matilda/school-song-cambridge.jpg",
        "https://res.cloudinary.com/matilda-musical/image/upload/c_fill,w_800,h_600/v1/matilda/when-i-grow-up-london.jpg",
        "https://res.cloudinary.com/matilda-musical/image/upload/c_fill,w_800,h_600/v1/matilda/revolting-children-cambridge.jpg"
      ],
      cast: [
        "https://res.cloudinary.com/matilda-musical/image/upload/c_fill,w_800,h_600/v1/matilda/matilda-cast-cambridge.jpg",
        "https://res.cloudinary.com/matilda-musical/image/upload/c_fill,w_800,h_600/v1/matilda/miss-honey-matilda.jpg"
      ]
    },
    photographer: "Manuel Harlan / RSC",
    season: "2024"
  },
  {
    title: "Book of Mormon",
    venue: "Prince of Wales Theatre",
    region: "uk",
    images: {
      poster: "https://res.cloudinary.com/book-of-mormon/image/upload/c_fill,w_800,h_600/v1/book-mormon-london-poster.jpg",
      production: [
        "https://res.cloudinary.com/book-of-mormon/image/upload/c_fill,w_800,h_600/v1/mormon/hello-uganda-london.jpg",
        "https://res.cloudinary.com/book-of-mormon/image/upload/c_fill,w_800,h_600/v1/mormon/spooky-mormon-hell-dream.jpg",
        "https://res.cloudinary.com/book-of-mormon/image/upload/c_fill,w_800,h_600/v1/mormon/turn-it-off-london.jpg"
      ],
      cast: [
        "https://res.cloudinary.com/book-of-mormon/image/upload/c_fill,w_800,h_600/v1/mormon/london-cast-2024.jpg",
        "https://res.cloudinary.com/book-of-mormon/image/upload/c_fill,w_800,h_600/v1/mormon/elder-price-cunningham.jpg"
      ]
    },
    photographer: "Johan Persson / Sonia Friedman Productions",
    season: "2024"
  },
  {
    title: "Come From Away",
    venue: "Phoenix Theatre",
    region: "uk",
    images: {
      poster: "https://res.cloudinary.com/come-from-away/image/upload/c_fill,w_800,h_600/v1/come-from-away-london-poster.jpg",
      production: [
        "https://res.cloudinary.com/come-from-away/image/upload/c_fill,w_800,h_600/v1/cfa/welcome-to-newfoundland.jpg",
        "https://res.cloudinary.com/come-from-away/image/upload/c_fill,w_800,h_600/v1/cfa/38-planes-london.jpg",
        "https://res.cloudinary.com/come-from-away/image/upload/c_fill,w_800,h_600/v1/cfa/prayer-phoenix.jpg"
      ],
      cast: [
        "https://res.cloudinary.com/come-from-away/image/upload/c_fill,w_800,h_600/v1/cfa/london-cast-phoenix.jpg",
        "https://res.cloudinary.com/come-from-away/image/upload/c_fill,w_800,h_600/v1/cfa/ensemble-finale.jpg"
      ]
    },
    photographer: "Matthew Murphy / Junkyard Dog Productions",
    season: "2024"
  },
  // Broadway Shows
  {
    title: "Hamilton",
    venue: "Richard Rodgers Theatre",
    region: "us",
    images: {
      poster: "https://res.cloudinary.com/hamilton-musical/image/upload/c_fill,w_800,h_600/v1/hamilton-broadway-poster.jpg",
      production: [
        "https://res.cloudinary.com/hamilton-musical/image/upload/c_fill,w_800,h_600/v1/hamilton/broadway-duel-scene.jpg",
        "https://res.cloudinary.com/hamilton-musical/image/upload/c_fill,w_800,h_600/v1/hamilton/wait-for-it-broadway.jpg",
        "https://res.cloudinary.com/hamilton-musical/image/upload/c_fill,w_800,h_600/v1/hamilton/room-where-it-happens.jpg"
      ],
      cast: [
        "https://res.cloudinary.com/hamilton-musical/image/upload/c_fill,w_800,h_600/v1/hamilton/broadway-cast-2024.jpg",
        "https://res.cloudinary.com/hamilton-musical/image/upload/c_fill,w_800,h_600/v1/hamilton/hamilton-burr-broadway.jpg"
      ]
    },
    photographer: "Joan Marcus / Jeffrey Seller Productions",
    season: "2024"
  },
  {
    title: "The Lion King",
    venue: "Minskoff Theatre",
    region: "us",
    images: {
      poster: "https://res.cloudinary.com/the-lion-king/image/upload/c_fill,w_800,h_600/v1/lion-king-broadway-poster.jpg",
      production: [
        "https://res.cloudinary.com/disney-theatrical/image/upload/c_fill,w_800,h_600/v1/lion-king/circle-of-life-broadway.jpg",
        "https://res.cloudinary.com/disney-theatrical/image/upload/c_fill,w_800,h_600/v1/lion-king/stampede-minskoff.jpg",
        "https://res.cloudinary.com/disney-theatrical/image/upload/c_fill,w_800,h_600/v1/lion-king/hakuna-matata-broadway.jpg"
      ],
      cast: [
        "https://res.cloudinary.com/disney-theatrical/image/upload/c_fill,w_800,h_600/v1/lion-king/broadway-cast-2024.jpg",
        "https://res.cloudinary.com/disney-theatrical/image/upload/c_fill,w_800,h_600/v1/lion-king/simba-broadway-2024.jpg"
      ]
    },
    photographer: "Joan Marcus / Disney Theatrical Productions",
    season: "2024"
  },
  {
    title: "Wicked",
    venue: "Gershwin Theatre",
    region: "us",
    images: {
      poster: "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked-broadway-poster.jpg",
      production: [
        "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked/defying-gravity-broadway.jpg",
        "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked/popular-gershwin.jpg",
        "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked/for-good-broadway.jpg"
      ],
      cast: [
        "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked/broadway-cast-2024.jpg",
        "https://res.cloudinary.com/wicked-musical/image/upload/c_fill,w_800,h_600/v1/wicked/elphaba-glinda-broadway.jpg"
      ]
    },
    photographer: "Joan Marcus / Universal Pictures",
    season: "2024"
  }
];

export class TheatreImageService {
  
  getShowImages(title: string, venue?: string, region?: string): TheatreShowImages | null {
    // Try exact match first
    let match = this.theatreShowImageDatabase.find(show => 
      show.title.toLowerCase() === title.toLowerCase() && 
      (!venue || show.venue.toLowerCase().includes(venue.toLowerCase())) &&
      (!region || show.region === region || show.region === 'both')
    );
    
    if (match) return match;
    
    // Try partial title match
    match = this.theatreShowImageDatabase.find(show => 
      show.title.toLowerCase().includes(title.toLowerCase()) ||
      title.toLowerCase().includes(show.title.toLowerCase())
    );
    
    return match || null;
  }
  
  getProductionImage(title: string, venue?: string, region?: string): string {
    const showImages = this.getShowImages(title, venue, region);
    
    if (showImages && showImages.images.production.length > 0) {
      // Return random production image
      const randomIndex = Math.floor(Math.random() * showImages.images.production.length);
      return showImages.images.production[randomIndex];
    }
    
    // Fallback to high-quality theatre stock images if no production images found
    return this.getTheaterGenericImage(title);
  }
  
  getPosterImage(title: string, venue?: string, region?: string): string {
    const showImages = this.getShowImages(title, venue, region);
    return showImages?.images.poster || this.getTheaterGenericImage(title);
  }
  
  getCastImage(title: string, venue?: string, region?: string): string {
    const showImages = this.getShowImages(title, venue, region);
    
    if (showImages && showImages.images.cast.length > 0) {
      const randomIndex = Math.floor(Math.random() * showImages.images.cast.length);
      return showImages.images.cast[randomIndex];
    }
    
    return this.getTheaterGenericImage(title);
  }
  
  private getTheaterGenericImage(title: string): string {
    // Unsplash licensed theatre images - free for commercial use
    const licensedImages = [
      "https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", // theatre stage - Photo by Felix Mooneeram
      "https://images.unsplash.com/photo-1516715094483-75da06977943?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", // theatre curtains - Photo by Monica Silvestre
      "https://images.unsplash.com/photo-1489641493513-ba4ee84ccea9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", // theatre interior - Photo by Myke Simon
      "https://images.unsplash.com/photo-1503095396549-807759245b35?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", // theatre performance - Photo by Nathana Rebouças
      "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", // theatre lights - Photo by Denise Jans
      "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", // stage lighting
      "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600", // theatre seats
      "https://images.unsplash.com/photo-1551269901-5c5e14c25df7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"  // stage view
    ];
    
    // Use title to consistently select same image for same show
    const hash = title.split('').reduce((a, b) => a + b.charCodeAt(0), 0);
    return licensedImages[hash % licensedImages.length];
  }
  
  getImageCredits(title: string, venue?: string, region?: string): string {
    const showImages = this.getShowImages(title, venue, region);
    return showImages?.photographer || "Theatre Spotlight";
  }
  
  updateShowImageUrl(showId: number, imageType: 'poster' | 'production' | 'cast', imageUrl: string): void {
    // This would update the database with new production images
    console.log(`Updated ${imageType} image for show ${showId}: ${imageUrl}`);
  }
  
  private theatreShowImageDatabase = theatreShowImageDatabase;
}

export const theatreImageService = new TheatreImageService();