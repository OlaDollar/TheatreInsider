import { db } from "./db";
import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface LegalDocument {
  id: string;
  type: 'privacy_policy' | 'terms_of_service' | 'disclaimer' | 'cookies_policy' | 'advertising_policy';
  title: string;
  content: string;
  lastUpdated: Date;
  jurisdiction: 'uk' | 'us' | 'both';
  version: string;
  changes: string[];
}

export class LegalComplianceManager {
  private legalDocuments: LegalDocument[] = [
    {
      id: 'privacy-policy',
      type: 'privacy_policy',
      title: 'Privacy Policy',
      jurisdiction: 'both',
      version: '1.0',
      lastUpdated: new Date(),
      changes: ['Initial version'],
      content: `
# Privacy Policy

**Last Updated:** ${new Date().toLocaleDateString()}

## Introduction

Theatre Spotlight ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website and use our services.

## Information We Collect

### Personal Information
- Email addresses (for newsletter subscriptions)
- Names (optional, for personalized content)
- Location data (to provide region-specific content)
- Account preferences and settings

### Automatically Collected Information
- IP addresses and device information
- Browser type and version
- Pages visited and time spent on site
- Referring websites
- Cookies and similar tracking technologies

### Analytics and Performance Data
- Website usage patterns
- Content engagement metrics
- Search queries within our site
- Email open rates and click-through rates

## How We Use Your Information

### Primary Uses
- Delivering personalized theatre content
- Sending newsletter subscriptions
- Improving website functionality
- Analyzing user preferences for content recommendations

### Marketing Communications
- Weekly newsletter with theatre news and reviews
- Special announcements about shows and performers
- Premium content offers and subscription promotions

## Data Sharing and Disclosure

### Third-Party Services
- Analytics providers (Google Analytics, privacy-compliant alternatives)
- Email service providers (for newsletter delivery)
- Payment processors (for premium subscriptions)
- Advertising partners (see Advertising Policy)

### Legal Requirements
We may disclose information when required by law or to protect our rights.

## Data Retention

- Newsletter data: Retained until unsubscription
- Analytics data: Anonymized after 26 months
- Account data: Deleted upon request

## Your Rights

### UK/EU Users (GDPR)
- Right to access your personal data
- Right to rectification of inaccurate data
- Right to erasure ("right to be forgotten")
- Right to data portability
- Right to object to processing

### US Users (CCPA)
- Right to know what personal information is collected
- Right to delete personal information
- Right to opt-out of sale of personal information
- Right to non-discrimination

## Security Measures

- SSL encryption for all data transmission
- Regular security audits and updates
- Limited access to personal information
- Secure data storage with reputable providers

## Contact Information

For privacy-related inquiries:
- Email: privacy@theatrespotlight.com
- Address: [Business Address]
- Data Protection Officer: [Contact Details]
      `
    },
    {
      id: 'advertising-policy',
      type: 'advertising_policy',
      title: 'Advertising and Sponsored Content Policy',
      jurisdiction: 'both',
      version: '1.0',
      lastUpdated: new Date(),
      changes: ['Initial version'],
      content: `
# Advertising and Sponsored Content Policy

**Last Updated:** ${new Date().toLocaleDateString()}

## Advertising Disclosure

Theatre Spotlight displays various forms of advertising and sponsored content to support our journalism and provide free access to theatre news and reviews.

## Types of Advertising

### Display Advertising
- Banner advertisements from theatre companies, venues, and related businesses
- Clearly marked as "Advertisement" or "Sponsored"
- Placement does not influence editorial content

### Sponsored Content
- Articles or reviews sponsored by theatre productions or venues
- Clearly labeled as "Sponsored Content" or "Paid Partnership"
- Editorial standards maintained regardless of sponsorship

### Affiliate Marketing
- Links to ticket vendors, merchandise, or services may earn commission
- Does not affect editorial independence or review scores
- Marked with "Affiliate Link" where applicable

### Premium Content Promotion
- Paid content may appear higher in search results
- Sponsored listings clearly marked as "Sponsored" or "Featured"
- Free editorial content remains uninfluenced

## Search Result Prioritization

**Important Notice:** Certain search results and content recommendations may be prioritized based on paid partnerships or sponsored arrangements. Such prioritized content will be clearly marked as "Sponsored," "Featured," or "Paid Placement."

### Editorial Independence
- Sponsored content does not influence our editorial opinions
- Reviews and ratings remain objective regardless of advertising relationships
- Clear separation between editorial and commercial content

## Advertiser Standards

### Accepted Advertisers
- Theatre companies and productions
- Performing arts venues
- Theatre-related merchandise and services
- Arts education institutions
- Entertainment and cultural events

### Prohibited Content
- Adult or explicit material
- Gambling or betting services
- Political advertising
- Misleading or false claims
- Content that conflicts with our editorial values

## User Controls

- Users may opt-out of personalized advertising
- Ad-blocking software is permitted
- Premium subscriptions offer reduced advertising
- Newsletter subscribers can control promotional content

## Transparency

All advertising relationships and sponsored content are disclosed in accordance with:
- UK Advertising Standards Authority (ASA) guidelines
- US Federal Trade Commission (FTC) regulations
- Industry best practices for digital media

For advertising inquiries: advertising@theatrespotlight.com
      `
    },
    {
      id: 'terms-of-service',
      type: 'terms_of_service',
      title: 'Terms of Service',
      jurisdiction: 'both',
      version: '1.0',
      lastUpdated: new Date(),
      changes: ['Initial version'],
      content: `
# Terms of Service

**Last Updated:** ${new Date().toLocaleDateString()}

## Acceptance of Terms

By accessing and using Theatre Spotlight, you accept and agree to be bound by these Terms of Service and our Privacy Policy.

## Description of Service

Theatre Spotlight provides theatre news, reviews, performer information, and related content through our website and digital platforms.

## User Obligations

### Acceptable Use
- Use the service for personal, non-commercial purposes
- Respect intellectual property rights
- Provide accurate information when creating accounts
- Comply with applicable laws and regulations

### Prohibited Activities
- Copying or redistributing content without permission
- Attempting to hack or disrupt our systems
- Posting harmful, offensive, or illegal content
- Creating fake accounts or impersonating others

## Intellectual Property

### Our Content
- Original articles, reviews, and analysis are protected by copyright
- User-generated content remains owned by users but licensed to us
- Trademarks and logos are protected intellectual property

### User Content
- You retain ownership of content you submit
- You grant us license to use, modify, and distribute your content
- You are responsible for ensuring you have rights to submit content

## Premium Subscriptions

### Free Access Limitations
- Limited to 2 articles per day for non-subscribers
- Access to article previews (first 30 words) after limit reached
- Full access to basic website features and newsletter

### Premium Benefits
- Unlimited article access
- Exclusive content and early access
- Enhanced performer database features
- Reduced advertising experience

### Billing and Cancellation
- Subscriptions billed monthly or annually
- Cancel anytime through account settings
- Refunds available within 30 days of initial subscription

## Content Standards

### Editorial Content
- Strives for accuracy and fairness
- Opinions are clearly marked as such
- Corrections published when errors are identified
- Editorial independence maintained

### User Submissions
- Subject to moderation and approval
- Must comply with community guidelines
- May be edited for length and clarity
- Rejected submissions may not be published

## Limitation of Liability

### Service Availability
- No guarantee of uninterrupted service
- Maintenance periods may cause temporary unavailability
- Content accuracy not guaranteed

### Damages
- Liability limited to subscription fees paid
- No liability for indirect or consequential damages
- User agrees to indemnify us against claims arising from their use

## Dispute Resolution

### Governing Law
- UK users: English law and jurisdiction
- US users: [State] law and jurisdiction
- International users: English law

### Arbitration
- Disputes resolved through binding arbitration
- Class action waivers where legally permitted
- Right to opt-out of arbitration within 30 days

## Changes to Terms

- Terms may be updated periodically
- Users notified of material changes
- Continued use constitutes acceptance of changes

## Contact Information

For questions about these Terms:
- Email: legal@theatrespotlight.com
- Address: [Business Address]
      `
    },
    {
      id: 'disclaimer',
      type: 'disclaimer',
      title: 'Website Disclaimer',
      jurisdiction: 'both',
      version: '1.0',
      lastUpdated: new Date(),
      changes: ['Initial version'],
      content: `
# Website Disclaimer

**Last Updated:** ${new Date().toLocaleDateString()}

## General Information

The information on Theatre Spotlight is provided for general informational and entertainment purposes only. While we strive for accuracy, we make no warranties about the completeness, reliability, or accuracy of this information.

## Editorial Content

### Reviews and Opinions
- Reviews represent the personal opinions of our critics and contributors
- Opinions may not reflect the views of show producers, venues, or advertisers
- We maintain editorial independence from commercial interests

### News and Information
- News articles based on publicly available information and press releases
- We verify information where possible but cannot guarantee complete accuracy
- Corrections published when errors are identified

## Third-Party Content

### External Links
- Links to external websites provided for convenience
- We do not endorse or control external content
- Users access external sites at their own risk

### User-Generated Content
- Comments and submissions reflect users' personal views
- Content moderated but not pre-approved
- We reserve the right to remove inappropriate content

## Commercial Disclaimers

### Advertising and Sponsorship
- Advertising and sponsored content clearly marked
- Sponsored content prioritization disclosed
- Editorial content remains independent of commercial relationships

### Affiliate Relationships
- Some links may generate commission payments
- Affiliate relationships do not influence editorial content
- Commissions help support our journalism

## Professional Advice

### Entertainment Decisions
- Information provided for general guidance only
- Users should make their own informed decisions about shows and events
- We are not responsible for individual entertainment choices or experiences

### Career Advice
- Career information provided for general guidance
- Professional career decisions should involve qualified advisors
- Success in theatre careers depends on many factors beyond our content

## Limitation of Liability

### Accuracy of Information
- Information provided "as is" without warranties
- Show times, prices, and availability subject to change
- Users should verify information with official sources

### Use of Service
- Use of website at user's own risk
- No liability for technical issues or service interruptions
- No guarantees about website performance or availability

## Legal Compliance

### Defamation Protection
- Content based on publicly available information
- Opinions clearly identified as such
- Right of reply offered to subjects of criticism

### Copyright Protection
- Original content protected by copyright
- Fair use principles applied to quoted material
- DMCA takedown procedures available

## Updates and Changes

This disclaimer may be updated periodically to reflect changes in our practices or legal requirements. Users are encouraged to review regularly.

## Contact Information

For questions about this disclaimer:
- Email: legal@theatrespotlight.com
- Address: [Business Address]
      `
    }
  ];

  async updateLegalDocuments(): Promise<void> {
    console.log('Checking for legal compliance updates...');
    
    try {
      // Check for UK law changes
      await this.checkUKLegalChanges();
      
      // Check for US law changes
      await this.checkUSLegalChanges();
      
      // Update documents if needed
      await this.updateDocumentsIfRequired();
      
      console.log('Legal compliance check completed');
      
    } catch (error) {
      console.error('Error updating legal documents:', error);
    }
  }

  private async checkUKLegalChanges(): Promise<void> {
    // In production, would monitor:
    // - ICO (Information Commissioner's Office) updates
    // - ASA (Advertising Standards Authority) changes
    // - GDPR modifications
    // - Data Protection Act updates
    
    console.log('Checking UK legal changes...');
    // Mock implementation - would use legal API or news feeds
  }

  private async checkUSLegalChanges(): Promise<void> {
    // In production, would monitor:
    // - FTC guidelines updates
    // - CCPA modifications
    // - State privacy law changes
    // - Digital advertising regulations
    
    console.log('Checking US legal changes...');
    // Mock implementation - would use legal API or news feeds
  }

  private async updateDocumentsIfRequired(): Promise<void> {
    // Check if any documents need updates based on legal changes
    const currentDate = new Date();
    
    for (const doc of this.legalDocuments) {
      const daysSinceUpdate = Math.floor(
        (currentDate.getTime() - doc.lastUpdated.getTime()) / (1000 * 60 * 60 * 24)
      );
      
      if (daysSinceUpdate > 30) {
        // Auto-update documents older than 30 days
        await this.refreshDocument(doc);
      }
    }
  }

  private async refreshDocument(doc: LegalDocument): Promise<void> {
    console.log(`Refreshing legal document: ${doc.title}`);
    
    // In production, would use AI to check for required updates
    const updatedContent = await this.generateUpdatedContent(doc);
    
    if (updatedContent !== doc.content) {
      doc.content = updatedContent;
      doc.lastUpdated = new Date();
      doc.version = this.incrementVersion(doc.version);
      doc.changes.push(`Updated ${new Date().toLocaleDateString()}: Compliance refresh`);
      
      console.log(`Updated ${doc.title} to version ${doc.version}`);
    }
  }

  private async generateUpdatedContent(doc: LegalDocument): Promise<string> {
    // In production, would use AI to ensure compliance with latest laws
    return doc.content; // Mock - return existing content
  }

  private incrementVersion(currentVersion: string): string {
    const parts = currentVersion.split('.');
    const patch = parseInt(parts[parts.length - 1]) + 1;
    parts[parts.length - 1] = patch.toString();
    return parts.join('.');
  }

  async getLegalDocument(type: string): Promise<LegalDocument | null> {
    return this.legalDocuments.find(doc => doc.type === type) || null;
  }

  async getAllLegalDocuments(): Promise<LegalDocument[]> {
    return this.legalDocuments;
  }

  async generateComplianceReport(): Promise<{
    status: 'compliant' | 'needs_review' | 'non_compliant';
    issues: string[];
    recommendations: string[];
  }> {
    const issues: string[] = [];
    const recommendations: string[] = [];
    
    // Check document freshness
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    
    for (const doc of this.legalDocuments) {
      if (doc.lastUpdated < thirtyDaysAgo) {
        issues.push(`${doc.title} not updated in 30+ days`);
        recommendations.push(`Review and update ${doc.title} for current legal requirements`);
      }
    }
    
    // Check for required disclaimers
    const hasAdvertisingDisclaimer = this.legalDocuments.some(
      doc => doc.type === 'advertising_policy'
    );
    
    if (!hasAdvertisingDisclaimer) {
      issues.push('Missing advertising disclosure policy');
      recommendations.push('Add comprehensive advertising and sponsored content policy');
    }
    
    const status = issues.length === 0 ? 'compliant' : 
                  issues.length <= 2 ? 'needs_review' : 'non_compliant';
    
    return { status, issues, recommendations };
  }
}

export const legalComplianceManager = new LegalComplianceManager();