import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs/promises";
import path from "path";

const execAsync = promisify(exec);

interface SecurityIssue {
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info';
  category: 'dependency' | 'code' | 'configuration' | 'secret' | 'permissions';
  description: string;
  file?: string;
  line?: number;
  recommendation: string;
}

interface SecurityScanResult {
  passed: boolean;
  issues: SecurityIssue[];
  summary: {
    critical: number;
    high: number;
    medium: number;
    low: number;
    info: number;
  };
  scanTime: Date;
  canDeploy: boolean;
}

export class SecurityScanner {
  private blockerSeverities = ['critical', 'high'];
  private sensitivePatterns = [
    /(?:password|passwd|pwd)\s*[:=]\s*['"]\w+['"]/gi,
    /(?:api[_-]?key|apikey)\s*[:=]\s*['"]\w+['"]/gi,
    /(?:secret|token)\s*[:=]\s*['"]\w+['"]/gi,
    /(?:database[_-]?url|db[_-]?url)\s*[:=]\s*['"]\w+['"]/gi,
    /(?:private[_-]?key|privatekey)\s*[:=]\s*['"]\w+['"]/gi,
    /(?:session[_-]?secret|sessionsecret)\s*[:=]\s*['"]\w+['"]/gi
  ];

  async runFullSecurityScan(): Promise<SecurityScanResult> {
    console.log('Starting comprehensive security scan...');
    
    const issues: SecurityIssue[] = [];
    
    try {
      // 1. Dependency vulnerability scan
      const depIssues = await this.scanDependencies();
      issues.push(...depIssues);
      
      // 2. Source code security scan
      const codeIssues = await this.scanSourceCode();
      issues.push(...codeIssues);
      
      // 3. Configuration security
      const configIssues = await this.scanConfiguration();
      issues.push(...configIssues);
      
      // 4. Secret detection
      const secretIssues = await this.scanForSecrets();
      issues.push(...secretIssues);
      
      // 5. File permissions
      const permissionIssues = await this.scanPermissions();
      issues.push(...permissionIssues);
      
      // Generate summary
      const summary = this.generateSummary(issues);
      const canDeploy = !issues.some(issue => 
        this.blockerSeverities.includes(issue.severity)
      );
      
      console.log(`Security scan completed: ${issues.length} issues found`);
      console.log(`Deployment ${canDeploy ? 'APPROVED' : 'BLOCKED'}`);
      
      return {
        passed: canDeploy,
        issues,
        summary,
        scanTime: new Date(),
        canDeploy
      };
      
    } catch (error) {
      console.error('Security scan failed:', error);
      return {
        passed: false,
        issues: [{
          severity: 'critical',
          category: 'code',
          description: 'Security scan failed to complete',
          recommendation: 'Fix scan errors before deployment',
        }],
        summary: { critical: 1, high: 0, medium: 0, low: 0, info: 0 },
        scanTime: new Date(),
        canDeploy: false
      };
    }
  }

  private async scanDependencies(): Promise<SecurityIssue[]> {
    const issues: SecurityIssue[] = [];
    
    try {
      // Check for known vulnerable dependencies
      const { stdout } = await execAsync('npm audit --json');
      const auditResult = JSON.parse(stdout);
      
      if (auditResult.vulnerabilities) {
        for (const [pkg, vuln] of Object.entries(auditResult.vulnerabilities)) {
          const vulnData = vuln as any;
          
          if (vulnData.severity === 'critical' || vulnData.severity === 'high') {
            issues.push({
              severity: vulnData.severity,
              category: 'dependency',
              description: `Vulnerable dependency: ${pkg} (${vulnData.via[0]?.title || 'Security issue'})`,
              recommendation: `Update ${pkg} to version ${vulnData.fixAvailable ? vulnData.fixAvailable.version : 'latest'} or higher`
            });
          }
        }
      }
      
    } catch (error) {
      // npm audit might fail but not block deployment
      issues.push({
        severity: 'medium',
        category: 'dependency',
        description: 'Could not run dependency vulnerability scan',
        recommendation: 'Manually verify all dependencies are up to date'
      });
    }
    
    return issues;
  }

  private async scanSourceCode(): Promise<SecurityIssue[]> {
    const issues: SecurityIssue[] = [];
    
    try {
      // Scan TypeScript/JavaScript files for common security issues
      const sourceFiles = await this.getSourceFiles();
      
      for (const file of sourceFiles) {
        const content = await fs.readFile(file, 'utf-8');
        const lines = content.split('\n');
        
        lines.forEach((line, index) => {
          // Check for eval() usage
          if (line.includes('eval(')) {
            issues.push({
              severity: 'high',
              category: 'code',
              description: 'Use of eval() function detected',
              file: file,
              line: index + 1,
              recommendation: 'Replace eval() with safer alternatives like JSON.parse() or Function constructor'
            });
          }
          
          // Check for SQL injection risks
          if (line.match(/\$\{.*\}.*(?:SELECT|INSERT|UPDATE|DELETE)/gi)) {
            issues.push({
              severity: 'high',
              category: 'code',
              description: 'Potential SQL injection vulnerability',
              file: file,
              line: index + 1,
              recommendation: 'Use parameterized queries or ORM methods instead of string concatenation'
            });
          }
          
          // Check for XSS risks
          if (line.includes('innerHTML') && line.includes('${')) {
            issues.push({
              severity: 'medium',
              category: 'code',
              description: 'Potential XSS vulnerability with innerHTML',
              file: file,
              line: index + 1,
              recommendation: 'Use textContent or proper escaping for dynamic content'
            });
          }
          
          // Check for weak random number generation
          if (line.includes('Math.random()') && (line.includes('token') || line.includes('secret') || line.includes('password'))) {
            issues.push({
              severity: 'medium',
              category: 'code',
              description: 'Weak random number generation for security-sensitive operation',
              file: file,
              line: index + 1,
              recommendation: 'Use crypto.randomBytes() or crypto.randomUUID() for cryptographically secure random values'
            });
          }
        });
      }
      
    } catch (error) {
      issues.push({
        severity: 'medium',
        category: 'code',
        description: 'Could not complete source code security scan',
        recommendation: 'Manually review code for security issues'
      });
    }
    
    return issues;
  }

  private async scanConfiguration(): Promise<SecurityIssue[]> {
    const issues: SecurityIssue[] = [];
    
    try {
      // Check package.json for security configurations
      const packageJson = await fs.readFile('package.json', 'utf-8');
      const pkg = JSON.parse(packageJson);
      
      // Check for development dependencies in production
      if (pkg.dependencies && Object.keys(pkg.dependencies).some(dep => 
        dep.includes('test') || dep.includes('dev') || dep.includes('mock')
      )) {
        issues.push({
          severity: 'low',
          category: 'configuration',
          description: 'Development dependencies found in production dependencies',
          file: 'package.json',
          recommendation: 'Move development-only packages to devDependencies'
        });
      }
      
      // Check for outdated Node.js version
      if (pkg.engines?.node) {
        const nodeVersion = pkg.engines.node.replace(/[^\d.]/g, '');
        const majorVersion = parseInt(nodeVersion.split('.')[0]);
        if (majorVersion < 18) {
          issues.push({
            severity: 'medium',
            category: 'configuration',
            description: 'Outdated Node.js version specified',
            file: 'package.json',
            recommendation: 'Update to Node.js 18 or later for security updates'
          });
        }
      }
      
      // Check for missing security headers middleware
      const serverFiles = await this.getServerFiles();
      let hasSecurityHeaders = false;
      
      for (const file of serverFiles) {
        const content = await fs.readFile(file, 'utf-8');
        if (content.includes('helmet') || content.includes('X-Frame-Options') || content.includes('Content-Security-Policy')) {
          hasSecurityHeaders = true;
          break;
        }
      }
      
      if (!hasSecurityHeaders) {
        issues.push({
          severity: 'medium',
          category: 'configuration',
          description: 'Missing security headers middleware',
          recommendation: 'Add helmet.js or manually configure security headers (X-Frame-Options, CSP, etc.)'
        });
      }
      
    } catch (error) {
      issues.push({
        severity: 'low',
        category: 'configuration',
        description: 'Could not complete configuration security scan',
        recommendation: 'Manually verify security configurations'
      });
    }
    
    return issues;
  }

  private async scanForSecrets(): Promise<SecurityIssue[]> {
    const issues: SecurityIssue[] = [];
    
    try {
      const sourceFiles = await this.getSourceFiles();
      
      for (const file of sourceFiles) {
        // Skip known safe files
        if (file.includes('node_modules') || file.includes('.git')) {
          continue;
        }
        
        const content = await fs.readFile(file, 'utf-8');
        const lines = content.split('\n');
        
        lines.forEach((line, index) => {
          this.sensitivePatterns.forEach(pattern => {
            if (pattern.test(line)) {
              // Skip if it's clearly a placeholder or example
              if (line.includes('example') || line.includes('placeholder') || 
                  line.includes('your_') || line.includes('YOUR_') ||
                  line.includes('xxx') || line.includes('***')) {
                return;
              }
              
              issues.push({
                severity: 'critical',
                category: 'secret',
                description: 'Potential hardcoded secret detected',
                file: file,
                line: index + 1,
                recommendation: 'Move sensitive values to environment variables or secret management system'
              });
            }
          });
        });
      }
      
    } catch (error) {
      issues.push({
        severity: 'medium',
        category: 'secret',
        description: 'Could not complete secret detection scan',
        recommendation: 'Manually verify no secrets are hardcoded in source files'
      });
    }
    
    return issues;
  }

  private async scanPermissions(): Promise<SecurityIssue[]> {
    const issues: SecurityIssue[] = [];
    
    try {
      // Check file permissions on sensitive files
      const sensitiveFiles = [
        '.env',
        '.env.local',
        '.env.production',
        'server/db.ts',
        'drizzle.config.ts'
      ];
      
      for (const file of sensitiveFiles) {
        try {
          const stats = await fs.stat(file);
          const mode = stats.mode & parseInt('777', 8);
          
          // Check if file is world-readable
          if (mode & parseInt('004', 8)) {
            issues.push({
              severity: 'medium',
              category: 'permissions',
              description: `Sensitive file ${file} is world-readable`,
              file: file,
              recommendation: 'Restrict file permissions to owner only (chmod 600)'
            });
          }
        } catch (error) {
          // File doesn't exist, which is fine for optional files
        }
      }
      
    } catch (error) {
      issues.push({
        severity: 'low',
        category: 'permissions',
        description: 'Could not complete permission scan',
        recommendation: 'Manually verify file permissions on sensitive files'
      });
    }
    
    return issues;
  }

  private async getSourceFiles(): Promise<string[]> {
    const files: string[] = [];
    
    const scanDir = async (dir: string) => {
      try {
        const items = await fs.readdir(dir);
        
        for (const item of items) {
          const fullPath = path.join(dir, item);
          const stats = await fs.stat(fullPath);
          
          if (stats.isDirectory()) {
            if (!item.startsWith('.') && item !== 'node_modules') {
              await scanDir(fullPath);
            }
          } else if (item.match(/\.(ts|js|tsx|jsx)$/)) {
            files.push(fullPath);
          }
        }
      } catch (error) {
        // Directory access issues
      }
    };
    
    await scanDir('.');
    return files;
  }

  private async getServerFiles(): Promise<string[]> {
    const files: string[] = [];
    
    try {
      const serverDir = 'server';
      const items = await fs.readdir(serverDir);
      
      for (const item of items) {
        if (item.match(/\.(ts|js)$/)) {
          files.push(path.join(serverDir, item));
        }
      }
    } catch (error) {
      // Server directory might not exist
    }
    
    return files;
  }

  private generateSummary(issues: SecurityIssue[]): SecurityScanResult['summary'] {
    const summary = {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
      info: 0
    };
    
    issues.forEach(issue => {
      summary[issue.severity]++;
    });
    
    return summary;
  }

  async generateSecurityReport(result: SecurityScanResult): Promise<string> {
    const report = `
# Security Scan Report
**Scan Time:** ${result.scanTime.toISOString()}
**Status:** ${result.canDeploy ? '✅ DEPLOYMENT APPROVED' : '❌ DEPLOYMENT BLOCKED'}

## Summary
- **Critical:** ${result.summary.critical}
- **High:** ${result.summary.high}  
- **Medium:** ${result.summary.medium}
- **Low:** ${result.summary.low}
- **Info:** ${result.summary.info}

## Issues Found

${result.issues.map(issue => `
### ${issue.severity.toUpperCase()}: ${issue.description}
**Category:** ${issue.category}
${issue.file ? `**File:** ${issue.file}${issue.line ? `:${issue.line}` : ''}` : ''}
**Recommendation:** ${issue.recommendation}
`).join('\n')}

## Deployment Decision
${result.canDeploy ? 
  '✅ **APPROVED FOR DEPLOYMENT**\nNo critical or high severity issues found.' : 
  '❌ **DEPLOYMENT BLOCKED**\nCritical or high severity issues must be resolved before deployment.'
}
    `.trim();
    
    return report;
  }
}

export const securityScanner = new SecurityScanner();