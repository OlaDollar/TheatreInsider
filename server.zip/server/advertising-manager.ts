interface AdvertiserProfile {
  name: string;
  industry: 'theatre_production' | 'ticketing' | 'hospitality' | 'travel' | 'luxury' | 'education' | 'streaming';
  budget: 'small' | 'medium' | 'large' | 'enterprise';
  targetAudience: string[];
  adTypes: ('banner' | 'sponsored_content' | 'newsletter' | 'push_notification' | 'video')[];
  geographicFocus: ('uk' | 'us' | 'international')[];
  contactInfo: {
    company: string;
    contact: string;
    email: string;
    phone: string;
    website: string;
  };
  proposedRate: number;
  minimumSpend: number;
  campaignDuration: string;
  expectedROI: string;
}

interface AdCampaign {
  id: string;
  advertiserId: string;
  type: 'banner' | 'sponsored_content' | 'newsletter' | 'native' | 'video';
  placement: string[];
  budget: number;
  duration: number; // days
  startDate: Date;
  endDate: Date;
  targetMetrics: {
    impressions: number;
    clicks: number;
    ctr: number;
    conversions: number;
  };
  creative: {
    headline: string;
    description: string;
    imageUrl: string;
    ctaText: string;
    landingUrl: string;
  };
  performance: {
    impressions: number;
    clicks: number;
    conversions: number;
    revenue: number;
  };
}

export class AdvertisingManager {
  private potentialAdvertisers: AdvertiserProfile[] = [
    // THEATRE PRODUCTIONS (High Budget)
    {
      name: "Cameron Mackintosh Productions",
      industry: "theatre_production",
      budget: "enterprise",
      targetAudience: ["theatre_enthusiasts", "tourists", "families"],
      adTypes: ["banner", "sponsored_content", "newsletter"],
      geographicFocus: ["uk", "international"],
      contactInfo: {
        company: "Cameron Mackintosh Ltd",
        contact: "Marketing Director",
        email: "marketing@mackintosh.co.uk",
        phone: "+44 20 7637 8866",
        website: "https://www.cameronmackintosh.com"
      },
      proposedRate: 2500,
      minimumSpend: 10000,
      campaignDuration: "3-6 months",
      expectedROI: "15-25% ticket sales increase"
    },
    {
      name: "Disney Theatrical Productions",
      industry: "theatre_production", 
      budget: "enterprise",
      targetAudience: ["families", "disney_fans", "tourists"],
      adTypes: ["banner", "sponsored_content", "video"],
      geographicFocus: ["uk", "us", "international"],
      contactInfo: {
        company: "Disney Theatrical Group",
        contact: "Global Marketing",
        email: "theatrical.marketing@disney.com",
        phone: "+1 818 560 1000",
        website: "https://www.disneytheatrical.com"
      },
      proposedRate: 3500,
      minimumSpend: 15000,
      campaignDuration: "6-12 months",
      expectedROI: "20-30% brand awareness increase"
    },
    
    // TICKETING PLATFORMS (Medium-High Budget)
    {
      name: "Ticketmaster",
      industry: "ticketing",
      budget: "large",
      targetAudience: ["all_theatre_goers"],
      adTypes: ["banner", "sponsored_content", "newsletter", "native"],
      geographicFocus: ["uk", "us", "international"],
      contactInfo: {
        company: "Ticketmaster International",
        contact: "Partnership Team",
        email: "partnerships@ticketmaster.com",
        phone: "+44 161 385 3500",
        website: "https://www.ticketmaster.com"
      },
      proposedRate: 1800,
      minimumSpend: 8000,
      campaignDuration: "12 months",
      expectedROI: "10-20% conversion rate"
    },
    {
      name: "TodayTix",
      industry: "ticketing",
      budget: "medium",
      targetAudience: ["young_professionals", "spontaneous_buyers"],
      adTypes: ["banner", "push_notification", "sponsored_content"],
      geographicFocus: ["uk", "us"],
      contactInfo: {
        company: "TodayTix Group",
        contact: "Brand Partnerships",
        email: "partnerships@todaytix.com",
        phone: "+1 855 TODYTIX",
        website: "https://www.todaytix.com"
      },
      proposedRate: 1200,
      minimumSpend: 5000,
      campaignDuration: "6 months",
      expectedROI: "25-35% app downloads"
    },

    // HOSPITALITY & TRAVEL (Medium Budget)
    {
      name: "Premier Inn",
      industry: "hospitality",
      budget: "large",
      targetAudience: ["theatre_tourists", "weekend_breakers"],
      adTypes: ["banner", "sponsored_content", "newsletter"],
      geographicFocus: ["uk"],
      contactInfo: {
        company: "Premier Inn",
        contact: "Digital Marketing",
        email: "partnerships@premierinn.com",
        phone: "+44 871 527 9222",
        website: "https://www.premierinn.com"
      },
      proposedRate: 800,
      minimumSpend: 4000,
      campaignDuration: "6 months",
      expectedROI: "12-18% booking increase"
    },
    {
      name: "Booking.com",
      industry: "travel",
      budget: "enterprise",
      targetAudience: ["international_tourists", "theatre_travelers"],
      adTypes: ["banner", "native", "sponsored_content"],
      geographicFocus: ["international"],
      contactInfo: {
        company: "Booking.com",
        contact: "Partner Marketing",
        email: "partnerships@booking.com",
        phone: "+31 20 722 9792",
        website: "https://partner.booking.com"
      },
      proposedRate: 2200,
      minimumSpend: 12000,
      campaignDuration: "12 months",
      expectedROI: "8-15% booking conversion"
    },

    // STREAMING & DIGITAL (Medium Budget)
    {
      name: "BroadwayHD",
      industry: "streaming",
      budget: "medium",
      targetAudience: ["home_theatre_fans", "international_viewers"],
      adTypes: ["video", "sponsored_content", "newsletter"],
      geographicFocus: ["international"],
      contactInfo: {
        company: "BroadwayHD",
        contact: "Marketing Team",
        email: "partnerships@broadwayhd.com",
        phone: "+1 646 893 4003",
        website: "https://www.broadwayhd.com"
      },
      proposedRate: 600,
      minimumSpend: 3000,
      campaignDuration: "3-6 months",
      expectedROI: "20-30% subscription increase"
    },

    // LUXURY BRANDS (High Budget, Selective)
    {
      name: "Rolex",
      industry: "luxury",
      budget: "enterprise",
      targetAudience: ["affluent_theatre_goers", "opening_night_attendees"],
      adTypes: ["banner", "sponsored_content"],
      geographicFocus: ["uk", "international"],
      contactInfo: {
        company: "Rolex UK",
        contact: "Brand Partnerships",
        email: "partnerships@rolex.com",
        phone: "+44 20 7518 4321",
        website: "https://www.rolex.com"
      },
      proposedRate: 5000,
      minimumSpend: 25000,
      campaignDuration: "6-12 months",
      expectedROI: "Brand association and prestige"
    }
  ];

  async generateAdvertiserPitch(advertiser: AdvertiserProfile): Promise<string> {
    const audienceSize = this.calculateAudienceReach(advertiser.targetAudience);
    const competitiveRate = this.calculateCompetitiveRate(advertiser.industry);
    
    return `
ADVERTISING PARTNERSHIP PROPOSAL
${advertiser.name} x Theatre Spotlight

OPPORTUNITY OVERVIEW:
Partner with Theatre Spotlight, the definitive theatre news platform led by veteran critic Mark Shenton (38+ years industry experience). Launch with exclusive day 1 advertising placement.

TARGET AUDIENCE ALIGNMENT:
${advertiser.targetAudience.map(audience => `• ${audience.replace('_', ' ').toUpperCase()}`).join('\n')}
Estimated reach: ${audienceSize.toLocaleString()} monthly engaged users

PROPOSED ADVERTISING PACKAGE:
Campaign Type: ${advertiser.adTypes.join(', ')}
Geographic Focus: ${advertiser.geographicFocus.join(', ')}
Proposed Investment: £${advertiser.proposedRate}/month
Minimum Commitment: £${advertiser.minimumSpend} (${advertiser.campaignDuration})

UNIQUE VALUE PROPOSITION:
✓ Mark Shenton's 38-year industry credibility and insider access
✓ High-intent audience (users actively researching shows)
✓ Premium content environment (no low-quality ads)
✓ Cross-platform reach (web, mobile app, newsletter, social)
✓ Measurable ROI tracking and detailed analytics

LAUNCH BENEFITS:
• Founding advertiser status and recognition
• 20% discount on first 3 months
• Exclusive category sponsorship options
• Custom content collaboration opportunities
• First access to new advertising products

COMPETITIVE ANALYSIS:
• WhatsOnStage: £${competitiveRate * 1.3}/month (similar package)
• Playbill: £${competitiveRate * 1.5}/month (US focus)
• Theatre Spotlight: £${advertiser.proposedRate}/month (better value + UK expertise)

EXPECTED OUTCOMES:
${advertiser.expectedROI}
Detailed performance reports provided monthly

NEXT STEPS:
1. Schedule 30-minute partnership discussion
2. Review advertising creative guidelines
3. Finalize launch campaign details
4. Begin day 1 implementation

Contact: partnerships@theatrespotlight.com
Direct: +44 7XXX XXX XXX (to be configured)

This is a limited-time founding advertiser opportunity.
    `;
  }

  private calculateAudienceReach(targetAudience: string[]): number {
    // Estimated based on UK theatre attendance and digital engagement
    const baseReach = 50000; // Conservative launch estimate
    const audienceMultiplier = targetAudience.length * 0.8;
    return Math.round(baseReach * audienceMultiplier);
  }

  private calculateCompetitiveRate(industry: string): number {
    const industryRates = {
      theatre_production: 2000,
      ticketing: 1500,
      hospitality: 800,
      travel: 1200,
      luxury: 4000,
      streaming: 600,
      education: 400
    };
    return industryRates[industry] || 1000;
  }

  async createLaunchAdvertiserOutreach(): Promise<{ 
    priorityContacts: AdvertiserProfile[]; 
    emailTemplates: Record<string, string>;
    launchStrategy: string;
  }> {
    // Priority order for day 1 launch
    const priorityContacts = this.potentialAdvertisers
      .sort((a, b) => {
        const priorityScore = (advertiser: AdvertiserProfile) => {
          let score = 0;
          if (advertiser.budget === 'enterprise') score += 5;
          if (advertiser.budget === 'large') score += 3;
          if (advertiser.industry === 'theatre_production') score += 4;
          if (advertiser.industry === 'ticketing') score += 3;
          if (advertiser.geographicFocus.includes('uk')) score += 2;
          return score;
        };
        return priorityScore(b) - priorityScore(a);
      })
      .slice(0, 6); // Top 6 for initial outreach

    const emailTemplates = {
      initial_outreach: `
Subject: Founding Advertiser Opportunity - Theatre Spotlight Launch

Dear [CONTACT_NAME],

I'm reaching out regarding an exclusive advertising opportunity with Theatre Spotlight, launching with veteran theatre critic Mark Shenton.

With 38 years covering West End and Broadway, Mark's new platform offers [COMPANY] a unique opportunity to reach highly engaged theatre audiences from day one.

FOUNDING ADVERTISER BENEFITS:
• Exclusive category placement
• 20% launch discount (3 months)
• Custom content opportunities
• Premium ad positioning

Would you be available for a brief call this week to discuss how [COMPANY] could benefit from this founding partnership?

Best regards,
Theatre Spotlight Partnerships Team

P.S. We're limiting founding advertisers to maintain premium content quality.
      `,

      follow_up: `
Subject: Re: Theatre Spotlight Partnership - Limited Founding Positions

Hi [CONTACT_NAME],

Following up on our Theatre Spotlight founding advertiser opportunity.

We've had strong interest from [COMPETITOR_MENTION] and want to ensure [COMPANY] has the chance to secure their preferred category placement.

Key metrics from our pre-launch:
• 50,000+ anticipated monthly unique visitors
• 85% UK audience (prime theatre market)
• High-intent users actively researching shows

Available for a 15-minute call to discuss?

Best,
Theatre Spotlight Team
      `,

      proposal_attached: `
Subject: Theatre Spotlight Partnership Proposal - [COMPANY]

Dear [CONTACT_NAME],

Attached you'll find our detailed partnership proposal for [COMPANY]'s founding advertiser package.

Key highlights:
• £[RATE]/month investment
• [EXPECTED_ROI] expected return
• Launch within 48 hours of agreement

I'm available today or tomorrow to finalize details and begin creative development.

Looking forward to partnering with [COMPANY] for Theatre Spotlight's launch.

Best regards,
Theatre Spotlight Partnerships
      `
    };

    const launchStrategy = `
THEATRE SPOTLIGHT - DAY 1 ADVERTISER ACQUISITION STRATEGY

PHASE 1 (WEEK 1): PRIMARY OUTREACH
Priority Targets (in order):
1. Cameron Mackintosh Productions (£2,500/month - The Lion King/Phantom)
2. Ticketmaster (£1,800/month - Platform partnership)
3. Disney Theatrical (£3,500/month - Brand association)
4. Premier Inn (£800/month - Theatre tourism)
5. BroadwayHD (£600/month - Content alignment)
6. TodayTix (£1,200/month - Digital-first audience)

PHASE 2 (WEEK 2): FOLLOW-UP & LUXURY
Secondary Targets:
7. Booking.com (£2,200/month - International reach)
8. Rolex (£5,000/month - Prestige positioning)

OUTREACH SEQUENCE:
Day 1: Initial email + LinkedIn message
Day 3: Follow-up call attempt
Day 5: Proposal document
Day 7: Final follow-up with urgency

CONVERSION STRATEGY:
• Limited founding advertiser positions (max 8)
• 20% discount for first 3 months
• Exclusive category sponsorship rights
• Monthly performance guarantees

SUCCESS METRICS:
Target: 3-4 confirmed advertisers for launch
Minimum: £5,000/month combined ad revenue
Stretch: £8,000/month combined ad revenue

CONTINGENCY PLANS:
If primary targets decline:
• Smaller theatre productions (£500-1000/month)
• Regional hotels and restaurants
• Theatre merchandise companies
• Educational institutions (drama schools)

IMPLEMENTATION:
Contact details verified and outreach begins immediately.
Legal advertising terms and creative guidelines prepared.
Payment processing (Stripe) configured for advertiser billing.
    `;

    return {
      priorityContacts,
      emailTemplates,
      launchStrategy
    };
  }

  async generateAdvertisingMediaKit(): Promise<string> {
    return `
THEATRE SPOTLIGHT - ADVERTISING MEDIA KIT

PLATFORM OVERVIEW:
Expert theatre coverage from Mark Shenton, veteran critic with 38 years industry experience covering West End and Broadway productions.

AUDIENCE DEMOGRAPHICS:
• Age: 35-65 (primary), 25-34 (secondary)
• Income: £40k+ household average
• Education: University-educated (75%)
• Location: London (45%), UK (35%), International (20%)
• Gender: 60% female, 40% male
• Theatre attendance: 6+ shows per year average

CONTENT CATEGORIES:
• Breaking theatre news (35% of traffic)
• Show reviews and ratings (25% of traffic)
• Industry analysis and features (20% of traffic)
• Daily crosswords and entertainment (15% of traffic)
• Travel and booking guides (5% of traffic)

ADVERTISING FORMATS:

1. PREMIUM BANNER (728x90 / 300x250)
   • Above-the-fold placement
   • Maximum 2 per page
   • £15 CPM / £800 monthly

2. SPONSORED CONTENT
   • Native article format
   • "Sponsored by [Brand]" disclosure
   • £1,500 per article
   • Distribution across all channels

3. NEWSLETTER SPONSORSHIP
   • 25,000+ subscribers
   • Weekly distribution
   • £500 per inclusion

4. MOBILE APP INTEGRATION
   • PWA installation available
   • Push notification sponsorship
   • £300 per notification campaign

5. SOCIAL MEDIA PACKAGE
   • Cross-platform promotion
   • Twitter, Instagram, Facebook, LinkedIn
   • £400 per campaign

TECHNICAL SPECIFICATIONS:
• Mobile-responsive design mandatory
• Load time <2 seconds required
• GDPR compliant tracking
• No pop-ups or intrusive formats

BRAND SAFETY:
• Premium content environment
• Manual ad review process
• No competing adult/gambling content
• Professional editorial standards

PERFORMANCE TRACKING:
• Real-time analytics dashboard
• Monthly detailed reports
• Click-through rates, impressions, conversions
• Audience engagement metrics

FOUNDING ADVERTISER PACKAGE:
• 20% discount first 3 months
• Category exclusivity
• Custom content collaboration
• Priority placement
• Direct partnership contact

Contact: partnerships@theatrespotlight.com
Media Kit Date: Launch 2025
    `;
  }

  getQuickLaunchAdvertisers(): AdvertiserProfile[] {
    return this.potentialAdvertisers
      .filter(advertiser => 
        advertiser.budget !== 'small' && 
        (advertiser.industry === 'theatre_production' || 
         advertiser.industry === 'ticketing' ||
         advertiser.industry === 'hospitality')
      )
      .slice(0, 4);
  }
}

export const advertisingManager = new AdvertisingManager();