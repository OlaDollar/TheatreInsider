import OpenAI from "openai";

interface TheatreJobRole {
  id: string;
  title: string;
  category: 'creative' | 'technical' | 'production' | 'business' | 'performance';
  briefDescription: string;
  keyResponsibilities: string[];
  typicalEmployers: string[];
  salaryRange: {
    uk: string;
    us: string;
  };
  careerPath: string[];
  requiredSkills: string[];
  qualifications: string[];
  interviewQuestions: string[];
  videoTopics: string[];
  industryContacts: string[];
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export class TheatreJobsGenerator {
  private jobRoles: TheatreJobRole[] = [
    {
      id: 'theatre-director',
      title: 'Theatre Director',
      category: 'creative',
      briefDescription: 'The creative visionary who interprets the script and guides the artistic vision of a production from concept to opening night.',
      keyResponsibilities: [
        'Interpret and develop the artistic vision for productions',
        'Direct actors in rehearsals and performances',
        'Collaborate with designers on set, costume, lighting, and sound',
        'Make casting decisions with producers',
        'Manage rehearsal schedules and creative timelines',
        'Communicate vision to all creative departments'
      ],
      typicalEmployers: [
        'National Theatre',
        'Royal Shakespeare Company',
        'Commercial theatre producers',
        'Regional repertory theatres',
        'Fringe theatre companies',
        'Drama schools and universities'
      ],
      salaryRange: {
        uk: '£25,000-£100,000+ per production',
        us: '$40,000-$150,000+ per production'
      },
      careerPath: [
        'Assistant Director',
        'Associate Director',
        'Director (smaller productions)',
        'Established Director',
        'Leading Director',
        'Artistic Director'
      ],
      requiredSkills: [
        'Strong leadership and communication',
        'Deep understanding of dramatic literature',
        'Collaborative working style',
        'Creative problem-solving',
        'Time management under pressure',
        'Ability to inspire and motivate teams'
      ],
      qualifications: [
        'Drama/Theatre Studies degree (preferred)',
        'Directing course or masterclass',
        'Extensive theatre experience',
        'Portfolio of directing work',
        'Understanding of all technical aspects'
      ],
      interviewQuestions: [
        'How do you approach interpreting a new script?',
        'Describe your directing process from auditions to opening night',
        'How do you handle creative disagreements with actors or designers?',
        'What\'s your vision for this particular production?',
        'How do you balance artistic vision with commercial considerations?'
      ],
      videoTopics: [
        'Behind the scenes of rehearsal process',
        'Collaboration with design teams',
        'Working with different acting styles',
        'Adapting classics for modern audiences',
        'Managing creative and technical teams'
      ],
      industryContacts: [
        'Artistic Directors at major theatres',
        'Casting Directors',
        'Theatre Producers',
        'Drama School Faculty',
        'Theatre Critics and Journalists'
      ]
    },
    {
      id: 'stage-manager',
      title: 'Stage Manager',
      category: 'production',
      briefDescription: 'The organizational backbone of theatrical productions, coordinating all aspects of rehearsals and performances to ensure smooth operations.',
      keyResponsibilities: [
        'Coordinate rehearsal schedules and logistics',
        'Maintain the prompt book with all cues and notes',
        'Call cues during performances',
        'Liaise between creative, technical, and management teams',
        'Ensure health and safety protocols',
        'Manage backstage during performances'
      ],
      typicalEmployers: [
        'West End and Broadway theatres',
        'Regional repertory companies',
        'Touring theatre companies',
        'Opera and ballet companies',
        'Corporate event companies',
        'Television and film productions'
      ],
      salaryRange: {
        uk: '£22,000-£45,000 annually',
        us: '$35,000-$70,000 annually'
      },
      careerPath: [
        'Assistant Stage Manager (ASM)',
        'Deputy Stage Manager (DSM)',
        'Stage Manager',
        'Company Manager',
        'Production Manager',
        'Theatre Manager'
      ],
      requiredSkills: [
        'Exceptional organizational abilities',
        'Clear communication under pressure',
        'Attention to detail',
        'Leadership and diplomacy',
        'Technical theatre knowledge',
        'Problem-solving in real-time'
      ],
      qualifications: [
        'Stage Management qualification',
        'Technical theatre training',
        'First Aid certification',
        'Health and Safety awareness',
        'Experience with theatre software'
      ],
      interviewQuestions: [
        'How do you handle multiple priorities during a busy rehearsal?',
        'Describe a time you solved a backstage emergency',
        'How do you maintain calm under pressure?',
        'What systems do you use for organizing production information?',
        'How do you handle conflicts between departments?'
      ],
      videoTopics: [
        'A day in the life during tech week',
        'Calling cues during a live performance',
        'Rehearsal room management',
        'Emergency procedures backstage',
        'Working with different personality types'
      ],
      industryContacts: [
        'Theatre General Managers',
        'Production Managers',
        'Technical Directors',
        'Venue Operations Managers',
        'Touring Company Managers'
      ]
    },
    {
      id: 'lighting-designer',
      title: 'Lighting Designer',
      category: 'technical',
      briefDescription: 'Creates the lighting concept and design that supports the dramatic narrative and enhances the visual storytelling of productions.',
      keyResponsibilities: [
        'Design lighting plots and concepts',
        'Collaborate with director and set designer',
        'Program lighting consoles and cues',
        'Supervise lighting installation',
        'Attend technical and dress rehearsals',
        'Train operators on lighting systems'
      ],
      typicalEmployers: [
        'Freelance for multiple theatres',
        'Theatre design consultancies',
        'Event production companies',
        'Television and film studios',
        'Concert and festival producers',
        'Architectural lighting firms'
      ],
      salaryRange: {
        uk: '£20,000-£60,000+ per production',
        us: '$30,000-$90,000+ per production'
      },
      careerPath: [
        'Lighting Technician',
        'Assistant Lighting Designer',
        'Lighting Designer',
        'Senior Lighting Designer',
        'Head of Lighting',
        'Design Consultant'
      ],
      requiredSkills: [
        'Artistic vision and color theory',
        'Technical electrical knowledge',
        'CAD and lighting software proficiency',
        'Collaboration and communication',
        'Problem-solving abilities',
        'Understanding of dramatic narrative'
      ],
      qualifications: [
        'Technical theatre or lighting design degree',
        'Electrical safety certification',
        'CAD software training',
        'Portfolio of lighting designs',
        'Understanding of lighting equipment'
      ],
      interviewQuestions: [
        'How do you approach lighting design for different genres?',
        'Describe your collaboration process with directors',
        'How do you balance artistic vision with technical limitations?',
        'What\'s your experience with different lighting technologies?',
        'How do you handle budget constraints in design?'
      ],
      videoTopics: [
        'From concept to installation process',
        'Programming complex lighting sequences',
        'Collaborating with other designers',
        'Using new lighting technologies',
        'Creating mood through lighting'
      ],
      industryContacts: [
        'Theatre Technical Directors',
        'Other Lighting Designers',
        'Equipment Rental Companies',
        'Production Managers',
        'Design Consultancies'
      ]
    },
    {
      id: 'producer',
      title: 'Theatre Producer',
      category: 'business',
      briefDescription: 'The business leader who initiates, finances, and oversees theatrical productions from development through to closure.',
      keyResponsibilities: [
        'Identify and develop new projects',
        'Secure financing and investors',
        'Hire creative and production teams',
        'Oversee budgets and financial management',
        'Coordinate marketing and publicity',
        'Manage legal and contractual obligations'
      ],
      typicalEmployers: [
        'Independent production companies',
        'Theatre chains and operators',
        'Entertainment corporations',
        'Self-employed entrepreneurs',
        'Partnership with other producers',
        'Theatre development organizations'
      ],
      salaryRange: {
        uk: '£30,000-£500,000+ annually',
        us: '$50,000-$1,000,000+ annually'
      },
      careerPath: [
        'Production Assistant',
        'Associate Producer',
        'Line Producer',
        'Producer',
        'Executive Producer',
        'Production Company Owner'
      ],
      requiredSkills: [
        'Business and financial acumen',
        'Networking and relationship building',
        'Project management expertise',
        'Risk assessment abilities',
        'Creative judgment',
        'Negotiation and deal-making'
      ],
      qualifications: [
        'Business or theatre management degree',
        'Legal and financial training',
        'Industry experience and contacts',
        'Understanding of theatre markets',
        'Knowledge of investment structures'
      ],
      interviewQuestions: [
        'How do you evaluate a potential production investment?',
        'Describe your approach to building production teams',
        'How do you balance creative and commercial considerations?',
        'What\'s your experience with international co-productions?',
        'How do you handle productions that exceed budget?'
      ],
      videoTopics: [
        'From script to stage: the producer journey',
        'Securing investment and financing',
        'Building creative partnerships',
        'Managing production crises',
        'International co-production strategies'
      ],
      industryContacts: [
        'Investors and Financial Backers',
        'Theatre Owners and Operators',
        'Artistic Directors',
        'Entertainment Lawyers',
        'Marketing and PR Agencies'
      ]
    },
    {
      id: 'costume-designer',
      title: 'Costume Designer',
      category: 'creative',
      briefDescription: 'Creates the visual identity of characters through clothing, makeup, and accessories that support the story and director\'s vision.',
      keyResponsibilities: [
        'Research and develop costume concepts',
        'Design costumes for all characters',
        'Collaborate with director and other designers',
        'Oversee costume construction and fittings',
        'Manage costume budgets and schedules',
        'Supervise wardrobe during production run'
      ],
      typicalEmployers: [
        'Freelance for theatre companies',
        'Costume rental houses',
        'Opera and ballet companies',
        'Film and television productions',
        'Theme parks and attractions',
        'Fashion and retail companies'
      ],
      salaryRange: {
        uk: '£15,000-£50,000+ per production',
        us: '$25,000-$75,000+ per production'
      },
      careerPath: [
        'Costume Assistant',
        'Wardrobe Supervisor',
        'Assistant Costume Designer',
        'Costume Designer',
        'Senior Costume Designer',
        'Head of Costume'
      ],
      requiredSkills: [
        'Artistic vision and fashion sense',
        'Historical and cultural research',
        'Sewing and construction knowledge',
        'Budgeting and project management',
        'Collaboration and communication',
        'Understanding of movement and performance'
      ],
      qualifications: [
        'Fashion design or costume design degree',
        'Portfolio of costume designs',
        'Pattern-making and construction skills',
        'Art history and cultural knowledge',
        'CAD and design software proficiency'
      ],
      interviewQuestions: [
        'How do you research historical periods for authenticity?',
        'Describe your process for character development through costume',
        'How do you handle quick changes and practical considerations?',
        'What\'s your approach to working within tight budgets?',
        'How do you collaborate with actors on costume fittings?'
      ],
      videoTopics: [
        'From concept sketches to finished costumes',
        'Historical research and accuracy',
        'Working with performers on character development',
        'Managing quick changes backstage',
        'Sustainable and budget-conscious design'
      ],
      industryContacts: [
        'Costume Rental Companies',
        'Fabric and Notions Suppliers',
        'Other Costume Designers',
        'Wardrobe Supervisors',
        'Theatre Seamstresses and Tailors'
      ]
    }
  ];

  async generateCareerGuide(jobRole: TheatreJobRole): Promise<string> {
    const prompt = `
Create an ORIGINAL career guide titled "How to Become a ${jobRole.title}" with completely unique content. This must be 100% original work with no copied text or plagiarized content from existing career guides or recruitment materials.

ORIGINALITY REQUIREMENTS:
- Write entirely new content from scratch
- Use unique examples and case studies
- Create original exercises and practical advice
- Develop fresh perspectives on career development
- No copying from existing career guides or recruitment materials

Job Role: ${jobRole.title}
Description: ${jobRole.briefDescription}
Key Responsibilities: ${jobRole.keyResponsibilities.join(', ')}
Required Skills: ${jobRole.requiredSkills.join(', ')}
Career Path: ${jobRole.careerPath.join(' → ')}
Typical Employers: ${jobRole.typicalEmployers.join(', ')}
Salary Range: UK: ${jobRole.salaryRange.uk}, US: ${jobRole.salaryRange.us}

Write an original 15,000+ word career guide with these unique chapters:
1. "Discovering Your Path" - Original introduction to the role
2. "The Reality of the Role" - Authentic daily experience descriptions
3. "Building Your Foundation" - Original skill development strategies
4. "Breaking Into the Industry" - Unique entry route advice
5. "Gaining Momentum" - Fresh early career guidance
6. "Climbing the Ladder" - Original advancement strategies
7. "Mastering Applications" - Unique portfolio and interview advice
8. "Professional Excellence" - Original industry practice insights
9. "Navigating Challenges" - Honest, original career insights
10. "Your Support Network" - Original resource compilation

CONTENT MUST BE:
- Completely original and unique
- Based on authentic industry knowledge
- Free from any plagiarized material
- Written in a fresh, engaging style
- Practical and actionable throughout

Include original examples, unique case studies, fresh quotes from hypothetical industry professionals, and innovative exercises. Ensure all content is completely original and plagiarism-free.
`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert career guidance writer creating 100% original content. Every word must be unique and plagiarism-free. Never copy or paraphrase existing career guides. Create entirely fresh, original content for theatre industry careers."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        max_tokens: 4000,
        temperature: 0.9, // Higher temperature for more original content
      });

      const content = response.choices[0].message.content || '';
      
      // Run plagiarism check on generated content
      const { plagiarismChecker } = await import("./plagiarism-checker");
      const plagiarismResult = await plagiarismChecker.checkContent(
        `How to Become a ${jobRole.title}`,
        content
      );

      if (!plagiarismResult.isOriginal) {
        console.warn(`PLAGIARISM DETECTED in career guide for ${jobRole.title}: Score ${plagiarismResult.riskScore}/20`);
        
        // Regenerate with even stricter originality requirements
        const retryPrompt = `
URGENT: Create a completely NEW and ORIGINAL career guide for ${jobRole.title} with zero plagiarism.

Previous attempt had plagiarism issues. This version must be:
- 100% original content with unique phrasing
- No similarities to existing career guides
- Fresh perspective and innovative approach
- Original examples and case studies
- Unique structure and flow

Write an entirely new 15,000+ word guide that is completely different from any existing career guidance materials. Use innovative language, unique metaphors, and fresh approaches to career advice.

Focus on practical, actionable content that is completely original.
`;

        const retryResponse = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            {
              role: "system",
              content: "Create 100% plagiarism-free, completely original career guidance content. Use unique language, fresh perspectives, and innovative approaches. Never reference or copy existing materials."
            },
            {
              role: "user",
              content: retryPrompt
            }
          ],
          max_tokens: 4000,
          temperature: 1.0, // Maximum creativity for originality
        });

        return retryResponse.choices[0].message.content || '';
      }

      console.log(`✅ Career guide for ${jobRole.title} passed plagiarism check: Score ${plagiarismResult.riskScore}/20`);
      return content;
    } catch (error) {
      console.error('Error generating plagiarism-free career guide:', error);
      throw new Error('Failed to generate original career guide');
    }
  }

  async generateTeaserArticle(jobRole: TheatreJobRole): Promise<{
    title: string;
    content: string;
    excerpt: string;
    tags: string[];
  }> {
    const prompt = `
Write an engaging teaser article about the role of ${jobRole.title} in theatre, based on insights from John Caird's "Theatre Craft" and industry knowledge.

Role: ${jobRole.title}
Description: ${jobRole.briefDescription}
Key Responsibilities: ${jobRole.keyResponsibilities.join(', ')}

Create a 800-1000 word article that:
- Explains what a ${jobRole.title} actually does in accessible terms
- Includes fascinating behind-the-scenes insights
- References the collaborative nature of theatre
- Mentions career opportunities and growth potential
- Ends with a teaser about our upcoming "How to Become a ${jobRole.title}" career guide

Write in Mark Shenton's engaging, knowledgeable style. Include specific examples and industry anecdotes where appropriate. Make it informative but entertaining for both theatre professionals and enthusiasts.

Structure:
- Compelling headline
- Engaging opening paragraph
- 3-4 main body sections
- Strong conclusion with career guide teaser
- Relevant tags for SEO
`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are Mark Shenton, the authoritative theatre critic and journalist. Write in your knowledgeable, engaging style that combines industry insight with accessibility for theatre lovers."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        max_tokens: 1500,
        temperature: 0.8
      });

      const content = response.choices[0].message.content || '';
      const lines = content.split('\n');
      const title = lines[0].replace(/^#+\s*/, '').trim();
      const mainContent = lines.slice(1).join('\n').trim();
      const excerpt = mainContent.substring(0, 200) + '...';

      return {
        title,
        content: mainContent,
        excerpt,
        tags: [
          'theatre jobs',
          'career guidance',
          jobRole.title.toLowerCase().replace(/\s+/g, '-'),
          jobRole.category,
          'theatre industry',
          'professional development'
        ]
      };
    } catch (error) {
      console.error('Error generating teaser article:', error);
      throw new Error('Failed to generate teaser article');
    }
  }

  async createJobsSection(): Promise<{
    articles: any[];
    careerGuides: { jobId: string; guide: string; originalityScore: number }[];
  }> {
    console.log('🎭 Creating plagiarism-free theatre jobs section...');

    const articles = [];
    const careerGuides = [];

    for (const jobRole of this.jobRoles) {
      try {
        console.log(`📝 Generating original content for ${jobRole.title}...`);

        // Generate teaser article
        const article = await this.generateTeaserArticle(jobRole);
        
        // Plagiarism check for teaser article
        const { plagiarismChecker } = await import("./plagiarism-checker");
        const articleCheck = await plagiarismChecker.checkContent(article.title, article.content);
        
        if (!articleCheck.isOriginal) {
          console.warn(`⚠️ Article plagiarism risk for ${jobRole.title}: Score ${articleCheck.riskScore}/20`);
          // Skip this article or regenerate
          continue;
        }

        articles.push({
          ...article,
          category: 'jobs',
          region: 'both',
          author: 'Mark Shenton',
          jobRole: jobRole.id,
          imageUrl: `https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80`
        });

        // Generate comprehensive career guide with plagiarism protection
        const guide = await this.generateCareerGuide(jobRole);
        
        // Final plagiarism verification for career guide
        const guideCheck = await plagiarismChecker.checkContent(
          `How to Become a ${jobRole.title}`,
          guide
        );

        careerGuides.push({
          jobId: jobRole.id,
          guide,
          originalityScore: 20 - guideCheck.riskScore // Higher score = more original
        });

        console.log(`✅ Generated original content for ${jobRole.title} (Originality: ${20 - guideCheck.riskScore}/20)`);
        
        // Brief pause to respect API limits and allow processing
        await new Promise(resolve => setTimeout(resolve, 2000));
      } catch (error) {
        console.error(`❌ Failed to generate content for ${jobRole.title}:`, error);
      }
    }

    // Filter out low-originality guides
    const originalGuides = careerGuides.filter(guide => guide.originalityScore >= 15);
    
    console.log(`🎯 Generated ${originalGuides.length} plagiarism-free career guides with high originality scores`);

    return { articles, careerGuides: originalGuides };
  }

  getJobRoles(): TheatreJobRole[] {
    return this.jobRoles;
  }

  getJobRole(id: string): TheatreJobRole | null {
    return this.jobRoles.find(role => role.id === id) || null;
  }

  getJobsByCategory(category: TheatreJobRole['category']): TheatreJobRole[] {
    return this.jobRoles.filter(role => role.category === category);
  }

  async generateInterviewQuestions(jobTitle: string, intervieweeBackground: string): Promise<string[]> {
    const jobRole = this.jobRoles.find(role => role.title.toLowerCase().includes(jobTitle.toLowerCase()));
    
    if (!jobRole) {
      return [
        'How did you get started in theatre?',
        'What does a typical day look like in your role?',
        'What advice would you give to someone starting out?',
        'What are the biggest challenges in your field?',
        'How has the industry changed during your career?'
      ];
    }

    const baseQuestions = jobRole.interviewQuestions;
    const customPrompt = `
Generate 5 additional personalized interview questions for a ${jobRole.title} with this background: ${intervieweeBackground}

Base questions already covered: ${baseQuestions.join(', ')}

Focus on:
- Their specific career journey
- Unique insights from their experience
- Current industry trends and challenges
- Practical advice for newcomers
- Personal anecdotes and behind-the-scenes stories

Return only the questions, numbered 1-5.
`;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an experienced theatre journalist creating insightful interview questions."
          },
          {
            role: "user",
            content: customPrompt
          }
        ],
        max_tokens: 300,
        temperature: 0.8
      });

      const customQuestions = response.choices[0].message.content?.split('\n')
        .filter(line => line.trim().length > 0)
        .map(line => line.replace(/^\d+\.?\s*/, '').trim()) || [];

      return [...baseQuestions, ...customQuestions];
    } catch (error) {
      console.error('Error generating custom interview questions:', error);
      return baseQuestions;
    }
  }
}

export const theatreJobsGenerator = new TheatreJobsGenerator();