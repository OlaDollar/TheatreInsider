import { db } from "./db";
import { shows } from "@shared/schema";
import { eq, and, like, sql } from "drizzle-orm";
import { affiliateManager } from "./affiliate-manager";

interface WhatsOnShow {
  id: number;
  title: string;
  venue: string;
  region: 'uk' | 'us';
  venueType: 'west_end' | 'off_west_end' | 'broadway' | 'off_broadway' | 'regional' | 'national';
  genre: 'musical' | 'play' | 'cabaret' | 'concert' | 'opera' | 'dance' | 'comedy';
  status: 'running' | 'preview' | 'announced' | 'closed' | 'suspended';
  description: string;
  ticketUrl: string;
  officialWebsite: string;
  imageUrl: string;
  director?: string;
  composer?: string;
  cast: string[];
  duration?: string;
  ageRating?: string;
  popularity: number;
  openingDate?: Date;
  closingDate?: Date;
  priceRange?: {
    min: number;
    max: number;
    currency: 'GBP' | 'USD';
  };
  affiliateLinks?: {
    tickets: string;
    hotels: string;
    travel: string;
  };
  ticketAvailability: 'available' | 'limited' | 'sold_out' | 'not_on_sale';
  similarShows?: WhatsOnShow[];
  lastUpdated: Date;
}

interface WhatsOnFilters {
  region?: 'uk' | 'us' | 'both';
  venueType?: string[];
  genre?: string[];
  status?: string[];
  priceRange?: {
    min?: number;
    max?: number;
  };
  searchTerm?: string;
}

export class WhatsOnManager {
  
  async getWhatsOn(filters: WhatsOnFilters = {}): Promise<{
    uk: WhatsOnShow[];
    us: WhatsOnShow[];
    total: number;
    lastUpdated: Date;
  }> {
    console.log('📅 Fetching What\'s On listings...');
    
    const allShows = await this.fetchCurrentShows(filters);
    
    // Separate by region
    const ukShows = allShows.filter(show => show.region === 'uk');
    const usShows = allShows.filter(show => show.region === 'us');
    
    // Add affiliate links
    const enrichedUKShows = await this.addAffiliateLinks(ukShows, 'uk');
    const enrichedUSShows = await this.addAffiliateLinks(usShows, 'us');
    
    return {
      uk: enrichedUKShows,
      us: enrichedUSShows,
      total: allShows.length,
      lastUpdated: new Date()
    };
  }

  private async fetchCurrentShows(filters: WhatsOnFilters): Promise<WhatsOnShow[]> {
    let query = db.select().from(shows);
    
    // Apply filters
    const conditions = [];
    
    if (filters.region && filters.region !== 'both') {
      conditions.push(eq(shows.region, filters.region));
    }
    
    if (filters.status && filters.status.length > 0) {
      conditions.push(sql`${shows.status} IN (${sql.join(filters.status.map(s => sql`${s}`), sql`,`)})`);
    } else {
      // Default to only running and preview shows (exclude closed)
      conditions.push(sql`${shows.status} IN ('running', 'preview', 'announced')`);
    }
    
    if (filters.searchTerm) {
      conditions.push(
        sql`(${shows.title} ILIKE ${'%' + filters.searchTerm + '%'} OR ${shows.venue} ILIKE ${'%' + filters.searchTerm + '%'})`
      );
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    const results = await query;
    
    const transformedShows = results.map(show => this.transformShow(show));
    
    // Add similar shows for sold out shows
    for (const show of transformedShows) {
      if (show.ticketAvailability === 'sold_out') {
        show.similarShows = await this.findSimilarShows(show, transformedShows);
      }
    }
    
    return transformedShows;
  }

  private transformShow(show: any): WhatsOnShow {
    return {
      id: show.id,
      title: show.title,
      venue: show.venue,
      region: show.region,
      venueType: this.categorizeVenueType(show.venue, show.region, show.venue_type),
      genre: this.categorizeGenre(show.genre, show.title),
      status: show.status,
      description: show.description,
      ticketUrl: show.ticketUrl,
      officialWebsite: show.officialWebsite,
      imageUrl: show.imageUrl,
      director: show.director,
      composer: show.composer,
      cast: show.cast || [],
      duration: show.duration,
      ageRating: show.ageRating,
      popularity: show.popularity,
      priceRange: this.estimatePriceRange(show.title, show.venue, show.region),
      ticketAvailability: this.checkTicketAvailability(show.title, show.venue, show.popularity),
      lastUpdated: new Date()
    };
  }

  private categorizeVenueType(venue: string, region: 'uk' | 'us', venueType?: string): WhatsOnShow['venueType'] {
    if (venueType) {
      return venueType as WhatsOnShow['venueType'];
    }
    
    // UK venue categorization
    if (region === 'uk') {
      const westEndVenues = [
        'lyceum theatre', 'apollo victoria', 'his majesty\'s theatre', 'victoria palace',
        'phoenix theatre', 'cambridge theatre', 'prince of wales theatre', 'gielgud theatre',
        'duchess theatre', 'fortune theatre', 'garrick theatre', 'criterion theatre'
      ];
      
      if (westEndVenues.some(v => venue.toLowerCase().includes(v))) {
        return 'west_end';
      }
      
      if (venue.toLowerCase().includes('royal') || venue.toLowerCase().includes('national')) {
        return 'national';
      }
      
      return 'off_west_end';
    }
    
    // US venue categorization
    if (region === 'us') {
      const broadwayVenues = [
        'richard rodgers', 'minskoff', 'gershwin', 'majestic', 'broadhurst', 'imperial',
        'palace theatre', 'st. james', 'winter garden', 'lunt-fontanne', 'nederlander'
      ];
      
      if (broadwayVenues.some(v => venue.toLowerCase().includes(v))) {
        return 'broadway';
      }
      
      if (venue.toLowerCase().includes('off-broadway') || venue.toLowerCase().includes('off broadway')) {
        return 'off_broadway';
      }
      
      return 'regional';
    }
    
    return 'regional';
  }

  private categorizeGenre(genre?: string, title?: string): WhatsOnShow['genre'] {
    if (!genre && !title) return 'musical';
    
    const text = `${genre} ${title}`.toLowerCase();
    
    if (text.includes('cabaret') || text.includes('54 below') || text.includes('crazy coqs')) {
      return 'cabaret';
    }
    
    if (text.includes('concert') || text.includes('symphony') || text.includes('philharmonic')) {
      return 'concert';
    }
    
    if (text.includes('opera')) {
      return 'opera';
    }
    
    if (text.includes('dance') || text.includes('ballet')) {
      return 'dance';
    }
    
    if (text.includes('comedy') || text.includes('stand-up')) {
      return 'comedy';
    }
    
    if (text.includes('play') && !text.includes('musical')) {
      return 'play';
    }
    
    return 'musical'; // Default
  }

  private estimatePriceRange(title: string, venue: string, region: 'uk' | 'us'): WhatsOnShow['priceRange'] {
    // Premium shows (higher prices)
    const premiumShows = ['hamilton', 'lion king', 'wicked', 'phantom', 'frozen'];
    const isPremium = premiumShows.some(show => title.toLowerCase().includes(show));
    
    if (region === 'uk') {
      if (isPremium) {
        return { min: 45, max: 150, currency: 'GBP' };
      }
      return { min: 25, max: 85, currency: 'GBP' };
    } else {
      if (isPremium) {
        return { min: 79, max: 299, currency: 'USD' };
      }
      return { min: 49, max: 149, currency: 'USD' };
    }
  }

  private async addAffiliateLinks(shows: WhatsOnShow[], region: 'uk' | 'us'): Promise<WhatsOnShow[]> {
    return shows.map(show => {
      const ticketLinks = affiliateManager.generateTicketLinks(show.title, show.venue, region);
      const hotelLinks = affiliateManager.generateHotelLinks(show.venue, region);
      
      return {
        ...show,
        affiliateLinks: {
          tickets: ticketLinks[0]?.affiliateUrl || show.ticketUrl,
          hotels: hotelLinks[0]?.affiliateUrl || '',
          travel: `/trip-planner?show=${encodeURIComponent(show.title)}&venue=${encodeURIComponent(show.venue)}`
        }
      };
    });
  }

  async getShowsByLocation(region: 'uk' | 'us', venueType?: string[]): Promise<WhatsOnShow[]> {
    const filters: WhatsOnFilters = { region };
    if (venueType && venueType.length > 0) {
      filters.venueType = venueType;
    }
    
    const result = await this.getWhatsOn(filters);
    return region === 'uk' ? result.uk : result.us;
  }

  async getShowsByGenre(genre: string[], region?: 'uk' | 'us'): Promise<WhatsOnShow[]> {
    const filters: WhatsOnFilters = { genre, region };
    
    const result = await this.getWhatsOn(filters);
    const allShows = [...result.uk, ...result.us];
    
    return allShows.filter(show => genre.includes(show.genre));
  }

  async searchShows(searchTerm: string, filters?: WhatsOnFilters): Promise<WhatsOnShow[]> {
    const searchFilters = { ...filters, searchTerm };
    
    const result = await this.getWhatsOn(searchFilters);
    return [...result.uk, ...result.us];
  }

  async getFeaturedShows(limit: number = 6): Promise<{
    uk: WhatsOnShow[];
    us: WhatsOnShow[];
  }> {
    const result = await this.getWhatsOn();
    
    // Sort by popularity and take top shows
    const topUK = result.uk
      .sort((a, b) => b.popularity - a.popularity)
      .slice(0, Math.ceil(limit / 2));
      
    const topUS = result.us
      .sort((a, b) => b.popularity - a.popularity)
      .slice(0, Math.floor(limit / 2));
    
    return { uk: topUK, us: topUS };
  }

  async updateShowsData(): Promise<{ updated: number; errors: string[] }> {
    console.log('🔄 Updating What\'s On data...');
    
    let updated = 0;
    const errors: string[] = [];
    
    try {
      // This would typically fetch from external APIs or update from press releases
      // For now, we'll update existing shows with fresh data
      
      const allShows = await db.select().from(shows);
      
      for (const show of allShows) {
        try {
          // Update popularity based on recent activity (simplified)
          const newPopularity = Math.max(10, show.popularity + Math.floor(Math.random() * 10 - 5));
          
          await db.update(shows)
            .set({ 
              popularity: newPopularity,
              // updatedAt would be here if we had that field
            })
            .where(eq(shows.id, show.id));
          
          updated++;
        } catch (error) {
          errors.push(`Failed to update ${show.title}: ${error.message}`);
        }
      }
      
      console.log(`✅ Updated ${updated} shows`);
      
    } catch (error) {
      errors.push(`Update failed: ${error.message}`);
    }
    
    return { updated, errors };
  }

  private checkTicketAvailability(title: string, venue: string, popularity: number): WhatsOnShow['ticketAvailability'] {
    // High demand shows are more likely to be sold out
    const highDemandShows = ['hamilton', 'lion king', 'wicked', 'phantom'];
    const isHighDemand = highDemandShows.some(show => title.toLowerCase().includes(show));
    
    // Simulate availability based on popularity and demand
    if (isHighDemand && popularity > 90) {
      return Math.random() > 0.7 ? 'sold_out' : 'limited';
    } else if (popularity > 85) {
      return Math.random() > 0.8 ? 'limited' : 'available';
    } else if (popularity < 30) {
      return 'available';
    }
    
    // Random availability for others
    const rand = Math.random();
    if (rand > 0.95) return 'sold_out';
    if (rand > 0.85) return 'limited';
    return 'available';
  }

  private async findSimilarShows(targetShow: WhatsOnShow, allShows: WhatsOnShow[]): Promise<WhatsOnShow[]> {
    const similarShows = allShows
      .filter(show => 
        show.id !== targetShow.id && 
        show.ticketAvailability !== 'sold_out' &&
        show.region === targetShow.region
      )
      .map(show => ({
        ...show,
        similarity: this.calculateSimilarity(targetShow, show)
      }))
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, 3)
      .map(({ similarity, ...show }) => show);
    
    return similarShows;
  }

  private calculateSimilarity(show1: WhatsOnShow, show2: WhatsOnShow): number {
    let score = 0;
    
    // Same genre = +3 points
    if (show1.genre === show2.genre) score += 3;
    
    // Same venue type = +2 points
    if (show1.venueType === show2.venueType) score += 2;
    
    // Similar popularity = +1 point
    const popularityDiff = Math.abs(show1.popularity - show2.popularity);
    if (popularityDiff < 20) score += 1;
    
    // Same composer = +2 points
    if (show1.composer && show2.composer && show1.composer === show2.composer) score += 2;
    
    // Similar title words = +1 point
    const words1 = show1.title.toLowerCase().split(' ');
    const words2 = show2.title.toLowerCase().split(' ');
    const commonWords = words1.filter(word => words2.includes(word) && word.length > 3);
    if (commonWords.length > 0) score += 1;
    
    return score;
  }

  getVenueTypeOptions(region: 'uk' | 'us'): Array<{ value: string; label: string }> {
    if (region === 'uk') {
      return [
        { value: 'west_end', label: 'West End' },
        { value: 'off_west_end', label: 'Off-West End' },
        { value: 'national', label: 'National Theatre' },
        { value: 'regional', label: 'Regional' }
      ];
    } else {
      return [
        { value: 'broadway', label: 'Broadway' },
        { value: 'off_broadway', label: 'Off-Broadway' },
        { value: 'regional', label: 'Regional' }
      ];
    }
  }

  getGenreOptions(): Array<{ value: string; label: string }> {
    return [
      { value: 'musical', label: 'Musical' },
      { value: 'play', label: 'Play' },
      { value: 'cabaret', label: 'Cabaret' },
      { value: 'concert', label: 'Concert' },
      { value: 'opera', label: 'Opera' },
      { value: 'dance', label: 'Dance' },
      { value: 'comedy', label: 'Comedy' }
    ];
  }
}

export const whatsOnManager = new WhatsOnManager();