import { db } from "./db";
import { shows, articles, reviews } from "@shared/schema";
import { eq } from "drizzle-orm";
import fs from "fs/promises";
import path from "path";

interface MediaFile {
  id: string;
  type: 'image' | 'video';
  category: 'poster' | 'production' | 'cast' | 'backstage' | 'promotional' | 'trailer';
  filename: string;
  originalName: string;
  size: number;
  mimeType: string;
  url: string;
  localPath?: string;
  showId?: number;
  photographer?: string;
  copyright?: string;
  description?: string;
  uploadedAt: Date;
}

interface MediaPreview {
  id: string;
  filename: string;
  size: number;
  type: 'image' | 'video';
  category: 'poster' | 'production' | 'cast' | 'backstage' | 'promotional' | 'trailer';
  thumbnailUrl: string;
  source: string;
  sourceType: 'local_file' | 'url' | 'server_path' | 'cdn_path';
  selected: boolean;
  isDuplicate: boolean;
  duplicateCount?: number;
  metadata: {
    mimeType: string;
    dimensions?: string;
    duration?: string;
  };
}

interface PressPackManifest {
  showTitle: string;
  venue: string;
  region: 'uk' | 'us' | 'both';
  season: string;
  photographer: string;
  copyright: string;
  contactEmail: string;
  files: {
    images: {
      posters: string[];
      production: string[];
      cast: string[];
      backstage: string[];
    };
    videos: {
      trailers: string[];
      behindScenes: string[];
      interviews: string[];
    };
  };
}

interface UploadSource {
  type: 'local_file' | 'url' | 'server_path' | 'cdn_path';
  source: string;
  headers?: Record<string, string>;
  credentials?: {
    username?: string;
    password?: string;
    apiKey?: string;
  };
}

export class MediaUploadManager {
  private uploadDir = '/home/runner/workspace/uploads';
  private allowedImageTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
  private allowedVideoTypes = ['video/mp4', 'video/webm', 'video/mov', 'video/avi'];
  private maxFileSize = 100 * 1024 * 1024; // 100MB

  constructor() {
    this.ensureUploadDirectory();
  }

  async previewPressPackFiles(
    sources: UploadSource[]
  ): Promise<{
    success: boolean;
    previews: MediaPreview[];
    errors: string[];
  }> {
    console.log(`🔍 Previewing ${sources.length} sources for selection...`);
    
    const previews: MediaPreview[] = [];
    const errors: string[] = [];

    for (const source of sources) {
      try {
        const sourcepreviews = await this.generatePreviewsFromSource(source);
        previews.push(...sourcepreviews);
      } catch (error) {
        errors.push(`Failed to preview ${source.source}: ${error.message}`);
      }
    }

    // Remove duplicates based on filename and size
    const uniquePreviews = this.removeDuplicatePreviews(previews);
    
    console.log(`📋 Found ${uniquePreviews.length} unique files for review`);
    
    return {
      success: uniquePreviews.length > 0,
      previews: uniquePreviews,
      errors
    };
  }

  private async generatePreviewsFromSource(source: UploadSource): Promise<MediaPreview[]> {
    switch (source.type) {
      case 'server_path':
        return this.previewServerPath(source.source);
      
      case 'url':
        return this.previewUrl(source.source);
      
      case 'cdn_path':
        return this.previewCdnPath(source.source);
      
      default:
        return [];
    }
  }

  private async previewServerPath(serverPath: string): Promise<MediaPreview[]> {
    try {
      const stats = await fs.stat(serverPath);
      const previews: MediaPreview[] = [];
      
      if (stats.isDirectory()) {
        const files = await fs.readdir(serverPath);
        
        for (const file of files) {
          const filePath = path.join(serverPath, file);
          const fileStats = await fs.stat(filePath);
          
          if (fileStats.isFile()) {
            const preview = await this.createFilePreview(filePath, file, fileStats.size);
            if (preview) previews.push(preview);
          }
        }
      } else {
        const filename = path.basename(serverPath);
        const preview = await this.createFilePreview(serverPath, filename, stats.size);
        if (preview) previews.push(preview);
      }
      
      return previews;
    } catch (error) {
      throw new Error(`Failed to preview server path: ${error.message}`);
    }
  }

  private async previewUrl(url: string): Promise<MediaPreview[]> {
    try {
      const response = await fetch(url, { method: 'HEAD' });
      const contentType = response.headers.get('content-type') || '';
      const contentLength = parseInt(response.headers.get('content-length') || '0');
      const filename = this.extractFilenameFromUrl(url) || 'downloaded_file';
      
      const preview: MediaPreview = {
        id: this.generateMediaId(),
        filename,
        size: contentLength,
        type: this.getMediaTypeFromMime(contentType),
        category: this.inferCategoryFromFilename(filename),
        thumbnailUrl: this.getThumbnailUrl(url, contentType),
        source: url,
        sourceType: 'url',
        selected: true,
        isDuplicate: false,
        metadata: {
          mimeType: contentType,
          dimensions: contentType.startsWith('image/') ? 'Unknown' : undefined,
          duration: contentType.startsWith('video/') ? 'Unknown' : undefined
        }
      };
      
      return [preview];
    } catch (error) {
      throw new Error(`Failed to preview URL: ${error.message}`);
    }
  }

  private async previewCdnPath(cdnPath: string): Promise<MediaPreview[]> {
    // For CDN paths, create preview without downloading
    const filename = this.extractFilenameFromUrl(cdnPath) || 'cdn_file';
    const mimeType = this.getMimeTypeFromFilename(filename);
    
    const preview: MediaPreview = {
      id: this.generateMediaId(),
      filename,
      size: 0,
      type: this.getMediaTypeFromMime(mimeType),
      category: this.inferCategoryFromFilename(filename),
      thumbnailUrl: cdnPath, // Use CDN URL as thumbnail
      source: cdnPath,
      sourceType: 'cdn_path',
      selected: true,
      isDuplicate: false,
      metadata: {
        mimeType,
        dimensions: 'Unknown',
        duration: undefined
      }
    };
    
    return [preview];
  }

  private async createFilePreview(filePath: string, filename: string, size: number): Promise<MediaPreview | null> {
    const mimeType = this.getMimeTypeFromFilename(filename);
    const isImage = this.allowedImageTypes.includes(mimeType);
    const isVideo = this.allowedVideoTypes.includes(mimeType);
    
    if (!isImage && !isVideo) return null;

    const preview: MediaPreview = {
      id: this.generateMediaId(),
      filename,
      size,
      type: this.getMediaTypeFromMime(mimeType),
      category: this.inferCategoryFromFilename(filename),
      thumbnailUrl: this.generateThumbnailUrl(filePath, mimeType),
      source: filePath,
      sourceType: 'server_path',
      selected: true,
      isDuplicate: false,
      metadata: {
        mimeType,
        dimensions: isImage ? await this.getImageDimensions(filePath) : undefined,
        duration: isVideo ? await this.getVideoDuration(filePath) : undefined
      }
    };
    
    return preview;
  }

  private removeDuplicatePreviews(previews: MediaPreview[]): MediaPreview[] {
    const seen = new Map<string, MediaPreview>();
    
    for (const preview of previews) {
      const key = `${preview.filename}_${preview.size}`;
      
      if (seen.has(key)) {
        // Mark as duplicate
        preview.isDuplicate = true;
        preview.selected = false;
        
        // Keep the first one selected
        const existing = seen.get(key)!;
        existing.duplicateCount = (existing.duplicateCount || 1) + 1;
      } else {
        seen.set(key, preview);
      }
    }
    
    return previews;
  }

  async processSelectedFiles(
    selectedIds: string[],
    previews: MediaPreview[],
    manifest: PressPackManifest
  ): Promise<{
    success: boolean;
    uploadedFiles: MediaFile[];
    errors: string[];
    showId?: number;
  }> {
    console.log(`📤 Processing ${selectedIds.length} selected files...`);
    
    const selectedPreviews = previews.filter(p => selectedIds.includes(p.id));
    const uploadedFiles: MediaFile[] = [];
    const errors: string[] = [];

    try {
      const showId = await this.findOrCreateShow(manifest);
      
      for (const preview of selectedPreviews) {
        try {
          const mediaFile = await this.uploadFromPreview(preview, manifest, showId);
          if (mediaFile) uploadedFiles.push(mediaFile);
        } catch (error) {
          errors.push(`Failed to upload ${preview.filename}: ${error.message}`);
        }
      }

      if (uploadedFiles.length > 0 && showId) {
        await this.updateShowWithNewMedia(showId, uploadedFiles);
      }

      console.log(`✅ Successfully uploaded ${uploadedFiles.length} files`);
      
      return {
        success: uploadedFiles.length > 0,
        uploadedFiles,
        errors,
        showId
      };
      
    } catch (error) {
      return {
        success: false,
        uploadedFiles: [],
        errors: [error.message]
      };
    }
  }

  private async uploadFromPreview(
    preview: MediaPreview,
    manifest: PressPackManifest,
    showId: number
  ): Promise<MediaFile | null> {
    const mediaFile: MediaFile = {
      id: preview.id,
      type: preview.type,
      category: preview.category,
      filename: preview.filename,
      originalName: preview.filename,
      size: preview.size,
      mimeType: preview.metadata.mimeType,
      url: preview.sourceType === 'cdn_path' ? preview.source : this.generatePublicUrl(preview.filename, showId),
      localPath: preview.sourceType === 'server_path' ? preview.source : undefined,
      showId,
      photographer: manifest.photographer,
      copyright: manifest.copyright,
      description: `${preview.category} image for ${manifest.showTitle}`,
      uploadedAt: new Date()
    };

    // For URLs, download the file
    if (preview.sourceType === 'url') {
      await this.downloadFileFromUrl(preview.source, showId, preview.filename);
    }

    return mediaFile;
  }

  private async downloadFileFromUrl(url: string, showId: number, filename: string): Promise<void> {
    const response = await fetch(url);
    const arrayBuffer = await response.arrayBuffer();
    const localPath = path.join(this.uploadDir, `${showId}_${filename}`);
    await fs.writeFile(localPath, Buffer.from(arrayBuffer));
  }

  private generateThumbnailUrl(filePath: string, mimeType: string): string {
    if (mimeType.startsWith('image/')) {
      return `/thumbnails/${path.basename(filePath)}`;
    } else if (mimeType.startsWith('video/')) {
      return `/thumbnails/${path.basename(filePath, path.extname(filePath))}.jpg`;
    }
    return '/assets/file-icon.png';
  }

  private getThumbnailUrl(url: string, mimeType: string): string {
    if (mimeType.startsWith('image/')) {
      return url; // Use original URL for images
    }
    return '/assets/video-icon.png';
  }

  private async getImageDimensions(filePath: string): Promise<string> {
    // Would implement actual image dimension reading
    return 'Unknown';
  }

  private async getVideoDuration(filePath: string): Promise<string> {
    // Would implement actual video duration reading
    return 'Unknown';
  }

  private async ensureUploadDirectory(): Promise<void> {
    try {
      await fs.access(this.uploadDir);
    } catch {
      await fs.mkdir(this.uploadDir, { recursive: true });
    }
  }

  async processPressPackUpload(
    sources: UploadSource[],
    manifest: PressPackManifest
  ): Promise<{
    success: boolean;
    uploadedFiles: MediaFile[];
    errors: string[];
    showId?: number;
  }> {
    console.log(`📦 Processing press pack for ${manifest.showTitle} at ${manifest.venue}`);
    
    const uploadedFiles: MediaFile[] = [];
    const errors: string[] = [];

    try {
      // Find or create show entry
      const showId = await this.findOrCreateShow(manifest);
      
      // Process each source
      for (const source of sources) {
        try {
          const files = await this.processUploadSource(source, manifest, showId);
          uploadedFiles.push(...files);
        } catch (error) {
          errors.push(`Failed to process ${source.source}: ${error.message}`);
        }
      }

      // Update show with new media URLs
      if (uploadedFiles.length > 0 && showId) {
        await this.updateShowWithNewMedia(showId, uploadedFiles);
      }

      console.log(`✅ Processed ${uploadedFiles.length} files for ${manifest.showTitle}`);
      
      return {
        success: uploadedFiles.length > 0,
        uploadedFiles,
        errors,
        showId
      };
      
    } catch (error) {
      console.error('Error processing press pack:', error);
      return {
        success: false,
        uploadedFiles: [],
        errors: [error.message]
      };
    }
  }

  private async processUploadSource(
    source: UploadSource,
    manifest: PressPackManifest,
    showId: number
  ): Promise<MediaFile[]> {
    console.log(`📁 Processing ${source.type}: ${source.source}`);
    
    switch (source.type) {
      case 'local_file':
        return this.processLocalFile(source.source, manifest, showId);
      
      case 'url':
        return this.processUrlDownload(source.source, manifest, showId, source.headers, source.credentials);
      
      case 'server_path':
        return this.processServerPath(source.source, manifest, showId);
      
      case 'cdn_path':
        return this.processCdnPath(source.source, manifest, showId);
      
      default:
        throw new Error(`Unsupported source type: ${source.type}`);
    }
  }

  private async processLocalFile(
    filePath: string,
    manifest: PressPackManifest,
    showId: number
  ): Promise<MediaFile[]> {
    try {
      const stats = await fs.stat(filePath);
      const filename = path.basename(filePath);
      const ext = path.extname(filename).toLowerCase();
      
      // Validate file
      const mediaFile = await this.validateAndProcessFile(
        filePath,
        filename,
        stats.size,
        manifest,
        showId
      );
      
      if (mediaFile) {
        return [mediaFile];
      }
      
      return [];
    } catch (error) {
      throw new Error(`Failed to process local file ${filePath}: ${error.message}`);
    }
  }

  private async processUrlDownload(
    url: string,
    manifest: PressPackManifest,
    showId: number,
    headers?: Record<string, string>,
    credentials?: any
  ): Promise<MediaFile[]> {
    try {
      console.log(`🌐 Downloading from URL: ${url}`);
      
      const requestHeaders: Record<string, string> = {
        'User-Agent': 'Theatre-Spotlight-Media-Uploader/1.0',
        ...headers
      };

      if (credentials?.apiKey) {
        requestHeaders['Authorization'] = `Bearer ${credentials.apiKey}`;
      } else if (credentials?.username && credentials?.password) {
        const auth = Buffer.from(`${credentials.username}:${credentials.password}`).toString('base64');
        requestHeaders['Authorization'] = `Basic ${auth}`;
      }

      const response = await fetch(url, { headers: requestHeaders });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const contentType = response.headers.get('content-type') || '';
      const contentLength = parseInt(response.headers.get('content-length') || '0');
      
      if (contentLength > this.maxFileSize) {
        throw new Error(`File too large: ${contentLength} bytes (max: ${this.maxFileSize})`);
      }

      const filename = this.extractFilenameFromUrl(url) || `download_${Date.now()}`;
      const localPath = path.join(this.uploadDir, `${showId}_${filename}`);
      
      const arrayBuffer = await response.arrayBuffer();
      await fs.writeFile(localPath, Buffer.from(arrayBuffer));
      
      const mediaFile = await this.createMediaFile(
        localPath,
        filename,
        contentLength,
        contentType,
        manifest,
        showId
      );
      
      return mediaFile ? [mediaFile] : [];
      
    } catch (error) {
      throw new Error(`Failed to download from URL ${url}: ${error.message}`);
    }
  }

  private async processServerPath(
    serverPath: string,
    manifest: PressPackManifest,
    showId: number
  ): Promise<MediaFile[]> {
    try {
      console.log(`📂 Processing server path: ${serverPath}`);
      
      const stats = await fs.stat(serverPath);
      
      if (stats.isDirectory()) {
        // Process all files in directory
        const files = await fs.readdir(serverPath);
        const mediaFiles: MediaFile[] = [];
        
        for (const file of files) {
          const filePath = path.join(serverPath, file);
          const fileStats = await fs.stat(filePath);
          
          if (fileStats.isFile()) {
            const mediaFile = await this.validateAndProcessFile(
              filePath,
              file,
              fileStats.size,
              manifest,
              showId
            );
            
            if (mediaFile) {
              mediaFiles.push(mediaFile);
            }
          }
        }
        
        return mediaFiles;
      } else {
        // Single file
        const filename = path.basename(serverPath);
        const mediaFile = await this.validateAndProcessFile(
          serverPath,
          filename,
          stats.size,
          manifest,
          showId
        );
        
        return mediaFile ? [mediaFile] : [];
      }
      
    } catch (error) {
      throw new Error(`Failed to process server path ${serverPath}: ${error.message}`);
    }
  }

  private async processCdnPath(
    cdnPath: string,
    manifest: PressPackManifest,
    showId: number
  ): Promise<MediaFile[]> {
    // For CDN paths, we just validate the URL and create a media record
    // without downloading the file locally
    
    try {
      const filename = this.extractFilenameFromUrl(cdnPath) || `cdn_file_${Date.now()}`;
      
      const mediaFile: MediaFile = {
        id: this.generateMediaId(),
        type: this.getMediaTypeFromFilename(filename),
        category: this.inferCategoryFromFilename(filename),
        filename,
        originalName: filename,
        size: 0, // Unknown for CDN files
        mimeType: this.getMimeTypeFromFilename(filename),
        url: cdnPath,
        showId,
        photographer: manifest.photographer,
        copyright: manifest.copyright,
        description: `Media for ${manifest.showTitle} at ${manifest.venue}`,
        uploadedAt: new Date()
      };
      
      return [mediaFile];
      
    } catch (error) {
      throw new Error(`Failed to process CDN path ${cdnPath}: ${error.message}`);
    }
  }

  private async validateAndProcessFile(
    filePath: string,
    filename: string,
    size: number,
    manifest: PressPackManifest,
    showId: number
  ): Promise<MediaFile | null> {
    if (size > this.maxFileSize) {
      throw new Error(`File ${filename} too large: ${size} bytes`);
    }

    const mimeType = this.getMimeTypeFromFilename(filename);
    const isImage = this.allowedImageTypes.includes(mimeType);
    const isVideo = this.allowedVideoTypes.includes(mimeType);
    
    if (!isImage && !isVideo) {
      console.warn(`Skipping unsupported file type: ${filename} (${mimeType})`);
      return null;
    }

    return this.createMediaFile(filePath, filename, size, mimeType, manifest, showId);
  }

  private async createMediaFile(
    localPath: string,
    filename: string,
    size: number,
    mimeType: string,
    manifest: PressPackManifest,
    showId: number
  ): Promise<MediaFile> {
    const mediaFile: MediaFile = {
      id: this.generateMediaId(),
      type: this.getMediaTypeFromMime(mimeType),
      category: this.inferCategoryFromFilename(filename),
      filename,
      originalName: filename,
      size,
      mimeType,
      url: this.generatePublicUrl(filename, showId),
      localPath,
      showId,
      photographer: manifest.photographer,
      copyright: manifest.copyright,
      description: `Media for ${manifest.showTitle} at ${manifest.venue}`,
      uploadedAt: new Date()
    };

    // Store media file record in database (would need media table)
    console.log(`💾 Created media record: ${mediaFile.id} - ${filename}`);
    
    return mediaFile;
  }

  private async findOrCreateShow(manifest: PressPackManifest): Promise<number> {
    // Try to find existing show
    const existingShows = await db.select().from(shows);
    const existingShow = existingShows.find(show => 
      show.title.toLowerCase() === manifest.showTitle.toLowerCase() &&
      show.venue.toLowerCase().includes(manifest.venue.toLowerCase())
    );

    if (existingShow) {
      console.log(`📍 Found existing show: ${existingShow.title} (ID: ${existingShow.id})`);
      return existingShow.id;
    }

    // Create new show
    const newShow = {
      title: manifest.showTitle,
      venue: manifest.venue,
      region: manifest.region,
      venue_type: manifest.region === 'uk' ? 'west_end' : 'broadway',
      status: 'running' as const,
      popularity: 50,
      description: `${manifest.showTitle} at ${manifest.venue}`,
      ticketUrl: '',
      officialWebsite: '',
      imageUrl: '',
      director: '',
      composer: '',
      cast: [],
      genre: 'Musical',
      duration: '2h 30m',
      ageRating: 'PG'
    };

    const [createdShow] = await db.insert(shows).values(newShow).returning();
    console.log(`✨ Created new show: ${createdShow.title} (ID: ${createdShow.id})`);
    
    return createdShow.id;
  }

  private async updateShowWithNewMedia(showId: number, mediaFiles: MediaFile[]): Promise<void> {
    // Find best poster image
    const posterImage = mediaFiles.find(file => 
      file.type === 'image' && file.category === 'poster'
    ) || mediaFiles.find(file => file.type === 'image');

    if (posterImage) {
      await db.update(shows)
        .set({ imageUrl: posterImage.url })
        .where(eq(shows.id, showId));
      
      console.log(`🖼️ Updated show ${showId} with poster image: ${posterImage.url}`);
    }
  }

  // Utility methods
  private generateMediaId(): string {
    return `media_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private generatePublicUrl(filename: string, showId: number): string {
    return `/uploads/shows/${showId}/${filename}`;
  }

  private extractFilenameFromUrl(url: string): string | null {
    try {
      const parsedUrl = new URL(url);
      const pathname = parsedUrl.pathname;
      return path.basename(pathname) || null;
    } catch {
      return null;
    }
  }

  private getMimeTypeFromFilename(filename: string): string {
    const ext = path.extname(filename).toLowerCase();
    const mimeTypes: Record<string, string> = {
      '.jpg': 'image/jpeg',
      '.jpeg': 'image/jpeg',
      '.png': 'image/png',
      '.webp': 'image/webp',
      '.mp4': 'video/mp4',
      '.webm': 'video/webm',
      '.mov': 'video/mov',
      '.avi': 'video/avi'
    };
    return mimeTypes[ext] || 'application/octet-stream';
  }

  private getMediaTypeFromMime(mimeType: string): 'image' | 'video' {
    return mimeType.startsWith('image/') ? 'image' : 'video';
  }

  private getMediaTypeFromFilename(filename: string): 'image' | 'video' {
    const mimeType = this.getMimeTypeFromFilename(filename);
    return this.getMediaTypeFromMime(mimeType);
  }

  private inferCategoryFromFilename(filename: string): MediaFile['category'] {
    const lower = filename.toLowerCase();
    
    if (lower.includes('poster')) return 'poster';
    if (lower.includes('cast')) return 'cast';
    if (lower.includes('production') || lower.includes('scene')) return 'production';
    if (lower.includes('backstage') || lower.includes('behind')) return 'backstage';
    if (lower.includes('trailer')) return 'trailer';
    
    // Default based on file type
    const type = this.getMediaTypeFromFilename(filename);
    return type === 'video' ? 'trailer' : 'production';
  }

  // API endpoints for press pack upload
  async uploadFromManifest(manifestPath: string): Promise<any> {
    try {
      const manifestContent = await fs.readFile(manifestPath, 'utf-8');
      const manifest: PressPackManifest = JSON.parse(manifestContent);
      
      // Convert manifest file paths to upload sources
      const sources: UploadSource[] = [];
      
      // Add image sources
      Object.entries(manifest.files.images).forEach(([category, files]) => {
        files.forEach(file => {
          sources.push({
            type: file.startsWith('http') ? 'url' : 'server_path',
            source: file
          });
        });
      });
      
      // Add video sources
      Object.entries(manifest.files.videos).forEach(([category, files]) => {
        files.forEach(file => {
          sources.push({
            type: file.startsWith('http') ? 'url' : 'server_path',
            source: file
          });
        });
      });
      
      return this.processPressPackUpload(sources, manifest);
      
    } catch (error) {
      throw new Error(`Failed to process manifest ${manifestPath}: ${error.message}`);
    }
  }

  async getUploadStatus(uploadId: string): Promise<any> {
    // Return status of ongoing upload
    return {
      id: uploadId,
      status: 'completed',
      filesProcessed: 0,
      totalFiles: 0,
      errors: []
    };
  }
}

export const mediaUploadManager = new MediaUploadManager();