interface IndustryContact {
  id: string;
  name: string;
  title: string;
  company: string;
  type: 'producer' | 'director' | 'casting_director' | 'agent' | 'publicist' | 'executive' | 'venue_manager';
  contact: {
    email?: string;
    phone?: string;
    assistant?: string;
    office?: string;
  };
  specialties: string[];
  currentProjects: string[];
  recentCredits: string[];
  region: 'uk' | 'us' | 'international';
  tier: 'major' | 'established' | 'emerging';
  lastUpdated: Date;
  verified: boolean;
}

interface CastingOpportunity {
  id: string;
  production: string;
  venue: string;
  castingDirector: string;
  roles: {
    character: string;
    description: string;
    requirements: string[];
    payRange?: string;
  }[];
  auditionDates: {
    start: Date;
    end: Date;
    location: string;
  };
  applicationDeadline: Date;
  contactDetails: string;
  productionDetails: {
    rehearsalStart?: Date;
    openingNight?: Date;
    runLength?: string;
    type: 'musical' | 'play' | 'opera' | 'dance' | 'variety';
  };
  requirements: {
    experience: string;
    ageRange: string;
    skills: string[];
    union: boolean;
  };
}

interface ProductionPipeline {
  id: string;
  title: string;
  type: 'musical' | 'play' | 'revival' | 'transfer';
  status: 'development' | 'pre_production' | 'casting' | 'rehearsals' | 'previews' | 'running' | 'closed';
  producer: string;
  director?: string;
  venue?: string;
  estimatedOpening?: Date;
  investment: {
    totalBudget?: number;
    seeking?: number;
    minimumInvestment?: number;
    investors?: string[];
  };
  creativeTeam: {
    writer?: string;
    composer?: string;
    lyricist?: string;
    designer?: string;
    choreographer?: string;
  };
  marketingNotes?: string;
  region: 'uk' | 'us' | 'international';
}

export class IndustryDatabase {
  private contacts: Map<string, IndustryContact> = new Map();
  private castingOpportunities: Map<string, CastingOpportunity> = new Map();
  private productionPipeline: Map<string, ProductionPipeline> = new Map();

  constructor() {
    this.seedDatabase();
  }

  private seedDatabase(): void {
    // Major UK Producers
    const ukProducers: IndustryContact[] = [
      {
        id: 'cameron-mackintosh',
        name: 'Sir Cameron Mackintosh',
        title: 'Producer',
        company: 'Cameron Mackintosh Ltd',
        type: 'producer',
        contact: {
          office: 'Cameron Mackintosh Ltd, 1 Bedford Square, London WC1B 3RA',
          email: 'info@cameronmackintosh.com'
        },
        specialties: ['Musical Theatre', 'Large Scale Productions', 'International Tours'],
        currentProjects: ['The Lion King', 'Mary Poppins', 'Hamilton'],
        recentCredits: ['Les Misérables', 'The Phantom of the Opera', 'Miss Saigon'],
        region: 'uk',
        tier: 'major',
        lastUpdated: new Date(),
        verified: true
      },
      {
        id: 'sonia-friedman',
        name: 'Sonia Friedman',
        title: 'Producer',
        company: 'Sonia Friedman Productions',
        type: 'producer',
        contact: {
          office: 'Sonia Friedman Productions, Duke of York\'s Theatre, St Martin\'s Lane, London WC2N 4BG'
        },
        specialties: ['Contemporary Drama', 'Transfers', 'Star Vehicles'],
        currentProjects: ['The Book of Mormon', 'Dreamgirls'],
        recentCredits: ['Harry Potter and the Cursed Child', 'The Ferryman'],
        region: 'uk',
        tier: 'major',
        lastUpdated: new Date(),
        verified: true
      }
    ];

    // Major US Producers
    const usProducers: IndustryContact[] = [
      {
        id: 'scott-rudin',
        name: 'Scott Rudin',
        title: 'Producer',
        company: 'Scott Rudin Productions',
        type: 'producer',
        contact: {
          office: 'Scott Rudin Productions, 120 West 45th Street, New York, NY 10036'
        },
        specialties: ['Serious Drama', 'Literary Adaptations', 'Star-Led Productions'],
        currentProjects: ['To Kill a Mockingbird'],
        recentCredits: ['The Humans', 'Three Tall Women', 'The Book of Mormon'],
        region: 'us',
        tier: 'major',
        lastUpdated: new Date(),
        verified: true
      }
    ];

    // Casting Directors
    const castingDirectors: IndustryContact[] = [
      {
        id: 'jim-carnahan',
        name: 'Jim Carnahan',
        title: 'Casting Director',
        company: 'Carnahan Casting',
        type: 'casting_director',
        contact: {
          office: 'New York, NY',
          email: 'info@carnahancasting.com'
        },
        specialties: ['Broadway Musicals', 'Principal Casting', 'Ensemble'],
        currentProjects: ['Wicked', 'Chicago'],
        recentCredits: ['Hamilton', 'Dear Evan Hansen', 'Come From Away'],
        region: 'us',
        tier: 'major',
        lastUpdated: new Date(),
        verified: true
      },
      {
        id: 'anne-mcnamara',
        name: 'Anne McNamara',
        title: 'Casting Director',
        company: 'Anne McNamara Casting',
        type: 'casting_director',
        contact: {
          office: 'London, UK'
        },
        specialties: ['West End Musicals', 'Touring Productions'],
        currentProjects: ['The Lion King', 'Frozen'],
        recentCredits: ['Aladdin', 'Beauty and the Beast'],
        region: 'uk',
        tier: 'major',
        lastUpdated: new Date(),
        verified: true
      }
    ];

    // Venue Managers
    const venueManagers: IndustryContact[] = [
      {
        id: 'rebecca-kane-evans',
        name: 'Rebecca Kane Evans',
        title: 'General Manager',
        company: 'National Theatre',
        type: 'venue_manager',
        contact: {
          office: 'National Theatre, South Bank, London SE1 9PX',
          email: 'info@nationaltheatre.org.uk'
        },
        specialties: ['New Writing', 'Classical Theatre', 'International Co-productions'],
        currentProjects: ['Leopoldstadt', 'Prima Facie'],
        recentCredits: ['The Curious Incident', 'War Horse', 'One Man Two Guvnors'],
        region: 'uk',
        tier: 'major',
        lastUpdated: new Date(),
        verified: true
      }
    ];

    // Add all contacts to database
    [...ukProducers, ...usProducers, ...castingDirectors, ...venueManagers].forEach(contact => {
      this.contacts.set(contact.id, contact);
    });

    // Seed casting opportunities
    this.seedCastingOpportunities();
    
    // Seed production pipeline
    this.seedProductionPipeline();
  }

  private seedCastingOpportunities(): void {
    const opportunities: CastingOpportunity[] = [
      {
        id: 'lion-king-swing',
        production: 'The Lion King',
        venue: 'Lyceum Theatre',
        castingDirector: 'Anne McNamara',
        roles: [
          {
            character: 'Swing/Understudy',
            description: 'Multiple ensemble roles and principal understudies',
            requirements: ['Strong singing voice', 'Movement/dance experience', 'Previous musical theatre experience'],
            payRange: '£600-800/week'
          }
        ],
        auditionDates: {
          start: new Date('2025-07-15'),
          end: new Date('2025-07-20'),
          location: 'Pineapple Dance Studios, London'
        },
        applicationDeadline: new Date('2025-07-10'),
        contactDetails: 'Applications via Spotlight only',
        productionDetails: {
          rehearsalStart: new Date('2025-08-01'),
          type: 'musical',
          runLength: 'Open run'
        },
        requirements: {
          experience: '2+ years professional musical theatre',
          ageRange: '20-40',
          skills: ['Singing', 'Dancing', 'Acting', 'Puppetry helpful'],
          union: true
        }
      }
    ];

    opportunities.forEach(opp => {
      this.castingOpportunities.set(opp.id, opp);
    });
  }

  private seedProductionPipeline(): void {
    const pipeline: ProductionPipeline[] = [
      {
        id: 'new-sondheim-musical',
        title: 'Here We Are (Sondheim)',
        type: 'musical',
        status: 'development',
        producer: 'Cameron Mackintosh',
        director: 'Joe Mantello',
        estimatedOpening: new Date('2025-10-01'),
        investment: {
          totalBudget: 8000000,
          seeking: 2000000,
          minimumInvestment: 25000
        },
        creativeTeam: {
          composer: 'Stephen Sondheim',
          lyricist: 'Stephen Sondheim',
          writer: 'Luis Buñuel/Stephen Sondheim'
        },
        marketingNotes: 'Final Sondheim musical, significant industry interest',
        region: 'uk'
      },
      {
        id: 'mcneal-transfer',
        title: 'McNeal (AI Drama)',
        type: 'play',
        status: 'pre_production',
        producer: 'Sonia Friedman Productions',
        director: 'Lila Neugebauer',
        venue: 'Wyndham\'s Theatre',
        estimatedOpening: new Date('2025-09-15'),
        investment: {
          totalBudget: 1500000
        },
        creativeTeam: {
          writer: 'Ayad Akhtar'
        },
        marketingNotes: 'Timely AI-themed drama, star casting in discussion',
        region: 'uk'
      }
    ];

    pipeline.forEach(prod => {
      this.productionPipeline.set(prod.id, prod);
    });
  }

  async searchContacts(query: {
    type?: IndustryContact['type'];
    region?: string;
    company?: string;
    specialty?: string;
    tier?: string;
  }): Promise<IndustryContact[]> {
    const results: IndustryContact[] = [];

    for (const contact of this.contacts.values()) {
      let matches = true;

      if (query.type && contact.type !== query.type) matches = false;
      if (query.region && contact.region !== query.region) matches = false;
      if (query.company && !contact.company.toLowerCase().includes(query.company.toLowerCase())) matches = false;
      if (query.tier && contact.tier !== query.tier) matches = false;
      if (query.specialty && !contact.specialties.some(s => 
        s.toLowerCase().includes(query.specialty!.toLowerCase())
      )) matches = false;

      if (matches) {
        results.push(contact);
      }
    }

    return results.sort((a, b) => {
      // Sort by tier (major first), then by name
      if (a.tier !== b.tier) {
        const tierOrder = { major: 3, established: 2, emerging: 1 };
        return tierOrder[b.tier] - tierOrder[a.tier];
      }
      return a.name.localeCompare(b.name);
    });
  }

  async getCurrentCastingOpportunities(region?: string): Promise<CastingOpportunity[]> {
    const opportunities: CastingOpportunity[] = [];
    const now = new Date();

    for (const opp of this.castingOpportunities.values()) {
      // Only show opportunities with future deadlines
      if (opp.applicationDeadline > now) {
        if (!region || opp.venue.includes(region)) {
          opportunities.push(opp);
        }
      }
    }

    return opportunities.sort((a, b) => 
      a.applicationDeadline.getTime() - b.applicationDeadline.getTime()
    );
  }

  async getProductionPipeline(status?: ProductionPipeline['status']): Promise<ProductionPipeline[]> {
    const productions: ProductionPipeline[] = [];

    for (const prod of this.productionPipeline.values()) {
      if (!status || prod.status === status) {
        productions.push(prod);
      }
    }

    return productions.sort((a, b) => {
      if (a.estimatedOpening && b.estimatedOpening) {
        return a.estimatedOpening.getTime() - b.estimatedOpening.getTime();
      }
      return a.title.localeCompare(b.title);
    });
  }

  async getContactById(id: string): Promise<IndustryContact | null> {
    return this.contacts.get(id) || null;
  }

  async updateContact(id: string, updates: Partial<IndustryContact>): Promise<boolean> {
    const contact = this.contacts.get(id);
    if (!contact) return false;

    const updatedContact = {
      ...contact,
      ...updates,
      lastUpdated: new Date()
    };

    this.contacts.set(id, updatedContact);
    console.log(`Updated contact: ${updatedContact.name} at ${updatedContact.company}`);
    return true;
  }

  async addNewContact(contact: Omit<IndustryContact, 'id' | 'lastUpdated'>): Promise<string> {
    const id = contact.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');
    
    const newContact: IndustryContact = {
      ...contact,
      id,
      lastUpdated: new Date()
    };

    this.contacts.set(id, newContact);
    console.log(`Added new contact: ${newContact.name} at ${newContact.company}`);
    return id;
  }

  async generateIndustryReport(): Promise<string> {
    const contactsByType = new Map<string, number>();
    const contactsByRegion = new Map<string, number>();
    
    for (const contact of this.contacts.values()) {
      contactsByType.set(contact.type, (contactsByType.get(contact.type) || 0) + 1);
      contactsByRegion.set(contact.region, (contactsByRegion.get(contact.region) || 0) + 1);
    }

    return `
INDUSTRY DATABASE REPORT
Generated: ${new Date().toISOString()}

TOTAL CONTACTS: ${this.contacts.size}

BY TYPE:
${Array.from(contactsByType.entries()).map(([type, count]) => 
  `- ${type.replace('_', ' ').toUpperCase()}: ${count}`
).join('\n')}

BY REGION:
${Array.from(contactsByRegion.entries()).map(([region, count]) => 
  `- ${region.toUpperCase()}: ${count}`
).join('\n')}

CURRENT CASTING OPPORTUNITIES: ${this.castingOpportunities.size}
PRODUCTIONS IN PIPELINE: ${this.productionPipeline.size}

VERIFIED CONTACTS: ${Array.from(this.contacts.values()).filter(c => c.verified).length}
LAST UPDATED: ${new Date().toISOString()}
    `.trim();
  }
}

export const industryDatabase = new IndustryDatabase();