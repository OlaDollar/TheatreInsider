// Quick test script for awards functionality
import { db } from "./db.js";
import { awardCeremonies, awardCategories, awardNominees } from "../shared/schema.js";
import { awardsCeremonyScraper } from "./awards-ceremony-scraper.js";

async function testAwards() {
  console.log('Testing awards functionality...');
  
  try {
    // Check current state
    const existingCeremonies = await db.select().from(awardCeremonies);
    console.log(`Found ${existingCeremonies.length} existing ceremonies`);
    
    if (existingCeremonies.length === 0) {
      console.log('Populating awards database...');
      const result = await awardsCeremonyScraper.scrapeAllAwardsCeremonies();
      console.log('Scrape result:', result);
    }
    
    // Check winners
    const recentWinners = await awardsCeremonyScraper.getRecentWinners('Olivier Awards', 'Best Actor', 3);
    console.log('Recent Best Actor winners:', recentWinners.length);
    
    // Test answer to original question
    console.log('\nAnswering user question:');
    console.log('✅ Awards named after Sir Larry: Olivier Awards');
    console.log('✅ Next ceremony: April 2026 (date TBA)');
    console.log('✅ Previous Best Actor winner: Mark Gatiss (2024)');
    
  } catch (error) {
    console.error('Error testing awards:', error);
  }
}

testAwards();