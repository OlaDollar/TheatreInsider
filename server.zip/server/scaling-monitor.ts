import { db } from "./db";
import { analytics } from "../shared/schema";
import { eq, gte, sql } from "drizzle-orm";

interface ScalingMetrics {
  dailyPageViews: number;
  monthlyRevenue: number;
  responseTime: number;
  errorRate: number;
  databaseConnections: number;
  cpuUsage: number;
  memoryUsage: number;
  contentGenerationLoad: number;
}

interface ScalingAlert {
  level: 'info' | 'warning' | 'critical';
  trigger: string;
  currentValue: number;
  threshold: number;
  recommendation: string;
  estimatedCost: string;
  timeToImplement: string;
  urgency: 'low' | 'medium' | 'high';
}

export class ScalingMonitor {
  private scalingThresholds = {
    // Phase 1 -> Phase 2 (Railway -> Vercel)
    phase2Triggers: {
      dailyPageViews: 50000,
      monthlyRevenue: 800, // £800/month - start planning for £1000
      responseTime: 2000, // 2+ seconds
      errorRate: 0.05, // 5% error rate
      databaseConnections: 80 // approaching Railway limits
    },
    
    // Phase 2 -> Phase 3 (Vercel -> DigitalOcean)
    phase3Triggers: {
      dailyPageViews: 200000,
      monthlyRevenue: 5000, // £5000/month - start planning for £6000
      responseTime: 3000, // 3+ seconds
      errorRate: 0.03, // 3% error rate
      databaseConnections: 400 // approaching PlanetScale free tier
    },
    
    // Emergency scaling needed
    emergencyTriggers: {
      dailyPageViews: 500000,
      responseTime: 5000, // 5+ seconds
      errorRate: 0.10, // 10% error rate
      cpuUsage: 90, // 90%+ CPU
      memoryUsage: 90 // 90%+ memory
    }
  };

  async checkScalingNeeds(): Promise<ScalingAlert[]> {
    const alerts: ScalingAlert[] = [];
    const metrics = await this.gatherMetrics();
    
    // Check Phase 2 triggers (Railway + Supabase -> Vercel + PlanetScale)
    if (this.shouldTriggerPhase2(metrics)) {
      alerts.push({
        level: 'warning',
        trigger: 'Ready for Phase 2 Scaling',
        currentValue: metrics.monthlyRevenue,
        threshold: this.scalingThresholds.phase2Triggers.monthlyRevenue,
        recommendation: 'Upgrade to Vercel Pro + PlanetScale for better performance and global CDN',
        estimatedCost: '$49/month (currently $30/month)',
        timeToImplement: '2-3 hours migration window',
        urgency: 'medium'
      });
    }
    
    // Check Phase 3 triggers (Vercel -> DigitalOcean)
    if (this.shouldTriggerPhase3(metrics)) {
      alerts.push({
        level: 'critical',
        trigger: 'Ready for Phase 3 Scaling',
        currentValue: metrics.monthlyRevenue,
        threshold: this.scalingThresholds.phase3Triggers.monthlyRevenue,
        recommendation: 'Migrate to DigitalOcean App Platform with dedicated database for enterprise performance',
        estimatedCost: '$60-120/month (currently $49/month)',
        timeToImplement: '4-6 hours migration window',
        urgency: 'high'
      });
    }
    
    // Check emergency triggers
    if (this.isEmergencyScaling(metrics)) {
      alerts.push({
        level: 'critical',
        trigger: 'EMERGENCY SCALING REQUIRED',
        currentValue: Math.max(metrics.responseTime, metrics.errorRate * 100),
        threshold: Math.min(this.scalingThresholds.emergencyTriggers.responseTime, this.scalingThresholds.emergencyTriggers.errorRate * 100),
        recommendation: 'IMMEDIATE ACTION: Site performance critical. Scale infrastructure NOW.',
        estimatedCost: 'Variable - $100-300/month for immediate relief',
        timeToImplement: '30 minutes emergency scaling',
        urgency: 'high'
      });
    }
    
    // Performance optimization suggestions
    const performanceAlerts = this.checkPerformanceOptimizations(metrics);
    alerts.push(...performanceAlerts);
    
    return alerts;
  }

  private async gatherMetrics(): Promise<ScalingMetrics> {
    try {
      // Get analytics from last 30 days
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      
      const analyticsData = await db
        .select()
        .from(analytics)
        .where(gte(analytics.createdAt, thirtyDaysAgo));
      
      // Calculate metrics
      const dailyPageViews = analyticsData.length / 30; // Average daily
      const monthlyRevenue = this.estimateRevenue(analyticsData);
      
      // Simulate performance metrics (in production, use APM tools)
      const responseTime = this.simulateResponseTime();
      const errorRate = this.simulateErrorRate();
      const databaseConnections = this.simulateDatabaseConnections();
      const cpuUsage = this.simulateCpuUsage();
      const memoryUsage = this.simulateMemoryUsage();
      const contentGenerationLoad = this.simulateContentLoad();
      
      return {
        dailyPageViews,
        monthlyRevenue,
        responseTime,
        errorRate,
        databaseConnections,
        cpuUsage,
        memoryUsage,
        contentGenerationLoad
      };
      
    } catch (error) {
      console.error('Error gathering scaling metrics:', error);
      return {
        dailyPageViews: 0,
        monthlyRevenue: 0,
        responseTime: 1000,
        errorRate: 0.01,
        databaseConnections: 10,
        cpuUsage: 50,
        memoryUsage: 50,
        contentGenerationLoad: 30
      };
    }
  }

  private estimateRevenue(analyticsData: any[]): number {
    // Estimate based on page views and conversion rates
    // Assuming £0.01 per page view (conservative estimate)
    const totalPageViews = analyticsData.length;
    return totalPageViews * 0.01;
  }

  private simulateResponseTime(): number {
    // In production, integrate with monitoring tools
    return Math.random() * 2000 + 500; // 500-2500ms
  }

  private simulateErrorRate(): number {
    return Math.random() * 0.02; // 0-2%
  }

  private simulateDatabaseConnections(): number {
    return Math.floor(Math.random() * 50) + 10; // 10-60 connections
  }

  private simulateCpuUsage(): number {
    return Math.random() * 40 + 30; // 30-70%
  }

  private simulateMemoryUsage(): number {
    return Math.random() * 30 + 40; // 40-70%
  }

  private simulateContentLoad(): number {
    return Math.random() * 50 + 20; // 20-70%
  }

  private shouldTriggerPhase2(metrics: ScalingMetrics): boolean {
    const triggers = this.scalingThresholds.phase2Triggers;
    return (
      metrics.monthlyRevenue >= triggers.monthlyRevenue ||
      metrics.dailyPageViews >= triggers.dailyPageViews ||
      metrics.responseTime >= triggers.responseTime ||
      metrics.errorRate >= triggers.errorRate ||
      metrics.databaseConnections >= triggers.databaseConnections
    );
  }

  private shouldTriggerPhase3(metrics: ScalingMetrics): boolean {
    const triggers = this.scalingThresholds.phase3Triggers;
    return (
      metrics.monthlyRevenue >= triggers.monthlyRevenue ||
      metrics.dailyPageViews >= triggers.dailyPageViews ||
      metrics.responseTime >= triggers.responseTime ||
      metrics.errorRate >= triggers.errorRate ||
      metrics.databaseConnections >= triggers.databaseConnections
    );
  }

  private isEmergencyScaling(metrics: ScalingMetrics): boolean {
    const triggers = this.scalingThresholds.emergencyTriggers;
    return (
      metrics.dailyPageViews >= triggers.dailyPageViews ||
      metrics.responseTime >= triggers.responseTime ||
      metrics.errorRate >= triggers.errorRate ||
      metrics.cpuUsage >= triggers.cpuUsage ||
      metrics.memoryUsage >= triggers.memoryUsage
    );
  }

  private checkPerformanceOptimizations(metrics: ScalingMetrics): ScalingAlert[] {
    const alerts: ScalingAlert[] = [];
    
    // CDN optimization
    if (metrics.responseTime > 1500) {
      alerts.push({
        level: 'info',
        trigger: 'CDN Optimization Opportunity',
        currentValue: metrics.responseTime,
        threshold: 1500,
        recommendation: 'Consider implementing Cloudflare CDN for faster global content delivery',
        estimatedCost: '$20/month for Cloudflare Pro',
        timeToImplement: '1 hour setup',
        urgency: 'low'
      });
    }
    
    // Database optimization
    if (metrics.databaseConnections > 30) {
      alerts.push({
        level: 'info',
        trigger: 'Database Connection Pooling',
        currentValue: metrics.databaseConnections,
        threshold: 30,
        recommendation: 'Implement connection pooling to reduce database load',
        estimatedCost: 'No additional cost - code optimization',
        timeToImplement: '2 hours development',
        urgency: 'low'
      });
    }
    
    return alerts;
  }

  async sendScalingAlert(alerts: ScalingAlert[]): Promise<void> {
    if (alerts.length === 0) return;
    
    const criticalAlerts = alerts.filter(a => a.level === 'critical');
    const warningAlerts = alerts.filter(a => a.level === 'warning');
    
    if (criticalAlerts.length > 0) {
      await this.sendEmailAlert(criticalAlerts, 'CRITICAL');
    }
    
    if (warningAlerts.length > 0) {
      await this.sendEmailAlert(warningAlerts, 'WARNING');
    }
    
    // Log all alerts for monitoring
    console.log('Scaling Alerts Generated:', alerts);
  }

  private async sendEmailAlert(alerts: ScalingAlert[], level: string): Promise<void> {
    const subject = `${level}: Theatre Spotlight Scaling Alert`;
    
    const body = `
Theatre Spotlight Infrastructure Alert

${level} SCALING RECOMMENDATIONS:

${alerts.map(alert => `
🚨 ${alert.trigger}
Current: ${alert.currentValue}
Threshold: ${alert.threshold}
Action: ${alert.recommendation}
Cost: ${alert.estimatedCost}
Time: ${alert.timeToImplement}
Urgency: ${alert.urgency.toUpperCase()}
`).join('\n')}

Next Steps:
1. Review current metrics and traffic patterns
2. Plan migration during low-traffic hours
3. Test new infrastructure before full cutover
4. Monitor performance post-migration

Dashboard: https://theatrespotlight.com/admin
    `.trim();
    
    // In production, send actual email
    console.log(`EMAIL ALERT: ${subject}`);
    console.log(body);
  }

  async generateScalingReport(): Promise<string> {
    const metrics = await this.gatherMetrics();
    const alerts = await this.checkScalingNeeds();
    
    return `
# Theatre Spotlight Scaling Report
**Generated:** ${new Date().toISOString()}

## Current Metrics
- **Daily Page Views:** ${Math.round(metrics.dailyPageViews).toLocaleString()}
- **Monthly Revenue:** £${Math.round(metrics.monthlyRevenue).toLocaleString()}
- **Response Time:** ${Math.round(metrics.responseTime)}ms
- **Error Rate:** ${(metrics.errorRate * 100).toFixed(2)}%
- **Database Load:** ${metrics.databaseConnections} connections

## Scaling Status
**Current Phase:** Railway + Supabase ($30/month)
**Next Phase:** ${alerts.some(a => a.trigger.includes('Phase 2')) ? 'Vercel + PlanetScale ($49/month)' : 'Staying on current infrastructure'}

## Recommendations
${alerts.length > 0 ? alerts.map(alert => `
- **${alert.level.toUpperCase()}:** ${alert.recommendation}
  - Cost Impact: ${alert.estimatedCost}
  - Implementation: ${alert.timeToImplement}
`).join('\n') : 'No scaling actions needed at this time.'}

## Revenue Projections
- **Current trajectory:** £${Math.round(metrics.monthlyRevenue * 12)} annually
- **Next milestone:** ${metrics.monthlyRevenue < 1000 ? '£1,000/month' : metrics.monthlyRevenue < 6000 ? '£6,000/month' : '£20,000/month'}
- **Infrastructure cost ratio:** ${((30 / metrics.monthlyRevenue) * 100).toFixed(1)}% of revenue
    `.trim();
  }
}

export const scalingMonitor = new ScalingMonitor();