/**
 * Proper Crossword Constructor
 * Based on authentic crossword construction algorithms
 * Implements proper numbering and word placement logic
 */

import { CrosswordAnswer, easyAnswers, mediumAnswers, hardAnswers, dedicatedAnswers } from './crossword-data';
import { clueVariationSystem } from './clue-variation-system';

interface CrosswordCell {
  letter: string | null;
  number: number | null;
  isBlack: boolean;
  startAcross: boolean;
  startDown: boolean;
}

interface WordSlot {
  number: number;
  row: number;
  col: number;
  length: number;
  direction: 'across' | 'down';
  cells: Array<{row: number, col: number}>;
}

interface PlacedWord {
  word: string;
  clue: string;
  slot: WordSlot;
  answer: CrosswordAnswer;
}

interface CrosswordClue {
  number: number;
  clue: string;
  answer: string;
  row: number;
  col: number;
}

interface CrosswordPuzzle {
  id: string;
  date: string;
  difficulty: 'easy' | 'medium' | 'hard' | 'dedicated';
  grid: string[][];
  solution: string[][];
  clues: {
    across: CrosswordClue[];
    down: CrosswordClue[];
  };
  size: number;
}

export class ProperCrosswordConstructor {
  private gridSize = 15;
  private grid: CrosswordCell[][];
  private placedWords: PlacedWord[] = [];
  private wordSlots: WordSlot[] = [];

  private targets = {
    easy: { across: 5, down: 7 },
    medium: { across: 8, down: 10 },
    hard: { across: 12, down: 15 },
    dedicated: { across: 15, down: 18 }
  };

  constructor() {
    this.initializeGrid();
  }

  private seededRandom(seed: number) {
    return function() {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };
  }

  async constructCrossword(difficulty: 'easy' | 'medium' | 'hard' | 'dedicated', date: string): Promise<CrosswordPuzzle> {
    // Set deterministic random for consistent daily puzzles
    const baseSeed = { easy: 1000, medium: 2000, hard: 3000, dedicated: 4000 }[difficulty];
    const dateSeed = parseInt(date.replace(/-/g, '')) % 1000;
    Math.random = this.seededRandom(baseSeed + dateSeed);

    // Initialize
    this.initializeGrid();
    this.placedWords = [];
    this.wordSlots = [];
    
    // Get answers for this difficulty
    let answers: CrosswordAnswer[];
    switch (difficulty) {
      case 'easy': answers = easyAnswers; break;
      case 'medium': answers = mediumAnswers; break;
      case 'hard': answers = hardAnswers; break;
      case 'dedicated': answers = dedicatedAnswers; break;
      default: answers = mediumAnswers;
    }
    const target = this.targets[difficulty];
    
    console.log(`ProperCrossword: Constructing ${difficulty} crossword with ${answers.length} available answers`);
    console.log(`Target: ${target.across} across, ${target.down} down`);
    
    // Step 1: Create authentic black square pattern
    this.createAuthenticBlackSquarePattern();
    
    // Step 2: Number the grid according to crossword rules
    this.numberGridProperly();
    
    // Step 3: Find all valid word slots
    this.findAllWordSlots();
    
    // Step 4: Place words in slots
    this.placeWordsInSlots(answers, target);
    
    // Step 5: Generate clues
    const clues = this.generateClues(date, difficulty);
    
    // Step 6: Create final grids
    const puzzleGrid = this.createPuzzleGrid();
    const solutionGrid = this.createSolutionGrid();

    console.log(`ProperCrossword: Final result - ${this.placedWords.length} words placed`);

    return {
      id: `crossword-${date}-${difficulty}`,
      date,
      difficulty,
      grid: puzzleGrid,
      solution: solutionGrid,
      clues,
      size: this.gridSize
    };
  }

  private initializeGrid(): void {
    this.grid = [];
    for (let row = 0; row < this.gridSize; row++) {
      this.grid[row] = [];
      for (let col = 0; col < this.gridSize; col++) {
        this.grid[row][col] = {
          letter: null,
          number: null,
          isBlack: false,
          startAcross: false,
          startDown: false
        };
      }
    }
  }

  private createAuthenticBlackSquarePattern(): void {
    // Use a proven symmetric pattern similar to professional crosswords
    const blackSquares = [
      [0, 3], [0, 11], [1, 6], [1, 8], [2, 1], [2, 13], 
      [3, 4], [3, 10], [4, 0], [4, 7], [4, 14], 
      [5, 2], [5, 5], [5, 9], [5, 12], [6, 6], [6, 8], 
      [7, 3], [7, 11], [8, 6], [8, 8], 
      [9, 2], [9, 5], [9, 9], [9, 12], [10, 0], [10, 7], [10, 14], 
      [11, 4], [11, 10], [12, 1], [12, 13], [13, 6], [13, 8], 
      [14, 3], [14, 11]
    ];

    // Apply black squares
    blackSquares.forEach(([row, col]) => {
      if (row >= 0 && row < this.gridSize && col >= 0 && col < this.gridSize) {
        this.grid[row][col].isBlack = true;
      }
    });

    console.log(`ProperCrossword: Applied ${blackSquares.length} black squares in symmetric pattern`);
  }

  private numberGridProperly(): void {
    let currentNumber = 1;
    
    // Number grid according to authentic crossword rules:
    // 1. Number each white square that starts a word (across or down)
    // 2. A square starts an across word if: 
    //    - It's white AND (it's the leftmost column OR the square to its left is black)
    //    - AND there's at least one more white square to its right
    // 3. A square starts a down word if:
    //    - It's white AND (it's the top row OR the square above it is black)
    //    - AND there's at least one more white square below it

    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        if (!this.grid[row][col].isBlack) {
          const startsAcross = this.startsAcrossWord(row, col);
          const startsDown = this.startsDownWord(row, col);
          
          if (startsAcross || startsDown) {
            this.grid[row][col].number = currentNumber;
            this.grid[row][col].startAcross = startsAcross;
            this.grid[row][col].startDown = startsDown;
            currentNumber++;
          }
        }
      }
    }
    
    console.log(`ProperCrossword: Grid numbered with ${currentNumber - 1} starting positions`);
  }

  private startsAcrossWord(row: number, col: number): boolean {
    // Must be at left edge or have black square to left
    const hasLeftBoundary = col === 0 || this.grid[row][col - 1].isBlack;
    
    if (!hasLeftBoundary) return false;
    
    // Must have at least 3 consecutive white squares
    let length = 0;
    for (let c = col; c < this.gridSize && !this.grid[row][c].isBlack; c++) {
      length++;
    }
    
    return length >= 3;
  }

  private startsDownWord(row: number, col: number): boolean {
    // Must be at top edge or have black square above
    const hasTopBoundary = row === 0 || this.grid[row - 1][col].isBlack;
    
    if (!hasTopBoundary) return false;
    
    // Must have at least 3 consecutive white squares
    let length = 0;
    for (let r = row; r < this.gridSize && !this.grid[r][col].isBlack; r++) {
      length++;
    }
    
    return length >= 3;
  }

  private findAllWordSlots(): void {
    this.wordSlots = [];
    
    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        const cell = this.grid[row][col];
        if (!cell.isBlack && cell.number) {
          
          // Check for across word
          if (cell.startAcross) {
            const length = this.getWordLength(row, col, 'across');
            const cells = [];
            for (let c = col; c < col + length; c++) {
              cells.push({row, col: c});
            }
            
            this.wordSlots.push({
              number: cell.number,
              row,
              col,
              length,
              direction: 'across',
              cells
            });
          }
          
          // Check for down word
          if (cell.startDown) {
            const length = this.getWordLength(row, col, 'down');
            const cells = [];
            for (let r = row; r < row + length; r++) {
              cells.push({row: r, col});
            }
            
            this.wordSlots.push({
              number: cell.number,
              row,
              col,
              length,
              direction: 'down',
              cells
            });
          }
        }
      }
    }
    
    console.log(`ProperCrossword: Found ${this.wordSlots.length} word slots`);
  }

  private getWordLength(row: number, col: number, direction: 'across' | 'down'): number {
    let length = 0;
    const deltaRow = direction === 'down' ? 1 : 0;
    const deltaCol = direction === 'across' ? 1 : 0;
    
    let currentRow = row;
    let currentCol = col;
    
    while (currentRow < this.gridSize && currentCol < this.gridSize && 
           !this.grid[currentRow][currentCol].isBlack) {
      length++;
      currentRow += deltaRow;
      currentCol += deltaCol;
    }
    
    return length;
  }

  private placeWordsInSlots(answers: CrosswordAnswer[], target: {across: number, down: number}): void {
    const shuffledAnswers = [...answers].sort(() => Math.random() - 0.5);
    const usedWords = new Set<string>();
    
    // Separate slots by direction
    const acrossSlots = this.wordSlots.filter(slot => slot.direction === 'across');
    const downSlots = this.wordSlots.filter(slot => slot.direction === 'down');
    
    let acrossCount = 0;
    let downCount = 0;
    
    // Fill across slots first
    for (const slot of acrossSlots) {
      if (acrossCount >= target.across) break;
      
      const matchingWords = shuffledAnswers.filter(answer => 
        answer.word.length === slot.length && 
        !usedWords.has(answer.word) &&
        this.canPlaceWord(answer.word, slot)
      );
      
      if (matchingWords.length > 0) {
        const selectedWord = matchingWords[0];
        this.placeWordInSlot(selectedWord, slot);
        usedWords.add(selectedWord.word);
        acrossCount++;
        
        console.log(`ProperCrossword: Placed "${selectedWord.word}" across at ${slot.row},${slot.col} (${slot.number})`);
      }
    }
    
    // Fill down slots
    for (const slot of downSlots) {
      if (downCount >= target.down) break;
      
      const matchingWords = shuffledAnswers.filter(answer => 
        answer.word.length === slot.length && 
        !usedWords.has(answer.word) &&
        this.canPlaceWord(answer.word, slot)
      );
      
      if (matchingWords.length > 0) {
        const selectedWord = matchingWords[0];
        this.placeWordInSlot(selectedWord, slot);
        usedWords.add(selectedWord.word);
        downCount++;
        
        console.log(`ProperCrossword: Placed "${selectedWord.word}" down at ${slot.row},${slot.col} (${slot.number})`);
      }
    }
    
    console.log(`ProperCrossword: Placed ${acrossCount} across and ${downCount} down words`);
  }

  private canPlaceWord(word: string, slot: WordSlot): boolean {
    // Check if word can be placed without conflicts
    for (let i = 0; i < word.length; i++) {
      const {row, col} = slot.cells[i];
      const currentLetter = this.grid[row][col].letter;
      
      if (currentLetter && currentLetter !== word[i]) {
        return false; // Conflict with existing letter
      }
    }
    
    return true;
  }

  private placeWordInSlot(answer: CrosswordAnswer, slot: WordSlot): void {
    // Place letters in grid
    for (let i = 0; i < answer.word.length; i++) {
      const {row, col} = slot.cells[i];
      this.grid[row][col].letter = answer.word[i];
    }
    
    // Record placement
    this.placedWords.push({
      word: answer.word,
      clue: answer.clue,
      slot,
      answer
    });
  }

  private generateClues(date: string, difficulty: string): { across: CrosswordClue[]; down: CrosswordClue[] } {
    const across: CrosswordClue[] = [];
    const down: CrosswordClue[] = [];
    
    for (const placement of this.placedWords) {
      const clue = clueVariationSystem.getUniqueClue(placement.word, difficulty, date);
      
      const clueEntry: CrosswordClue = {
        number: placement.slot.number,
        clue,
        answer: placement.word,
        row: placement.slot.row,
        col: placement.slot.col
      };
      
      if (placement.slot.direction === 'across') {
        across.push(clueEntry);
      } else {
        down.push(clueEntry);
      }
    }
    
    // Sort by number
    across.sort((a, b) => a.number - b.number);
    down.sort((a, b) => a.number - b.number);
    
    return { across, down };
  }

  private createPuzzleGrid(): string[][] {
    return this.grid.map(row =>
      row.map(cell => {
        if (cell.isBlack) return '█';
        if (cell.number) return cell.number.toString();
        return ' ';
      })
    );
  }

  private createSolutionGrid(): string[][] {
    return this.grid.map(row =>
      row.map(cell => {
        if (cell.isBlack) return '█';
        return cell.letter || ' ';
      })
    );
  }
}

export const properCrosswordConstructor = new ProperCrosswordConstructor();