import * as cheerio from "cheerio";
import { aiContentGenerator } from "./ai-content";

interface ShentonStageArticle {
  title: string;
  content: string;
  url: string;
  author: string;
  publishedDate: string;
  category: string;
  excerpt: string;
}

export class ShentonStageScraper {
  private baseUrl = 'https://www.shentonstage.com';
  private processedCount = 0;
  private observationsCreated = 0;

  async scrapeAllContent(): Promise<{ processed: number; observationsCreated: number }> {
    console.log('🎭 Starting comprehensive Shentonstage.com scraping...');
    
    try {
      // Get sitemap or main sections
      const sections = await this.discoverSections();
      
      for (const section of sections) {
        console.log(`Scraping section: ${section}`);
        await this.scrapeSection(section);
        
        // Delay between sections
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
      
      console.log(`Scraping complete: ${this.processedCount} articles processed, ${this.observationsCreated} ShentonAI observations created`);
      
      return {
        processed: this.processedCount,
        observationsCreated: this.observationsCreated
      };
      
    } catch (error) {
      console.error('Error in comprehensive scraping:', error);
      return {
        processed: this.processedCount,
        observationsCreated: this.observationsCreated
      };
    }
  }

  private async discoverSections(): Promise<string[]> {
    try {
      const response = await fetch(this.baseUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; Theatre Spotlight Bot)',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const html = await response.text();
      const $ = cheerio.load(html);
      
      // Extract navigation links to find all sections
      const sections = new Set<string>();
      
      // Common section patterns
      const sectionSelectors = [
        'nav a[href*="/"]',
        '.menu a[href*="/"]', 
        '.navigation a[href*="/"]',
        'header a[href*="/"]',
        '.nav-link[href*="/"]'
      ];
      
      sectionSelectors.forEach(selector => {
        $(selector).each((i, element) => {
          const href = $(element).attr('href');
          if (href && href.startsWith('/') && href.length > 1) {
            sections.add(href);
          }
        });
      });
      
      // Add known theatre content sections
      const knownSections = [
        '/reviews',
        '/news', 
        '/interviews',
        '/features',
        '/opinion',
        '/west-end',
        '/broadway',
        '/off-west-end',
        '/touring',
        '/fringe',
        '/musicals'
      ];
      
      knownSections.forEach(section => sections.add(section));
      
      console.log(`Discovered ${sections.size} sections to scrape`);
      return Array.from(sections);
      
    } catch (error) {
      console.error('Error discovering sections:', error);
      // Fallback to known sections
      return ['/reviews', '/news', '/interviews', '/features', '/opinion'];
    }
  }

  private async scrapeSection(sectionPath: string): Promise<void> {
    try {
      // Scrape multiple pages of each section
      for (let page = 1; page <= 20; page++) {
        const articles = await this.scrapePage(sectionPath, page);
        
        if (articles.length === 0) {
          console.log(`No more articles found in ${sectionPath} at page ${page}`);
          break;
        }
        
        console.log(`Found ${articles.length} articles in ${sectionPath} page ${page}`);
        
        // Process each article through ShentonAI
        for (const article of articles) {
          await this.processArticleWithShentonAI(article);
          this.processedCount++;
          
          // Rate limiting
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
        
        // Delay between pages
        await new Promise(resolve => setTimeout(resolve, 1500));
      }
    } catch (error) {
      console.error(`Error scraping section ${sectionPath}:`, error);
    }
  }

  private async scrapePage(sectionPath: string, page: number): Promise<ShentonStageArticle[]> {
    const articles: ShentonStageArticle[] = [];
    
    try {
      const pageUrl = page === 1 
        ? `${this.baseUrl}${sectionPath}`
        : `${this.baseUrl}${sectionPath}?page=${page}`;
      
      console.log(`Scraping: ${pageUrl}`);
      
      const response = await fetch(pageUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; Theatre Spotlight Bot)',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }
      });
      
      if (!response.ok) {
        if (response.status === 404) {
          return []; // No more pages
        }
        throw new Error(`HTTP ${response.status}`);
      }
      
      const html = await response.text();
      const $ = cheerio.load(html);
      
      // Extract articles with various selectors
      const articleSelectors = [
        'article',
        '.post',
        '.entry', 
        '.article-item',
        '.content-item',
        '.blog-post',
        '.news-item',
        '.review-item'
      ];
      
      articleSelectors.forEach(selector => {
        $(selector).each((index, element) => {
          const article = this.extractArticleData($, $(element), sectionPath);
          if (article && article.title && article.content) {
            articles.push(article);
          }
        });
      });
      
      // Also try extracting from direct content if no articles found
      if (articles.length === 0) {
        const directArticle = this.extractDirectContent($, sectionPath, pageUrl);
        if (directArticle) {
          articles.push(directArticle);
        }
      }
      
    } catch (error) {
      console.error(`Error scraping page ${page} of ${sectionPath}:`, error);
    }
    
    return articles;
  }

  private extractArticleData($: cheerio.CheerioAPI, $article: cheerio.Cheerio<cheerio.Element>, category: string): ShentonStageArticle | null {
    try {
      // Extract title with multiple selectors
      const titleSelectors = ['h1', 'h2', 'h3', '.title', '.headline', '.entry-title', '.post-title'];
      let title = '';
      
      for (const selector of titleSelectors) {
        title = $article.find(selector).first().text().trim();
        if (title) break;
      }
      
      // Extract content
      const contentSelectors = ['.content', '.body', '.text', '.entry-content', '.post-content', 'p'];
      let content = '';
      
      for (const selector of contentSelectors) {
        const contentText = $article.find(selector).text().trim();
        if (contentText && contentText.length > content.length) {
          content = contentText;
        }
      }
      
      // Extract other metadata
      const link = $article.find('a').first().attr('href') || '';
      const author = $article.find('.author, .byline, .writer').text().trim() || 'Mark Shenton';
      const date = $article.find('.date, time, .published').text().trim() || new Date().toISOString();
      
      // Create excerpt from content
      const excerpt = content.length > 200 ? content.substring(0, 200) + '...' : content;
      
      if (!title || !content || content.length < 100) {
        return null;
      }
      
      return {
        title,
        content: content.substring(0, 3000), // Limit content length
        url: link.startsWith('http') ? link : `${this.baseUrl}${link}`,
        author,
        publishedDate: date,
        category: category.replace('/', ''),
        excerpt
      };
      
    } catch (error) {
      console.error('Error extracting article data:', error);
      return null;
    }
  }

  private extractDirectContent($: cheerio.CheerioAPI, category: string, url: string): ShentonStageArticle | null {
    try {
      // For pages that might be single articles
      const title = $('h1').first().text().trim() || $('title').text().trim();
      const content = $('.content, .article, .post, main').text().trim();
      
      if (!title || !content || content.length < 100) {
        return null;
      }
      
      return {
        title,
        content: content.substring(0, 3000),
        url,
        author: 'Mark Shenton',
        publishedDate: new Date().toISOString(),
        category: category.replace('/', ''),
        excerpt: content.substring(0, 200) + '...'
      };
      
    } catch (error) {
      console.error('Error extracting direct content:', error);
      return null;
    }
  }

  private async processArticleWithShentonAI(article: ShentonStageArticle): Promise<void> {
    try {
      // Create ShentonAI observation from Shentonstage content
      const observation = await aiContentGenerator.generateObservationFromNews({
        title: article.title,
        content: article.content,
        source: 'Shentonstage.com',
        publishedAt: new Date(),
        region: this.determineRegion(article.content),
        category: this.mapCategory(article.category)
      });

      if (observation) {
        this.observationsCreated++;
        console.log(`Created ShentonAI observation: "${observation.title}"`);
      }
      
    } catch (error) {
      console.error(`Error processing article "${article.title}":`, error);
    }
  }

  private determineRegion(content: string): 'uk' | 'us' | 'both' {
    const ukTerms = ['west end', 'london', 'uk', 'britain', 'british', 'olivier', 'national theatre'];
    const usTerms = ['broadway', 'new york', 'tony', 'off-broadway', 'manhattan'];
    
    const lowerContent = content.toLowerCase();
    const ukCount = ukTerms.filter(term => lowerContent.includes(term)).length;
    const usCount = usTerms.filter(term => lowerContent.includes(term)).length;
    
    if (ukCount > usCount) return 'uk';
    if (usCount > ukCount) return 'us';
    return 'both';
  }

  private mapCategory(category: string): 'news' | 'review' | 'announcement' {
    const lowerCategory = category.toLowerCase();
    
    if (lowerCategory.includes('review')) return 'review';
    if (lowerCategory.includes('news')) return 'news';
    if (lowerCategory.includes('announcement') || lowerCategory.includes('feature')) return 'announcement';
    
    return 'news';
  }
}

export const shentonStageScraper = new ShentonStageScraper();