import { db } from "./db";
import { topicFollowers, articles, reviews } from "../shared/schema";
import { eq, and, inArray } from "drizzle-orm";

interface TopicAlert {
  id: string;
  userId?: number;
  email: string;
  topic: string;
  topicType: 'show' | 'performer' | 'venue' | 'category' | 'keyword';
  isActive: boolean;
  frequency: 'immediate' | 'daily' | 'weekly';
  lastSent?: Date;
  createdAt: Date;
}

interface AlertNotification {
  id: string;
  alertId: string;
  contentId: number;
  contentType: 'article' | 'review';
  title: string;
  excerpt: string;
  url: string;
  sentAt: Date;
  opened?: boolean;
  clicked?: boolean;
}

export class TopicAlertSystem {
  private pendingAlerts: Map<string, AlertNotification[]> = new Map();

  async subscribeToTopic(data: {
    email: string;
    topic: string;
    topicType: 'show' | 'performer' | 'venue' | 'category' | 'keyword';
    frequency?: 'immediate' | 'daily' | 'weekly';
    userId?: number;
  }): Promise<{ success: boolean; alertId?: string; message: string }> {
    try {
      // Check if already subscribed
      const existingAlert = await db
        .select()
        .from(topicFollowers)
        .where(
          and(
            eq(topicFollowers.email, data.email),
            eq(topicFollowers.topic, data.topic),
            eq(topicFollowers.topicType, data.topicType)
          )
        );

      if (existingAlert.length > 0) {
        // Reactivate if inactive
        if (!existingAlert[0].isActive) {
          await db
            .update(topicFollowers)
            .set({ isActive: true, frequency: data.frequency || 'immediate' })
            .where(eq(topicFollowers.id, existingAlert[0].id));
          
          return {
            success: true,
            alertId: existingAlert[0].id.toString(),
            message: 'Subscription reactivated successfully'
          };
        }
        
        return {
          success: false,
          message: `Already subscribed to ${data.topic} alerts`
        };
      }

      // Create new subscription
      const [newAlert] = await db
        .insert(topicFollowers)
        .values({
          userId: data.userId,
          email: data.email,
          topic: data.topic,
          topicType: data.topicType,
          frequency: data.frequency || 'immediate',
          isActive: true,
          createdAt: new Date()
        })
        .returning();

      // Send confirmation email
      await this.sendConfirmationEmail(data.email, data.topic, data.topicType);

      return {
        success: true,
        alertId: newAlert.id.toString(),
        message: `Successfully subscribed to ${data.topic} alerts`
      };

    } catch (error) {
      console.error('Error subscribing to topic:', error);
      return {
        success: false,
        message: 'Failed to subscribe to topic alerts'
      };
    }
  }

  async unsubscribeFromTopic(alertId: string, email: string): Promise<{ success: boolean; message: string }> {
    try {
      const result = await db
        .update(topicFollowers)
        .set({ isActive: false })
        .where(
          and(
            eq(topicFollowers.id, parseInt(alertId)),
            eq(topicFollowers.email, email)
          )
        );

      return {
        success: true,
        message: 'Successfully unsubscribed from topic alerts'
      };

    } catch (error) {
      console.error('Error unsubscribing from topic:', error);
      return {
        success: false,
        message: 'Failed to unsubscribe from topic alerts'
      };
    }
  }

  async checkForNewContent(): Promise<void> {
    console.log('Checking for new content to alert followers...');
    
    try {
      // Get all active subscriptions
      const activeAlerts = await db
        .select()
        .from(topicFollowers)
        .where(eq(topicFollowers.isActive, true));

      // Get recent content (last 24 hours)
      const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

      const recentArticles = await db
        .select()
        .from(articles)
        .where(eq(articles.publishedAt, oneDayAgo)); // This would need proper date comparison

      const recentReviews = await db
        .select()
        .from(reviews)
        .where(eq(reviews.publishedAt, oneDayAgo)); // This would need proper date comparison

      // Process alerts
      for (const alert of activeAlerts) {
        await this.processAlertForContent(alert, recentArticles, recentReviews);
      }

      // Send batched alerts
      await this.sendBatchedAlerts();

    } catch (error) {
      console.error('Error checking for new content:', error);
    }
  }

  private async processAlertForContent(alert: any, articles: any[], reviews: any[]): Promise<void> {
    const matchingContent: AlertNotification[] = [];

    // Check articles
    for (const article of articles) {
      if (this.contentMatchesTopi(article, alert)) {
        matchingContent.push({
          id: `alert-${alert.id}-article-${article.id}`,
          alertId: alert.id.toString(),
          contentId: article.id,
          contentType: 'article',
          title: article.title,
          excerpt: article.excerpt || article.content.substring(0, 150) + '...',
          url: `/news/${article.slug}`,
          sentAt: new Date(),
          opened: false,
          clicked: false
        });
      }
    }

    // Check reviews
    for (const review of reviews) {
      if (this.contentMatchesTopi(review, alert)) {
        matchingContent.push({
          id: `alert-${alert.id}-review-${review.id}`,
          alertId: alert.id.toString(),
          contentId: review.id,
          contentType: 'review',
          title: review.title,
          excerpt: review.excerpt || review.content.substring(0, 150) + '...',
          url: `/reviews/${review.slug}`,
          sentAt: new Date(),
          opened: false,
          clicked: false
        });
      }
    }

    // Store pending alerts
    if (matchingContent.length > 0) {
      const existing = this.pendingAlerts.get(alert.email) || [];
      this.pendingAlerts.set(alert.email, [...existing, ...matchingContent]);
    }
  }

  private contentMatchesTopi(content: any, alert: any): boolean {
    const topic = alert.topic.toLowerCase();
    const title = content.title.toLowerCase();
    const contentText = content.content.toLowerCase();

    switch (alert.topicType) {
      case 'show':
        return title.includes(topic) || contentText.includes(topic);
      
      case 'performer':
        return title.includes(topic) || contentText.includes(topic);
      
      case 'venue':
        return content.venue?.toLowerCase().includes(topic) || 
               title.includes(topic) || 
               contentText.includes(topic);
      
      case 'category':
        return content.category === topic;
      
      case 'keyword':
        return title.includes(topic) || contentText.includes(topic);
      
      default:
        return false;
    }
  }

  private async sendBatchedAlerts(): Promise<void> {
    for (const [email, alerts] of this.pendingAlerts.entries()) {
      try {
        await this.sendAlertEmail(email, alerts);
        
        // Update last sent timestamp
        const alertIds = [...new Set(alerts.map(a => parseInt(a.alertId)))];
        await db
          .update(topicFollowers)
          .set({ lastSent: new Date() })
          .where(inArray(topicFollowers.id, alertIds));

      } catch (error) {
        console.error(`Error sending alert to ${email}:`, error);
      }
    }

    // Clear pending alerts
    this.pendingAlerts.clear();
  }

  private async sendAlertEmail(email: string, alerts: AlertNotification[]): Promise<void> {
    // Group alerts by topic
    const groupedAlerts = alerts.reduce((groups, alert) => {
      const key = alert.alertId;
      if (!groups[key]) groups[key] = [];
      groups[key].push(alert);
      return groups;
    }, {} as Record<string, AlertNotification[]>);

    const subject = alerts.length === 1 
      ? `New article: ${alerts[0].title}` 
      : `${alerts.length} new theatre articles for your followed topics`;

    const htmlContent = this.generateAlertEmailHTML(email, groupedAlerts);

    // In production, use actual email service
    console.log(`Sending alert email to ${email}:`);
    console.log(`Subject: ${subject}`);
    console.log(`Content: ${htmlContent}`);
  }

  private generateAlertEmailHTML(email: string, groupedAlerts: Record<string, AlertNotification[]>): string {
    let html = `
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .header { background-color: #8B4513; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; }
            .alert-group { margin-bottom: 30px; border-bottom: 1px solid #eee; padding-bottom: 20px; }
            .article { margin-bottom: 15px; padding: 10px; border-left: 3px solid #DAA520; }
            .article h3 { margin: 0 0 5px 0; color: #8B4513; }
            .article p { margin: 5px 0; color: #666; }
            .cta-button { display: inline-block; background-color: #DAA520; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin: 5px 0; }
            .footer { background-color: #f5f5f5; padding: 15px; text-align: center; font-size: 12px; }
            .unsubscribe { color: #666; text-decoration: none; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>🎭 Theatre Spotlight</h1>
            <p>Your followed topics have new content!</p>
          </div>
          
          <div class="content">
    `;

    for (const [alertId, alerts] of Object.entries(groupedAlerts)) {
      html += `<div class="alert-group">`;
      
      for (const alert of alerts) {
        html += `
          <div class="article">
            <h3>${alert.title}</h3>
            <p>${alert.excerpt}</p>
            <a href="https://theatrespotlight.com${alert.url}?utm_source=email&utm_medium=alert&utm_campaign=topic_follow" class="cta-button">
              Read ${alert.contentType === 'article' ? 'Article' : 'Review'}
            </a>
          </div>
        `;
      }
      
      html += `</div>`;
    }

    html += `
          </div>
          
          <div class="footer">
            <p>You're receiving this because you follow topics on Theatre Spotlight.</p>
            <p>
              <a href="https://theatrespotlight.com/unsubscribe?email=${encodeURIComponent(email)}" class="unsubscribe">
                Manage your topic subscriptions
              </a>
            </p>
            <p>Theatre Spotlight - The world's leading theatre news source</p>
          </div>
        </body>
      </html>
    `;

    return html;
  }

  private async sendConfirmationEmail(email: string, topic: string, topicType: string): Promise<void> {
    console.log(`Sending confirmation email to ${email} for ${topicType}: ${topic}`);
    
    // In production, send actual confirmation email
    const subject = `Confirmed: Following ${topic} on Theatre Spotlight`;
    const content = `
      You're now following "${topic}" (${topicType}) on Theatre Spotlight.
      You'll receive alerts when new articles or reviews are published about this topic.
      
      Manage your subscriptions: https://theatrespotlight.com/alerts
    `;
  }

  async getUserAlerts(email: string): Promise<any[]> {
    try {
      return await db
        .select()
        .from(topicFollowers)
        .where(and(
          eq(topicFollowers.email, email),
          eq(topicFollowers.isActive, true)
        ));
    } catch (error) {
      console.error('Error getting user alerts:', error);
      return [];
    }
  }

  async updateAlertFrequency(alertId: string, email: string, frequency: 'immediate' | 'daily' | 'weekly'): Promise<boolean> {
    try {
      await db
        .update(topicFollowers)
        .set({ frequency })
        .where(and(
          eq(topicFollowers.id, parseInt(alertId)),
          eq(topicFollowers.email, email)
        ));
      
      return true;
    } catch (error) {
      console.error('Error updating alert frequency:', error);
      return false;
    }
  }

  // Popular topics for suggestion
  async getPopularTopics(): Promise<{ topic: string; topicType: string; followers: number }[]> {
    // Mock data - in production would query database
    return [
      { topic: 'Hamilton', topicType: 'show', followers: 1250 },
      { topic: 'Wicked', topicType: 'show', followers: 980 },
      { topic: 'Lin-Manuel Miranda', topicType: 'performer', followers: 756 },
      { topic: 'Broadway', topicType: 'category', followers: 2100 },
      { topic: 'West End', topicType: 'category', followers: 1800 },
      { topic: 'Patti LuPone', topicType: 'performer', followers: 634 },
      { topic: 'The Phantom of the Opera', topicType: 'show', followers: 523 },
      { topic: 'Majestic Theatre', topicType: 'venue', followers: 234 },
      { topic: 'Tony Awards', topicType: 'keyword', followers: 1456 },
      { topic: 'Stephen Sondheim', topicType: 'performer', followers: 445 }
    ];
  }
}

export const topicAlertSystem = new TopicAlertSystem();