/**
 * Simple Working Crossword Generator
 * Generates reliable theatre crosswords using comprehensive vocabulary
 */

import { getWordsByDifficulty, getAllWords, vocabularyStats } from './comprehensive-theatre-vocabulary';
import { getMassiveTheatreWords, massiveStats } from './massive-theatre-database';
import { getBroadwayLegendsWords, legendsStats } from './broadway-legends-database';
import { generateMillionTheatreWords, getMillionWordStats } from './million-word-generator';
import { generateUltraMassiveDatabase } from './ultra-massive-generator';

export interface CrosswordPuzzle {
  id: string;
  date: string;
  difficulty: string;
  title: string;
  grid: string[][];
  solution: string[][];
  clues: {
    across: CrosswordClue[];
    down: CrosswordClue[];
  };
  size: number;
}

export interface CrosswordClue {
  number: number;
  clue: string;
  answer: string;
  startRow: number;
  startCol: number;
  length: number;
  direction: 'across' | 'down';
}

class SimpleWorkingCrossword {
  generateCrossword(difficulty: string, date: string): CrosswordPuzzle {
    console.log(`Generating ${difficulty} crossword for ${date}`);
    const ultraMassive = generateUltraMassiveDatabase();
    console.log(`Using comprehensive vocabulary: ${vocabularyStats.total} total words`);
    console.log(`Using massive database: ${massiveStats.total} biographical words`);
    console.log(`Using Broadway legends: ${legendsStats.total} legendary words`);
    console.log(`Using ultra-massive generator: ${ultraMassive.length} systematic words`);
    console.log(`🎯 TOTAL AVAILABLE: ${vocabularyStats.total + massiveStats.total + legendsStats.total + ultraMassive.length} crossword clues`);
    
    const templates = this.getCrosswordTemplates();
    const template = templates[difficulty] || templates['medium'];
    
    return this.buildCrosswordFromTemplate(template, difficulty, date);
  }
  
  private getCrosswordTemplates() {
    return {
      easy: {
        size: 15,
        words: this.selectWordsForGrid('easy', [
          // Horizontal words (longer answers)
          { length: 6, row: 1, col: 1, direction: 'across', number: 1 },
          { length: 4, row: 3, col: 1, direction: 'across', number: 7 },
          { length: 5, row: 5, col: 1, direction: 'across', number: 8 },
          { length: 4, row: 7, col: 1, direction: 'across', number: 9 },
          { length: 5, row: 9, col: 1, direction: 'across', number: 11 },
          { length: 6, row: 11, col: 1, direction: 'across', number: 13 },
          
          // Vertical words
          { length: 5, row: 1, col: 1, direction: 'down', number: 1 },
          { length: 4, row: 1, col: 2, direction: 'down', number: 2 },
          { length: 5, row: 1, col: 3, direction: 'down', number: 3 },
          { length: 4, row: 1, col: 4, direction: 'down', number: 4 },
          { length: 5, row: 1, col: 5, direction: 'down', number: 5 },
          { length: 4, row: 1, col: 6, direction: 'down', number: 6 }
        ])
      },
      
      medium: {
        size: 15,
        words: this.selectWordsForGrid('medium', [
          // Horizontal words - major shows
          { length: 8, row: 1, col: 1, direction: 'across', number: 1 },
          { length: 6, row: 3, col: 1, direction: 'across', number: 8 },
          { length: 7, row: 5, col: 1, direction: 'across', number: 10 },
          { length: 7, row: 7, col: 1, direction: 'across', number: 12 },
          { length: 7, row: 9, col: 1, direction: 'across', number: 14 },
          { length: 5, row: 11, col: 1, direction: 'across', number: 16 },
          
          // Vertical words - composers, actors, terms
          { length: 9, row: 1, col: 1, direction: 'down', number: 1 },
          { length: 6, row: 1, col: 2, direction: 'down', number: 2 },
          { length: 7, row: 1, col: 3, direction: 'down', number: 3 },
          { length: 4, row: 1, col: 4, direction: 'down', number: 4 },
          { length: 5, row: 1, col: 5, direction: 'down', number: 5 },
          { length: 5, row: 1, col: 6, direction: 'down', number: 6 },
          { length: 5, row: 1, col: 7, direction: 'down', number: 7 },
          { length: 5, row: 1, col: 8, direction: 'down', number: 9 }
        ])
      },
      
      hard: {
        size: 15,
        words: this.selectWordsForGrid('hard', [
          // Horizontal words - composers and complex shows
          { length: 8, row: 1, col: 1, direction: 'across', number: 1 },
          { length: 6, row: 3, col: 1, direction: 'across', number: 9 },
          { length: 7, row: 5, col: 1, direction: 'across', number: 11 },
          { length: 7, row: 7, col: 1, direction: 'across', number: 13 },
          { length: 9, row: 9, col: 1, direction: 'across', number: 15 },
          { length: 8, row: 11, col: 1, direction: 'across', number: 17 },
          
          // Vertical words - advanced terminology and names
          { length: 7, row: 1, col: 1, direction: 'down', number: 1 },
          { length: 5, row: 1, col: 2, direction: 'down', number: 2 },
          { length: 6, row: 1, col: 3, direction: 'down', number: 3 },
          { length: 5, row: 1, col: 4, direction: 'down', number: 4 },
          { length: 6, row: 1, col: 5, direction: 'down', number: 5 },
          { length: 6, row: 1, col: 6, direction: 'down', number: 6 },
          { length: 6, row: 1, col: 7, direction: 'down', number: 7 },
          { length: 6, row: 1, col: 8, direction: 'down', number: 8 }
        ])
      },
      
      expert: {
        size: 15,
        words: this.selectWordsForGrid('expert', [
          // Horizontal words - advanced terminology and rare shows
          { length: 10, row: 1, col: 1, direction: 'across', number: 1 },
          { length: 9, row: 3, col: 1, direction: 'across', number: 11 },
          { length: 10, row: 5, col: 1, direction: 'across', number: 13 },
          { length: 5, row: 7, col: 1, direction: 'across', number: 15 },
          { length: 8, row: 9, col: 1, direction: 'across', number: 17 },
          { length: 7, row: 11, col: 1, direction: 'across', number: 19 },
          
          // Vertical words - expert level terminology
          { length: 10, row: 1, col: 1, direction: 'down', number: 1 },
          { length: 9, row: 1, col: 2, direction: 'down', number: 2 },
          { length: 8, row: 1, col: 3, direction: 'down', number: 3 },
          { length: 9, row: 1, col: 4, direction: 'down', number: 4 },
          { length: 9, row: 1, col: 5, direction: 'down', number: 5 },
          { length: 8, row: 1, col: 6, direction: 'down', number: 6 },
          { length: 8, row: 1, col: 7, direction: 'down', number: 7 },
          { length: 8, row: 1, col: 8, direction: 'down', number: 8 },
          { length: 10, row: 1, col: 9, direction: 'down', number: 9 },
          { length: 7, row: 1, col: 10, direction: 'down', number: 10 }
        ])
      }
    };
  }
  
  private buildCrosswordFromTemplate(template: any, difficulty: string, date: string): CrosswordPuzzle {
    const size = template.size;
    const grid = Array(size).fill(null).map(() => Array(size).fill('█'));
    const solution = Array(size).fill(null).map(() => Array(size).fill('█'));
    
    // Place all words in the grid
    template.words.forEach((wordData: any) => {
      const { word, row, col, direction } = wordData;
      for (let i = 0; i < word.length; i++) {
        const r = direction === 'across' ? row : row + i;
        const c = direction === 'across' ? col + i : col;
        if (r < size && c < size) {
          grid[r][c] = '';
          solution[r][c] = word[i];
        }
      }
    });
    
    // Separate clues by direction
    const acrossClues = template.words
      .filter((w: any) => w.direction === 'across')
      .map((w: any) => ({
        number: w.number,
        clue: w.clue,
        answer: w.word,
        startRow: w.row,
        startCol: w.col,
        length: w.word.length,
        direction: 'across' as const
      }));
      
    const downClues = template.words
      .filter((w: any) => w.direction === 'down')
      .map((w: any) => ({
        number: w.number,
        clue: w.clue,
        answer: w.word,
        startRow: w.row,
        startCol: w.col,
        length: w.word.length,
        direction: 'down' as const
      }));
    
    return {
      id: `crossword-${date}-${difficulty}`,
      date,
      difficulty,
      title: `Theatre Crossword - ${difficulty.charAt(0).toUpperCase() + difficulty.slice(1)}`,
      grid,
      solution,
      clues: { across: acrossClues, down: downClues },
      size
    };
  }
  
  private selectWordsForGrid(difficulty: string, positions: Array<{length: number, row: number, col: number, direction: string, number: number}>): any[] {
    // Combine all vocabulary databases including ultra-massive generator
    const comprehensiveWords = getWordsByDifficulty(difficulty as any);
    const massiveWords = getMassiveTheatreWords().filter(w => w.difficulty === difficulty);
    const legendsWords = getBroadwayLegendsWords().filter(w => w.difficulty === difficulty);
    const ultraMassiveWords = generateUltraMassiveDatabase().filter(w => w.difficulty === difficulty);
    const availableWords = [...comprehensiveWords, ...massiveWords, ...legendsWords, ...ultraMassiveWords];
    
    console.log(`Total words available for ${difficulty}: ${availableWords.length} (${comprehensiveWords.length} comprehensive + ${massiveWords.length} massive + ${legendsWords.length} legends + ${ultraMassiveWords.length} ultra-massive)`);
    
    const selectedWords: any[] = [];
    const usedWords = new Set<string>();
    
    positions.forEach(pos => {
      // Find words of the right length that haven't been used
      const candidateWords = availableWords.filter(w => w.length === pos.length && !usedWords.has(w.word));
      
      if (candidateWords.length > 0) {
        // Pick a random word from candidates
        const randomWord = candidateWords[Math.floor(Math.random() * candidateWords.length)];
        selectedWords.push({
          word: randomWord.word,
          row: pos.row,
          col: pos.col,
          direction: pos.direction,
          number: pos.number,
          clue: randomWord.clue
        });
        
        // Mark word as used
        usedWords.add(randomWord.word);
      } else {
        // Fallback if no word of exact length found - use any available word
        const fallbackWords = availableWords.filter(w => !usedWords.has(w.word));
        if (fallbackWords.length > 0) {
          const fallbackWord = fallbackWords[Math.floor(Math.random() * fallbackWords.length)];
          selectedWords.push({
            word: fallbackWord.word,
            row: pos.row,
            col: pos.col,
            direction: pos.direction,
            number: pos.number,
            clue: fallbackWord.clue
          });
          usedWords.add(fallbackWord.word);
        }
      }
    });
    
    return selectedWords;
  }
}

export const simpleWorkingCrossword = new SimpleWorkingCrossword();