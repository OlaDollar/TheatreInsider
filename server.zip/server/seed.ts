import { db } from "./db";
import { articles, reviews, shows } from "@shared/schema";
import { generateSlug, generateMetaDescription, extractTags } from "@shared/seo";
import { performerDataService } from "./performer-data";
import { theatreImageService } from "./theatre-images";

export async function seedDatabase() {
  console.log("Seeding database...");

  // Clear existing data (in development)
  await db.delete(articles);
  await db.delete(reviews);
  await db.delete(shows);

  // Seed articles with SEO data
  const sampleArticlesData = [
    {
      title: "Lion King Celebrates 25 Years in London's West End with Star-Studded Gala",
      content: "Disney's award-winning musical reaches historic milestone with special anniversary performance featuring original cast members and surprise guests. The evening was filled with memorable performances and emotional tributes to this groundbreaking production that has captivated audiences for over two decades.",
      excerpt: "Disney's award-winning musical reaches historic milestone with special anniversary performance featuring original cast members and surprise guests.",
      author: "Sarah Mitchell",
      category: "news" as const,
      region: "uk" as const,
      imageUrl: "https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600",
      isFeatured: true,
      isPremium: false
    },
    {
      title: "Chicago Announces Extended Run Through 2025",
      content: "The longest-running American musical on Broadway continues its record-breaking success with confirmed performances well into next year. This extension reflects the show's enduring popularity and critical acclaim, securing its place as one of Broadway's most beloved productions.",
      excerpt: "The longest-running American musical on Broadway continues its record-breaking success with confirmed performances well into next year.",
      author: "Mark Harrison",
      category: "news" as const,
      region: "us" as const,
      imageUrl: "https://images.unsplash.com/photo-1574267432553-4b4628081c31?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      isFeatured: false,
      isPremium: false
    },
    {
      title: "Hamilton Returns to West End After Sold-Out Run",
      content: "Lin-Manuel Miranda's revolutionary musical is set for a triumphant return to London's Victoria Palace Theatre following unprecedented demand. The production will feature both returning and new cast members, bringing fresh energy to this groundbreaking show.",
      excerpt: "Lin-Manuel Miranda's revolutionary musical is set for a triumphant return to London's Victoria Palace Theatre following unprecedented demand.",
      author: "Emma Thompson",
      category: "news" as const,
      region: "uk" as const,
      imageUrl: "https://images.unsplash.com/photo-1514306191717-452ec28c7814?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      isFeatured: false,
      isPremium: false
    },
    {
      title: "Wicked Soars Past 6,000 Performances on Broadway",
      content: "The beloved musical about the untold story of the witches of Oz continues to defy gravity with record-breaking attendance. This milestone performance featured special appearances from original cast members and a celebration of the show's enduring legacy.",
      excerpt: "The beloved musical about the untold story of the witches of Oz continues to defy gravity with record-breaking attendance.",
      author: "David Chen",
      category: "news" as const,
      region: "us" as const,
      imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      isFeatured: false,
      isPremium: false
    },
    {
      title: "New West End Theatre District Investment Announced",
      content: "A major £50 million investment has been announced to renovate and modernize several historic West End theatres. The initiative aims to preserve the architectural heritage while upgrading facilities to meet modern accessibility standards and enhance the audience experience.",
      excerpt: "A major £50 million investment has been announced to renovate and modernize several historic West End theatres.",
      author: "Rachel Green",
      category: "announcement" as const,
      region: "uk" as const,
      venue_type: "national",
      imageUrl: "https://images.unsplash.com/photo-1516715094483-75da06977943?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      isFeatured: false,
      isPremium: true
    }
  ];

  // Generate SEO data for articles
  const sampleArticles = sampleArticlesData.map(article => ({
    ...article,
    slug: generateSlug(article.title),
    metaDescription: generateMetaDescription(article.content),
    tags: extractTags(article.content, article.title)
  }));

  await db.insert(articles).values(sampleArticles);

  // Seed reviews with SEO data
  const sampleReviewsData = [
    {
      showTitle: "The Phantom of the Opera",
      venue: "Her Majesty's Theatre",
      rating: 5,
      reviewText: "Andrew Lloyd Webber's iconic musical bids an emotional goodbye to Broadway after 35 extraordinary years. This final production showcases why it became the longest-running show in Broadway history with stunning performances, incredible staging, and a score that continues to captivate audiences worldwide. The performances are nothing short of spectacular, with each cast member delivering powerhouse vocals and emotional depth that brings the tragic love story to life.",
      excerpt: "Andrew Lloyd Webber's iconic musical bids an emotional goodbye to Broadway after 35 extraordinary years. This final production showcases why it became the longest-running show in Broadway history.",
      reviewer: "James Mitchell",
      imageUrl: "https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=150",
      region: "us" as const
    },
    {
      showTitle: "Six The Musical",
      venue: "Arts Theatre",
      rating: 4,
      reviewText: "This innovative retelling of Henry VIII's six wives as pop stars delivers incredible vocals and fresh historical perspective, though some moments feel rushed in the 80-minute runtime. The costumes and choreography are exceptional, bringing a modern twist to historical figures. Each queen gets her moment to shine with distinct musical styles ranging from pop to R&B to ballads.",
      excerpt: "This innovative retelling of Henry VIII's six wives as pop stars delivers incredible vocals and fresh historical perspective, though some moments feel rushed in the 80-minute runtime.",
      reviewer: "Rachel Green",
      imageUrl: "https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=150",
      region: "uk" as const
    },
    {
      showTitle: "The Book of Mormon",
      venue: "Prince of Wales Theatre",
      rating: 4,
      reviewText: "Trey Parker and Matt Stone's irreverent musical continues to shock and delight audiences with its bold humor and surprisingly heartfelt message. While not for the easily offended, the show's satirical take on religion and cultural differences is both provocative and genuinely touching. The performances are energetic and the songs are undeniably catchy.",
      excerpt: "Trey Parker and Matt Stone's irreverent musical continues to shock and delight audiences with its bold humor and surprisingly heartfelt message.",
      reviewer: "Michael Thompson",
      imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=150",
      region: "uk" as const
    }
  ];

  // Generate SEO data for reviews
  const sampleReviews = sampleReviewsData.map(review => ({
    ...review,
    slug: generateSlug(`${review.showTitle} ${review.venue} review`),
    metaDescription: generateMetaDescription(review.reviewText),
    tags: extractTags(review.reviewText, review.showTitle)
  }));

  await db.insert(reviews).values(sampleReviews);

  // Seed shows with enhanced data
  const sampleShows = [
    { 
      title: "The Lion King", 
      venue: "Lyceum Theatre", 
      region: "uk" as const, 
      venue_type: "west_end",
      status: "running" as const, 
      popularity: 100,
      description: "Disney's award-winning musical brings the Pride Lands to life with stunning costumes, innovative puppetry, and an unforgettable score.",
      ticketUrl: "https://lionking.co.uk",
      officialWebsite: "https://lionking.co.uk",
      imageUrl: "https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
      director: "Julie Taymor",
      composer: "Elton John & Hans Zimmer",
      cast: ["Simba", "Nala", "Mufasa", "Scar"],
      genre: "Musical",
      duration: "2h 30m",
      ageRating: "U"
    },
    { 
      title: "Hamilton", 
      venue: "Richard Rodgers Theatre", 
      region: "us" as const, 
      venue_type: "broadway",
      status: "running" as const, 
      popularity: 95,
      description: "The revolutionary musical about Alexander Hamilton's rise from orphan to founding father through hip-hop, R&B, and traditional show tunes.",
      ticketUrl: "https://hamiltonmusical.com",
      officialWebsite: "https://hamiltonmusical.com",
      imageUrl: "https://images.unsplash.com/photo-1514306191717-452ec28c7814?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
      director: "Thomas Kail",
      composer: "Lin-Manuel Miranda",
      cast: ["Alexander Hamilton", "Aaron Burr", "Eliza Hamilton", "George Washington"],
      genre: "Historical Musical",
      duration: "2h 45m",
      ageRating: "PG-13"
    },
    { 
      title: "The Phantom of the Opera", 
      venue: "Majestic Theatre", 
      region: "us" as const, 
      venue_type: "broadway",
      status: "closed" as const, 
      popularity: 90,
      description: "Andrew Lloyd Webber's timeless tale of love, obsession, and music in the shadows of the Paris Opera House.",
      ticketUrl: "",
      officialWebsite: "https://thephantomoftheopera.com",
      imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=200",
      director: "Hal Prince",
      composer: "Andrew Lloyd Webber",
      cast: ["The Phantom", "Christine Daaé", "Raoul"],
      genre: "Gothic Romance Musical",
      duration: "2h 35m",
      ageRating: "PG"
    },
    { 
      title: "Wicked", 
      venue: "Apollo Victoria Theatre", 
      region: "uk" as const, 
      venue_type: "west_end",
      status: "running" as const, 
      popularity: 85,
      description: "The untold story of the witches of Oz, exploring friendship, love, and the complex nature of good and evil.",
      ticketUrl: "https://wickedthemusical.co.uk",
      officialWebsite: "https://wickedthemusical.co.uk",
      imageUrl: theatreImageService.getProductionImage("Wicked", "Apollo Victoria Theatre", "uk"),
      director: "Joe Mantello",
      composer: "Stephen Schwartz",
      cast: ["Elphaba", "Glinda", "Fiyero", "The Wizard"],
      genre: "Fantasy Musical",
      duration: "2h 45m",
      ageRating: "PG"
    }
  ];

  // Check for existing shows to prevent duplicates
  const existingShows = await db.select().from(shows);
  const existingTitles = new Set(existingShows.map(show => show.title));
  
  const newShows = sampleShows.filter(show => !existingTitles.has(show.title));
  
  if (newShows.length > 0) {
    await db.insert(shows).values(newShows);
    console.log(`Added ${newShows.length} new shows to database`);
  } else {
    console.log('All shows already exist in database');
  }

  // Seed performer database
  await performerDataService.seedPerformerDatabase();

  console.log("Database seeded successfully!");
}