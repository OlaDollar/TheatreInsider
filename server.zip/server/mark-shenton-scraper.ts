import * as cheerio from "cheerio";
import { aiContentGenerator } from "./ai-content";
import { db } from "./db";
import { articles, reviews } from "@shared/schema";
import { generateSlug, generateMetaDescription, extractTags } from "@shared/seo";

interface ScrapedArticle {
  title: string;
  content: string;
  url: string;
  publishedAt: Date;
  author?: string;
  source: string;
  isMarkShentonStyle?: boolean;
}

export class MarkShentonScraper {
  private sources = [
    {
      name: "WhatsOnStage",
      baseUrl: "https://www.whatsonstage.com",
      searchPaths: [
        "/london-news",
        "/west-end-news",
        "/broadway-news",
        "/reviews"
      ],
      authorSelectors: [
        ".author",
        ".byline",
        "[data-author]",
        ".article-author"
      ],
      contentSelectors: [
        ".article-content",
        ".content",
        ".article-body",
        ".post-content"
      ]
    },
    {
      name: "The Stage",
      baseUrl: "https://www.thestage.co.uk",
      searchPaths: [
        "/news",
        "/reviews",
        "/opinion"
      ],
      authorSelectors: [
        ".author-name",
        ".byline",
        ".post-author"
      ],
      contentSelectors: [
        ".entry-content",
        ".article-content",
        ".post-content"
      ]
    },
    {
      name: "Sunday Express",
      baseUrl: "https://www.express.co.uk",
      searchPaths: [
        "/entertainment/theatre",
        "/showbiz/theatre"
      ],
      authorSelectors: [
        ".author",
        ".byline",
        ".article-author"
      ],
      contentSelectors: [
        ".article-text",
        ".article-content"
      ]
    },
    {
      name: "Playbill",
      baseUrl: "https://www.playbill.com",
      searchPaths: [
        "/news",
        "/reviews",
        "/features"
      ],
      authorSelectors: [
        ".author-name",
        ".byline",
        ".article-byline",
        ".contributor-name"
      ],
      contentSelectors: [
        ".article-body",
        ".content-body",
        ".article-content",
        ".story-content"
      ]
    },
    {
      name: "American Theatre",
      baseUrl: "https://www.americantheatre.org",
      searchPaths: [
        "/news",
        "/reviews",
        "/features"
      ],
      authorSelectors: [
        ".author-name",
        ".byline",
        ".post-author"
      ],
      contentSelectors: [
        ".entry-content",
        ".article-content",
        ".post-content"
      ]
    },
    {
      name: "Theatre Weekly",
      baseUrl: "https://www.theatreweekly.com",
      searchPaths: [
        "/news",
        "/reviews"
      ],
      authorSelectors: [
        ".author",
        ".byline"
      ],
      contentSelectors: [
        ".content",
        ".article-content"
      ]
    },
    {
      name: "Mercury Musical Development",
      baseUrl: "https://www.mercurymusicaldevelopments.co.uk",
      searchPaths: [
        "/news",
        "/projects",
        "/developments"
      ],
      authorSelectors: [
        ".author",
        ".byline",
        ".post-author"
      ],
      contentSelectors: [
        ".content",
        ".entry-content",
        ".article-content"
      ]
    },
    {
      name: "National Youth Theatre",
      baseUrl: "https://www.nyt.org.uk",
      searchPaths: [
        "/news",
        "/blog",
        "/productions"
      ],
      authorSelectors: [
        ".author",
        ".byline"
      ],
      contentSelectors: [
        ".content",
        ".post-content",
        ".article-body"
      ]
    },
    {
      name: "54 Below",
      baseUrl: "https://www.54below.com",
      searchPaths: [
        "/news",
        "/events",
        "/shows"
      ],
      authorSelectors: [
        ".author",
        ".byline"
      ],
      contentSelectors: [
        ".content",
        ".event-description",
        ".show-description"
      ]
    },
    {
      name: "Crazy Coqs",
      baseUrl: "https://www.crazycoqs.com",
      searchPaths: [
        "/whats-on",
        "/news"
      ],
      authorSelectors: [
        ".author",
        ".byline"
      ],
      contentSelectors: [
        ".content",
        ".description"
      ]
    }
  ];

  private markShentonStyleIndicators = [
    // Writing style indicators
    "industry insider",
    "theatrical flair",
    "west end veteran",
    "off west end",
    "fringe theatre",
    "broadway stalwart",
    "off broadway",
    "regional theatre",
    "national theatre",
    "youth theatre",
    "new writing",
    "musical development",
    "workshop production",
    "scratch performance",
    "cabaret performance",
    "intimate venue",
    "musical theatre concert",
    "behind the scenes",
    "theatre world",
    "stage door",
    "opening night",
    "first night",
    "curtain call",
    "theatrical history",
    "theatre critic",
    "theatre journalism",
    
    // Common phrases Mark Shenton uses
    "as someone who has covered",
    "having witnessed",
    "theatre-goers",
    "the production values",
    "the cast delivers",
    "standout performance",
    "theatrical magic",
    "stage presence",
    "compelling storytelling",
    "captivated audience",
    
    // Theatre terminology he frequently uses
    "proscenium",
    "downstage",
    "upstage",
    "ensemble cast",
    "leading man",
    "leading lady",
    "understudy",
    "matinee",
    "interval",
    "programme",
    "stalls",
    "dress circle",
    "gallery",
    
    // Youth theatre and development terminology
    "emerging artists",
    "young performers",
    "development workshop",
    "new musical",
    "world premiere",
    "workshop reading",
    "creative development",
    "commissioning",
    "mentorship program",
    "talent development",
    "creative labs",
    
    // Cabaret and concert terminology
    "cabaret",
    "intimate setting",
    "musical theatre songs",
    "concert performance",
    "solo show",
    "jazz venue",
    "supper club",
    "intimate concert",
    "broadway standards",
    "showtunes",
    
    // Notable performers (Mark Shenton would know these artists)
    "liz callaway",
    "barb jungr",
    "karen mason",
    "jamie deroy",
    "steve ross",
    "aaron weinstein",
    "lee roy reams",
    "karen akers"
  ];

  async scrapeMarkShentonContent(): Promise<ScrapedArticle[]> {
    const allArticles: ScrapedArticle[] = [];

    for (const source of this.sources) {
      try {
        console.log(`Scraping ${source.name}...`);
        
        for (const path of source.searchPaths) {
          try {
            const articles = await this.scrapePage(source, path);
            allArticles.push(...articles);
            
            // Add delay to be respectful to servers
            await new Promise(resolve => setTimeout(resolve, 2000));
          } catch (error) {
            console.error(`Error scraping ${source.name}${path}:`, error.message);
          }
        }
      } catch (error) {
        console.error(`Error with source ${source.name}:`, error.message);
      }
    }

    // Analyze articles for Mark Shenton's style
    const analyzedArticles = await this.analyzeArticlesForStyle(allArticles);
    
    return analyzedArticles.filter(article => article.isMarkShentonStyle);
  }

  private async scrapePage(source: any, path: string): Promise<ScrapedArticle[]> {
    const url = `${source.baseUrl}${path}`;
    const articles: ScrapedArticle[] = [];

    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Theatre Spotlight Content Aggregator 1.0',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const html = await response.text();
      const $ = cheerio.load(html);

      // Find article links - expanded to include cabaret and concert content
      const articleLinks = $('a[href*="/news/"], a[href*="/review"], a[href*="/opinion/"], a[href*="/features/"], a[href*="/theatre/"], a[href*="/broadway/"], a[href*="/west-end/"], a[href*="/youth/"], a[href*="/development/"], a[href*="/new-writing/"], a[href*="/workshop/"], a[href*="/cabaret/"], a[href*="/concert/"], a[href*="/events/"], a[href*="/shows/"]')
        .map((_, el) => $(el).attr('href'))
        .get()
        .filter(href => href && href.includes('/'))
        .slice(0, 25); // Increased to 25 articles per page for comprehensive coverage

      // Scrape individual articles
      for (const link of articleLinks) {
        try {
          const fullUrl = link.startsWith('http') ? link : `${source.baseUrl}${link}`;
          const article = await this.scrapeArticle(fullUrl, source);
          if (article) {
            articles.push(article);
          }
          
          // Delay between individual article scrapes
          await new Promise(resolve => setTimeout(resolve, 1000));
        } catch (error) {
          console.error(`Error scraping article ${link}:`, error.message);
        }
      }
    } catch (error) {
      console.error(`Error fetching page ${url}:`, error.message);
    }

    return articles;
  }

  private async scrapeArticle(url: string, source: any): Promise<ScrapedArticle | null> {
    try {
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Theatre Spotlight Content Aggregator 1.0',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }
      });

      if (!response.ok) {
        return null;
      }

      const html = await response.text();
      const $ = cheerio.load(html);

      // Extract title
      const title = $('h1').first().text().trim() || 
                   $('title').text().trim() ||
                   $('.article-title').text().trim();

      if (!title) return null;

      // Extract content
      let content = '';
      for (const selector of source.contentSelectors) {
        const contentElement = $(selector).first();
        if (contentElement.length) {
          content = contentElement.text().trim();
          break;
        }
      }

      if (!content || content.length < 200) return null;

      // Extract author
      let author = '';
      for (const selector of source.authorSelectors) {
        const authorElement = $(selector).first();
        if (authorElement.length) {
          author = authorElement.text().trim();
          break;
        }
      }

      // Extract publish date
      let publishedAt = new Date();
      const dateSelectors = ['time', '.date', '.published', '[datetime]', '.article-date'];
      for (const selector of dateSelectors) {
        const dateElement = $(selector).first();
        if (dateElement.length) {
          const dateText = dateElement.attr('datetime') || dateElement.text();
          const parsedDate = new Date(dateText);
          if (!isNaN(parsedDate.getTime())) {
            publishedAt = parsedDate;
            break;
          }
        }
      }

      return {
        title,
        content,
        url,
        publishedAt,
        author,
        source: source.name
      };
    } catch (error) {
      console.error(`Error scraping individual article ${url}:`, error.message);
      return null;
    }
  }

  private async analyzeArticlesForStyle(articles: ScrapedArticle[]): Promise<ScrapedArticle[]> {
    const analyzedArticles: ScrapedArticle[] = [];

    for (const article of articles) {
      try {
        // Check if explicitly attributed to Mark Shenton
        const isExplicitlyMarkShenton = this.isExplicitlyMarkShenton(article);
        
        // Check writing style indicators
        const styleScore = this.calculateStyleScore(article);
        
        // Use AI to analyze writing style if available
        let aiStyleMatch = false;
        if (process.env.OPENAI_API_KEY) {
          aiStyleMatch = await this.aiStyleAnalysis(article);
        }

        // Determine if this matches Mark Shenton's style
        const isMarkShentonStyle = isExplicitlyMarkShenton || 
                                  styleScore >= 3 || 
                                  aiStyleMatch;

        analyzedArticles.push({
          ...article,
          isMarkShentonStyle
        });

        if (isMarkShentonStyle) {
          console.log(`Found Mark Shenton style article: "${article.title}" (Score: ${styleScore})`);
        }

      } catch (error) {
        console.error('Error analyzing article style:', error);
        analyzedArticles.push(article); // Add without style analysis
      }
    }

    return analyzedArticles;
  }

  private isExplicitlyMarkShenton(article: ScrapedArticle): boolean {
    const authorText = (article.author || '').toLowerCase();
    return authorText.includes('mark shenton') || 
           authorText.includes('shenton');
  }

  private calculateStyleScore(article: ScrapedArticle): number {
    const fullText = `${article.title} ${article.content}`.toLowerCase();
    let score = 0;

    for (const indicator of this.markShentonStyleIndicators) {
      if (fullText.includes(indicator.toLowerCase())) {
        score += 1;
      }
    }

    // Additional scoring for theatre-specific content
    if (fullText.includes('west end')) score += 2;
    if (fullText.includes('off west end') || fullText.includes('fringe')) score += 2;
    if (fullText.includes('broadway')) score += 2;
    if (fullText.includes('off broadway')) score += 2;
    if (fullText.includes('national theatre')) score += 2;
    if (fullText.includes('regional theatre')) score += 1;
    if (fullText.includes('theatre') || fullText.includes('theater')) score += 1;
    if (fullText.includes('musical')) score += 1;
    if (fullText.includes('review') && fullText.includes('star')) score += 2;
    if (fullText.includes('fringe festival')) score += 1;
    if (fullText.includes('touring production')) score += 1;
    if (fullText.includes('youth theatre') || fullText.includes('young performers')) score += 2;
    if (fullText.includes('new writing') || fullText.includes('new musical')) score += 2;
    if (fullText.includes('development') || fullText.includes('workshop')) score += 1;
    if (fullText.includes('world premiere') || fullText.includes('premiere')) score += 2;
    if (fullText.includes('cabaret') || fullText.includes('intimate venue')) score += 2;
    if (fullText.includes('musical theatre concert') || fullText.includes('broadway standards')) score += 2;
    if (fullText.includes('liz callaway') || fullText.includes('barb jungr')) score += 3;
    if (fullText.includes('solo show') || fullText.includes('supper club')) score += 1;

    return score;
  }

  private async aiStyleAnalysis(article: ScrapedArticle): Promise<boolean> {
    try {
      if (!process.env.OPENAI_API_KEY) return false;

      const prompt = `
Analyze this theatre article and determine if it matches Mark Shenton's writing style.

Mark Shenton's characteristics:
- Authoritative theatre critic with decades of experience
- Industry insider perspective with behind-the-scenes knowledge
- Engaging storytelling with theatrical flair
- Professional yet accessible language
- Rich context about theatre history and personalities
- Detailed knowledge of West End, Off-West End, Broadway, Off-Broadway, National Theatre, Youth Theatre, New Writing Development, Cabaret, and Musical Theatre Concerts
- Uses theatre terminology naturally
- Balances criticism with appreciation

Article Title: ${article.title}
Article Content: ${article.content.substring(0, 1000)}...

Does this match Mark Shenton's distinctive writing style? Consider:
1. Authority and expertise level
2. Writing tone and vocabulary
3. Theatre industry knowledge
4. Storytelling approach
5. Use of insider terminology

Respond with just "YES" or "NO".
      `;

      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'gpt-4o',
          messages: [
            {
              role: 'system',
              content: 'You are an expert in analyzing writing styles, particularly theatre journalism.'
            },
            {
              role: 'user',
              content: prompt
            }
          ],
          temperature: 0.1,
          max_tokens: 10
        })
      });

      if (!response.ok) {
        return false;
      }

      const data = await response.json();
      const result = data.choices[0].message.content.trim().toUpperCase();
      
      return result === 'YES';
    } catch (error) {
      console.error('Error in AI style analysis:', error);
      return false;
    }
  }

  async processAndPublishScrapedContent(): Promise<{ processed: number; published: number }> {
    let processed = 0;
    let published = 0;

    try {
      console.log('Starting Mark Shenton content scraping...');
      const scrapedArticles = await this.scrapeMarkShentonContent();
      processed = scrapedArticles.length;

      console.log(`Found ${processed} articles matching Mark Shenton's style`);

      for (const article of scrapedArticles) {
        try {
          // Check if we already have this article (by title similarity)
          const existingArticles = await db.select()
            .from(articles)
            .where(eq(articles.title, article.title));

          if (existingArticles.length > 0) {
            console.log(`Skipping duplicate article: ${article.title}`);
            continue;
          }

          // Rewrite in Mark Shenton's style to ensure consistency
          const rewritten = await aiContentGenerator.rewriteExistingContent(
            article.content,
            article.title,
            'article'
          );

          // Determine region and venue type based on content
          const region = this.determineRegion(article);
          const venueType = this.determineVenueType(article);
          const category = this.determineCategory(article);

          // Generate SEO data
          const slug = generateSlug(rewritten.title);
          const metaDescription = generateMetaDescription(rewritten.content);
          const tags = extractTags(rewritten.content, rewritten.title);

          // Save to database
          await db.insert(articles).values({
            title: rewritten.title,
            content: rewritten.content,
            excerpt: rewritten.excerpt,
            author: "Mark Shenton",
            category,
            region,
            venue_type: venueType,
            imageUrl: this.getStockImageUrl(category),
            isFeatured: Math.random() > 0.8, // 20% chance of being featured
            isPremium: Math.random() > 0.7, // 30% chance of being premium
            slug,
            metaDescription,
            tags
          });

          published++;
          console.log(`Published: ${rewritten.title}`);

          // Add delay to avoid overwhelming the system
          await new Promise(resolve => setTimeout(resolve, 2000));

        } catch (error) {
          console.error('Error processing scraped article:', error);
        }
      }

      console.log(`Mark Shenton content processing complete: ${processed} processed, ${published} published`);
      return { processed, published };

    } catch (error) {
      console.error('Error in Mark Shenton content processing:', error);
      return { processed, published };
    }
  }

  private determineRegion(article: ScrapedArticle): 'uk' | 'us' | 'both' {
    const content = `${article.title} ${article.content}`.toLowerCase();
    
    const ukIndicators = [
      'west end', 'off west end', 'london', 'uk', 'britain', 'british', 
      'royal opera house', 'national theatre', 'royal shakespeare company',
      'fringe', 'edinburgh', 'manchester', 'birmingham', 'glasgow',
      'national youth theatre', 'mercury musical development', 'young vic'
    ];
    const usIndicators = [
      'broadway', 'off broadway', 'new york', 'us', 'america', 'american', 
      'lincoln center', 'chicago', 'los angeles', 'regional theatre',
      'tcg', 'theatre communications group', 'new york theatre workshop'
    ];
    
    const ukScore = ukIndicators.reduce((score, term) => score + (content.includes(term) ? 1 : 0), 0);
    const usScore = usIndicators.reduce((score, term) => score + (content.includes(term) ? 1 : 0), 0);
    
    if (ukScore > usScore) return 'uk';
    if (usScore > ukScore) return 'us';
    return 'both';
  }

  private determineVenueType(article: ScrapedArticle): string {
    const content = `${article.title} ${article.content}`.toLowerCase();
    
    if (content.includes('west end') && !content.includes('off')) return 'west_end';
    if (content.includes('off west end') || content.includes('fringe')) return 'off_west_end';
    if (content.includes('broadway') && !content.includes('off')) return 'broadway';
    if (content.includes('off broadway')) return 'off_broadway';
    if (content.includes('national theatre') || content.includes('royal shakespeare')) return 'national';
    if (content.includes('regional theatre') || content.includes('touring')) return 'regional';
    if (content.includes('youth theatre') || content.includes('young performers') || content.includes('national youth theatre')) return 'youth';
    if (content.includes('development') || content.includes('workshop') || content.includes('new writing') || content.includes('mercury musical')) return 'development';
    if (content.includes('cabaret') || content.includes('intimate venue') || content.includes('supper club')) return 'cabaret';
    if (content.includes('concert') || content.includes('musical theatre concert') || content.includes('solo show')) return 'concert_hall';
    
    return 'regional'; // Default fallback
  }

  private determineCategory(article: ScrapedArticle): 'news' | 'review' | 'announcement' | 'cabaret' | 'concert' {
    const content = `${article.title} ${article.content}`.toLowerCase();
    
    if (content.includes('review') || content.includes('stars') || content.includes('rating')) {
      return 'review';
    }
    
    if (content.includes('cabaret') || content.includes('intimate venue') || content.includes('supper club')) {
      return 'cabaret';
    }
    
    if (content.includes('concert') || content.includes('musical theatre concert') || content.includes('solo show')) {
      return 'concert';
    }
    
    if (content.includes('announces') || content.includes('casting') || content.includes('opening')) {
      return 'announcement';
    }
    
    return 'news';
  }

  private getStockImageUrl(category: string): string {
    const images = {
      news: "https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      review: "https://images.unsplash.com/photo-1516715094483-75da06977943?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      announcement: "https://images.unsplash.com/photo-1514306191717-452ec28c7814?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      cabaret: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
      concert: "https://images.unsplash.com/photo-1501612780327-45045538702b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300"
    };
    return images[category] || images.news;
  }
}

export class ShentonStageComprehensiveScraper {
  async scrapeShentonStageComprehensive(): Promise<ScrapedArticle[]> {
    const articles: ScrapedArticle[] = [];
    const baseUrl = 'https://www.shentonstage.com';
    
    try {
      // Scrape multiple sections and pagination
      const sections = [
        '/reviews',
        '/news', 
        '/interviews',
        '/features',
        '/opinion'
      ];
      
      for (const section of sections) {
        console.log(`Scraping ${baseUrl}${section}...`);
        
        // Scrape multiple pages of each section
        for (let page = 1; page <= 10; page++) {
          try {
            const pageUrl = `${baseUrl}${section}?page=${page}`;
            const response = await fetch(pageUrl, {
              headers: {
                'User-Agent': 'Mozilla/5.0 (compatible; Theatre Spotlight Bot)'
              }
            });
            
            if (!response.ok) break; // No more pages
            
            const html = await response.text();
            const pageArticles = await this.extractArticlesFromHTML(html, baseUrl);
            
            if (pageArticles.length === 0) break; // No more content
            
            articles.push(...pageArticles);
            console.log(`Found ${pageArticles.length} articles on ${section} page ${page}`);
            
            // Delay between page requests
            await new Promise(resolve => setTimeout(resolve, 1500));
          } catch (error) {
            console.error(`Error scraping ${section} page ${page}:`, error);
            break;
          }
        }
      }
      
      // Also scrape the main homepage for latest articles
      const homepageResponse = await fetch(baseUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (compatible; Theatre Spotlight Bot)'
        }
      });
      
      if (homepageResponse.ok) {
        const homepageHtml = await homepageResponse.text();
        const homepageArticles = await this.extractArticlesFromHTML(homepageHtml, baseUrl);
        articles.push(...homepageArticles);
        console.log(`Found ${homepageArticles.length} articles from homepage`);
      }
      
    } catch (error) {
      console.error('Error in comprehensive Shentonstage scraping:', error);
    }
    
    // Remove duplicates based on title
    const uniqueArticles = articles.filter((article, index, self) => 
      index === self.findIndex(a => a.title === article.title)
    );
    
    console.log(`Total unique articles from Shentonstage.com: ${uniqueArticles.length}`);
    return uniqueArticles;
  }

  private async extractArticlesFromHTML(html: string, baseUrl: string): Promise<ScrapedArticle[]> {
    const articles: ScrapedArticle[] = [];
    
    try {
      // Use cheerio for HTML parsing
      const cheerio = await import('cheerio');
      const $ = cheerio.load(html);
      
      // Extract articles (adjust selectors based on actual Shentonstage.com structure)
      $('article, .post, .entry, .article-item').each((index, element) => {
        const $article = $(element);
        
        const title = $article.find('h1, h2, h3, .title, .headline').first().text().trim();
        const content = $article.find('.content, .body, .text, p').text().trim();
        const link = $article.find('a').first().attr('href');
        const author = $article.find('.author, .byline').text().trim();
        const date = $article.find('.date, time').text().trim();
        
        if (title && content) {
          articles.push({
            title,
            content: content.substring(0, 2000), // Limit content length
            source: 'Shentonstage.com',
            author: author || 'Mark Shenton',
            url: link ? (link.startsWith('http') ? link : baseUrl + link) : baseUrl,
            publishedDate: date,
            isMarkShentonStyle: true // All content from Shentonstage is Mark Shenton's
          });
        }
      });
      
    } catch (error) {
      console.error('Error extracting articles from HTML:', error);
    }
    
    return articles;
  }
}

export const markShentonScraper = new MarkShentonScraper();
export const shentonStageComprehensiveScraper = new ShentonStageComprehensiveScraper();