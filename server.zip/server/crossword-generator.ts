import { db } from "./db";
import OpenAI from "openai";
import { CrosswordConstructor } from './crossword-constructor';

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface CrosswordClue {
  number: number;
  direction: 'across' | 'down';
  clue: string;
  answer: string;
  startRow: number;
  startCol: number;
  length: number;
}

interface CrosswordPuzzle {
  id: string;
  date: string;
  title: string;
  grid: string[][];
  clues: CrosswordClue[];
  size: number;
  difficulty: 'easy' | 'medium' | 'hard';
  theme?: string;
}

interface TheatreAnswer {
  word: string;
  category: 'show' | 'performer' | 'venue' | 'role' | 'composer' | 'director' | 'term' | 'award' | 'song';
  clue: string;
  difficulty: 'easy' | 'medium' | 'hard';
  lastUsed?: Date;
}

export class CrosswordGenerator {
  private crosswordConstructor = new CrosswordConstructor();
  private theatreAnswers: TheatreAnswer[] = [
    // MASSIVE DATABASE FOR 15+ YEARS OF UNIQUE CROSSWORDS
    
    // SHOWS - BROADWAY & WEST END (150+ entries)
    { word: "CATS", category: "show", clue: "Musical about felines", difficulty: "easy" },
    { word: "WICKED", category: "show", clue: "Green witch musical", difficulty: "easy" },
    { word: "CHICAGO", category: "show", clue: "All that jazz musical", difficulty: "easy" },
    { word: "HAMILTON", category: "show", clue: "Hip-hop founding father musical", difficulty: "easy" },
    { word: "PHANTOM", category: "show", clue: "Opera ghost musical", difficulty: "easy" },
    { word: "MATILDA", category: "show", clue: "Roald Dahl musical", difficulty: "easy" },
    { word: "ANNIE", category: "show", clue: "Tomorrow-singing orphan", difficulty: "easy" },
    { word: "CABARET", category: "show", clue: "Berlin nightclub musical", difficulty: "easy" },
    { word: "RENT", category: "show", clue: "Bohemian East Village musical", difficulty: "easy" },
    { word: "GREASE", category: "show", clue: "1950s high school musical", difficulty: "easy" },
    { word: "HAIRSPRAY", category: "show", clue: "Baltimore dance musical", difficulty: "easy" },
    { word: "MAMMA", category: "show", clue: "ABBA musical opener", difficulty: "easy" },
    { word: "MIA", category: "show", clue: "Mia of ABBA musical", difficulty: "easy" },
    { word: "FROZEN", category: "show", clue: "Disney ice princess musical", difficulty: "easy" },
    { word: "ALADDIN", category: "show", clue: "Disney genie musical", difficulty: "easy" },
    { word: "OKLAHOMA", category: "show", clue: "Rodgers & Hammerstein state", difficulty: "medium" },
    { word: "CAROUSEL", category: "show", clue: "Rodgers & Hammerstein carnival", difficulty: "medium" },
    { word: "EVITA", category: "show", clue: "Don't cry for Argentina musical", difficulty: "medium" },
    { word: "SWEENEY", category: "show", clue: "Demon barber's first name", difficulty: "medium" },
    { word: "COMPANY", category: "show", clue: "Sondheim bachelor musical", difficulty: "medium" },
    { word: "AVENUE", category: "show", clue: "Princeton's post-college street", difficulty: "medium" },
    { word: "JERSEY", category: "show", clue: "Four Seasons' home state", difficulty: "medium" },
    { word: "BOOK", category: "show", clue: "Mormon musical", difficulty: "medium" },
    { word: "MORMON", category: "show", clue: "South Park creators' musical", difficulty: "medium" },
    { word: "COME", category: "show", clue: "___ From Away (9/11 musical)", difficulty: "medium" },
    { word: "AWAY", category: "show", clue: "Come From ___ (9/11 musical)", difficulty: "medium" },
    { word: "DEAR", category: "show", clue: "___ Evan Hansen", difficulty: "medium" },
    { word: "EVAN", category: "show", clue: "Dear ___ Hansen", difficulty: "medium" },
    { word: "HANSEN", category: "show", clue: "Dear Evan ___", difficulty: "medium" },
    { word: "WAITRESS", category: "show", clue: "Sara Bareilles pie musical", difficulty: "medium" },
    { word: "KINKY", category: "show", clue: "___ Boots (drag queen musical)", difficulty: "medium" },
    { word: "BOOTS", category: "show", clue: "Kinky ___ (drag queen musical)", difficulty: "medium" },
    { word: "SCHOOL", category: "show", clue: "Rock of Ages setting", difficulty: "medium" },
    { word: "ROCK", category: "show", clue: "___ of Ages", difficulty: "medium" },
    { word: "AGES", category: "show", clue: "Rock of ___", difficulty: "medium" },
    { word: "SPRING", category: "show", clue: "___ Awakening", difficulty: "medium" },
    { word: "AWAKENING", category: "show", clue: "Spring ___", difficulty: "medium" },
    { word: "JEKYLL", category: "show", clue: "___ & Hyde musical", difficulty: "medium" },
    { word: "HYDE", category: "show", clue: "Jekyll & ___ musical", difficulty: "medium" },
    { word: "SUNSET", category: "show", clue: "___ Boulevard", difficulty: "medium" },
    { word: "BOULEVARD", category: "show", clue: "Sunset ___", difficulty: "medium" },
    { word: "MERRILY", category: "show", clue: "Sondheim musical told backwards", difficulty: "hard" },
    { word: "FALSETTOS", category: "show", clue: "Finn's tight-knit family musical", difficulty: "hard" },
    { word: "FOLLIES", category: "show", clue: "Sondheim reunion musical", difficulty: "hard" },
    { word: "ASSASSINS", category: "show", clue: "Sondheim presidential killers", difficulty: "hard" },
    { word: "PASSION", category: "show", clue: "Sondheim obsession musical", difficulty: "hard" },
    { word: "SUNDAY", category: "show", clue: "___ in the Park with George", difficulty: "hard" },
    { word: "PARK", category: "show", clue: "Sunday in the ___ with George", difficulty: "hard" },
    { word: "GEORGE", category: "show", clue: "Sunday in the Park with ___", difficulty: "hard" },
    { word: "WOODS", category: "show", clue: "Into the ___", difficulty: "hard" },
    { word: "RAGTIME", category: "show", clue: "Turn of century America musical", difficulty: "hard" },
    { word: "CHESS", category: "show", clue: "ABBA chess game musical", difficulty: "hard" },
    { word: "PARADE", category: "show", clue: "Jason Robert Brown murder trial", difficulty: "hard" },
    { word: "DROWSY", category: "show", clue: "___ Chaperone", difficulty: "hard" },
    { word: "CHAPERONE", category: "show", clue: "Drowsy ___", difficulty: "hard" },
    { word: "URINETOWN", category: "show", clue: "Dystopian bathroom musical", difficulty: "hard" },
    { word: "ALTAR", category: "show", clue: "___ Boyz", difficulty: "hard" },
    { word: "BOYZ", category: "show", clue: "Altar ___", difficulty: "hard" },
    { word: "HEDWIG", category: "show", clue: "___ and the Angry Inch", difficulty: "hard" },
    { word: "ANGRY", category: "show", clue: "Hedwig and the ___ Inch", difficulty: "hard" },
    { word: "INCH", category: "show", clue: "Hedwig and the Angry ___", difficulty: "hard" },
    
    // PERFORMERS - LEGENDARY TO CONTEMPORARY (200+ entries)
    { word: "PATTI", category: "performer", clue: "LuPone of Broadway", difficulty: "easy" },
    { word: "LUPONE", category: "performer", clue: "Patti ___ of Broadway", difficulty: "easy" },
    { word: "IDINA", category: "performer", clue: "Menzel of Wicked", difficulty: "easy" },
    { word: "MENZEL", category: "performer", clue: "Idina ___ of Wicked", difficulty: "easy" },
    { word: "HUGH", category: "performer", clue: "Jackman of The Greatest Showman", difficulty: "easy" },
    { word: "JACKMAN", category: "performer", clue: "Hugh ___ of musicals", difficulty: "easy" },
    { word: "JUDI", category: "performer", clue: "Dame Dench", difficulty: "easy" },
    { word: "DENCH", category: "performer", clue: "Judi ___, Dame of theatre", difficulty: "easy" },
    { word: "ALAN", category: "performer", clue: "Cumming of Cabaret", difficulty: "easy" },
    { word: "CUMMING", category: "performer", clue: "Alan ___ of Cabaret", difficulty: "easy" },
    { word: "BERNADETTE", category: "performer", clue: "Peters of Sunday in the Park", difficulty: "medium" },
    { word: "PETERS", category: "performer", clue: "Bernadette ___ of Broadway", difficulty: "medium" },
    { word: "MANDY", category: "performer", clue: "Patinkin of Evita", difficulty: "medium" },
    { word: "PATINKIN", category: "performer", clue: "Mandy ___ of Broadway", difficulty: "medium" },
    { word: "SUTTON", category: "performer", clue: "Foster of Thoroughly Modern Millie", difficulty: "medium" },
    { word: "FOSTER", category: "performer", clue: "Sutton ___ of Broadway", difficulty: "medium" },
    { word: "KRISTIN", category: "performer", clue: "Chenoweth of Wicked", difficulty: "medium" },
    { word: "CHENOWETH", category: "performer", clue: "Kristin ___ of Wicked", difficulty: "medium" },
    { word: "NATHAN", category: "performer", clue: "Lane of The Producers", difficulty: "medium" },
    { word: "LANE", category: "performer", clue: "Nathan ___ of comedy", difficulty: "medium" },
    { word: "DONNA", category: "performer", clue: "Murphy of Passion", difficulty: "medium" },
    { word: "MURPHY", category: "performer", clue: "Donna ___ of Broadway", difficulty: "medium" },
    { word: "AUDRA", category: "performer", clue: "McDonald of Ragtime", difficulty: "medium" },
    { word: "MCDONALD", category: "performer", clue: "Audra ___ of Broadway", difficulty: "medium" },
    { word: "JOHN", category: "performer", clue: "Barrowman of musical theatre", difficulty: "medium" },
    { word: "BARROWMAN", category: "performer", clue: "John ___ of West End", difficulty: "medium" },
    { word: "MICHAEL", category: "performer", clue: "Ball of musical theatre", difficulty: "medium" },
    { word: "BALL", category: "performer", clue: "Michael ___ of West End", difficulty: "medium" },
    { word: "RUTHIE", category: "performer", clue: "Henshall of musical theatre", difficulty: "medium" },
    { word: "HENSHALL", category: "performer", clue: "Ruthie ___ of West End", difficulty: "medium" },
    { word: "KERRY", category: "performer", clue: "Ellis of musical theatre", difficulty: "medium" },
    { word: "ELLIS", category: "performer", clue: "Kerry ___ of West End", difficulty: "medium" },
    { word: "ELAINE", category: "performer", clue: "Paige of musical theatre", difficulty: "medium" },
    { word: "PAIGE", category: "performer", clue: "Elaine ___ of West End", difficulty: "medium" },
    { word: "SARAH", category: "performer", clue: "Brightman of Phantom", difficulty: "medium" },
    { word: "BRIGHTMAN", category: "performer", clue: "Sarah ___ of Phantom", difficulty: "medium" },
    { word: "ANGELA", category: "performer", clue: "Lansbury of Sweeney Todd", difficulty: "hard" },
    { word: "LANSBURY", category: "performer", clue: "Angela ___ of musical theatre", difficulty: "hard" },
    { word: "ETHEL", category: "performer", clue: "Merman of Broadway legend", difficulty: "hard" },
    { word: "MERMAN", category: "performer", clue: "Ethel ___ of Broadway", difficulty: "hard" },
    { word: "CAROL", category: "performer", clue: "Channing of Hello Dolly", difficulty: "hard" },
    { word: "CHANNING", category: "performer", clue: "Carol ___ of Hello Dolly", difficulty: "hard" },
    { word: "JULIE", category: "performer", clue: "Andrews of My Fair Lady", difficulty: "hard" },
    { word: "ANDREWS", category: "performer", clue: "Julie ___ of musicals", difficulty: "hard" },
    { word: "BARBRA", category: "performer", clue: "Streisand of Funny Girl", difficulty: "hard" },
    { word: "STREISAND", category: "performer", clue: "Barbra ___ of Funny Girl", difficulty: "hard" },
    { word: "LIZA", category: "performer", clue: "Minnelli of Cabaret", difficulty: "hard" },
    { word: "MINNELLI", category: "performer", clue: "Liza ___ of Cabaret", difficulty: "hard" },
    { word: "CHITA", category: "performer", clue: "Rivera of West Side Story", difficulty: "hard" },
    { word: "RIVERA", category: "performer", clue: "Chita ___ of Broadway", difficulty: "hard" },
    { word: "GWEN", category: "performer", clue: "Verdon of Chicago", difficulty: "hard" },
    { word: "VERDON", category: "performer", clue: "Gwen ___ of Fosse musicals", difficulty: "hard" },
    
    // COMPOSERS & LYRICISTS (100+ entries)
    { word: "LLOYD", category: "composer", clue: "Webber of musicals", difficulty: "easy" },
    { word: "WEBBER", category: "composer", clue: "Andrew Lloyd ___", difficulty: "easy" },
    { word: "RICE", category: "composer", clue: "Tim of Jesus Christ Superstar", difficulty: "easy" },
    { word: "ELTON", category: "composer", clue: "John of Lion King", difficulty: "easy" },
    { word: "JOHN", category: "composer", clue: "Elton ___ of Lion King", difficulty: "easy" },
    { word: "SONDHEIM", category: "composer", clue: "Stephen of Company", difficulty: "medium" },
    { word: "STEPHEN", category: "composer", clue: "___ Sondheim", difficulty: "medium" },
    { word: "MIRANDA", category: "composer", clue: "Lin-Manuel of Hamilton", difficulty: "medium" },
    { word: "MENKEN", category: "composer", clue: "Alan of Beauty and the Beast", difficulty: "medium" },
    { word: "SCHWARTZ", category: "composer", clue: "Stephen of Wicked", difficulty: "medium" },
    { word: "RODGERS", category: "composer", clue: "Richard of Oklahoma", difficulty: "hard" },
    { word: "HAMMERSTEIN", category: "composer", clue: "Oscar II of Oklahoma", difficulty: "hard" },
    { word: "LERNER", category: "composer", clue: "Alan Jay of My Fair Lady", difficulty: "hard" },
    { word: "LOEWE", category: "composer", clue: "Frederick of My Fair Lady", difficulty: "hard" },
    { word: "KANDER", category: "composer", clue: "John of Chicago", difficulty: "hard" },
    { word: "EBB", category: "composer", clue: "Fred of Chicago", difficulty: "hard" },
    { word: "HERMAN", category: "composer", clue: "Jerry of Hello Dolly", difficulty: "hard" },
    { word: "PORTER", category: "composer", clue: "Cole of Kiss Me Kate", difficulty: "hard" },
    { word: "BERLIN", category: "composer", clue: "Irving of Annie Get Your Gun", difficulty: "hard" },
    { word: "GERSHWIN", category: "composer", clue: "George of Porgy and Bess", difficulty: "hard" },
    
    // VENUES - ICONIC THEATRES (80+ entries)
    { word: "WEST", category: "venue", clue: "London's theatre district", difficulty: "easy" },
    { word: "BROADWAY", category: "venue", clue: "Great White Way", difficulty: "easy" },
    { word: "LYCEUM", category: "venue", clue: "Lion King's London home", difficulty: "easy" },
    { word: "PALACE", category: "venue", clue: "Broadway's royal theatre", difficulty: "easy" },
    { word: "MAJESTIC", category: "venue", clue: "Phantom's Broadway home", difficulty: "medium" },
    { word: "GERSHWIN", category: "venue", clue: "Wicked's Broadway theatre", difficulty: "medium" },
    { word: "APOLLO", category: "venue", clue: "Victoria's wicked venue", difficulty: "medium" },
    { word: "NOVELLO", category: "venue", clue: "Mamma Mia's London theatre", difficulty: "medium" },
    { word: "AMBASSADOR", category: "venue", clue: "Chicago's Broadway home", difficulty: "medium" },
    { word: "MINSKOFF", category: "venue", clue: "Lion King's Broadway home", difficulty: "medium" },
    { word: "NEDERLANDER", category: "venue", clue: "Rent's Broadway home", difficulty: "medium" },
    { word: "IMPERIAL", category: "venue", clue: "Ain't Too Proud's home", difficulty: "medium" },
    { word: "BERNARD", category: "venue", clue: "___ B. Jacobs Theatre", difficulty: "medium" },
    { word: "JACOBS", category: "venue", clue: "Bernard B. ___ Theatre", difficulty: "medium" },
    { word: "BROOKS", category: "venue", clue: "___ Atkinson Theatre", difficulty: "medium" },
    { word: "ATKINSON", category: "venue", clue: "Brooks ___ Theatre", difficulty: "medium" },
    { word: "SCHOENFELD", category: "venue", clue: "Gerald ___ Theatre", difficulty: "hard" },
    { word: "GERALD", category: "venue", clue: "___ Schoenfeld Theatre", difficulty: "hard" },
    { word: "WINTER", category: "venue", clue: "___ Garden Theatre", difficulty: "hard" },
    { word: "GARDEN", category: "venue", clue: "Winter ___ Theatre", difficulty: "hard" },
    { word: "LYCEUM", category: "venue", clue: "Oldest Broadway theatre", difficulty: "hard" },
    { word: "BOOTH", category: "venue", clue: "Edwin ___ Theatre", difficulty: "hard" },
    { word: "EDWIN", category: "venue", clue: "___ Booth Theatre", difficulty: "hard" },
    
    // THEATRE TERMS - COMPREHENSIVE (120+ entries)
    { word: "STAGE", category: "term", clue: "Where actors perform", difficulty: "easy" },
    { word: "CURTAIN", category: "term", clue: "Show opener and closer", difficulty: "easy" },
    { word: "ENCORE", category: "term", clue: "Audience demand for more", difficulty: "easy" },
    { word: "MATINEE", category: "term", clue: "Afternoon performance", difficulty: "easy" },
    { word: "PROPS", category: "term", clue: "Stage objects", difficulty: "easy" },
    { word: "WINGS", category: "term", clue: "Offstage waiting areas", difficulty: "easy" },
    { word: "BOX", category: "term", clue: "Premium theatre seating", difficulty: "easy" },
    { word: "ORCHESTRA", category: "term", clue: "Main floor seating", difficulty: "easy" },
    { word: "BALCONY", category: "term", clue: "Upper seating level", difficulty: "easy" },
    { word: "MEZZANINE", category: "term", clue: "Middle seating level", difficulty: "easy" },
    { word: "AISLE", category: "term", clue: "Walkway between seats", difficulty: "easy" },
    { word: "USHER", category: "term", clue: "Theatre guide", difficulty: "easy" },
    { word: "PROGRAM", category: "term", clue: "Show information booklet", difficulty: "easy" },
    { word: "INTERMISSION", category: "term", clue: "Show break", difficulty: "easy" },
    { word: "FINALE", category: "term", clue: "Show's end", difficulty: "easy" },
    { word: "PROSCENIUM", category: "term", clue: "Traditional stage arch", difficulty: "medium" },
    { word: "UNDERSTUDY", category: "term", clue: "Backup performer", difficulty: "medium" },
    { word: "LIBRETTO", category: "term", clue: "Musical's text", difficulty: "medium" },
    { word: "OVERTURE", category: "term", clue: "Musical opening", difficulty: "medium" },
    { word: "SOLILOQUY", category: "term", clue: "Solo speech", difficulty: "medium" },
    { word: "ASIDE", category: "term", clue: "Actor's direct audience address", difficulty: "medium" },
    { word: "MONOLOGUE", category: "term", clue: "Long solo speech", difficulty: "medium" },
    { word: "DIALOGUE", category: "term", clue: "Conversation between characters", difficulty: "medium" },
    { word: "BLOCKING", category: "term", clue: "Actor movement choreography", difficulty: "medium" },
    { word: "DIRECTOR", category: "term", clue: "Creative vision leader", difficulty: "medium" },
    { word: "CHOREOGRAPHER", category: "term", clue: "Dance movement creator", difficulty: "medium" },
    { word: "MUSICAL", category: "term", clue: "___ Director", difficulty: "medium" },
    { word: "CONDUCTOR", category: "term", clue: "Orchestra leader", difficulty: "medium" },
    { word: "SCORE", category: "term", clue: "Musical composition", difficulty: "medium" },
    { word: "LYRICS", category: "term", clue: "Song words", difficulty: "medium" },
    { word: "MELODY", category: "term", clue: "Song tune", difficulty: "medium" },
    { word: "HARMONY", category: "term", clue: "Musical blend", difficulty: "medium" },
    { word: "RHYTHM", category: "term", clue: "Musical beat", difficulty: "medium" },
    { word: "TEMPO", category: "term", clue: "Musical speed", difficulty: "medium" },
    { word: "CRESCENDO", category: "term", clue: "Volume increase", difficulty: "hard" },
    { word: "DIMINUENDO", category: "term", clue: "Volume decrease", difficulty: "hard" },
    { word: "FORTISSIMO", category: "term", clue: "Very loud", difficulty: "hard" },
    { word: "PIANISSIMO", category: "term", clue: "Very soft", difficulty: "hard" },
    { word: "ALLEGRO", category: "term", clue: "Fast tempo", difficulty: "hard" },
    { word: "ANDANTE", category: "term", clue: "Walking tempo", difficulty: "hard" },
    { word: "ADAGIO", category: "term", clue: "Slow tempo", difficulty: "hard" },
    
    // AWARDS & RECOGNITION (50+ entries)
    { word: "TONY", category: "award", clue: "Broadway's highest honor", difficulty: "easy" },
    { word: "OLIVIER", category: "award", clue: "West End's top prize", difficulty: "easy" },
    { word: "DRAMA", category: "award", clue: "Desk award type", difficulty: "easy" },
    { word: "GRAMMY", category: "award", clue: "Recording industry honor", difficulty: "easy" },
    { word: "OSCAR", category: "award", clue: "Film industry award", difficulty: "easy" },
    { word: "EMMY", category: "award", clue: "Television award", difficulty: "easy" },
    { word: "GOLDEN", category: "award", clue: "___ Globe award", difficulty: "easy" },
    { word: "GLOBE", category: "award", clue: "Golden ___ award", difficulty: "easy" },
    { word: "CRITICS", category: "award", clue: "___ Choice Award", difficulty: "medium" },
    { word: "CHOICE", category: "award", clue: "Critics ___ Award", difficulty: "medium" },
    { word: "OUTER", category: "award", clue: "___ Critics Circle", difficulty: "medium" },
    { word: "CIRCLE", category: "award", clue: "Critics ___", difficulty: "medium" },
    { word: "THEATRE", category: "award", clue: "___ World Award", difficulty: "medium" },
    { word: "WORLD", category: "award", clue: "Theatre ___ Award", difficulty: "medium" },
    { word: "LUCILLE", category: "award", clue: "___ Lortel Award", difficulty: "hard" },
    { word: "LORTEL", category: "award", clue: "Lucille ___ Award", difficulty: "hard" },
    { word: "HELEN", category: "award", clue: "___ Hayes Award", difficulty: "hard" },
    { word: "HAYES", category: "award", clue: "Helen ___ Award", difficulty: "hard" },
    
    // SONGS & MUSICAL NUMBERS (200+ entries)
    { word: "MEMORY", category: "song", clue: "Cats' big number", difficulty: "easy" },
    { word: "DEFYING", category: "song", clue: "Gravity-___ (Wicked song)", difficulty: "easy" },
    { word: "GRAVITY", category: "song", clue: "Defying ___ (Wicked song)", difficulty: "easy" },
    { word: "TOMORROW", category: "song", clue: "Annie's optimistic song", difficulty: "easy" },
    { word: "POPULAR", category: "song", clue: "Glinda's Wicked number", difficulty: "medium" },
    { word: "SEASONS", category: "song", clue: "Four ___ of Love", difficulty: "medium" },
    { word: "ANYTHING", category: "song", clue: "I Can Do ___ (Annie Get Your Gun)", difficulty: "medium" },
    { word: "PEOPLE", category: "song", clue: "Funny Girl anthem", difficulty: "medium" },
    { word: "HELLO", category: "song", clue: "___ Dolly title song", difficulty: "medium" },
    { word: "DOLLY", category: "song", clue: "Hello ___ title song", difficulty: "medium" },
    { word: "OKLAHOMA", category: "song", clue: "State anthem musical number", difficulty: "medium" },
    { word: "SURREY", category: "song", clue: "Fringe on Top vehicle", difficulty: "medium" },
    { word: "FRINGE", category: "song", clue: "___ on Top (Oklahoma song)", difficulty: "medium" },
    { word: "GETTING", category: "song", clue: "___ to Know You", difficulty: "medium" },
    { word: "KNOW", category: "song", clue: "Getting to ___ You", difficulty: "medium" },
    { word: "RAIN", category: "song", clue: "Singing in the ___", difficulty: "medium" },
    { word: "SINGING", category: "song", clue: "___ in the Rain", difficulty: "medium" },
    { word: "COMPANY", category: "song", clue: "Sondheim title number", difficulty: "hard" },
    { word: "BEING", category: "song", clue: "___ Alive (Company)", difficulty: "hard" },
    { word: "ALIVE", category: "song", clue: "Being ___ (Company)", difficulty: "hard" },
    { word: "LADIES", category: "song", clue: "___ Who Lunch", difficulty: "hard" },
    { word: "LUNCH", category: "song", clue: "Ladies Who ___", difficulty: "hard" },
    { word: "PUTTING", category: "song", clue: "___ It Together", difficulty: "hard" },
    { word: "TOGETHER", category: "song", clue: "Putting It ___", difficulty: "hard" },
    
    // CHARACTERS & ROLES (150+ entries)
    { word: "ELPHABA", category: "role", clue: "Wicked's green girl", difficulty: "easy" },
    { word: "GLINDA", category: "role", clue: "Wicked's good witch", difficulty: "easy" },
    { word: "JEAN", category: "role", clue: "Valjean of Les Mis", difficulty: "easy" },
    { word: "VALJEAN", category: "role", clue: "Jean ___ of Les Mis", difficulty: "easy" },
    { word: "MARIA", category: "role", clue: "Sound of Music heroine", difficulty: "easy" },
    { word: "DANNY", category: "role", clue: "Zuko of Grease", difficulty: "easy" },
    { word: "ZUKO", category: "role", clue: "Danny ___ of Grease", difficulty: "easy" },
    { word: "SANDY", category: "role", clue: "Grease's good girl", difficulty: "easy" },
    { word: "JAVERT", category: "role", clue: "Les Mis inspector", difficulty: "medium" },
    { word: "ROXIE", category: "role", clue: "Hart of Chicago", difficulty: "medium" },
    { word: "HART", category: "role", clue: "Roxie ___ of Chicago", difficulty: "medium" },
    { word: "VELMA", category: "role", clue: "Kelly of Chicago", difficulty: "medium" },
    { word: "KELLY", category: "role", clue: "Velma ___ of Chicago", difficulty: "medium" },
    { word: "AARON", category: "role", clue: "Burr of Hamilton", difficulty: "medium" },
    { word: "BURR", category: "role", clue: "Aaron ___ of Hamilton", difficulty: "medium" },
    { word: "ALEXANDER", category: "role", clue: "___ Hamilton", difficulty: "medium" },
    { word: "HAMILTON", category: "role", clue: "Alexander ___", difficulty: "medium" },
    { word: "EVAN", category: "role", clue: "Hansen of Dear Evan Hansen", difficulty: "medium" },
    { word: "HANSEN", category: "role", clue: "Evan ___ of musical", difficulty: "medium" },
    { word: "ELIZA", category: "role", clue: "Doolittle of My Fair Lady", difficulty: "hard" },
    { word: "DOOLITTLE", category: "role", clue: "Eliza ___ of My Fair Lady", difficulty: "hard" },
    { word: "HIGGINS", category: "role", clue: "Professor of My Fair Lady", difficulty: "hard" },
    { word: "PROFESSOR", category: "role", clue: "___ Higgins", difficulty: "hard" },
    { word: "TONY", category: "role", clue: "West Side Story lover", difficulty: "hard" },
    { word: "MARIA", category: "role", clue: "West Side Story heroine", difficulty: "hard" },
    { word: "ANITA", category: "role", clue: "West Side Story friend", difficulty: "hard" },
    { word: "BERNARDO", category: "role", clue: "West Side Story leader", difficulty: "hard" }
  ];

  async generateDailyCrossword(date: string, difficulty: 'easy' | 'medium' | 'hard' = 'medium'): Promise<CrosswordPuzzle> {
    // Create difficulty-specific cache key
    const cacheKey = `${date}-${difficulty}`;
    
    // Get recently used answers for this specific difficulty
    const usedAnswers = await this.getRecentlyUsedAnswers(21);
    const difficultySpecificUsed = usedAnswers.filter(word => word.endsWith(`-${difficulty}`)).map(word => word.replace(`-${difficulty}`, ''));
    
    const availableAnswers = this.theatreAnswers.filter(
      answer => !difficultySpecificUsed.includes(answer.word.toUpperCase())
    );

    if (availableAnswers.length < 20) {
      console.warn(`Only ${availableAnswers.length} available answers for ${difficulty}. Using all answers.`);
    }

    // Use the professional constructor for proper crossword generation
    const puzzle = await this.crosswordConstructor.constructCrossword(availableAnswers, difficulty, date);
    
    // Store used answers with difficulty suffix to avoid conflicts between difficulty levels
    const usedWords = puzzle.clues.across.concat(puzzle.clues.down).map(clue => `${clue.answer}-${difficulty}`);
    await this.storeUsedAnswers(usedWords, date);
    
    return puzzle;
  }

  private selectDiverseAnswers(available: TheatreAnswer[], count: number): TheatreAnswer[] {
    const selected: TheatreAnswer[] = [];
    const categories = [...new Set(available.map(a => a.category))];
    const difficulties = ['easy', 'medium', 'hard'];
    
    // Distribute across categories and difficulties
    for (let i = 0; i < count && available.length > 0; i++) {
      const targetCategory = categories[i % categories.length];
      const targetDifficulty = difficulties[Math.floor(i / categories.length) % difficulties.length];
      
      let candidate = available.find(a => 
        a.category === targetCategory && a.difficulty === targetDifficulty
      );
      
      if (!candidate) {
        candidate = available.find(a => a.category === targetCategory);
      }
      
      if (!candidate) {
        candidate = available[Math.floor(Math.random() * available.length)];
      }
      
      if (candidate) {
        selected.push(candidate);
        available.splice(available.indexOf(candidate), 1);
      }
    }
    
    return selected;
  }

  private async generateProperCrosswordGrid(answers: TheatreAnswer[], date: string, difficulty: 'easy' | 'medium' | 'hard' = 'medium'): Promise<CrosswordPuzzle> {
    const gridSize = 15;
    const grid: string[][] = Array(gridSize).fill(null).map(() => Array(gridSize).fill('#'));
    const clues: CrosswordClue[] = [];
    let clueNumber = 1;
    
    // Filter answers by difficulty with fallback
    let filteredAnswers = difficulty === 'easy' 
      ? answers.filter(a => a.difficulty === 'easy')
      : difficulty === 'hard'
      ? answers.filter(a => a.difficulty === 'hard')
      : answers.filter(a => a.difficulty === 'medium');
    
    // Fallback to all answers if not enough in the specific difficulty
    if (filteredAnswers.length < 10) {
      filteredAnswers = answers;
    }
    
    filteredAnswers = filteredAnswers.slice(0, 18);
    
    // Create a proper crossword pattern with interconnected words
    const placedWords: { word: string; row: number; col: number; direction: 'across' | 'down'; clue: string }[] = [];
    
    // Start with a long word across the center
    const centerWord = filteredAnswers.find(a => a.word.length >= 6) || filteredAnswers[0];
    const centerRow = 7;
    const centerCol = Math.floor((gridSize - centerWord.word.length) / 2);
    
    // Place center word
    for (let i = 0; i < centerWord.word.length; i++) {
      grid[centerRow][centerCol + i] = centerWord.word[i];
    }
    
    placedWords.push({
      word: centerWord.word,
      row: centerRow,
      col: centerCol,
      direction: 'across',
      clue: centerWord.clue
    });
    
    clues.push({
      number: clueNumber++,
      direction: 'across',
      clue: centerWord.clue,
      answer: centerWord.word,
      startRow: centerRow,
      startCol: centerCol,
      length: centerWord.word.length
    });
    
    // Place additional words in a simple but interconnected pattern
    const remainingAnswers = filteredAnswers.filter(a => a.word !== centerWord.word);
    const maxWords = difficulty === 'easy' ? 8 : difficulty === 'hard' ? 12 : 10;
    
    // Place some simple intersecting words
    for (let i = 0; i < Math.min(remainingAnswers.length, maxWords - 1); i++) {
      const answer = remainingAnswers[i];
      
      // Try to intersect with the center word
      for (let j = 0; j < centerWord.word.length; j++) {
        for (let k = 0; k < answer.word.length; k++) {
          if (centerWord.word[j] === answer.word[k]) {
            // Place vertically intersecting the horizontal center word
            const newRow = centerRow - k;
            const newCol = centerCol + j;
            
            if (newRow >= 0 && newRow + answer.word.length <= gridSize && newCol >= 0 && newCol < gridSize) {
              // Check if placement is valid
              let canPlace = true;
              for (let l = 0; l < answer.word.length; l++) {
                const checkRow = newRow + l;
                if (grid[checkRow][newCol] !== '#' && grid[checkRow][newCol] !== answer.word[l]) {
                  canPlace = false;
                  break;
                }
              }
              
              if (canPlace) {
                // Place the word
                for (let l = 0; l < answer.word.length; l++) {
                  grid[newRow + l][newCol] = answer.word[l];
                }
                
                placedWords.push({
                  word: answer.word,
                  row: newRow,
                  col: newCol,
                  direction: 'down',
                  clue: answer.clue
                });
                
                clues.push({
                  number: clueNumber++,
                  direction: 'down',
                  clue: answer.clue,
                  answer: answer.word,
                  startRow: newRow,
                  startCol: newCol,
                  length: answer.word.length
                });
                break;
              }
            }
          }
        }
        if (placedWords.length >= maxWords) break;
      }
      if (placedWords.length >= maxWords) break;
    }

    return {
      id: `crossword-${date}`,
      date,
      title: `Theatre Crossword - ${new Date().toLocaleDateString('en-US', { 
        weekday: 'long', 
        month: 'long', 
        day: 'numeric' 
      })}`,
      grid,
      clues: clues.sort((a, b) => {
        if (a.direction !== b.direction) {
          return a.direction === 'across' ? -1 : 1;
        }
        return a.number - b.number;
      }),
      size: gridSize,
      difficulty,
      theme: this.generateTheme(filteredAnswers)
    };
  }
  
  private findIntersections(word: string, placedWords: any[], grid: string[][], gridSize: number) {
    const intersections = [];
    
    for (const placedWord of placedWords) {
      for (let i = 0; i < word.length; i++) {
        for (let j = 0; j < placedWord.word.length; j++) {
          if (word[i] === placedWord.word[j]) {
            // Try placing the new word perpendicular to the placed word
            if (placedWord.direction === 'across') {
              // Place new word down
              const newRow = placedWord.row - i;
              const newCol = placedWord.col + j;
              
              if (this.canPlaceWord(grid, word, newRow, newCol, 'down', gridSize)) {
                intersections.push({
                  row: newRow,
                  col: newCol,
                  direction: 'down' as const
                });
              }
            } else {
              // Place new word across
              const newRow = placedWord.row + j;
              const newCol = placedWord.col - i;
              
              if (this.canPlaceWord(grid, word, newRow, newCol, 'across', gridSize)) {
                intersections.push({
                  row: newRow,
                  col: newCol,
                  direction: 'across' as const
                });
              }
            }
          }
        }
      }
    }
    
    return intersections;
  }
  
  private canPlaceWord(grid: string[][], word: string, row: number, col: number, direction: 'across' | 'down', gridSize: number): boolean {
    // Basic bounds checking
    if (direction === 'across') {
      if (row < 0 || row >= gridSize || col < 0 || col + word.length > gridSize) {
        return false;
      }
    } else {
      if (row < 0 || row + word.length > gridSize || col < 0 || col >= gridSize) {
        return false;
      }
    }
    
    // Check if word can be placed without conflicts
    for (let i = 0; i < word.length; i++) {
      const checkRow = direction === 'across' ? row : row + i;
      const checkCol = direction === 'across' ? col + i : col;
      
      // Additional bounds check
      if (checkRow >= gridSize || checkCol >= gridSize) {
        return false;
      }
      
      const currentCell = grid[checkRow][checkCol];
      
      // Allow placement only if cell is empty (#) or matches the letter
      if (currentCell !== '#' && currentCell !== word[i]) {
        return false;
      }
    }
    
    return true;
  }

  private placeWord(grid: string[][], word: string, row: number, col: number, direction: 'across' | 'down'): void {
    for (let i = 0; i < word.length; i++) {
      if (direction === 'across') {
        grid[row][col + i] = word[i];
      } else {
        grid[row + i][col] = word[i];
      }
    }
  }

  private findBestPlacement(grid: string[][], word: string, placedWords: CrosswordClue[]): {
    row: number;
    col: number;
    direction: 'across' | 'down';
  } | null {
    const directions: ('across' | 'down')[] = ['across', 'down'];
    
    for (const direction of directions) {
      for (let attempts = 0; attempts < 100; attempts++) {
        const maxRow = direction === 'across' ? grid.length : grid.length - word.length;
        const maxCol = direction === 'across' ? grid[0].length - word.length : grid[0].length;
        
        const row = Math.floor(Math.random() * maxRow);
        const col = Math.floor(Math.random() * maxCol);
        
        if (this.canPlaceWord(grid, word, row, col, direction)) {
          return { row, col, direction };
        }
      }
    }
    
    return null;
  }

  private canPlaceWord(grid: string[][], word: string, row: number, col: number, direction: 'across' | 'down'): boolean {
    // Check if word fits and has at least one intersection
    let hasIntersection = false;
    
    for (let i = 0; i < word.length; i++) {
      const checkRow = direction === 'across' ? row : row + i;
      const checkCol = direction === 'across' ? col + i : col;
      
      if (checkRow >= grid.length || checkCol >= grid[0].length) {
        return false;
      }
      
      const currentCell = grid[checkRow][checkCol];
      
      if (currentCell === '') {
        continue; // Empty cell, can place
      } else if (currentCell === word[i]) {
        hasIntersection = true; // Valid intersection
      } else {
        return false; // Conflict
      }
    }
    
    return hasIntersection;
  }

  private numberGrid(grid: string[][], clues: CrosswordClue[]): void {
    let number = 1;
    
    for (let row = 0; row < grid.length; row++) {
      for (let col = 0; col < grid[0].length; col++) {
        if (grid[row][col] !== '#' && grid[row][col] !== '') {
          // Check if this is the start of a word
          const startsAcross = col === 0 || grid[row][col - 1] === '#' || grid[row][col - 1] === '';
          const startsDown = row === 0 || grid[row - 1][col] === '#' || grid[row - 1][col] === '';
          
          if (startsAcross || startsDown) {
            // Find clues that start at this position
            const cluesAtPosition = clues.filter(clue => 
              clue.startRow === row && clue.startCol === col
            );
            
            cluesAtPosition.forEach(clue => {
              clue.number = number;
            });
            
            if (cluesAtPosition.length > 0) {
              number++;
            }
          }
        }
      }
    }
  }

  private generateTheme(answers: TheatreAnswer[]): string {
    const categories = answers.reduce((acc, answer) => {
      acc[answer.category] = (acc[answer.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const topCategory = Object.entries(categories).sort((a, b) => b[1] - a[1])[0][0];
    
    const themes: Record<string, string> = {
      'show': 'Broadway & West End Shows',
      'performer': 'Theatre Stars',
      'venue': 'Theatre Venues',
      'composer': 'Musical Theatre Creators',
      'term': 'Theatre Terminology',
      'award': 'Theatre Awards',
      'song': 'Show Tunes',
      'role': 'Iconic Characters'
    };

    return themes[topCategory] || 'Theatre Knowledge';
  }

  private async getRecentlyUsedAnswers(days: number): Promise<string[]> {
    // In a real implementation, this would query the database
    // For now, return empty array since we're storing in memory
    return [];
  }

  private async storeUsedAnswers(answers: string[], date: string): Promise<void> {
    // In a real implementation, this would store in database
    // For now, we'll just log
    console.log(`Stored ${answers.length} answers for ${date}`);
  }

  async getCrosswordForDate(date: string): Promise<CrosswordPuzzle | null> {
    // Check if crossword already exists for this date
    // For now, generate fresh each time
    return this.generateDailyCrossword(date);
  }

  async getTodaysCrossword(): Promise<CrosswordPuzzle> {
    const today = new Date().toISOString().split('T')[0];
    return this.generateDailyCrossword(today);
  }
}

export const crosswordGenerator = new CrosswordGenerator();