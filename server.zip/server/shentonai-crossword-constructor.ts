/**
 * ShentonAI Crossword Constructor
 * Professional theatre crossword system with ChatGPT standards compliance
 */

import { CrosswordAnswer, easyAnswers, mediumAnswers, hardAnswers, dedicatedAnswers } from './crossword-data';
import { clueVariationSystem } from './clue-variation-system';
import { authenticGridExtractor } from './authentic-grid-extractor';

interface GridCell {
  letter: string | null;
  number: number | null;
  isBlack: boolean;
  wordStart: boolean;
}

interface CrosswordClue {
  number: number;
  clue: string;
  answer: string;
  row: number;
  col: number;
}

interface CrosswordPuzzle {
  id: string;
  date: string;
  difficulty: 'easy' | 'medium' | 'hard' | 'dedicated';
  grid: string[][];
  solution: string[][];
  clues: {
    across: CrosswordClue[];
    down: CrosswordClue[];
  };
  size: number;
}

interface WordPlacement {
  word: string;
  clue: string;
  row: number;
  col: number;
  direction: 'across' | 'down';
  number?: number;
  length?: number;
  answer: CrosswordAnswer;
}

export class ShentonAICrosswordConstructor {
  private gridSize = 15;
  private grid: GridCell[][];
  private placedWords: WordPlacement[] = [];
  
  // Minimum targets (can exceed for better grids)
  private targets = {
    easy: { across: 4, down: 6 },
    medium: { across: 8, down: 10 },
    hard: { across: 12, down: 12 },
    dedicated: { across: 15, down: 17 }
  };

  constructor() {
    this.initializeGrid();
  }

  private seededRandom(seed: number) {
    return function() {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };
  }

  async constructCrossword(difficulty: 'easy' | 'medium' | 'hard' | 'dedicated', date: string): Promise<CrosswordPuzzle> {
    // Set deterministic random
    const baseSeed = { easy: 1000, medium: 2000, hard: 3000, dedicated: 4000 }[difficulty];
    const dateSeed = parseInt(date.replace(/-/g, '')) % 1000;
    Math.random = this.seededRandom(baseSeed + dateSeed);

    // Initialize empty grid
    this.initializeGrid();
    this.placedWords = [];
    
    // Get answers for this difficulty
    let answers: CrosswordAnswer[];
    switch (difficulty) {
      case 'easy': answers = easyAnswers; break;
      case 'medium': answers = mediumAnswers; break;
      case 'hard': answers = hardAnswers; break;
      case 'dedicated': answers = dedicatedAnswers; break;
      default: answers = mediumAnswers;
    }
    const target = this.targets[difficulty];
    
    console.log(`ShentonAI: Constructing ${difficulty} crossword with ${answers.length} available answers`);
    console.log(`Target: ${target.across} across, ${target.down} down`);
    
    // Step 1: Get authentic crossword grid from Guardian/Sun/Express
    const authenticGrid = await this.getAuthenticGrid();
    console.log(`ShentonAI: Using authentic ${authenticGrid.source} grid #${authenticGrid.number} with ${authenticGrid.blackSquares.length} black squares`);
    
    // Step 2: Apply authentic layout to our grid
    this.applyAuthenticLayout(authenticGrid);
    
    // Step 3: Fill slots with theatre words using pre-calculated slots
    if (authenticGrid.wordSlots && authenticGrid.wordSlots.length > 0) {
      console.log(`ShentonAI: Using ${authenticGrid.wordSlots.length} pre-calculated word slots`);
      this.fillAuthenticSlots(authenticGrid.wordSlots, answers, target);
    } else {
      // Fallback: Calculate word slots from the applied black square pattern
      console.log('ShentonAI: No pre-calculated slots, calculating from grid...');
      const calculatedSlots = this.findWordSlotsInAppliedGrid();
      this.fillAuthenticSlots(calculatedSlots, answers, target);
    }
    
    console.log(`ShentonAI: Placed ${this.placedWords.length} total words`);
    
    // Step 4: Fill letters in solution
    this.fillLettersInGrid();
    
    // Generate clues with variations
    const clues = this.generateCluesWithVariations(date);
    
    // Create final grids
    const puzzleGrid = this.createPuzzleGrid();
    const solutionGrid = this.createSolutionGrid();

    return {
      id: `crossword-${date}-${difficulty}`,
      date,
      difficulty,
      grid: puzzleGrid,
      solution: solutionGrid,
      clues,
      size: this.gridSize
    };
  }

  private initializeGrid(): void {
    this.grid = Array(this.gridSize).fill(null).map(() =>
      Array(this.gridSize).fill(null).map(() => ({
        letter: null,
        number: null,
        isBlack: false,
        wordStart: false
      }))
    );
  }

  private placeWordsStrategically(answers: CrosswordAnswer[], target: { across: number; down: number }): void {
    // Filter answers to appropriate lengths for 15x15 grid
    const usableAnswers = answers.filter(a => a.word.length >= 3 && a.word.length <= 11);
    
    console.log(`ShentonAI: Filtered to ${usableAnswers.length} usable answers`);
    
    // Place across words strategically
    let acrossCount = 0;
    let nextRow = 1;
    
    for (const answer of usableAnswers) {
      if (acrossCount >= target.across) break;
      if (nextRow >= this.gridSize - 1) break;
      
      if (answer.word.length <= this.gridSize - 2) {
        const placement: WordPlacement = {
          word: answer.word,
          clue: answer.clue,
          row: nextRow,
          col: 1,
          direction: 'across',
          answer
        };
        
        this.placeWordSafely(placement);
        this.placedWords.push(placement);
        acrossCount++;
        nextRow += 2; // Proper spacing for readability
        
        console.log(`ShentonAI: Placed across word "${answer.word}" at row ${nextRow-2}`);
      }
    }
    
    // Place down words strategically
    let downCount = 0;
    let nextCol = 2;
    
    for (const answer of usableAnswers) {
      if (downCount >= target.down) break;
      if (this.isWordAlreadyPlaced(answer.word)) continue;
      if (nextCol >= this.gridSize - 1) break;
      
      if (answer.word.length <= this.gridSize - 2) {
        const placement: WordPlacement = {
          word: answer.word,
          clue: answer.clue,
          row: 1,
          col: nextCol,
          direction: 'down',
          answer
        };
        
        this.placeWordSafely(placement);
        this.placedWords.push(placement);
        downCount++;
        nextCol += 2; // Proper spacing for readability
        
        console.log(`ShentonAI: Placed down word "${answer.word}" at col ${nextCol-2}`);
      }
    }
    
    // Fill remaining slots to meet minimum requirements
    this.fillRemainingSlots(answers, target, acrossCount, downCount);
  }

  private placeWordSafely(placement: WordPlacement): void {
    const { word, row, col, direction } = placement;
    const deltaRow = direction === 'down' ? 1 : 0;
    const deltaCol = direction === 'across' ? 1 : 0;
    
    for (let i = 0; i < word.length; i++) {
      const currentRow = row + i * deltaRow;
      const currentCol = col + i * deltaCol;
      
      if (this.isValidPosition(currentRow, currentCol)) {
        this.grid[currentRow][currentCol].letter = word[i];
        if (i === 0) {
          this.grid[currentRow][currentCol].wordStart = true;
        }
      }
    }
  }

  private canPlaceWordSafely(placement: WordPlacement): boolean {
    const { word, row, col, direction } = placement;
    const deltaRow = direction === 'down' ? 1 : 0;
    const deltaCol = direction === 'across' ? 1 : 0;
    
    // Check if word fits in grid
    const endRow = row + (word.length - 1) * deltaRow;
    const endCol = col + (word.length - 1) * deltaCol;
    
    if (endRow >= this.gridSize || endCol >= this.gridSize) return false;
    
    // Check for conflicts with existing letters
    for (let i = 0; i < word.length; i++) {
      const currentRow = row + i * deltaRow;
      const currentCol = col + i * deltaCol;
      
      if (!this.isValidPosition(currentRow, currentCol)) return false;
      
      const cell = this.grid[currentRow][currentCol];
      if (cell.letter && cell.letter !== word[i]) return false;
    }
    
    return true;
  }

  private isWordAlreadyPlaced(word: string): boolean {
    return this.placedWords.some(p => p.word === word);
  }

  private fillRemainingSlots(answers: CrosswordAnswer[], target: { across: number; down: number }, acrossCount: number, downCount: number): void {
    const remainingAnswers = answers.filter(a => !this.isWordAlreadyPlaced(a.word));
    
    // Continue adding across words until target met - maximum fill
    let row = acrossCount;
    let attempts = 0;
    while (acrossCount < target.across && remainingAnswers.length > 0 && attempts < 100) {
      const answer = remainingAnswers.shift();
      if (!answer) break;
      
      if (answer.word.length <= this.gridSize - 2) {
        const placement: WordPlacement = {
          word: answer.word,
          clue: answer.clue,
          row: row,
          col: 0,
          direction: 'across',
          answer
        };
        
        this.placeWordSafely(placement);
        this.placedWords.push(placement);
        acrossCount++;
        row = (row + 1) % (this.gridSize - 1);
        console.log(`ShentonAI: Extra across word "${answer.word}" placed to meet target`);
      }
      attempts++;
    }
    
    // Continue adding down words until target met - maximum fill
    let col = downCount;
    let downAttempts = 0;
    while (downCount < target.down && remainingAnswers.length > 0 && downAttempts < 100) {
      const answer = remainingAnswers.shift();
      if (!answer || this.isWordAlreadyPlaced(answer.word)) {
        downAttempts++;
        continue;
      }
      
      if (answer.word.length <= this.gridSize - 2) {
        const placement: WordPlacement = {
          word: answer.word,
          clue: answer.clue,
          row: 0,
          col: col,
          direction: 'down',
          answer
        };
        
        this.placeWordSafely(placement);
        this.placedWords.push(placement);
        downCount++;
        col = (col + 1) % (this.gridSize - 1);
        console.log(`ShentonAI: Extra down word "${answer.word}" placed to meet target`);
      }
      downAttempts++;
    }
    
    console.log(`ShentonAI: Final counts - ${acrossCount}/${target.across} across, ${downCount}/${target.down} down`);
  }

  private numberGrid(): void {
    let currentNumber = 1;
    
    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        const cell = this.grid[row][col];
        
        if (cell.letter && cell.wordStart) {
          cell.number = currentNumber++;
        }
      }
    }
  }

  private generateCluesWithVariations(date: string): { across: CrosswordClue[]; down: CrosswordClue[] } {
    const across: CrosswordClue[] = [];
    const down: CrosswordClue[] = [];
    const usedClues = new Set<string>();
    
    for (const placement of this.placedWords) {
      const cell = this.grid[placement.row][placement.col];
      if (!cell.number) continue;
      
      // Use original Guardian-quality clue directly from the data
      const clue = placement.answer.clue;
      
      const clueEntry: CrosswordClue = {
        number: cell.number,
        clue,
        answer: placement.word,
        row: placement.row,
        col: placement.col
      };
      
      if (placement.direction === 'across') {
        across.push(clueEntry);
      } else {
        down.push(clueEntry);
      }
    }
    
    // Sort by number
    across.sort((a, b) => a.number - b.number);
    down.sort((a, b) => a.number - b.number);
    
    return { across, down };
  }

  private createPuzzleGrid(): string[][] {
    return this.grid.map(row =>
      row.map(cell => {
        if (cell.isBlack) return '█';
        if (cell.number) return cell.number.toString();
        return ' ';
      })
    );
  }

  private async getAuthenticGrid(): Promise<any> {
    try {
      const authenticGrid = authenticGridExtractor.getRandomGrid();
      console.log(`ShentonAI: Retrieved authentic ${authenticGrid.source} grid with ${authenticGrid.wordSlots?.length || 0} word slots`);
      return authenticGrid;
    } catch (error) {
      console.log('ShentonAI: Using fallback grid due to extraction error');
      return this.getFallbackGrid();
    }
  }

  private getFallbackGrid(): any {
    // Use authentic Guardian grid as fallback
    return {
      id: 'guardian-29995',
      source: 'guardian',
      number: '29995',
      blackSquares: [
        [0, 3], [0, 11], [1, 6], [1, 8], [2, 1], [2, 13], [3, 4], [3, 10],
        [4, 0], [4, 7], [4, 14], [5, 2], [5, 5], [5, 9], [5, 12],
        [6, 6], [6, 8], [7, 3], [7, 11], [8, 6], [8, 8],
        [9, 2], [9, 5], [9, 9], [9, 12], [10, 0], [10, 7], [10, 14],
        [11, 4], [11, 10], [12, 1], [12, 13], [13, 6], [13, 8], [14, 3], [14, 11]
      ],
      numberedCells: [],
      wordSlots: []
    };
  }

  private applyAuthenticLayout(authenticGrid: any): void {
    console.log(`ShentonAI: Applying authentic ${authenticGrid.source} layout`);
    
    // Clear existing grid
    this.initializeGrid();
    
    // Apply authentic black squares
    authenticGrid.blackSquares.forEach(([row, col]: [number, number]) => {
      if (row < this.gridSize && col < this.gridSize) {
        this.grid[row][col].isBlack = true;
      }
    });
    
    // Apply numbered cells if available
    if (authenticGrid.numberedCells) {
      authenticGrid.numberedCells.forEach(({row, col, number}: {row: number, col: number, number: number}) => {
        if (row < this.gridSize && col < this.gridSize) {
          this.grid[row][col].number = number;
        }
      });
    }
    
    const blackCount = this.countBlackSquares();
    console.log(`ShentonAI: Applied authentic layout - ${blackCount} black squares`);
  }

  private processAuthenticGrid(authenticGrid: any): any {
    // Find word slots based on black square layout
    const wordSlots: Array<{number: number, row: number, col: number, length: number, direction: 'across' | 'down'}> = [];
    
    // Create proper grid layout
    const gridArray: boolean[][] = [];
    for (let i = 0; i < 15; i++) {
      gridArray[i] = new Array(15).fill(false);
    }
    
    // Mark black squares
    authenticGrid.blackSquares.forEach(([row, col]: [number, number]) => {
      if (row >= 0 && row < 15 && col >= 0 && col < 15) {
        gridArray[row][col] = true;
      }
    });

    let currentNumber = 1;
    
    // Find word starting positions
    for (let row = 0; row < 15; row++) {
      for (let col = 0; col < 15; col++) {
        if (!gridArray[row][col]) {
          const isAcrossStart = this.isWordStart(gridArray, row, col, 'across');
          const isDownStart = this.isWordStart(gridArray, row, col, 'down');
          
          if (isAcrossStart || isDownStart) {
            // Set grid number
            if (row < this.gridSize && col < this.gridSize) {
              this.grid[row][col].number = currentNumber;
            }
            
            if (isAcrossStart) {
              const length = this.getWordLength(gridArray, row, col, 'across');
              if (length >= 3) {
                wordSlots.push({number: currentNumber, row, col, length, direction: 'across'});
              }
            }
            
            if (isDownStart) {
              const length = this.getWordLength(gridArray, row, col, 'down');
              if (length >= 3) {
                wordSlots.push({number: currentNumber, row, col, length, direction: 'down'});
              }
            }
            
            currentNumber++;
          }
        }
      }
    }

    console.log(`ShentonAI: Found ${wordSlots.length} word slots in authentic grid`);
    return { ...authenticGrid, wordSlots };
  }

  private isWordStart(grid: boolean[][], row: number, col: number, direction: 'across' | 'down'): boolean {
    try {
      // Validate grid bounds
      if (!grid || row < 0 || row >= 15 || col < 0 || col >= 15) {
        return false;
      }
      
      // Ensure we have proper grid arrays
      if (!Array.isArray(grid[row])) {
        return false;
      }
      
      // Current cell must be empty
      if (grid[row][col] === true) {
        return false;
      }
      
      if (direction === 'across') {
        // Previous cell must be blocked or edge
        const prevBlocked = col === 0 || (col > 0 && grid[row][col - 1] === true);
        // Must have at least 3 consecutive empty cells
        const hasLength = col + 2 < 15 && 
                         grid[row][col + 1] === false && 
                         grid[row][col + 2] === false;
        return prevBlocked && hasLength;
      } else {
        // Previous cell must be blocked or edge
        const prevBlocked = row === 0 || (row > 0 && grid[row - 1][col] === true);
        // Must have at least 3 consecutive empty cells
        const hasLength = row + 2 < 15 && 
                         grid[row + 1][col] === false && 
                         grid[row + 2][col] === false;
        return prevBlocked && hasLength;
      }
    } catch (error) {
      console.error(`Error in isWordStart: ${error.message}`);
      return false;
    }
  }

  private getWordLength(grid: boolean[][], row: number, col: number, direction: 'across' | 'down'): number {
    try {
      let length = 0;
      const deltaRow = direction === 'down' ? 1 : 0;
      const deltaCol = direction === 'across' ? 1 : 0;
      
      let currentRow = row;
      let currentCol = col;
      
      while (currentRow >= 0 && currentRow < 15 && 
             currentCol >= 0 && currentCol < 15 && 
             Array.isArray(grid[currentRow]) && 
             grid[currentRow][currentCol] === false) {
        length++;
        currentRow += deltaRow;
        currentCol += deltaCol;
      }
      
      return length;
    } catch (error) {
      console.error(`Error in getWordLength: ${error.message}`);
      return 0;
    }
  }

  private fillAuthenticSlots(wordSlots: any[], answers: CrosswordAnswer[], target: { across: number; down: number }): void {
    const usedWords = new Set();
    let acrossSlots = wordSlots.filter(s => s.direction === 'across');
    let downSlots = wordSlots.filter(s => s.direction === 'down');
    
    console.log(`ShentonAI: Filling slots from ${acrossSlots.length} across and ${downSlots.length} down available`);
    
    // Clear existing placements
    this.placedWords = [];
    
    // Fill across slots up to target
    let acrossCount = 0;
    for (const slot of acrossSlots) {
      if (acrossCount >= target.across) break;
      
      const fittingWords = answers.filter(word => 
        word.word.length === slot.length && !usedWords.has(word.word)
      );
      
      if (fittingWords.length > 0) {
        const selectedWord = fittingWords[0];
        this.placedWords.push({
          word: selectedWord.word,
          clue: selectedWord.clue,
          answer: selectedWord,
          row: slot.row,
          col: slot.col,
          direction: 'across'
        });
        usedWords.add(selectedWord.word);
        acrossCount++;
        
        // Place letters in grid
        for (let i = 0; i < selectedWord.word.length; i++) {
          if (slot.col + i < this.gridSize && !this.grid[slot.row][slot.col + i].isBlack) {
            this.grid[slot.row][slot.col + i].letter = selectedWord.word[i];
          }
        }
        
        console.log(`ShentonAI: Placed "${selectedWord.word}" across at ${slot.row},${slot.col} (length ${slot.length})`);
      }
    }
    
    // Fill down slots up to target
    let downCount = 0;
    for (const slot of downSlots) {
      if (downCount >= target.down) break;
      
      const fittingWords = answers.filter(word => 
        word.word.length === slot.length && !usedWords.has(word.word)
      );
      
      if (fittingWords.length > 0) {
        const selectedWord = fittingWords[0];
        this.placedWords.push({
          word: selectedWord.word,
          clue: selectedWord.clue,
          answer: selectedWord,
          row: slot.row,
          col: slot.col,
          direction: 'down'
        });
        usedWords.add(selectedWord.word);
        downCount++;
        
        // Place letters in grid
        for (let i = 0; i < selectedWord.word.length; i++) {
          if (slot.row + i < this.gridSize && !this.grid[slot.row + i][slot.col].isBlack) {
            this.grid[slot.row + i][slot.col].letter = selectedWord.word[i];
          }
        }
        
        console.log(`ShentonAI: Placed "${selectedWord.word}" down at ${slot.row},${slot.col} (length ${slot.length})`);
      }
    }
    
    console.log(`ShentonAI: Total words placed: ${this.placedWords.length} (${acrossCount} across, ${downCount} down)`);
  }

  private findWordSlotsInAppliedGrid(): any[] {
    const slots = [];
    let currentNumber = 1;
    
    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        if (!this.grid[row][col].isBlack) {
          const acrossStart = this.isWordStartInGrid(row, col, 'across');
          const downStart = this.isWordStartInGrid(row, col, 'down');
          
          if (acrossStart || downStart) {
            // Set grid number
            this.grid[row][col].number = currentNumber;
            
            if (acrossStart) {
              const length = this.getWordLengthInGrid(row, col, 'across');
              if (length >= 3) {
                slots.push({number: currentNumber, row, col, length, direction: 'across'});
              }
            }
            
            if (downStart) {
              const length = this.getWordLengthInGrid(row, col, 'down');
              if (length >= 3) {
                slots.push({number: currentNumber, row, col, length, direction: 'down'});
              }
            }
            
            currentNumber++;
          }
        }
      }
    }
    
    console.log(`ShentonAI: Found ${slots.length} word slots in applied grid`);
    return slots;
  }

  private isWordStartInGrid(row: number, col: number, direction: 'across' | 'down'): boolean {
    if (direction === 'across') {
      const prevBlack = col === 0 || this.grid[row][col - 1].isBlack;
      const hasLength = this.getWordLengthInGrid(row, col, 'across') >= 3;
      return prevBlack && hasLength;
    } else {
      const prevBlack = row === 0 || this.grid[row - 1][col].isBlack;
      const hasLength = this.getWordLengthInGrid(row, col, 'down') >= 3;
      return prevBlack && hasLength;
    }
  }

  private getWordLengthInGrid(row: number, col: number, direction: 'across' | 'down'): number {
    let length = 0;
    const deltaRow = direction === 'down' ? 1 : 0;
    const deltaCol = direction === 'across' ? 1 : 0;
    
    let currentRow = row;
    let currentCol = col;
    
    while (currentRow < this.gridSize && currentCol < this.gridSize && !this.grid[currentRow][currentCol].isBlack) {
      length++;
      currentRow += deltaRow;
      currentCol += deltaCol;
    }
    
    return length;
  }

  private findWordSlots(): Array<{row: number, col: number, length: number, direction: 'across' | 'down'}> {
    const slots = [];
    
    // Find across slots
    for (let row = 0; row < this.gridSize; row++) {
      let currentSlot = { start: -1, length: 0 };
      
      for (let col = 0; col < this.gridSize; col++) {
        if (!this.grid[row][col].isBlack) {
          if (currentSlot.start === -1) currentSlot.start = col;
          currentSlot.length++;
        } else {
          if (currentSlot.length >= 3) {
            slots.push({row, col: currentSlot.start, length: currentSlot.length, direction: 'across' as const});
          }
          currentSlot = { start: -1, length: 0 };
        }
      }
      if (currentSlot.length >= 3) {
        slots.push({row, col: currentSlot.start, length: currentSlot.length, direction: 'across' as const});
      }
    }
    
    // Find down slots
    for (let col = 0; col < this.gridSize; col++) {
      let currentSlot = { start: -1, length: 0 };
      
      for (let row = 0; row < this.gridSize; row++) {
        if (!this.grid[row][col].isBlack) {
          if (currentSlot.start === -1) currentSlot.start = row;
          currentSlot.length++;
        } else {
          if (currentSlot.length >= 3) {
            slots.push({row: currentSlot.start, col, length: currentSlot.length, direction: 'down' as const});
          }
          currentSlot = { start: -1, length: 0 };
        }
      }
      if (currentSlot.length >= 3) {
        slots.push({row: currentSlot.start, col, length: currentSlot.length, direction: 'down' as const});
      }
    }
    
    return slots;
  }

  private fillWordsInSlots(slots: any[], answers: CrosswordAnswer[], target: { across: number; down: number }): void {
    const usedWords = new Set();
    const acrossSlots = slots.filter(s => s.direction === 'across').slice(0, target.across);
    const downSlots = slots.filter(s => s.direction === 'down').slice(0, target.down);
    
    // Fill across slots
    acrossSlots.forEach(slot => {
      const fittingWords = answers.filter(word => 
        word.word.length === slot.length && !usedWords.has(word.word)
      );
      
      if (fittingWords.length > 0) {
        const selectedWord = fittingWords[0];
        this.placedWords.push({
          word: selectedWord.word,
          answer: selectedWord,
          row: slot.row,
          col: slot.col,
          direction: 'across'
        });
        usedWords.add(selectedWord.word);
      }
    });
    
    // Fill down slots
    downSlots.forEach(slot => {
      const fittingWords = answers.filter(word => 
        word.word.length === slot.length && !usedWords.has(word.word)
      );
      
      if (fittingWords.length > 0) {
        const selectedWord = fittingWords[0];
        this.placedWords.push({
          word: selectedWord.word,
          answer: selectedWord,
          row: slot.row,
          col: slot.col,
          direction: 'down'
        });
        usedWords.add(selectedWord.word);
      }
    });
  }

  private numberGridCells(): void {
    let currentNumber = 1;
    
    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        if (!this.grid[row][col].isBlack) {
          const isAcrossStart = this.isWordStart(row, col, 'across');
          const isDownStart = this.isWordStart(row, col, 'down');
          
          if (isAcrossStart || isDownStart) {
            this.grid[row][col].number = currentNumber;
            currentNumber++;
          }
        }
      }
    }
  }

  private isWordStart(row: number, col: number, direction: 'across' | 'down'): boolean {
    // Check bounds first
    if (row < 0 || row >= 15 || col < 0 || col >= 15) return false;
    
    // Check if current cell is black
    if (!this.grid || !this.grid[row] || this.grid[row][col] === '█') return false;
    
    if (direction === 'across') {
      const prevBlack = col === 0 || this.grid[row][col - 1] === '█';
      const hasLength = col + 2 < 15 && this.grid[row][col + 1] !== '█' && this.grid[row][col + 2] !== '█';
      return prevBlack && hasLength;
    } else {
      const prevBlack = row === 0 || this.grid[row - 1][col] === '█';
      const hasLength = row + 2 < 15 && this.grid[row + 1][col] !== '█' && this.grid[row + 2][col] !== '█';
      return prevBlack && hasLength;
    }
  }

  private countBlackSquares(): number {
    let count = 0;
    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        if (this.grid[row][col].isBlack) count++;
      }
    }
    return count;
  }

  private createSolutionGrid(): string[][] {
    // First fill in the letters from placed words
    this.fillLettersInGrid();
    
    return this.grid.map(row =>
      row.map(cell => {
        if (cell.isBlack) return '█';
        return cell.letter || ' ';
      })
    );
  }

  private fillLettersInGrid(): void {
    // Clear any existing letters first
    for (let row = 0; row < this.gridSize; row++) {
      for (let col = 0; col < this.gridSize; col++) {
        if (!this.grid[row][col].isBlack) {
          this.grid[row][col].letter = '';
        }
      }
    }
    
    // Fill letters for each placed word
    this.placedWords.forEach(placement => {
      const { word, row, col, direction } = placement;
      const deltaRow = direction === 'down' ? 1 : 0;
      const deltaCol = direction === 'across' ? 1 : 0;
      
      console.log(`ShentonAI: Filling "${word}" ${direction} at ${row},${col}`);
      
      for (let i = 0; i < word.length; i++) {
        const currentRow = row + i * deltaRow;
        const currentCol = col + i * deltaCol;
        
        if (this.isValidPosition(currentRow, currentCol) && !this.grid[currentRow][currentCol].isBlack) {
          this.grid[currentRow][currentCol].letter = word[i].toUpperCase();
        }
      }
    });
  }

  private isValidPosition(row: number, col: number): boolean {
    return row >= 0 && row < this.gridSize && col >= 0 && col < this.gridSize;
  }
}

export const shentonaiCrosswordConstructor = new ShentonAICrosswordConstructor();