import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

interface OriginalityCheck {
  isOriginal: boolean;
  originalityScore: number; // 0-100, higher is more original
  issues: string[];
  recommendations: string[];
  passesPublishing: boolean;
}

export class OriginalityValidator {
  private commonPhrases = [
    'the world of theatre',
    'breaking into the industry',
    'essential skills needed',
    'step-by-step guide',
    'career opportunities',
    'professional development',
    'industry standards',
    'networking is key',
    'building your portfolio',
    'gaining experience'
  ];

  async validateOriginalContent(title: string, content: string): Promise<OriginalityCheck> {
    console.log(`🔍 Validating originality for: ${title}`);

    // Check for common clichéd phrases
    const clicheIssues = this.detectCommonPhrases(content);
    
    // AI-powered originality assessment
    const aiAssessment = await this.performAIOriginalityCheck(content);
    
    // Calculate overall originality score
    const clichePenalty = Math.min(clicheIssues.length * 5, 30);
    const originalityScore = Math.max(0, aiAssessment.score - clichePenalty);
    
    const issues = [...clicheIssues, ...aiAssessment.issues];
    const isOriginal = originalityScore >= 70 && issues.length <= 3;
    const passesPublishing = originalityScore >= 80 && issues.length <= 1;

    return {
      isOriginal,
      originalityScore,
      issues,
      recommendations: this.generateRecommendations(issues, originalityScore),
      passesPublishing
    };
  }

  private detectCommonPhrases(content: string): string[] {
    const issues: string[] = [];
    const lowerContent = content.toLowerCase();

    for (const phrase of this.commonPhrases) {
      const count = (lowerContent.match(new RegExp(phrase.toLowerCase(), 'g')) || []).length;
      if (count > 2) {
        issues.push(`Overuse of common phrase: "${phrase}" (${count} times)`);
      }
    }

    // Check for generic career guide structure
    const genericPatterns = [
      /chapter \d+:?/gi,
      /step \d+:?/gi,
      /getting started/gi,
      /building experience/gi,
      /career progression/gi,
      /application process/gi
    ];

    let genericCount = 0;
    for (const pattern of genericPatterns) {
      const matches = content.match(pattern);
      if (matches && matches.length > 1) {
        genericCount += matches.length;
      }
    }

    if (genericCount > 8) {
      issues.push(`Generic career guide structure detected (${genericCount} common headings)`);
    }

    return issues;
  }

  private async performAIOriginalityCheck(content: string): Promise<{
    score: number;
    issues: string[];
  }> {
    try {
      const prompt = `
Assess the originality of this career guidance content on a scale of 0-100:

${content.substring(0, 2000)}...

Rate the originality based on:
1. Uniqueness of language and phrasing
2. Fresh perspectives and insights
3. Original examples and case studies
4. Innovative structure and approach
5. Absence of generic career guide clichés

Provide:
- Originality score (0-100)
- Specific issues with originality
- Assessment of plagiarism risk

Return JSON format: { "score": number, "issues": ["issue1", "issue2"] }
`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert content originality assessor. Evaluate content for uniqueness, freshness, and absence of plagiarism."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 500,
        temperature: 0.3
      });

      const result = JSON.parse(response.choices[0].message.content || '{"score": 50, "issues": []}');
      return {
        score: Math.max(0, Math.min(100, result.score)),
        issues: result.issues || []
      };
    } catch (error) {
      console.error('Error in AI originality check:', error);
      return { score: 60, issues: ['Unable to complete AI assessment'] };
    }
  }

  private generateRecommendations(issues: string[], score: number): string[] {
    const recommendations: string[] = [];

    if (score < 70) {
      recommendations.push('Content needs significant originality improvements before publication');
    }

    if (issues.some(issue => issue.includes('common phrase'))) {
      recommendations.push('Replace common career guidance phrases with unique, fresh language');
    }

    if (issues.some(issue => issue.includes('generic structure'))) {
      recommendations.push('Restructure content with innovative chapter titles and unique organization');
    }

    if (issues.some(issue => issue.includes('plagiarism'))) {
      recommendations.push('Rewrite sections flagged for potential plagiarism concerns');
    }

    if (score >= 80) {
      recommendations.push('Content meets high originality standards for professional publication');
    }

    return recommendations;
  }

  async generateOriginalAlternatives(problematicText: string): Promise<string[]> {
    try {
      const prompt = `
Rewrite this text to be completely original and unique while maintaining meaning:

"${problematicText}"

Provide 3 completely different versions that:
- Use fresh, unique language
- Avoid career guidance clichés
- Maintain professional tone
- Are completely original

Return as JSON array: ["version1", "version2", "version3"]
`;

      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are an expert copywriter creating original, unique alternatives to common text."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        response_format: { type: "json_object" },
        max_tokens: 300,
        temperature: 0.9
      });

      const result = JSON.parse(response.choices[0].message.content || '[]');
      return Array.isArray(result) ? result : result.alternatives || [];
    } catch (error) {
      console.error('Error generating alternatives:', error);
      return [];
    }
  }

  async validateCareerGuideCollection(guides: { jobId: string; guide: string }[]): Promise<{
    overallOriginality: number;
    publishReady: number;
    needsRevision: number;
    results: { jobId: string; check: OriginalityCheck }[];
  }> {
    console.log('🔍 Validating originality of entire career guide collection...');

    const results = [];
    let totalScore = 0;
    let publishReady = 0;
    let needsRevision = 0;

    for (const guide of guides) {
      const check = await this.validateOriginalContent(`Career Guide: ${guide.jobId}`, guide.guide);
      results.push({ jobId: guide.jobId, check });
      
      totalScore += check.originalityScore;
      
      if (check.passesPublishing) {
        publishReady++;
      } else {
        needsRevision++;
      }

      // Brief pause between checks
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    const overallOriginality = guides.length > 0 ? totalScore / guides.length : 0;

    console.log(`📊 Collection originality: ${overallOriginality.toFixed(1)}/100`);
    console.log(`✅ Ready to publish: ${publishReady}/${guides.length}`);
    console.log(`⚠️ Need revision: ${needsRevision}/${guides.length}`);

    return {
      overallOriginality,
      publishReady,
      needsRevision,
      results
    };
  }
}

export const originalityValidator = new OriginalityValidator();