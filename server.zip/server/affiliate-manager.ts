interface AffiliatePartner {
  name: string;
  domain: string;
  commission: string;
  type: 'tickets' | 'merchandise' | 'hotels' | 'experiences' | 'books' | 'streaming';
  regions: string[];
  signupUrl: string;
  trackingCode?: string;
  isActive: boolean;
  monthlyRevenue?: number;
}

interface AffiliateLink {
  originalUrl: string;
  affiliateUrl: string;
  partner: string;
  commission: string;
  category: string;
}

export class AffiliateManager {
  private partners: AffiliatePartner[] = [
    // TICKET VENDORS
    {
      name: "Ticketmaster",
      domain: "ticketmaster.com",
      commission: "3-8%",
      type: "tickets",
      regions: ["uk", "us", "international"],
      signupUrl: "https://affiliates.ticketmaster.com",
      trackingCode: "?tm_link=TM_AFF_THEATRE_SPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },
    {
      name: "See Tickets",
      domain: "seetickets.com",
      commission: "5-10%",
      type: "tickets",
      regions: ["uk"],
      signupUrl: "https://www.seetickets.com/affiliates",
      trackingCode: "?aff=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },
    {
      name: "ATG Tickets",
      domain: "atgtickets.com",
      commission: "4-6%",
      type: "tickets",
      regions: ["uk"],
      signupUrl: "https://www.atgtickets.com/affiliate-programme",
      trackingCode: "?affiliate=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },
    {
      name: "TodayTix",
      domain: "todaytix.com",
      commission: "6-12%",
      type: "tickets",
      regions: ["us", "uk"],
      signupUrl: "https://www.todaytix.com/insider/affiliates",
      trackingCode: "?aff_id=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },
    {
      name: "StubHub",
      domain: "stubhub.com",
      commission: "2-5%",
      type: "tickets",
      regions: ["us", "uk", "international"],
      signupUrl: "https://www.stubhub.com/affiliates",
      trackingCode: "?aff=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },

    // MERCHANDISE & BOOKS
    {
      name: "Amazon Associates",
      domain: "amazon.com",
      commission: "1-10%",
      type: "books",
      regions: ["us", "uk", "international"],
      signupUrl: "https://affiliate-program.amazon.com",
      trackingCode: "?tag=theatrespotlight-20",
      isActive: true,
      monthlyRevenue: 0
    },
    {
      name: "Theatre Books Direct",
      domain: "theatrebooksdirect.com",
      commission: "8-15%",
      type: "books",
      regions: ["uk", "international"],
      signupUrl: "https://www.theatrebooksdirect.com/affiliates",
      trackingCode: "?ref=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },
    {
      name: "Broadway Merchandise",
      domain: "broadwaymerchandise.com",
      commission: "5-12%",
      type: "merchandise",
      regions: ["us", "international"],
      signupUrl: "https://www.broadwaymerchandise.com/affiliate",
      trackingCode: "?aff=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },

    // HOTELS & EXPERIENCES
    {
      name: "Booking.com",
      domain: "booking.com",
      commission: "3-7%",
      type: "hotels",
      regions: ["uk", "us", "international"],
      signupUrl: "https://secure.booking.com/affiliate-program",
      trackingCode: "?aid=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },
    {
      name: "Expedia",
      domain: "expedia.com",
      commission: "2-8%",
      type: "hotels",
      regions: ["us", "international"],
      signupUrl: "https://www.expediapartnercentral.com/Affiliate",
      trackingCode: "?aff=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },
    {
      name: "GetYourGuide",
      domain: "getyourguide.com",
      commission: "6-10%",
      type: "experiences",
      regions: ["uk", "us", "international"],
      signupUrl: "https://affiliate.getyourguide.com",
      trackingCode: "?partner_id=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },
    {
      name: "Viator",
      domain: "viator.com",
      commission: "4-8%",
      type: "experiences",
      regions: ["us", "international"],
      signupUrl: "https://www.viator.com/partner-with-us/affiliates",
      trackingCode: "?aid=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },

    // STREAMING & DIGITAL
    {
      name: "BroadwayHD",
      domain: "broadwayhd.com",
      commission: "10-20%",
      type: "streaming",
      regions: ["us", "uk", "international"],
      signupUrl: "https://www.broadwayhd.com/affiliates",
      trackingCode: "?ref=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    },
    {
      name: "Digital Theatre+",
      domain: "digitaltheatreplus.com",
      commission: "8-15%",
      type: "streaming",
      regions: ["uk", "international"],
      signupUrl: "https://www.digitaltheatreplus.com/affiliate",
      trackingCode: "?aff=THEATRESPOTLIGHT",
      isActive: true,
      monthlyRevenue: 0
    }
  ];

  generateAffiliateLink(originalUrl: string, region: string = 'international'): AffiliateLink | null {
    try {
      const url = new URL(originalUrl);
      const domain = url.hostname.toLowerCase();
      
      // Find matching partner
      const partner = this.partners.find(p => 
        domain.includes(p.domain.replace('www.', '')) && 
        p.regions.includes(region) && 
        p.isActive
      );
      
      if (!partner || !partner.trackingCode) {
        return null;
      }
      
      // Generate affiliate URL
      const separator = originalUrl.includes('?') ? '&' : '?';
      const affiliateUrl = originalUrl + separator + partner.trackingCode.substring(1);
      
      return {
        originalUrl,
        affiliateUrl,
        partner: partner.name,
        commission: partner.commission,
        category: partner.type
      };
      
    } catch (error) {
      console.error('Error generating affiliate link:', error);
      return null;
    }
  }

  processContentForAffiliateLinks(content: string, region: string = 'international'): string {
    let processedContent = content;
    
    // Find all URLs in content
    const urlPattern = /https?:\/\/[^\s<>"]+/gi;
    const urls = content.match(urlPattern) || [];
    
    for (const originalUrl of urls) {
      const affiliateLink = this.generateAffiliateLink(originalUrl, region);
      
      if (affiliateLink) {
        // Replace URL with affiliate link and add disclosure
        const linkHtml = `<a href="${affiliateLink.affiliateUrl}" target="_blank" rel="noopener sponsored" class="affiliate-link" data-partner="${affiliateLink.partner}" data-commission="${affiliateLink.commission}">`;
        
        processedContent = processedContent.replace(
          new RegExp(originalUrl.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'),
          affiliateLink.affiliateUrl
        );
      }
    }
    
    return processedContent;
  }

  generateTicketLinks(showTitle: string, venue: string, region: string): AffiliateLink[] {
    const links: AffiliateLink[] = [];
    const searchQuery = encodeURIComponent(`${showTitle} ${venue}`);
    
    const ticketPartners = this.partners.filter(p => 
      p.type === 'tickets' && 
      p.regions.includes(region) && 
      p.isActive
    );
    
    for (const partner of ticketPartners) {
      let searchUrl = '';
      
      switch (partner.name) {
        case 'Ticketmaster':
          searchUrl = `https://www.ticketmaster.com/search?q=${searchQuery}`;
          break;
        case 'See Tickets':
          searchUrl = `https://www.seetickets.com/search?q=${searchQuery}`;
          break;
        case 'ATG Tickets':
          searchUrl = `https://www.atgtickets.com/search?q=${searchQuery}`;
          break;
        case 'TodayTix':
          searchUrl = `https://www.todaytix.com/search?q=${searchQuery}`;
          break;
        case 'StubHub':
          searchUrl = `https://www.stubhub.com/find/s/?q=${searchQuery}`;
          break;
      }
      
      if (searchUrl && partner.trackingCode) {
        const affiliateUrl = searchUrl + (searchUrl.includes('?') ? '&' : '?') + partner.trackingCode.substring(1);
        
        links.push({
          originalUrl: searchUrl,
          affiliateUrl,
          partner: partner.name,
          commission: partner.commission,
          category: 'tickets'
        });
      }
    }
    
    return links;
  }

  generateMerchandiseLinks(showTitle: string, category: 'books' | 'merchandise' = 'books'): AffiliateLink[] {
    const links: AffiliateLink[] = [];
    const searchQuery = encodeURIComponent(showTitle);
    
    const merchandisePartners = this.partners.filter(p => 
      p.type === category && 
      p.isActive
    );
    
    for (const partner of merchandisePartners) {
      let searchUrl = '';
      
      switch (partner.name) {
        case 'Amazon Associates':
          searchUrl = `https://www.amazon.com/s?k=${searchQuery}+theatre`;
          break;
        case 'Theatre Books Direct':
          searchUrl = `https://www.theatrebooksdirect.com/search?q=${searchQuery}`;
          break;
        case 'Broadway Merchandise':
          searchUrl = `https://www.broadwaymerchandise.com/search?q=${searchQuery}`;
          break;
      }
      
      if (searchUrl && partner.trackingCode) {
        const affiliateUrl = searchUrl + (searchUrl.includes('?') ? '&' : '?') + partner.trackingCode.substring(1);
        
        links.push({
          originalUrl: searchUrl,
          affiliateUrl,
          partner: partner.name,
          commission: partner.commission,
          category
        });
      }
    }
    
    return links;
  }

  generateHotelLinks(venue: string, region: string): AffiliateLink[] {
    const links: AffiliateLink[] = [];
    const location = this.getLocationFromVenue(venue, region);
    
    const hotelPartners = this.partners.filter(p => 
      p.type === 'hotels' && 
      p.regions.includes(region) && 
      p.isActive
    );
    
    for (const partner of hotelPartners) {
      let searchUrl = '';
      
      switch (partner.name) {
        case 'Booking.com':
          searchUrl = `https://www.booking.com/searchresults.html?ss=${encodeURIComponent(location)}`;
          break;
        case 'Expedia':
          searchUrl = `https://www.expedia.com/Hotel-Search?destination=${encodeURIComponent(location)}`;
          break;
      }
      
      if (searchUrl && partner.trackingCode) {
        const affiliateUrl = searchUrl + (searchUrl.includes('?') ? '&' : '?') + partner.trackingCode.substring(1);
        
        links.push({
          originalUrl: searchUrl,
          affiliateUrl,
          partner: partner.name,
          commission: partner.commission,
          category: 'hotels'
        });
      }
    }
    
    return links;
  }

  private getLocationFromVenue(venue: string, region: string): string {
    // Map venues to locations for hotel search
    if (region === 'uk') {
      if (venue.includes('West End') || venue.includes('London')) {
        return 'London West End';
      }
      return 'London, UK';
    }
    
    if (region === 'us') {
      if (venue.includes('Broadway') || venue.includes('Theater District')) {
        return 'New York Theater District';
      }
      return 'New York, NY';
    }
    
    return venue;
  }

  getAffiliateDisclosure(links: AffiliateLink[]): string {
    if (links.length === 0) {
      return '';
    }
    
    const partners = [...new Set(links.map(l => l.partner))];
    
    return `
<div class="affiliate-disclosure">
  <p class="text-sm text-gray-600 italic">
    Theatre Spotlight may earn commission from purchases made through links to ${partners.join(', ')}. 
    This helps support our independent theatre journalism at no extra cost to you.
  </p>
</div>
    `.trim();
  }

  async trackAffiliateClick(linkUrl: string, partner: string, contentId: number): Promise<void> {
    // Track affiliate clicks for revenue reporting
    console.log(`Affiliate click tracked: ${partner} - ${linkUrl} - Content: ${contentId}`);
    
    // In production, store in analytics database
    try {
      // await db.insert(affiliateClicks).values({
      //   contentId,
      //   partner,
      //   linkUrl,
      //   clickedAt: new Date()
      // });
    } catch (error) {
      console.error('Error tracking affiliate click:', error);
    }
  }

  getActivePartners(): AffiliatePartner[] {
    return this.partners.filter(p => p.isActive);
  }

  getPartnersByType(type: AffiliatePartner['type']): AffiliatePartner[] {
    return this.partners.filter(p => p.type === type && p.isActive);
  }

  getPartnersByRegion(region: string): AffiliatePartner[] {
    return this.partners.filter(p => p.regions.includes(region) && p.isActive);
  }

  async getMonthlyAffiliateReport(): Promise<{ totalRevenue: number; partnerBreakdown: { partner: string; revenue: number; clicks: number }[] }> {
    // Generate monthly affiliate revenue report
    const partnerBreakdown = this.partners.map(partner => ({
      partner: partner.name,
      revenue: partner.monthlyRevenue || 0,
      clicks: 0 // Would be calculated from analytics
    }));
    
    const totalRevenue = partnerBreakdown.reduce((sum, p) => sum + p.revenue, 0);
    
    return {
      totalRevenue,
      partnerBreakdown
    };
  }
}

export const affiliateManager = new AffiliateManager();