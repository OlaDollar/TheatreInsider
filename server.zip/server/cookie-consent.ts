interface CookieConsent {
  essential: boolean;
  analytics: boolean;
  marketing: boolean;
  preferences: boolean;
  timestamp: Date;
  locale: string;
  ipAddress?: string;
  userAgent?: string;
}

interface CookiePolicy {
  locale: string;
  title: string;
  description: string;
  categories: {
    essential: {
      name: string;
      description: string;
      required: boolean;
      impact: string;
    };
    analytics: {
      name: string;
      description: string;
      required: boolean;
      impact: string;
    };
    marketing: {
      name: string;
      description: string;
      required: boolean;
      impact: string;
    };
    preferences: {
      name: string;
      description: string;
      required: boolean;
      impact: string;
    };
  };
  legalBasis: string;
  dataRetention: string;
  thirdParties: string[];
}

export class CookieConsentManager {
  private policies: Map<string, CookiePolicy> = new Map();

  constructor() {
    this.initializePolicies();
  }

  private initializePolicies(): void {
    // UK/EU GDPR Policy
    this.policies.set('uk', {
      locale: 'uk',
      title: 'Cookie Preferences',
      description: 'We use cookies to improve your browsing experience and provide personalized content. Choose which cookies you accept.',
      categories: {
        essential: {
          name: 'Essential Cookies',
          description: 'Required for basic site functionality, login, and security.',
          required: true,
          impact: 'Without these: Site won\'t work properly, can\'t stay logged in, security may be compromised.'
        },
        analytics: {
          name: 'Analytics Cookies',
          description: 'Help us understand how visitors use our site to improve performance.',
          required: false,
          impact: 'Without these: We can\'t improve site speed or fix user experience issues.'
        },
        marketing: {
          name: 'Marketing Cookies',
          description: 'Show you relevant theatre ads and track campaign effectiveness.',
          required: false,
          impact: 'Without these: You\'ll see generic ads instead of theatre content you might enjoy.'
        },
        preferences: {
          name: 'Preference Cookies',
          description: 'Remember your settings like region (UK/US) and content preferences.',
          required: false,
          impact: 'Without these: Site resets to default settings each visit, less personalized experience.'
        }
      },
      legalBasis: 'GDPR Article 6(1)(a) - Consent',
      dataRetention: 'Cookies expire after 12 months, analytics data anonymized after 26 months',
      thirdParties: ['Google Analytics', 'Facebook Pixel', 'Theatre booking partners']
    });

    // US CCPA Policy
    this.policies.set('us', {
      locale: 'us',
      title: 'Cookie Choices',
      description: 'We use cookies to enhance your theatre browsing experience. You have choices about what data we collect.',
      categories: {
        essential: {
          name: 'Necessary Cookies',
          description: 'Required for site operation, security, and basic features.',
          required: true,
          impact: 'Without these: Site features break, can\'t maintain login, security vulnerabilities.'
        },
        analytics: {
          name: 'Performance Cookies',
          description: 'Measure site performance and user behavior to improve our service.',
          required: false,
          impact: 'Without these: Can\'t optimize site speed or identify popular content.'
        },
        marketing: {
          name: 'Advertising Cookies',
          description: 'Deliver personalized theatre ads and measure ad campaign success.',
          required: false,
          impact: 'Without these: Less relevant ads, can\'t measure what theatre content interests you.'
        },
        preferences: {
          name: 'Personalization Cookies',
          description: 'Save your regional preferences and customize your theatre news feed.',
          required: false,
          impact: 'Without these: Default settings only, no personalized theatre recommendations.'
        }
      },
      legalBasis: 'CCPA - Right to opt-out of sale of personal information',
      dataRetention: 'Cookies deleted after 12 months, opt-out honored indefinitely',
      thirdParties: ['Google Analytics', 'Social media platforms', 'Advertising networks']
    });

    // EU Policy (similar to UK but with EU-specific language)
    this.policies.set('eu', {
      locale: 'eu',
      title: 'Cookie Consent',
      description: 'This site uses cookies in accordance with EU privacy laws. Please choose your preferences.',
      categories: {
        essential: {
          name: 'Strictly Necessary',
          description: 'Essential for website security, authentication, and core functionality.',
          required: true,
          impact: 'Refusing these will prevent the website from functioning properly.'
        },
        analytics: {
          name: 'Statistical Cookies',
          description: 'Anonymous usage statistics to improve website performance.',
          required: false,
          impact: 'Refusing these means we cannot improve the site based on user behavior.'
        },
        marketing: {
          name: 'Targeting Cookies',
          description: 'Personalized advertising based on your theatre interests.',
          required: false,
          impact: 'Refusing these means less relevant advertisements and promotions.'
        },
        preferences: {
          name: 'Functional Cookies',
          description: 'Enhanced features like remembering your language and region settings.',
          required: false,
          impact: 'Refusing these means a less personalized browsing experience.'
        }
      },
      legalBasis: 'GDPR Article 6(1)(a) and ePrivacy Directive',
      dataRetention: 'Maximum 12 months, data minimization principles applied',
      thirdParties: ['EU-compliant analytics providers', 'Theatre industry partners']
    });

    // International/Default Policy
    this.policies.set('international', {
      locale: 'international',
      title: 'Cookie Settings',
      description: 'We use cookies to provide the best theatre news experience. You control what data we collect.',
      categories: {
        essential: {
          name: 'Required Cookies',
          description: 'Necessary for basic website functions and security.',
          required: true,
          impact: 'Site won\'t work without these essential functions.'
        },
        analytics: {
          name: 'Usage Analytics',
          description: 'Help us understand popular content and improve our theatre coverage.',
          required: false,
          impact: 'We can\'t optimize content without understanding what readers prefer.'
        },
        marketing: {
          name: 'Personalized Ads',
          description: 'Show theatre ads and promotions relevant to your interests.',
          required: false,
          impact: 'You\'ll see generic ads instead of theatre-specific content.'
        },
        preferences: {
          name: 'Personal Settings',
          description: 'Remember your preferences for a customized experience.',
          required: false,
          impact: 'Settings reset each visit without these preferences saved.'
        }
      },
      legalBasis: 'Consent-based cookie usage',
      dataRetention: 'Cookies expire after 12 months maximum',
      thirdParties: ['Analytics services', 'Advertising partners', 'Social platforms']
    });
  }

  getPolicy(locale: string): CookiePolicy {
    return this.policies.get(locale) || this.policies.get('international')!;
  }

  async saveConsent(consent: CookieConsent): Promise<void> {
    // Store consent in database
    console.log('Saving cookie consent:', consent);
    
    // In production, store in database with user association
    try {
      // await db.insert(cookieConsents).values({
      //   userId: consent.userId,
      //   essential: consent.essential,
      //   analytics: consent.analytics,
      //   marketing: consent.marketing,
      //   preferences: consent.preferences,
      //   locale: consent.locale,
      //   ipAddress: consent.ipAddress,
      //   userAgent: consent.userAgent,
      //   timestamp: consent.timestamp
      // });
    } catch (error) {
      console.error('Error saving cookie consent:', error);
    }
  }

  generateConsentBanner(locale: string, userAgent?: string): any {
    const policy = this.getPolicy(locale);
    
    return {
      policy,
      bannerConfig: {
        position: 'bottom',
        theme: 'theatre', // burgundy and gold theme
        showDetailsLink: true,
        showRejectAll: locale === 'uk' || locale === 'eu', // GDPR requires reject option
        allowGranular: true,
        autoShow: true,
        respectDNT: locale === 'us', // Honor Do Not Track in US
        cookieLifetime: 365, // days
        recheckPeriod: 30 // days before asking again
      },
      legalRequirements: {
        gdprApplies: locale === 'uk' || locale === 'eu',
        ccpaApplies: locale === 'us',
        requiresOptIn: locale === 'uk' || locale === 'eu',
        requiresOptOut: locale === 'us',
        showDataController: locale === 'uk' || locale === 'eu',
        showRightsInfo: true
      }
    };
  }

  // Detect user locale from IP/headers
  detectUserLocale(ipAddress?: string, acceptLanguage?: string, userAgent?: string): string {
    // In production, use IP geolocation service
    // For now, return based on Accept-Language header
    
    if (acceptLanguage) {
      if (acceptLanguage.includes('en-GB') || acceptLanguage.includes('en-UK')) {
        return 'uk';
      }
      if (acceptLanguage.includes('en-US')) {
        return 'us';
      }
      if (acceptLanguage.includes('en-')) {
        return 'international';
      }
      // Check for EU languages
      const euLanguages = ['de', 'fr', 'es', 'it', 'nl', 'pl', 'pt', 'sv', 'da', 'fi'];
      if (euLanguages.some(lang => acceptLanguage.includes(lang))) {
        return 'eu';
      }
    }
    
    return 'international';
  }

  // Generate simple consent choices for API
  getSimpleChoices(locale: string): any {
    const policy = this.getPolicy(locale);
    
    return {
      title: policy.title,
      description: policy.description,
      choices: [
        {
          id: 'accept_all',
          label: 'Accept All Cookies',
          description: 'Enable all features including personalized content and analytics',
          impact: 'Best experience: Personalized theatre news, relevant ads, performance optimization'
        },
        {
          id: 'essential_only',
          label: 'Essential Cookies Only',
          description: 'Only cookies required for basic site functionality',
          impact: 'Limited experience: Basic site only, no personalization, generic ads, no analytics'
        },
        {
          id: 'customize',
          label: 'Customize Settings',
          description: 'Choose exactly which cookies to enable',
          impact: 'You control your privacy level and site experience'
        }
      ],
      categories: policy.categories,
      legalInfo: {
        basis: policy.legalBasis,
        retention: policy.dataRetention,
        thirdParties: policy.thirdParties,
        contact: 'privacy@theatrespotlight.com',
        dpo: locale === 'uk' || locale === 'eu' ? 'dpo@theatrespotlight.com' : null
      }
    };
  }
}

export const cookieConsentManager = new CookieConsentManager();