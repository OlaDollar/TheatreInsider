import { db } from "./db";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";

interface SubscriptionTier {
  id: string;
  name: string;
  price: number;
  currency: string;
  features: string[];
  limits: {
    articlesPerMonth: number;
    videosPerMonth: number;
    downloadableContent: boolean;
    industryDatabase: boolean;
    conciergeService: boolean;
    eventAccess: boolean;
    adFree: boolean;
  };
}

interface UserSubscription {
  userId: number;
  tier: string;
  status: 'active' | 'cancelled' | 'expired' | 'trial';
  startDate: Date;
  endDate: Date;
  paymentMethod?: string;
  lastPayment?: Date;
  nextPayment?: Date;
  trialEndDate?: Date;
}

export class SubscriptionManager {
  private subscriptionTiers: SubscriptionTier[] = [
    {
      id: 'free',
      name: 'Theatre Fan',
      price: 0,
      currency: 'GBP',
      features: [
        'Access to basic articles and news',
        'Standard newsletter subscription',
        'General show information',
        'Basic theatre facts',
        'Limited search functionality'
      ],
      limits: {
        articlesPerMonth: 10,
        videosPerMonth: 0,
        downloadableContent: false,
        industryDatabase: false,
        conciergeService: false,
        eventAccess: false,
        adFree: false
      }
    },
    {
      id: 'premium',
      name: 'Theatre Insider',
      price: 9.99,
      currency: 'GBP',
      features: [
        'Unlimited article access',
        'Exclusive video interview library',
        'Behind-the-scenes footage collection',
        'Extended articles with deeper analysis',
        'Premium photo galleries from press nights',
        'Ad-free browsing experience',
        'Early access to reviews (24 hours early)',
        'Premium newsletter with insider content',
        'Advanced trip planning tools',
        'Priority booking alerts',
        'Personal theatre recommendations',
        'Member-only discussion forums'
      ],
      limits: {
        articlesPerMonth: -1, // unlimited
        videosPerMonth: -1, // unlimited
        downloadableContent: true,
        industryDatabase: false,
        conciergeService: true,
        eventAccess: true,
        adFree: true
      }
    },
    {
      id: 'industry_pro',
      name: 'Industry Professional',
      price: 29.99,
      currency: 'GBP',
      features: [
        'All Theatre Insider features',
        'Complete industry contact database',
        'Casting announcement alerts',
        'Production development pipeline access',
        'Box office performance data',
        'Industry analytics and trends reports',
        'Professional directory listing',
        'Direct contact with theatre publicists',
        'Investment opportunity alerts',
        'Exclusive industry networking events',
        'Direct messaging with Mark Shenton',
        'Custom industry reports',
        'White-label content licensing'
      ],
      limits: {
        articlesPerMonth: -1,
        videosPerMonth: -1,
        downloadableContent: true,
        industryDatabase: true,
        conciergeService: true,
        eventAccess: true,
        adFree: true
      }
    }
  ];

  private activeSubscriptions: Map<number, UserSubscription> = new Map();

  async getUserSubscription(userId: number): Promise<UserSubscription | null> {
    // Check cache first
    if (this.activeSubscriptions.has(userId)) {
      return this.activeSubscriptions.get(userId)!;
    }

    // In a real implementation, this would query a subscriptions table
    // For now, return free tier as default
    const freeSubscription: UserSubscription = {
      userId,
      tier: 'free',
      status: 'active',
      startDate: new Date(),
      endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000) // 1 year from now
    };

    this.activeSubscriptions.set(userId, freeSubscription);
    return freeSubscription;
  }

  async upgradeSubscription(userId: number, newTier: string, paymentMethod: string): Promise<{
    success: boolean;
    subscription?: UserSubscription;
    error?: string;
  }> {
    const tier = this.subscriptionTiers.find(t => t.id === newTier);
    if (!tier) {
      return { success: false, error: 'Invalid subscription tier' };
    }

    const startDate = new Date();
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + 1); // Monthly billing

    const subscription: UserSubscription = {
      userId,
      tier: newTier,
      status: 'active',
      startDate,
      endDate,
      paymentMethod,
      lastPayment: startDate,
      nextPayment: endDate
    };

    this.activeSubscriptions.set(userId, subscription);

    // In a real implementation, this would:
    // 1. Process payment through Stripe/PayPal
    // 2. Update database
    // 3. Send confirmation email
    // 4. Log the transaction

    console.log(`User ${userId} upgraded to ${tier.name} (£${tier.price}/month)`);

    return { success: true, subscription };
  }

  async startFreeTrial(userId: number, tier: string = 'premium'): Promise<{
    success: boolean;
    subscription?: UserSubscription;
    error?: string;
  }> {
    const subscriptionTier = this.subscriptionTiers.find(t => t.id === tier);
    if (!subscriptionTier || tier === 'free') {
      return { success: false, error: 'Invalid trial tier' };
    }

    const startDate = new Date();
    const trialEndDate = new Date();
    trialEndDate.setDate(trialEndDate.getDate() + 14); // 14-day trial

    const trialSubscription: UserSubscription = {
      userId,
      tier,
      status: 'trial',
      startDate,
      endDate: trialEndDate,
      trialEndDate
    };

    this.activeSubscriptions.set(userId, trialSubscription);

    console.log(`User ${userId} started ${subscriptionTier.name} free trial`);

    return { success: true, subscription: trialSubscription };
  }

  async checkAccess(userId: number, feature: string): Promise<boolean> {
    const subscription = await this.getUserSubscription(userId);
    if (!subscription) return false;

    const tier = this.subscriptionTiers.find(t => t.id === subscription.tier);
    if (!tier) return false;

    // Check if subscription is active
    if (subscription.status === 'expired' || subscription.status === 'cancelled') {
      return false;
    }

    // Check if trial has expired
    if (subscription.status === 'trial' && subscription.trialEndDate && new Date() > subscription.trialEndDate) {
      return false;
    }

    // Feature-specific access checks
    switch (feature) {
      case 'unlimited_articles':
        return tier.limits.articlesPerMonth === -1;
      case 'video_content':
        return tier.limits.videosPerMonth > 0 || tier.limits.videosPerMonth === -1;
      case 'ad_free':
        return tier.limits.adFree;
      case 'industry_database':
        return tier.limits.industryDatabase;
      case 'concierge_service':
        return tier.limits.conciergeService;
      case 'premium_events':
        return tier.limits.eventAccess;
      case 'downloadable_content':
        return tier.limits.downloadableContent;
      default:
        return true; // Default to allowing access for unknown features
    }
  }

  async getUsageStats(userId: number): Promise<{
    articlesRead: number;
    videosWatched: number;
    downloadsUsed: number;
    monthlyLimits: {
      articles: number;
      videos: number;
    };
  }> {
    const subscription = await this.getUserSubscription(userId);
    const tier = this.subscriptionTiers.find(t => t.id === subscription?.tier);

    // In a real implementation, this would query usage from database
    // For now, return mock data
    return {
      articlesRead: 5,
      videosWatched: 2,
      downloadsUsed: 1,
      monthlyLimits: {
        articles: tier?.limits.articlesPerMonth || 10,
        videos: tier?.limits.videosPerMonth || 0
      }
    };
  }

  getSubscriptionTiers(): SubscriptionTier[] {
    return this.subscriptionTiers;
  }

  getTierDetails(tierId: string): SubscriptionTier | null {
    return this.subscriptionTiers.find(t => t.id === tierId) || null;
  }

  async generateSubscriptionReport(): Promise<string> {
    const totalSubscriptions = this.activeSubscriptions.size;
    const tierCounts = {
      free: 0,
      premium: 0,
      industry_pro: 0
    };

    let monthlyRevenue = 0;

    for (const subscription of this.activeSubscriptions.values()) {
      if (subscription.status === 'active' || subscription.status === 'trial') {
        tierCounts[subscription.tier]++;
        
        const tier = this.subscriptionTiers.find(t => t.id === subscription.tier);
        if (tier && subscription.status === 'active') {
          monthlyRevenue += tier.price;
        }
      }
    }

    return `
SUBSCRIPTION REPORT
Generated: ${new Date().toISOString()}

TOTAL ACTIVE USERS: ${totalSubscriptions}

TIER BREAKDOWN:
- Theatre Fan (Free): ${tierCounts.free} users
- Theatre Insider (£9.99): ${tierCounts.premium} users  
- Industry Professional (£29.99): ${tierCounts.industry_pro} users

MONTHLY REVENUE: £${monthlyRevenue.toFixed(2)}
ANNUAL PROJECTION: £${(monthlyRevenue * 12).toFixed(2)}

CONVERSION OPPORTUNITIES:
- Free users ready for upgrade: ${Math.floor(tierCounts.free * 0.1)}
- Premium users for Pro upgrade: ${Math.floor(tierCounts.premium * 0.05)}
    `.trim();
  }

  async processPaymentWebhook(eventType: string, data: any): Promise<void> {
    // Handle Stripe/PayPal webhook events
    switch (eventType) {
      case 'payment.succeeded':
        console.log(`Payment succeeded for user ${data.userId}`);
        break;
      case 'payment.failed':
        console.log(`Payment failed for user ${data.userId}`);
        break;
      case 'subscription.cancelled':
        console.log(`Subscription cancelled for user ${data.userId}`);
        break;
    }
  }
}

export const subscriptionManager = new SubscriptionManager();