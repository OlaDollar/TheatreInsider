interface ShowPerformance {
  showTitle: string;
  venue: string;
  dates: Date[];
  ticketAvailability: {
    date: string;
    performance: 'matinee' | 'evening';
    seatsAvailable: number;
    priceRange: {
      min: number;
      max: number;
    };
    bookingUrls: {
      ticketmaster?: string;
      seeTickets?: string;
      atg?: string;
      todayTix?: string;
    };
  }[];
}

interface SeatAvailabilityData {
  available: boolean;
  totalSeats: number;
  availableSeats: number;
  priceRange: {
    min: number;
    max: number;
  };
  nextAvailableDate?: string;
  bookingUrl: string;
  affiliateCode: string;
}

export class SeatAvailabilityChecker {
  private currentProductions: ShowPerformance[] = [
    {
      showTitle: "The Lion King",
      venue: "Lyceum Theatre",
      dates: this.generateUpcomingDates(90),
      ticketAvailability: this.generateAvailabilityData("The Lion King", "Lyceum Theatre")
    },
    {
      showTitle: "Hamilton",
      venue: "Victoria Palace Theatre", 
      dates: this.generateUpcomingDates(120),
      ticketAvailability: this.generateAvailabilityData("Hamilton", "Victoria Palace Theatre")
    },
    {
      showTitle: "The Phantom of the Opera",
      venue: "His Majesty's Theatre",
      dates: this.generateUpcomingDates(60),
      ticketAvailability: this.generateAvailabilityData("The Phantom of the Opera", "His Majesty's Theatre")
    },
    {
      showTitle: "Chicago",
      venue: "Phoenix Theatre",
      dates: this.generateUpcomingDates(30),
      ticketAvailability: this.generateAvailabilityData("Chicago", "Phoenix Theatre")
    },
    {
      showTitle: "Wicked",
      venue: "Apollo Victoria Theatre",
      dates: this.generateUpcomingDates(180),
      ticketAvailability: this.generateAvailabilityData("Wicked", "Apollo Victoria Theatre")
    }
  ];

  private generateUpcomingDates(daysAhead: number): Date[] {
    const dates = [];
    const today = new Date();
    
    for (let i = 1; i <= daysAhead; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      // Skip Mondays (most West End shows are dark)
      if (date.getDay() !== 1) {
        dates.push(date);
      }
    }
    
    return dates;
  }

  private generateAvailabilityData(showTitle: string, venue: string) {
    const availability = [];
    const dates = this.generateUpcomingDates(30);
    
    for (const date of dates) {
      const dateStr = date.toISOString().split('T')[0];
      const isWeekend = date.getDay() === 0 || date.getDay() === 6;
      const baseSeats = Math.floor(Math.random() * 400) + 100;
      
      // Evening performance
      availability.push({
        date: dateStr,
        performance: 'evening' as const,
        seatsAvailable: Math.floor(baseSeats * (0.3 + Math.random() * 0.4)),
        priceRange: {
          min: isWeekend ? 45 : 35,
          max: isWeekend ? 150 : 120
        },
        bookingUrls: this.generateBookingUrls(showTitle, venue, dateStr, 'evening')
      });

      // Matinee performance (weekends and some weekdays)
      if (isWeekend || Math.random() > 0.6) {
        availability.push({
          date: dateStr,
          performance: 'matinee' as const,
          seatsAvailable: Math.floor(baseSeats * (0.4 + Math.random() * 0.3)),
          priceRange: {
            min: isWeekend ? 40 : 30,
            max: isWeekend ? 130 : 100
          },
          bookingUrls: this.generateBookingUrls(showTitle, venue, dateStr, 'matinee')
        });
      }
    }
    
    return availability;
  }

  private generateBookingUrls(showTitle: string, venue: string, date: string, performance: string) {
    const encodedShow = encodeURIComponent(showTitle);
    const encodedVenue = encodeURIComponent(venue);
    
    return {
      ticketmaster: `https://www.ticketmaster.com/event/${encodedShow}-tickets?tm_link=TM_AFF_THEATRE_SPOTLIGHT&date=${date}&perf=${performance}`,
      seeTickets: `https://www.seetickets.com/event/${encodedShow}/${encodedVenue}?aff=THEATRESPOTLIGHT&date=${date}`,
      atg: `https://www.atgtickets.com/shows/${encodedShow}?affiliate=THEATRESPOTLIGHT&venue=${encodedVenue}&date=${date}`,
      todayTix: `https://www.todaytix.com/x/london/${encodedShow}?aff_id=THEATRESPOTLIGHT&date=${date}&time=${performance}`
    };
  }

  async checkSeatAvailability(showTitle: string, venue?: string): Promise<SeatAvailabilityData | null> {
    // Find matching production
    const production = this.currentProductions.find(prod => 
      prod.showTitle.toLowerCase().includes(showTitle.toLowerCase()) ||
      showTitle.toLowerCase().includes(prod.showTitle.toLowerCase())
    );

    if (!production) {
      return null;
    }

    // Get next available performance
    const now = new Date();
    const availablePerformances = production.ticketAvailability
      .filter(perf => {
        const perfDate = new Date(perf.date);
        return perfDate > now && perf.seatsAvailable > 0;
      })
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    if (availablePerformances.length === 0) {
      return {
        available: false,
        totalSeats: 0,
        availableSeats: 0,
        priceRange: { min: 0, max: 0 },
        bookingUrl: '',
        affiliateCode: 'THEATRESPOTLIGHT'
      };
    }

    const nextPerf = availablePerformances[0];
    const totalAvailableSeats = availablePerformances.reduce((sum, perf) => sum + perf.seatsAvailable, 0);

    // Prioritize booking platforms based on availability and commission
    const bookingUrl = nextPerf.bookingUrls.todayTix || 
                      nextPerf.bookingUrls.seeTickets || 
                      nextPerf.bookingUrls.atg || 
                      nextPerf.bookingUrls.ticketmaster || '';

    return {
      available: true,
      totalSeats: availablePerformances.length * 500, // Estimated theater capacity
      availableSeats: totalAvailableSeats,
      priceRange: nextPerf.priceRange,
      nextAvailableDate: nextPerf.date,
      bookingUrl,
      affiliateCode: 'THEATRESPOTLIGHT'
    };
  }

  async getShowAvailabilityForArticle(articleTitle: string, articleContent: string): Promise<SeatAvailabilityData | null> {
    // Extract show names from article title and content
    const text = `${articleTitle} ${articleContent}`.toLowerCase();
    
    for (const production of this.currentProductions) {
      const showName = production.showTitle.toLowerCase();
      
      if (text.includes(showName) || 
          text.includes(showName.replace(/the\s+/g, '')) ||
          this.fuzzyMatch(showName, text)) {
        
        const availability = await this.checkSeatAvailability(production.showTitle, production.venue);
        
        if (availability?.available) {
          return {
            ...availability,
            showTitle: production.showTitle,
            venue: production.venue
          } as SeatAvailabilityData & { showTitle: string; venue: string };
        }
      }
    }
    
    return null;
  }

  private fuzzyMatch(showName: string, text: string): boolean {
    const showWords = showName.split(' ').filter(word => word.length > 2);
    const matchedWords = showWords.filter(word => text.includes(word));
    return matchedWords.length >= Math.ceil(showWords.length * 0.6);
  }

  async getAllCurrentProductions(): Promise<ShowPerformance[]> {
    return this.currentProductions.map(prod => ({
      ...prod,
      ticketAvailability: prod.ticketAvailability.filter(perf => {
        const perfDate = new Date(perf.date);
        return perfDate > new Date() && perf.seatsAvailable > 0;
      })
    }));
  }

  generateBookingTrackingUrl(originalUrl: string, articleId: number): string {
    const trackingParams = new URLSearchParams({
      source: 'theatre_spotlight',
      article_id: articleId.toString(),
      utm_source: 'theatrespotlight',
      utm_medium: 'article',
      utm_campaign: 'seat_booking',
      return_url: encodeURIComponent(`${process.env.SITE_URL || 'https://theatrespotlight.com'}?booking_complete=true`)
    });

    const separator = originalUrl.includes('?') ? '&' : '?';
    return `${originalUrl}${separator}${trackingParams.toString()}`;
  }
}

export const seatAvailabilityChecker = new SeatAvailabilityChecker();