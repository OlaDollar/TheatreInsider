import { 
  users, articles, reviews, shows, newsletters, performers, productions, performerRoles, performerMedia,
  type User, type InsertUser,
  type Article, type InsertArticle,
  type Review, type InsertReview,
  type Show, type InsertShow,
  type Newsletter, type InsertNewsletter,
  type Performer, type InsertPerformer,
  type Production, type InsertProduction,
  type PerformerRole, type InsertPerformerRole,
  type PerformerMedia, type InsertPerformerMedia
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, ilike, or, gte, lt, sql } from "drizzle-orm";
import { generateSlug, generateMetaDescription, extractTags } from "@shared/seo";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Articles
  getArticles(params?: { category?: string; region?: string; featured?: boolean; limit?: number }): Promise<Article[]>;
  getArticle(id: number): Promise<Article | undefined>;
  createArticle(article: InsertArticle): Promise<Article>;
  searchArticles(query: string): Promise<Article[]>;

  // Reviews
  getReviews(params?: { region?: string; limit?: number }): Promise<Review[]>;
  getReview(id: number): Promise<Review | undefined>;
  createReview(review: InsertReview): Promise<Review>;

  // Shows
  getShows(params?: { region?: string; status?: string }): Promise<Show[]>;
  getTrendingShows(limit?: number): Promise<Show[]>;
  createShow(show: InsertShow): Promise<Show>;

  // Newsletter
  subscribeNewsletter(newsletter: InsertNewsletter): Promise<Newsletter>;

  // Analytics
  incrementArticleViews(id: number): Promise<void>;
  incrementReviewViews(id: number): Promise<void>;

  // Performers
  getPerformers(params?: { nationality?: string; status?: string; featured?: boolean; limit?: number }): Promise<Performer[]>;
  getPerformer(id: number): Promise<Performer | undefined>;
  getPerformerBySlug(slug: string): Promise<Performer | undefined>;
  createPerformer(performer: InsertPerformer): Promise<Performer>;
  searchPerformers(query: string): Promise<Performer[]>;

  // Productions
  getProductions(params?: { region?: string; venue_type?: string; year?: number; limit?: number }): Promise<Production[]>;
  getProduction(id: number): Promise<Production | undefined>;
  createProduction(production: InsertProduction): Promise<Production>;
  getPerformerProductions(performerId: number): Promise<(Production & { role: string; roleType: string; isOriginalCast: boolean })[]>;

  // Performer Roles
  createPerformerRole(role: InsertPerformerRole): Promise<PerformerRole>;
  getPerformerRoles(performerId: number): Promise<PerformerRole[]>;

  // Performer Media
  getPerformerMedia(performerId: number): Promise<PerformerMedia[]>;
  createPerformerMedia(media: InsertPerformerMedia): Promise<PerformerMedia>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private articles: Map<number, Article>;
  private reviews: Map<number, Review>;
  private shows: Map<number, Show>;
  private newsletters: Map<number, Newsletter>;
  private currentUserId: number;
  private currentArticleId: number;
  private currentReviewId: number;
  private currentShowId: number;
  private currentNewsletterId: number;

  constructor() {
    this.users = new Map();
    this.articles = new Map();
    this.reviews = new Map();
    this.shows = new Map();
    this.newsletters = new Map();
    this.currentUserId = 1;
    this.currentArticleId = 1;
    this.currentReviewId = 1;
    this.currentShowId = 1;
    this.currentNewsletterId = 1;

    this.seedData();
  }

  private seedData() {
    // Seed articles
    const sampleArticles: Omit<Article, 'id'>[] = [
      {
        title: "Lion King Celebrates 25 Years in London's West End with Star-Studded Gala",
        content: "Disney's award-winning musical reaches historic milestone with special anniversary performance featuring original cast members and surprise guests. The evening was filled with memorable performances and emotional tributes to this groundbreaking production.",
        excerpt: "Disney's award-winning musical reaches historic milestone with special anniversary performance featuring original cast members and surprise guests.",
        author: "Sarah Mitchell",
        category: "news",
        region: "uk",
        imageUrl: "https://images.unsplash.com/photo-1507924538820-ede94a04019d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&h=600",
        isFeatured: true,
        isPremium: false,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000) // 2 hours ago
      },
      {
        title: "Chicago Announces Extended Run Through 2025",
        content: "The longest-running American musical on Broadway continues its record-breaking success with confirmed performances well into next year. This extension reflects the show's enduring popularity and critical acclaim.",
        excerpt: "The longest-running American musical on Broadway continues its record-breaking success with confirmed performances well into next year...",
        author: "Mark Harrison",
        category: "news",
        region: "us",
        imageUrl: "https://images.unsplash.com/photo-1574267432553-4b4628081c31?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
        isFeatured: false,
        isPremium: false,
        createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000) // 4 hours ago
      },
      {
        title: "Hamilton Returns to West End After Sold-Out Run",
        content: "Lin-Manuel Miranda's revolutionary musical is set for a triumphant return to London's Victoria Palace Theatre following unprecedented demand. The production will feature both returning and new cast members.",
        excerpt: "Lin-Manuel Miranda's revolutionary musical is set for a triumphant return to London's Victoria Palace Theatre following unprecedented demand...",
        author: "Emma Thompson",
        category: "news",
        region: "uk",
        imageUrl: "https://images.unsplash.com/photo-1514306191717-452ec28c7814?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=300",
        isFeatured: false,
        isPremium: false,
        createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000) // 6 hours ago
      }
    ];

    sampleArticles.forEach(article => {
      const id = this.currentArticleId++;
      this.articles.set(id, { ...article, id });
    });

    // Seed reviews
    const sampleReviews: Omit<Review, 'id'>[] = [
      {
        showTitle: "The Phantom of the Opera",
        venue: "Her Majesty's Theatre",
        rating: 5,
        reviewText: "Andrew Lloyd Webber's iconic musical bids an emotional goodbye to Broadway after 35 extraordinary years. This final production showcases why it became the longest-running show in Broadway history with stunning performances and incredible staging.",
        excerpt: "Andrew Lloyd Webber's iconic musical bids an emotional goodbye to Broadway after 35 extraordinary years. This final production showcases why it became the longest-running show in Broadway history...",
        reviewer: "James Mitchell",
        imageUrl: "https://pixabay.com/get/ga67c50a9c43f72ee108cd2cc87248ba1c6144c0637be9bc005da87a697961edc428a2921623f66fd283b63dadf69f86329e50ced472f5ef65359ade589867163_1280.jpg",
        region: "us",
        createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000) // 1 day ago
      },
      {
        showTitle: "Six The Musical",
        venue: "Arts Theatre",
        rating: 4,
        reviewText: "This innovative retelling of Henry VIII's six wives as pop stars delivers incredible vocals and fresh historical perspective, though some moments feel rushed in the 80-minute runtime. The costumes and choreography are exceptional.",
        excerpt: "This innovative retelling of Henry VIII's six wives as pop stars delivers incredible vocals and fresh historical perspective, though some moments feel rushed in the 80-minute runtime...",
        reviewer: "Rachel Green",
        imageUrl: "https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=150",
        region: "uk",
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000) // 2 days ago
      }
    ];

    sampleReviews.forEach(review => {
      const id = this.currentReviewId++;
      this.reviews.set(id, { ...review, id });
    });

    // Seed shows
    const sampleShows: Omit<Show, 'id'>[] = [
      { title: "The Lion King", venue: "Lyceum Theatre", region: "uk", status: "running", popularity: 100 },
      { title: "Hamilton", venue: "Richard Rodgers Theatre", region: "us", status: "running", popularity: 95 },
      { title: "The Phantom of the Opera", venue: "Majestic Theatre", region: "us", status: "closed", popularity: 90 },
      { title: "Wicked", venue: "Apollo Victoria Theatre", region: "uk", status: "running", popularity: 85 }
    ];

    sampleShows.forEach(show => {
      const id = this.currentShowId++;
      this.shows.set(id, { ...show, id });
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Article methods
  async getArticles(params?: { category?: string; region?: string; featured?: boolean; limit?: number }): Promise<Article[]> {
    let articles = Array.from(this.articles.values());
    
    if (params?.category) {
      articles = articles.filter(article => article.category === params.category);
    }
    
    if (params?.region && params.region !== 'both') {
      articles = articles.filter(article => article.region === params.region || article.region === 'both');
    }
    
    if (params?.featured !== undefined) {
      articles = articles.filter(article => article.isFeatured === params.featured);
    }
    
    articles.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    if (params?.limit) {
      articles = articles.slice(0, params.limit);
    }
    
    return articles;
  }

  async getArticle(id: number): Promise<Article | undefined> {
    return this.articles.get(id);
  }

  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const id = this.currentArticleId++;
    const article: Article = { 
      ...insertArticle, 
      id, 
      createdAt: new Date()
    };
    this.articles.set(id, article);
    return article;
  }

  async searchArticles(query: string): Promise<Article[]> {
    const articles = Array.from(this.articles.values());
    const lowercaseQuery = query.toLowerCase();
    
    return articles.filter(article => 
      article.title.toLowerCase().includes(lowercaseQuery) ||
      article.content.toLowerCase().includes(lowercaseQuery) ||
      article.author.toLowerCase().includes(lowercaseQuery)
    );
  }

  // Review methods
  async getReviews(params?: { region?: string; limit?: number }): Promise<Review[]> {
    let reviews = Array.from(this.reviews.values());
    
    if (params?.region && params.region !== 'both') {
      reviews = reviews.filter(review => review.region === params.region);
    }
    
    reviews.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    if (params?.limit) {
      reviews = reviews.slice(0, params.limit);
    }
    
    return reviews;
  }

  async getReview(id: number): Promise<Review | undefined> {
    return this.reviews.get(id);
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.currentReviewId++;
    const review: Review = { 
      ...insertReview, 
      id, 
      createdAt: new Date()
    };
    this.reviews.set(id, review);
    return review;
  }

  // Show methods
  async getShows(params?: { region?: string; status?: string }): Promise<Show[]> {
    let shows = Array.from(this.shows.values());
    
    if (params?.region && params.region !== 'both') {
      shows = shows.filter(show => show.region === params.region);
    }
    
    if (params?.status) {
      shows = shows.filter(show => show.status === params.status);
    }
    
    return shows;
  }

  async getTrendingShows(limit: number = 10): Promise<Show[]> {
    const shows = Array.from(this.shows.values());
    shows.sort((a, b) => (b.popularity || 0) - (a.popularity || 0));
    return shows.slice(0, limit);
  }

  async createShow(insertShow: InsertShow): Promise<Show> {
    const id = this.currentShowId++;
    const show: Show = { ...insertShow, id };
    this.shows.set(id, show);
    return show;
  }

  // Newsletter methods
  async subscribeNewsletter(insertNewsletter: InsertNewsletter): Promise<Newsletter> {
    const id = this.currentNewsletterId++;
    const newsletter: Newsletter = { 
      ...insertNewsletter, 
      id, 
      subscribedAt: new Date()
    };
    this.newsletters.set(id, newsletter);
    return newsletter;
  }

  // Analytics methods (no-op for memory storage)
  async incrementArticleViews(id: number): Promise<void> {
    const article = this.articles.get(id);
    if (article) {
      article.viewCount = (article.viewCount || 0) + 1;
    }
  }

  async incrementReviewViews(id: number): Promise<void> {
    const review = this.reviews.get(id);
    if (review) {
      review.viewCount = (review.viewCount || 0) + 1;
    }
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Article methods
  async getArticles(params?: { category?: string; region?: string; featured?: boolean; limit?: number }): Promise<Article[]> {
    let query = db.select().from(articles);
    
    const conditions = [];
    
    if (params?.category) {
      conditions.push(eq(articles.category, params.category));
    }
    
    if (params?.region && params.region !== 'both') {
      conditions.push(or(eq(articles.region, params.region), eq(articles.region, 'both')));
    }
    
    if (params?.featured !== undefined) {
      conditions.push(eq(articles.isFeatured, params.featured));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    query = query.orderBy(desc(articles.createdAt));
    
    if (params?.limit) {
      query = query.limit(params.limit);
    }
    
    return await query;
  }

  async getArticle(id: number): Promise<Article | undefined> {
    const [article] = await db.select().from(articles).where(eq(articles.id, id));
    return article || undefined;
  }

  async createArticle(insertArticle: InsertArticle): Promise<Article> {
    const slug = generateSlug(insertArticle.title);
    const metaDescription = generateMetaDescription(insertArticle.content);
    const tags = extractTags(insertArticle.content, insertArticle.title);
    
    const [article] = await db
      .insert(articles)
      .values({
        ...insertArticle,
        slug,
        metaDescription,
        tags
      })
      .returning();
    return article;
  }

  async searchArticles(query: string): Promise<Article[]> {
    return await db.select().from(articles).where(
      or(
        ilike(articles.title, `%${query}%`),
        ilike(articles.content, `%${query}%`),
        ilike(articles.author, `%${query}%`)
      )
    ).orderBy(desc(articles.createdAt));
  }

  // Review methods
  async getReviews(params?: { region?: string; limit?: number }): Promise<Review[]> {
    let query = db.select().from(reviews);
    
    if (params?.region && params.region !== 'both') {
      query = query.where(eq(reviews.region, params.region));
    }
    
    query = query.orderBy(desc(reviews.createdAt));
    
    if (params?.limit) {
      query = query.limit(params.limit);
    }
    
    return await query;
  }

  async getReview(id: number): Promise<Review | undefined> {
    const [review] = await db.select().from(reviews).where(eq(reviews.id, id));
    return review || undefined;
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const slug = generateSlug(`${insertReview.showTitle} ${insertReview.venue} review`);
    const metaDescription = generateMetaDescription(insertReview.reviewText);
    const tags = extractTags(insertReview.reviewText, insertReview.showTitle);
    
    const [review] = await db
      .insert(reviews)
      .values({
        ...insertReview,
        slug,
        metaDescription,
        tags
      })
      .returning();
    return review;
  }

  // Show methods
  async getShows(params?: { region?: string; status?: string }): Promise<Show[]> {
    let query = db.select().from(shows);
    
    const conditions = [];
    
    if (params?.region && params.region !== 'both') {
      conditions.push(eq(shows.region, params.region));
    }
    
    if (params?.status) {
      conditions.push(eq(shows.status, params.status));
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return await query;
  }

  async getTrendingShows(limit: number = 10): Promise<Show[]> {
    return await db.select().from(shows)
      .orderBy(desc(shows.popularity))
      .limit(limit);
  }

  async createShow(insertShow: InsertShow): Promise<Show> {
    const [show] = await db
      .insert(shows)
      .values(insertShow)
      .returning();
    return show;
  }

  // Newsletter methods
  async subscribeNewsletter(insertNewsletter: InsertNewsletter): Promise<Newsletter> {
    const [newsletter] = await db
      .insert(newsletters)
      .values(insertNewsletter)
      .returning();
    return newsletter;
  }

  // Analytics methods
  async incrementArticleViews(id: number): Promise<void> {
    await db.update(articles)
      .set({ viewCount: articles.viewCount + 1 })
      .where(eq(articles.id, id));
  }

  async incrementReviewViews(id: number): Promise<void> {
    await db.update(reviews)
      .set({ viewCount: reviews.viewCount + 1 })
      .where(eq(reviews.id, id));
  }

  // Performers
  async getPerformers(params?: { nationality?: string; status?: string; featured?: boolean; limit?: number }): Promise<Performer[]> {
    let query = db.select().from(performers);
    
    const conditions = [];
    if (params?.nationality) conditions.push(eq(performers.nationality, params.nationality));
    if (params?.status) conditions.push(eq(performers.status, params.status));
    if (params?.featured) conditions.push(eq(performers.isFeatured, params.featured));
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return query.orderBy(performers.name).limit(params?.limit || 50);
  }

  async getPerformer(id: number): Promise<Performer | undefined> {
    const [performer] = await db.select().from(performers).where(eq(performers.id, id));
    return performer || undefined;
  }

  async getPerformerBySlug(slug: string): Promise<Performer | undefined> {
    const [performer] = await db.select().from(performers).where(eq(performers.slug, slug));
    return performer || undefined;
  }

  async createPerformer(insertPerformer: InsertPerformer): Promise<Performer> {
    const [performer] = await db.insert(performers).values(insertPerformer).returning();
    return performer;
  }

  async searchPerformers(query: string): Promise<Performer[]> {
    return db.select().from(performers)
      .where(or(
        ilike(performers.name, `%${query}%`),
        ilike(performers.biography, `%${query}%`),
        ilike(performers.notableFor, `%${query}%`)
      ))
      .orderBy(performers.name)
      .limit(20);
  }

  // Productions
  async getProductions(params?: { region?: string; venue_type?: string; year?: number; limit?: number }): Promise<Production[]> {
    let query = db.select().from(productions);
    
    const conditions = [];
    if (params?.region) conditions.push(eq(productions.region, params.region));
    if (params?.venue_type) conditions.push(eq(productions.venue_type, params.venue_type));
    if (params?.year) {
      conditions.push(
        or(
          and(
            gte(productions.openingDate, `${params.year}-01-01`),
            lt(productions.openingDate, `${params.year + 1}-01-01`)
          ),
          productions.isCurrentlyRunning
        )
      );
    }
    
    if (conditions.length > 0) {
      query = query.where(and(...conditions));
    }
    
    return query.orderBy(desc(productions.openingDate)).limit(params?.limit || 50);
  }

  async getProduction(id: number): Promise<Production | undefined> {
    const [production] = await db.select().from(productions).where(eq(productions.id, id));
    return production || undefined;
  }

  async createProduction(insertProduction: InsertProduction): Promise<Production> {
    const [production] = await db.insert(productions).values(insertProduction).returning();
    return production;
  }

  async getPerformerProductions(performerId: number): Promise<(Production & { role: string; roleType: string; isOriginalCast: boolean })[]> {
    return db.select({
      id: productions.id,
      showId: productions.showId,
      title: productions.title,
      venue: productions.venue,
      region: productions.region,
      venue_type: productions.venue_type,
      openingDate: productions.openingDate,
      closingDate: productions.closingDate,
      isCurrentlyRunning: productions.isCurrentlyRunning,
      director: productions.director,
      musicalDirector: productions.musicalDirector,
      choreographer: productions.choreographer,
      description: productions.description,
      slug: productions.slug,
      createdAt: productions.createdAt,
      updatedAt: productions.updatedAt,
      role: performerRoles.role,
      roleType: performerRoles.roleType,
      isOriginalCast: performerRoles.isOriginalCast
    })
    .from(productions)
    .innerJoin(performerRoles, eq(performerRoles.productionId, productions.id))
    .where(eq(performerRoles.performerId, performerId))
    .orderBy(desc(productions.openingDate));
  }

  // Performer Roles
  async createPerformerRole(insertRole: InsertPerformerRole): Promise<PerformerRole> {
    const [role] = await db.insert(performerRoles).values(insertRole).returning();
    return role;
  }

  async getPerformerRoles(performerId: number): Promise<PerformerRole[]> {
    return db.select().from(performerRoles).where(eq(performerRoles.performerId, performerId));
  }

  // Performer Media
  async getPerformerMedia(performerId: number): Promise<PerformerMedia[]> {
    return db.select().from(performerMedia)
      .where(eq(performerMedia.performerId, performerId))
      .orderBy(desc(performerMedia.releaseDate));
  }

  async createPerformerMedia(insertMedia: InsertPerformerMedia): Promise<PerformerMedia> {
    const [media] = await db.insert(performerMedia).values(insertMedia).returning();
    return media;
  }
}

export const storage = new DatabaseStorage();
