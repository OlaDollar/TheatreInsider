import { db } from "./db";
import { articles, reviews, shows, performers, users, newsletter } from "@shared/schema";

interface ColumnConstraint {
  table: string;
  column: string;
  type: string;
  nullable: boolean;
  defaultValue?: any;
  uniqueConstraint?: boolean;
  foreignKey?: boolean;
}

interface ValidationResult {
  valid: boolean;
  errors: {
    table: string;
    column: string;
    issue: string;
    suggestedFix: string;
    autoFixAvailable: boolean;
  }[];
  fixes: {
    table: string;
    column: string;
    fixType: 'default' | 'conditional' | 'manual';
    defaultValue?: any;
    condition?: string;
  }[];
}

export class DatabaseValidator {
  private tableConstraints: ColumnConstraint[] = [
    // Articles table constraints (auto-generated IDs should not be validated)
    // { table: 'articles', column: 'id', type: 'serial', nullable: false, uniqueConstraint: true },
    { table: 'articles', column: 'title', type: 'text', nullable: false },
    { table: 'articles', column: 'content', type: 'text', nullable: false },
    { table: 'articles', column: 'excerpt', type: 'text', nullable: false },
    { table: 'articles', column: 'author', type: 'text', nullable: false, defaultValue: 'Mark Shenton' },
    { table: 'articles', column: 'category', type: 'text', nullable: false, defaultValue: 'news' },
    { table: 'articles', column: 'region', type: 'text', nullable: false, defaultValue: 'both' },
    { table: 'articles', column: 'imageUrl', type: 'text', nullable: true },
    { table: 'articles', column: 'slug', type: 'text', nullable: false, uniqueConstraint: true },
    { table: 'articles', column: 'publishedAt', type: 'timestamp', nullable: false, defaultValue: 'NOW()' },
    { table: 'articles', column: 'createdAt', type: 'timestamp', nullable: false, defaultValue: 'NOW()' },
    { table: 'articles', column: 'updatedAt', type: 'timestamp', nullable: false, defaultValue: 'NOW()' },

    // Reviews table constraints (auto-generated IDs should not be validated)
    // { table: 'reviews', column: 'id', type: 'serial', nullable: false, uniqueConstraint: true },
    { table: 'reviews', column: 'showTitle', type: 'text', nullable: false },
    { table: 'reviews', column: 'content', type: 'text', nullable: false },
    { table: 'reviews', column: 'rating', type: 'integer', nullable: false },
    { table: 'reviews', column: 'author', type: 'text', nullable: false, defaultValue: 'Mark Shenton' },
    { table: 'reviews', column: 'venue', type: 'text', nullable: false },
    { table: 'reviews', column: 'region', type: 'text', nullable: false, defaultValue: 'both' },
    { table: 'reviews', column: 'publishedAt', type: 'timestamp', nullable: false, defaultValue: 'NOW()' },

    // Shows table constraints (auto-generated IDs should not be validated)
    // { table: 'shows', column: 'id', type: 'serial', nullable: false, uniqueConstraint: true },
    { table: 'shows', column: 'title', type: 'text', nullable: false },
    { table: 'shows', column: 'venue', type: 'text', nullable: false },
    { table: 'shows', column: 'region', type: 'text', nullable: false, defaultValue: 'both' },
    { table: 'shows', column: 'status', type: 'text', nullable: false, defaultValue: 'upcoming' },

    // Performers table constraints (auto-generated IDs should not be validated)
    // { table: 'performers', column: 'id', type: 'serial', nullable: false, uniqueConstraint: true },
    { table: 'performers', column: 'name', type: 'text', nullable: false },
    { table: 'performers', column: 'slug', type: 'text', nullable: false, uniqueConstraint: true },
    { table: 'performers', column: 'bio', type: 'text', nullable: true },

    // Users table constraints (auto-generated IDs should not be validated)
    // { table: 'users', column: 'id', type: 'serial', nullable: false, uniqueConstraint: true },
    { table: 'users', column: 'username', type: 'text', nullable: false, uniqueConstraint: true },
    { table: 'users', column: 'email', type: 'text', nullable: false, uniqueConstraint: true },

    // Newsletter table constraints (auto-generated IDs should not be validated)
    // { table: 'newsletter', column: 'id', type: 'serial', nullable: false, uniqueConstraint: true },
    { table: 'newsletter', column: 'email', type: 'text', nullable: false, uniqueConstraint: true },
    { table: 'newsletter', column: 'subscribedAt', type: 'timestamp', nullable: false, defaultValue: 'NOW()' }
  ];

  async validateAllTables(): Promise<ValidationResult> {
    const errors: ValidationResult['errors'] = [];
    const fixes: ValidationResult['fixes'] = [];

    console.log('🔍 Starting comprehensive database validation...');

    // Check each table for null constraint violations
    for (const constraint of this.tableConstraints) {
      if (!constraint.nullable) {
        try {
          const nullCheck = await this.checkNullValues(constraint.table, constraint.column);
          
          if (nullCheck.hasNulls) {
            errors.push({
              table: constraint.table,
              column: constraint.column,
              issue: `Found ${nullCheck.count} null values in non-nullable column`,
              suggestedFix: constraint.defaultValue ? 
                `Set default value: ${constraint.defaultValue}` : 
                'Manual value assignment required',
              autoFixAvailable: !!constraint.defaultValue
            });

            if (constraint.defaultValue) {
              fixes.push({
                table: constraint.table,
                column: constraint.column,
                fixType: 'default',
                defaultValue: constraint.defaultValue
              });
            } else {
              fixes.push({
                table: constraint.table,
                column: constraint.column,
                fixType: 'manual'
              });
            }
          }
        } catch (error) {
          console.warn(`Could not check ${constraint.table}.${constraint.column}:`, error.message);
        }
      }

      // Check unique constraints
      if (constraint.uniqueConstraint) {
        try {
          const duplicateCheck = await this.checkDuplicateValues(constraint.table, constraint.column);
          
          if (duplicateCheck.hasDuplicates) {
            errors.push({
              table: constraint.table,
              column: constraint.column,
              issue: `Found ${duplicateCheck.count} duplicate values in unique column`,
              suggestedFix: 'Add suffix to duplicate values or manual resolution required',
              autoFixAvailable: true
            });

            fixes.push({
              table: constraint.table,
              column: constraint.column,
              fixType: 'conditional',
              condition: 'Add incremental suffix to duplicates'
            });
          }
        } catch (error) {
          console.warn(`Could not check duplicates for ${constraint.table}.${constraint.column}:`, error.message);
        }
      }
    }

    return {
      valid: errors.length === 0,
      errors,
      fixes
    };
  }

  private async checkNullValues(table: string, column: string): Promise<{ hasNulls: boolean; count: number }> {
    try {
      const result = await db.execute(`
        SELECT COUNT(*) as null_count 
        FROM ${table} 
        WHERE ${column} IS NULL
      `);
      
      const nullCount = parseInt(result.rows[0]?.null_count || '0');
      
      return {
        hasNulls: nullCount > 0,
        count: nullCount
      };
    } catch (error) {
      console.error(`Error checking null values for ${table}.${column}:`, error);
      return { hasNulls: false, count: 0 };
    }
  }

  private async checkDuplicateValues(table: string, column: string): Promise<{ hasDuplicates: boolean; count: number }> {
    try {
      const result = await db.execute(`
        SELECT COUNT(*) as duplicate_count
        FROM (
          SELECT ${column}, COUNT(*) as cnt
          FROM ${table}
          WHERE ${column} IS NOT NULL
          GROUP BY ${column}
          HAVING COUNT(*) > 1
        ) duplicates
      `);
      
      const duplicateCount = parseInt(result.rows[0]?.duplicate_count || '0');
      
      return {
        hasDuplicates: duplicateCount > 0,
        count: duplicateCount
      };
    } catch (error) {
      console.error(`Error checking duplicates for ${table}.${column}:`, error);
      return { hasDuplicates: false, count: 0 };
    }
  }

  async applyAutomaticFixes(fixes: ValidationResult['fixes']): Promise<{ success: boolean; applied: number; failed: number }> {
    let applied = 0;
    let failed = 0;

    console.log('🔧 Applying automatic database fixes...');

    for (const fix of fixes) {
      try {
        if (fix.fixType === 'default' && fix.defaultValue) {
          await this.applyDefaultValueFix(fix.table, fix.column, fix.defaultValue);
          applied++;
          console.log(`✅ Fixed ${fix.table}.${fix.column} with default value: ${fix.defaultValue}`);
        } else if (fix.fixType === 'conditional') {
          await this.applyConditionalFix(fix.table, fix.column);
          applied++;
          console.log(`✅ Fixed ${fix.table}.${fix.column} with conditional logic`);
        }
      } catch (error) {
        failed++;
        console.error(`❌ Failed to fix ${fix.table}.${fix.column}:`, error.message);
      }
    }

    return { success: failed === 0, applied, failed };
  }

  private async applyDefaultValueFix(table: string, column: string, defaultValue: any): Promise<void> {
    let sqlValue = defaultValue;
    
    // Handle special default values
    if (defaultValue === 'NOW()') {
      sqlValue = 'CURRENT_TIMESTAMP';
    } else if (typeof defaultValue === 'string') {
      sqlValue = `'${defaultValue.replace(/'/g, "''")}'`;
    }

    await db.execute(`
      UPDATE ${table} 
      SET ${column} = ${sqlValue} 
      WHERE ${column} IS NULL
    `);
  }

  private async applyConditionalFix(table: string, column: string): Promise<void> {
    if (column === 'slug') {
      // Fix duplicate slugs by adding incremental suffix
      await db.execute(`
        UPDATE ${table} 
        SET ${column} = ${column} || '-' || ROW_NUMBER() OVER (PARTITION BY ${column} ORDER BY id)
        WHERE id IN (
          SELECT id FROM (
            SELECT id, ROW_NUMBER() OVER (PARTITION BY ${column} ORDER BY id) as rn
            FROM ${table}
            WHERE ${column} IS NOT NULL
          ) ranked
          WHERE rn > 1
        )
      `);
    }
  }

  async validateDataBeforeInsertion(table: string, data: Record<string, any>): Promise<{
    valid: boolean;
    errors: string[];
    correctedData: Record<string, any>;
  }> {
    const errors: string[] = [];
    const correctedData = { ...data };
    
    const tableConstraints = this.tableConstraints.filter(c => c.table === table);
    
    for (const constraint of tableConstraints) {
      const value = data[constraint.column];
      
      // Skip validation for auto-generated ID columns
      if (constraint.column === 'id' && constraint.type === 'serial') {
        continue;
      }
      
      // Check null constraints
      if (!constraint.nullable && (value === null || value === undefined)) {
        if (constraint.defaultValue) {
          if (constraint.defaultValue === 'NOW()') {
            correctedData[constraint.column] = new Date();
          } else {
            correctedData[constraint.column] = constraint.defaultValue;
          }
          console.log(`Auto-corrected ${constraint.column} with default: ${constraint.defaultValue}`);
        } else {
          errors.push(`${constraint.column} cannot be null and no default value available`);
        }
      }
      
      // Type validation
      if (value !== null && value !== undefined) {
        if (constraint.type === 'integer' && typeof value !== 'number') {
          const parsed = parseInt(value);
          if (isNaN(parsed)) {
            errors.push(`${constraint.column} must be a valid integer`);
          } else {
            correctedData[constraint.column] = parsed;
          }
        }
      }
    }
    
    return {
      valid: errors.length === 0,
      errors,
      correctedData
    };
  }

  async generateDatabaseHealthReport(): Promise<string> {
    const validation = await this.validateAllTables();
    
    const report = `
DATABASE HEALTH REPORT
Generated: ${new Date().toISOString()}

OVERALL STATUS: ${validation.valid ? 'HEALTHY' : 'ISSUES DETECTED'}

CONSTRAINT VIOLATIONS FOUND: ${validation.errors.length}

${validation.errors.map((error, index) => `
${index + 1}. ${error.table}.${error.column}
   Issue: ${error.issue}
   Fix: ${error.suggestedFix}
   Auto-fixable: ${error.autoFixAvailable ? 'Yes' : 'No'}
`).join('')}

AUTOMATIC FIXES AVAILABLE: ${validation.fixes.filter(f => f.fixType !== 'manual').length}
MANUAL FIXES REQUIRED: ${validation.fixes.filter(f => f.fixType === 'manual').length}

RECOMMENDATIONS:
${validation.errors.length === 0 ? 
  '✅ Database is healthy - no constraint violations detected' :
  `⚠️  Apply ${validation.fixes.length} fixes to resolve constraint violations`
}
${validation.fixes.length > 0 ? 
  '🔧 Run applyAutomaticFixes() to resolve auto-fixable issues' : 
  ''
}
    `.trim();

    return report;
  }

  async runDailyHealthCheck(): Promise<void> {
    console.log('🏥 Running daily database health check...');
    
    const validation = await this.validateAllTables();
    
    if (!validation.valid) {
      console.warn(`⚠️  Database health issues detected: ${validation.errors.length} problems found`);
      
      // Apply automatic fixes
      const autoFixes = validation.fixes.filter(f => f.fixType !== 'manual');
      if (autoFixes.length > 0) {
        const fixResult = await this.applyAutomaticFixes(autoFixes);
        console.log(`🔧 Applied ${fixResult.applied} automatic fixes, ${fixResult.failed} failed`);
      }
      
      // Log manual fixes needed
      const manualFixes = validation.fixes.filter(f => f.fixType === 'manual');
      if (manualFixes.length > 0) {
        console.warn(`👤 ${manualFixes.length} manual fixes required:`);
        manualFixes.forEach(fix => {
          console.warn(`   - ${fix.table}.${fix.column}: Manual value assignment needed`);
        });
      }
    } else {
      console.log('✅ Database health check passed - no issues detected');
    }
  }
}

export const databaseValidator = new DatabaseValidator();