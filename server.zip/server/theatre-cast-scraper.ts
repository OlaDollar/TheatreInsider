import { db } from "./db";
import { shows, castMembers, venues } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import * as cheerio from 'cheerio';

interface CastMember {
  character: string;
  actor: string;
  isAlternate?: boolean;
  startDate?: Date;
  endDate?: Date;
}

interface ShowCastData {
  showTitle: string;
  venue: string;
  cast: CastMember[];
  lastUpdated: Date;
}

export class TheatreCastScraper {
  private readonly userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36';

  async scrapeAllShows(): Promise<void> {
    console.log('Starting comprehensive theatre cast scraping...');
    
    const scrapers = [
      this.scrapeOliverCast(),
      this.scrapeWickedCast(),
      this.scrapePhantomCast(),
      this.scrapeLionKingCast(),
      this.scrapeHamiltonCast(),
      this.scrapeMatildaCast(),
      this.scrapeSixCast(),
      this.scrapeMammaMiaCast(),
      this.scrapeBookOfMormonCast(),
      this.scrapeMousetrapCast()
    ];

    const results = await Promise.allSettled(scrapers);
    
    let successful = 0;
    let failed = 0;
    
    results.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        successful++;
      } else {
        failed++;
        console.error(`Scraper ${index + 1} failed:`, result.reason);
      }
    });

    console.log(`Cast scraping complete: ${successful} successful, ${failed} failed`);
  }

  private async fetchWithRetry(url: string, retries = 3): Promise<string> {
    for (let i = 0; i < retries; i++) {
      try {
        const response = await fetch(url, {
          headers: {
            'User-Agent': this.userAgent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
          }
        });

        if (!response.ok) {
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }

        return await response.text();
      } catch (error) {
        console.error(`Attempt ${i + 1} failed for ${url}:`, error);
        if (i === retries - 1) throw error;
        await this.delay(2000 * (i + 1)); // Exponential backoff
      }
    }
    throw new Error('All retry attempts failed');
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Oliver! Cast Scraper
  private async scrapeOliverCast(): Promise<ShowCastData> {
    try {
      const html = await this.fetchWithRetry('https://oliverthemusical.com/cast-creative/');
      const $ = cheerio.load(html);
      
      const cast: CastMember[] = [];
      
      // Scrape main cast members
      $('.cast-member').each((_, element) => {
        const character = $(element).find('.character-name').text().trim();
        const actor = $(element).find('.actor-name').text().trim();
        
        if (character && actor) {
          cast.push({
            character,
            actor,
            isAlternate: $(element).hasClass('alternate')
          });
        }
      });

      const showData: ShowCastData = {
        showTitle: 'Oliver!',
        venue: 'Gielgud Theatre',
        cast,
        lastUpdated: new Date()
      };

      await this.updateCastInDatabase(showData);
      return showData;
    } catch (error) {
      console.error('Error scraping Oliver cast:', error);
      throw error;
    }
  }

  // Wicked Cast Scraper
  private async scrapeWickedCast(): Promise<ShowCastData> {
    try {
      const html = await this.fetchWithRetry('https://www.wickedthemusical.co.uk/cast-creative/');
      const $ = cheerio.load(html);
      
      const cast: CastMember[] = [];
      
      $('.cast-grid .cast-member').each((_, element) => {
        const character = $(element).find('.character').text().trim();
        const actor = $(element).find('.actor').text().trim();
        
        if (character && actor) {
          cast.push({
            character,
            actor
          });
        }
      });

      const showData: ShowCastData = {
        showTitle: 'Wicked',
        venue: 'Apollo Victoria Theatre',
        cast,
        lastUpdated: new Date()
      };

      await this.updateCastInDatabase(showData);
      return showData;
    } catch (error) {
      console.error('Error scraping Wicked cast:', error);
      throw error;
    }
  }

  // Phantom Cast Scraper
  private async scrapePhantomCast(): Promise<ShowCastData> {
    try {
      const html = await this.fetchWithRetry('https://uk.thephantomoftheopera.com/');
      const $ = cheerio.load(html);
      
      const cast: CastMember[] = [];
      
      $('.cast-section .cast-member').each((_, element) => {
        const character = $(element).find('.role').text().trim();
        const actor = $(element).find('.name').text().trim();
        
        if (character && actor) {
          cast.push({
            character,
            actor
          });
        }
      });

      const showData: ShowCastData = {
        showTitle: 'The Phantom of the Opera',
        venue: 'Her Majesty\'s Theatre',
        cast,
        lastUpdated: new Date()
      };

      await this.updateCastInDatabase(showData);
      return showData;
    } catch (error) {
      console.error('Error scraping Phantom cast:', error);
      throw error;
    }
  }

  // Lion King Cast Scraper
  private async scrapeLionKingCast(): Promise<ShowCastData> {
    try {
      const html = await this.fetchWithRetry('https://www.thelionking.co.uk/cast-and-creatives');
      const $ = cheerio.load(html);
      
      const cast: CastMember[] = [];
      
      $('.cast-list .cast-item').each((_, element) => {
        const character = $(element).find('.character-name').text().trim();
        const actor = $(element).find('.actor-name').text().trim();
        
        if (character && actor) {
          cast.push({
            character,
            actor
          });
        }
      });

      const showData: ShowCastData = {
        showTitle: 'The Lion King',
        venue: 'Lyceum Theatre',
        cast,
        lastUpdated: new Date()
      };

      await this.updateCastInDatabase(showData);
      return showData;
    } catch (error) {
      console.error('Error scraping Lion King cast:', error);
      throw error;
    }
  }

  // Hamilton Cast Scraper
  private async scrapeHamiltonCast(): Promise<ShowCastData> {
    try {
      const html = await this.fetchWithRetry('https://hamiltonmusical.com/london/');
      const $ = cheerio.load(html);
      
      const cast: CastMember[] = [];
      
      $('.cast-members .cast-member').each((_, element) => {
        const character = $(element).find('.character').text().trim();
        const actor = $(element).find('.actor').text().trim();
        
        if (character && actor) {
          cast.push({
            character,
            actor
          });
        }
      });

      const showData: ShowCastData = {
        showTitle: 'Hamilton',
        venue: 'Victoria Palace Theatre',
        cast,
        lastUpdated: new Date()
      };

      await this.updateCastInDatabase(showData);
      return showData;
    } catch (error) {
      console.error('Error scraping Hamilton cast:', error);
      throw error;
    }
  }

  // Additional scrapers for other major shows
  private async scrapeMatildaCast(): Promise<ShowCastData> {
    return this.scrapeGenericShow('Matilda The Musical', 'Cambridge Theatre', 'https://uk.matildathemusical.com/');
  }

  private async scrapeSixCast(): Promise<ShowCastData> {
    return this.scrapeGenericShow('SIX The Musical', 'Vaudeville Theatre', 'https://sixthemusical.com/');
  }

  private async scrapeMammaMiaCast(): Promise<ShowCastData> {
    return this.scrapeGenericShow('Mamma Mia!', 'Novello Theatre', 'https://mamma-mia.com/');
  }

  private async scrapeBookOfMormonCast(): Promise<ShowCastData> {
    return this.scrapeGenericShow('The Book of Mormon', 'Prince of Wales Theatre', 'https://bookofmormonmusical.co.uk/');
  }

  private async scrapeMousetrapCast(): Promise<ShowCastData> {
    return this.scrapeGenericShow('The Mousetrap', 'St Martin\'s Theatre', 'https://www.the-mousetrap.co.uk/');
  }

  // Generic scraper for shows with similar HTML structures
  private async scrapeGenericShow(title: string, venue: string, url: string): Promise<ShowCastData> {
    try {
      const html = await this.fetchWithRetry(url);
      const $ = cheerio.load(html);
      
      const cast: CastMember[] = [];
      
      // Try multiple common selectors for cast information
      const selectors = [
        '.cast-member',
        '.cast-list .cast-item',
        '.cast-grid .cast-member',
        '.cast .cast-member',
        '.performer',
        '.actor-info'
      ];

      for (const selector of selectors) {
        if ($(selector).length > 0) {
          $(selector).each((_, element) => {
            const character = $(element).find('.character, .role, .character-name').first().text().trim();
            const actor = $(element).find('.actor, .name, .actor-name, .performer-name').first().text().trim();
            
            if (character && actor) {
              cast.push({
                character,
                actor
              });
            }
          });
          break; // Stop after finding cast with first working selector
        }
      }

      const showData: ShowCastData = {
        showTitle: title,
        venue,
        cast,
        lastUpdated: new Date()
      };

      await this.updateCastInDatabase(showData);
      return showData;
    } catch (error) {
      console.error(`Error scraping ${title} cast:`, error);
      throw error;
    }
  }

  // Update cast information in database
  private async updateCastInDatabase(showData: ShowCastData): Promise<void> {
    try {
      // Find or create show record
      const [show] = await db
        .select()
        .from(shows)
        .where(and(
          eq(shows.title, showData.showTitle),
          eq(shows.venue, showData.venue)
        ))
        .limit(1);

      let showId: number;
      
      if (!show) {
        const [newShow] = await db
          .insert(shows)
          .values({
            title: showData.showTitle,
            venue: showData.venue,
            status: 'running',
            lastCastUpdate: showData.lastUpdated
          })
          .returning();
        showId = newShow.id;
      } else {
        showId = show.id;
        // Update last cast update time
        await db
          .update(shows)
          .set({ lastCastUpdate: showData.lastUpdated })
          .where(eq(shows.id, showId));
      }

      // Clear existing cast for this show
      await db
        .delete(castMembers)
        .where(eq(castMembers.showId, showId));

      // Insert new cast members
      if (showData.cast.length > 0) {
        await db
          .insert(castMembers)
          .values(
            showData.cast.map(member => ({
              showId,
              character: member.character,
              actor: member.actor,
              isAlternate: member.isAlternate || false,
              startDate: member.startDate || showData.lastUpdated,
              endDate: member.endDate
            }))
          );
      }

      console.log(`Updated cast for ${showData.showTitle}: ${showData.cast.length} members`);
    } catch (error) {
      console.error(`Error updating database for ${showData.showTitle}:`, error);
      throw error;
    }
  }

  // Compare with previous cast data and detect changes
  async detectCastChanges(): Promise<any[]> {
    try {
      const changes = await db
        .select()
        .from(shows)
        .where(eq(shows.status, 'running'));
      
      // Logic to compare current cast with previous version
      // and return list of changes for notifications
      
      return [];
    } catch (error) {
      console.error('Error detecting cast changes:', error);
      return [];
    }
  }
}

export const theatreCastScraper = new TheatreCastScraper();