import { db } from "./db";
import { scraperLogs, dataValidation } from "@shared/schema";
import type { InsertScraperLog, InsertDataValidation } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export class ScraperLogger {
  private scraperName: string;

  constructor(scraperName: string) {
    this.scraperName = scraperName;
  }

  async logAction(
    action: 'add' | 'update' | 'archived' | 'validation_failed',
    entityType: string,
    entityName: string,
    options: {
      entityId?: string;
      previousData?: any;
      newData?: any;
      validationStatus?: 'valid' | 'invalid' | 'outdated' | 'archived';
      validationReason?: string;
      sourceUrl?: string;
      notes?: string;
      processingTime?: number;
    } = {}
  ): Promise<void> {
    try {
      const logEntry: InsertScraperLog = {
        scraperName: this.scraperName,
        action,
        entityType,
        entityId: options.entityId,
        entityName,
        previousData: options.previousData ? JSON.stringify(options.previousData) : null,
        newData: options.newData ? JSON.stringify(options.newData) : null,
        validationStatus: options.validationStatus,
        validationReason: options.validationReason,
        sourceUrl: options.sourceUrl,
        notes: options.notes,
        processingTime: options.processingTime,
      };

      await db.insert(scraperLogs).values(logEntry);
      console.log(`📊 [${this.scraperName}] ${action.toUpperCase()}: ${entityName} ${options.entityId ? `(ID: ${options.entityId})` : ''}`);
    } catch (error) {
      console.error(`❌ Failed to log scraper action:`, error);
    }
  }

  async validateData(
    entityType: string,
    entityId: string,
    validationChecks: string[],
    isValid: boolean,
    failedChecks: string[] = [],
    nextValidationDays: number = 30
  ): Promise<void> {
    try {
      const nextValidationDate = new Date();
      nextValidationDate.setDate(nextValidationDate.getDate() + nextValidationDays);

      const validationEntry: InsertDataValidation = {
        entityType,
        entityId,
        isValid,
        validationChecks,
        failedChecks,
        nextValidationDate,
      };

      await db.insert(dataValidation).values(validationEntry);
    } catch (error) {
      console.error(`❌ Failed to log data validation:`, error);
    }
  }

  async archiveEntity(
    entityType: string,
    entityId: string,
    reason: string
  ): Promise<void> {
    try {
      // Update validation record to mark as archived
      await db
        .update(dataValidation)
        .set({
          archivedAt: new Date(),
          archivedReason: reason,
          isValid: false
        })
        .where(eq(dataValidation.entityId, entityId));

      // Log the archival action
      await this.logAction('archived', entityType, `Entity ${entityId}`, {
        entityId,
        validationReason: reason,
        validationStatus: 'archived'
      });
    } catch (error) {
      console.error(`❌ Failed to archive entity:`, error);
    }
  }

  // Data validation utilities
  static validateWebsiteUrl(url: string): boolean {
    try {
      new URL(url);
      return url.startsWith('http://') || url.startsWith('https://');
    } catch {
      return false;
    }
  }

  static validateYear(year: number): boolean {
    const currentYear = new Date().getFullYear();
    return year >= 1800 && year <= currentYear;
  }

  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  static validatePhoneNumber(phone: string): boolean {
    const phoneRegex = /^\+?[\d\s\-\(\)]{10,}$/;
    return phoneRegex.test(phone);
  }

  static isDataStale(lastUpdated: Date, maxAgeDays: number = 365): boolean {
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - lastUpdated.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > maxAgeDays;
  }

  // Get recent logs for this scraper
  async getRecentLogs(limit: number = 50): Promise<any[]> {
    try {
      return await db
        .select()
        .from(scraperLogs)
        .where(eq(scraperLogs.scraperName, this.scraperName))
        .orderBy(desc(scraperLogs.createdAt))
        .limit(limit);
    } catch (error) {
      console.error(`❌ Failed to get recent logs:`, error);
      return [];
    }
  }

  // Get validation summary
  async getValidationSummary(): Promise<{
    total: number;
    valid: number;
    invalid: number;
    archived: number;
  }> {
    try {
      const logs = await db
        .select()
        .from(scraperLogs)
        .where(eq(scraperLogs.scraperName, this.scraperName));

      const summary = {
        total: logs.length,
        valid: logs.filter(l => l.validationStatus === 'valid').length,
        invalid: logs.filter(l => l.validationStatus === 'invalid').length,
        archived: logs.filter(l => l.validationStatus === 'archived').length,
      };

      return summary;
    } catch (error) {
      console.error(`❌ Failed to get validation summary:`, error);
      return { total: 0, valid: 0, invalid: 0, archived: 0 };
    }
  }
}