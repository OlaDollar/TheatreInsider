import { db } from "./db";
import { articles, reviews } from "../shared/schema";
import { eq } from "drizzle-orm";

interface ContentAdvisory {
  level: 'none' | 'guidance' | 'warning' | 'restricted';
  categories: string[];
  description: string;
  ageRating: string;
  localeSpecific: {
    uk: {
      rating: string;
      warning: string;
      required: boolean;
    };
    us: {
      rating: string;
      warning: string;
      required: boolean;
    };
    eu: {
      rating: string;
      warning: string;
      required: boolean;
    };
    international: {
      rating: string;
      warning: string;
      required: boolean;
    };
  };
}

interface ContentFlags {
  violence: boolean;
  language: boolean;
  sexualContent: boolean;
  substanceUse: boolean;
  gambling: boolean;
  mentalHealth: boolean;
  politicalContent: boolean;
  religiousContent: boolean;
  discriminatory: boolean;
  flashingLights: boolean;
}

export class ContentAdvisorySystem {
  private advisoryPatterns = {
    // Violence and disturbing content
    violence: [
      /\b(?:murder|kill|death|suicide|violence|blood|weapon|gun|knife|stab|shoot|assault|abuse|torture|rape)\b/gi,
      /\b(?:violent|graphic|disturbing|brutal|savage|aggressive|attack|fight|war|battle)\b/gi
    ],
    
    // Strong language
    language: [
      /\b(?:fuck|shit|damn|hell|bastard|bitch|cunt|piss|cock|dick|ass|arse)\b/gi,
      /\b(?:bloody|blimey|bugger|sod|git|twat|prat|tart|slag|whore|slut)\b/gi
    ],
    
    // Sexual content
    sexualContent: [
      /\b(?:sex|sexual|nude|naked|breast|penis|vagina|orgasm|intercourse|masturbation|pornography)\b/gi,
      /\b(?:erotic|sensual|intimate|seductive|provocative|suggestive|risqué|adult)\b/gi
    ],
    
    // Substance use
    substanceUse: [
      /\b(?:drug|drugs|cocaine|heroin|marijuana|cannabis|alcohol|drunk|drinking|smoking|cigarette|addiction)\b/gi,
      /\b(?:overdose|withdrawal|rehab|intoxicated|substance|abuse|narcotic|stimulant|depressant)\b/gi
    ],
    
    // Gambling
    gambling: [
      /\b(?:gambling|casino|poker|blackjack|roulette|betting|lottery|jackpot|slot machine)\b/gi,
      /\b(?:wager|bet|odds|bookmaker|bookie|punt|stake|gamble)\b/gi
    ],
    
    // Mental health
    mentalHealth: [
      /\b(?:depression|anxiety|suicide|self-harm|mental illness|eating disorder|trauma|ptsd)\b/gi,
      /\b(?:psychological|psychiatric|therapy|counseling|medication|antidepressant)\b/gi
    ],
    
    // Political content
    politicalContent: [
      /\b(?:politics|government|election|vote|candidate|parliament|congress|conservative|liberal|labour|democrat|republican)\b/gi,
      /\b(?:brexit|immigration|abortion|gun control|healthcare|taxation|welfare|climate change)\b/gi
    ],
    
    // Religious content
    religiousContent: [
      /\b(?:religion|religious|god|jesus|christ|muslim|islam|jewish|judaism|hindu|buddhist|christian|catholic|protestant)\b/gi,
      /\b(?:bible|quran|torah|prayer|worship|faith|belief|sacred|holy|divine|spiritual)\b/gi
    ],
    
    // Discriminatory content
    discriminatory: [
      /\b(?:racist|racism|sexist|sexism|homophobic|transphobic|xenophobic|bigot|prejudice|discrimination)\b/gi,
      /\b(?:stereotype|bias|intolerance|hate|offensive|derogatory|slur|epithet)\b/gi
    ],
    
    // Flashing lights (for epilepsy)
    flashingLights: [
      /\b(?:flashing|strobe|strobing|flickering|rapid|quick|fast|bright|intense|lighting effects)\b/gi,
      /\b(?:epilepsy|seizure|photosensitive|visual effects|stage lights|disco)\b/gi
    ]
  };

  async analyzeContent(contentId: number, contentType: 'article' | 'review', locale: string = 'international'): Promise<ContentAdvisory> {
    try {
      // Get content from database
      const content = await this.getContent(contentId, contentType);
      if (!content) {
        throw new Error('Content not found');
      }

      // Analyze content for flags
      const flags = this.detectContentFlags(content);
      
      // Generate advisory based on flags and locale
      const advisory = this.generateAdvisory(flags, locale);
      
      // Store advisory in database (if needed)
      await this.storeAdvisory(contentId, contentType, advisory);
      
      return advisory;
      
    } catch (error) {
      console.error('Error analyzing content advisory:', error);
      return this.getDefaultAdvisory(locale);
    }
  }

  private async getContent(contentId: number, contentType: 'article' | 'review'): Promise<any> {
    if (contentType === 'article') {
      const [article] = await db
        .select()
        .from(articles)
        .where(eq(articles.id, contentId));
      return article;
    } else {
      const [review] = await db
        .select()
        .from(reviews)
        .where(eq(reviews.id, contentId));
      return review;
    }
  }

  private detectContentFlags(content: any): ContentFlags {
    const fullText = `${content.title} ${content.content} ${content.excerpt || ''}`.toLowerCase();
    
    const flags: ContentFlags = {
      violence: false,
      language: false,
      sexualContent: false,
      substanceUse: false,
      gambling: false,
      mentalHealth: false,
      politicalContent: false,
      religiousContent: false,
      discriminatory: false,
      flashingLights: false
    };

    // Check each category
    Object.entries(this.advisoryPatterns).forEach(([category, patterns]) => {
      for (const pattern of patterns) {
        if (pattern.test(fullText)) {
          flags[category as keyof ContentFlags] = true;
          break;
        }
      }
    });

    return flags;
  }

  private generateAdvisory(flags: ContentFlags, locale: string): ContentAdvisory {
    const categories: string[] = [];
    let level: ContentAdvisory['level'] = 'none';
    
    // Determine categories and severity
    if (flags.violence) {
      categories.push('Violence');
      level = 'warning';
    }
    
    if (flags.language) {
      categories.push('Strong Language');
      if (level === 'none') level = 'guidance';
    }
    
    if (flags.sexualContent) {
      categories.push('Sexual Content');
      level = 'warning';
    }
    
    if (flags.substanceUse) {
      categories.push('Substance Use');
      if (level === 'none') level = 'guidance';
    }
    
    if (flags.gambling) {
      categories.push('Gambling References');
      level = 'restricted';
    }
    
    if (flags.mentalHealth) {
      categories.push('Mental Health Themes');
      if (level === 'none') level = 'guidance';
    }
    
    if (flags.politicalContent) {
      categories.push('Political Content');
      if (level === 'none') level = 'guidance';
    }
    
    if (flags.religiousContent) {
      categories.push('Religious Themes');
      if (level === 'none') level = 'guidance';
    }
    
    if (flags.discriminatory) {
      categories.push('Discriminatory Content');
      level = 'warning';
    }
    
    if (flags.flashingLights) {
      categories.push('Flashing Lights');
      level = 'warning';
    }

    return {
      level,
      categories,
      description: this.generateDescription(categories),
      ageRating: this.determineAgeRating(level, flags, locale),
      localeSpecific: this.generateLocaleSpecificWarnings(level, categories, flags, locale)
    };
  }

  private generateDescription(categories: string[]): string {
    if (categories.length === 0) {
      return 'No content advisories required';
    }
    
    if (categories.length === 1) {
      return `Contains ${categories[0].toLowerCase()}`;
    }
    
    if (categories.length === 2) {
      return `Contains ${categories[0].toLowerCase()} and ${categories[1].toLowerCase()}`;
    }
    
    const lastCategory = categories.pop();
    return `Contains ${categories.join(', ').toLowerCase()}, and ${lastCategory?.toLowerCase()}`;
  }

  private determineAgeRating(level: ContentAdvisory['level'], flags: ContentFlags, locale: string): string {
    if (locale === 'uk') {
      if (flags.gambling || flags.sexualContent) return 'U';
      if (flags.violence || flags.language) return 'PG';
      if (level === 'warning') return 'PG';
      return 'U';
    }
    
    if (locale === 'us') {
      if (flags.gambling || flags.sexualContent || flags.violence) return 'PG-13';
      if (flags.language || level === 'warning') return 'PG';
      return 'G';
    }
    
    if (locale === 'eu') {
      if (flags.gambling || flags.sexualContent) return '16+';
      if (flags.violence || level === 'warning') return '12+';
      if (flags.language) return '6+';
      return '0+';
    }
    
    // International default
    if (level === 'restricted') return '18+';
    if (level === 'warning') return '15+';
    if (level === 'guidance') return '12+';
    return 'All Ages';
  }

  private generateLocaleSpecificWarnings(level: ContentAdvisory['level'], categories: string[], flags: ContentFlags, currentLocale: string): ContentAdvisory['localeSpecific'] {
    return {
      uk: {
        rating: this.determineAgeRating(level, flags, 'uk'),
        warning: this.generateUKWarning(categories, flags),
        required: level !== 'none' && this.requiresUKWarning(flags)
      },
      us: {
        rating: this.determineAgeRating(level, flags, 'us'),
        warning: this.generateUSWarning(categories, flags),
        required: level !== 'none' && this.requiresUSWarning(flags)
      },
      eu: {
        rating: this.determineAgeRating(level, flags, 'eu'),
        warning: this.generateEUWarning(categories, flags),
        required: level !== 'none' && this.requiresEUWarning(flags)
      },
      international: {
        rating: this.determineAgeRating(level, flags, 'international'),
        warning: this.generateInternationalWarning(categories, flags),
        required: level === 'warning' || level === 'restricted'
      }
    };
  }

  private generateUKWarning(categories: string[], flags: ContentFlags): string {
    if (categories.length === 0) return '';
    
    let warning = 'This content ';
    
    if (flags.gambling) {
      warning += 'contains gambling references and is regulated under UK Gambling Act 2005. ';
    }
    
    if (flags.violence || flags.sexualContent) {
      warning += 'may not be suitable for younger viewers. ';
    }
    
    if (flags.mentalHealth) {
      warning += 'discusses mental health themes. Support available at mind.org.uk. ';
    }
    
    if (flags.flashingLights) {
      warning += 'contains flashing lights that may trigger epileptic seizures. ';
    }
    
    return warning.trim();
  }

  private generateUSWarning(categories: string[], flags: ContentFlags): string {
    if (categories.length === 0) return '';
    
    let warning = 'Content advisory: ';
    
    if (flags.gambling) {
      warning += 'Contains gambling references. ';
    }
    
    if (flags.violence) {
      warning += 'Contains violence and may not be suitable for all audiences. ';
    }
    
    if (flags.language) {
      warning += 'Contains strong language. ';
    }
    
    if (flags.mentalHealth) {
      warning += 'Discusses mental health themes. Support available at 988lifeline.org. ';
    }
    
    if (flags.flashingLights) {
      warning += 'Contains flashing lights. ';
    }
    
    return warning.trim();
  }

  private generateEUWarning(categories: string[], flags: ContentFlags): string {
    if (categories.length === 0) return '';
    
    let warning = 'Avertissement de contenu: ';
    
    if (flags.gambling) {
      warning += 'Contient des références au jeu. ';
    }
    
    if (flags.violence || flags.sexualContent) {
      warning += 'Peut ne pas convenir à tous les publics. ';
    }
    
    if (flags.discriminatory) {
      warning += 'Soumis au règlement européen sur les services numériques. ';
    }
    
    if (flags.flashingLights) {
      warning += 'Contient des lumières clignotantes. ';
    }
    
    return warning.trim();
  }

  private generateInternationalWarning(categories: string[], flags: ContentFlags): string {
    if (categories.length === 0) return '';
    
    let warning = 'Content Warning: ';
    
    if (flags.gambling) {
      warning += 'Contains gambling references. ';
    }
    
    if (flags.violence) {
      warning += 'Contains violence. ';
    }
    
    if (flags.sexualContent) {
      warning += 'Contains sexual content. ';
    }
    
    if (flags.language) {
      warning += 'Contains strong language. ';
    }
    
    if (flags.mentalHealth) {
      warning += 'Discusses mental health themes. ';
    }
    
    if (flags.flashingLights) {
      warning += 'Contains flashing lights. ';
    }
    
    return warning.trim();
  }

  private requiresUKWarning(flags: ContentFlags): boolean {
    return flags.gambling || flags.violence || flags.sexualContent || flags.flashingLights;
  }

  private requiresUSWarning(flags: ContentFlags): boolean {
    return flags.gambling || flags.violence || flags.language || flags.flashingLights;
  }

  private requiresEUWarning(flags: ContentFlags): boolean {
    return flags.gambling || flags.discriminatory || flags.violence || flags.flashingLights;
  }

  private getDefaultAdvisory(locale: string): ContentAdvisory {
    return {
      level: 'none',
      categories: [],
      description: 'No content advisories required',
      ageRating: locale === 'uk' ? 'U' : locale === 'us' ? 'G' : locale === 'eu' ? '0+' : 'All Ages',
      localeSpecific: {
        uk: { rating: 'U', warning: '', required: false },
        us: { rating: 'G', warning: '', required: false },
        eu: { rating: '0+', warning: '', required: false },
        international: { rating: 'All Ages', warning: '', required: false }
      }
    };
  }

  private async storeAdvisory(contentId: number, contentType: 'article' | 'review', advisory: ContentAdvisory): Promise<void> {
    // In production, store advisory in database
    console.log(`Advisory stored for ${contentType}:${contentId}:`, advisory.level);
  }

  async bulkAnalyzeContent(contentIds: number[], contentType: 'article' | 'review', locale: string = 'international'): Promise<Map<number, ContentAdvisory>> {
    const advisories = new Map<number, ContentAdvisory>();
    
    for (const contentId of contentIds) {
      try {
        const advisory = await this.analyzeContent(contentId, contentType, locale);
        advisories.set(contentId, advisory);
      } catch (error) {
        console.error(`Error analyzing content ${contentId}:`, error);
        advisories.set(contentId, this.getDefaultAdvisory(locale));
      }
    }
    
    return advisories;
  }

  formatAdvisoryForDisplay(advisory: ContentAdvisory, locale: string): string {
    const localeAdvisory = advisory.localeSpecific[locale as keyof typeof advisory.localeSpecific] || advisory.localeSpecific.international;
    
    if (!localeAdvisory.required) {
      return '';
    }
    
    return `
<div class="content-advisory ${advisory.level}">
  <div class="advisory-header">
    <span class="advisory-icon">⚠️</span>
    <span class="advisory-rating">${localeAdvisory.rating}</span>
  </div>
  <div class="advisory-content">
    <p class="advisory-description">${advisory.description}</p>
    ${localeAdvisory.warning ? `<p class="advisory-warning">${localeAdvisory.warning}</p>` : ''}
    ${advisory.categories.length > 0 ? `<div class="advisory-categories">${advisory.categories.join(', ')}</div>` : ''}
  </div>
</div>
    `.trim();
  }
}

export const contentAdvisorySystem = new ContentAdvisorySystem();