import { db } from "./db";
import { shows, venues } from "@shared/schema";
import { eq, and } from "drizzle-orm";
import * as cheerio from 'cheerio';

interface VenueData {
  name: string;
  address: string;
  capacity?: number;
  currentShows: string[];
  website: string;
  bookingInfo?: string;
}

interface ShowScheduleData {
  title: string;
  venue: string;
  startDate?: Date;
  endDate?: Date;
  matineeDays: string[];
  eveningDays: string[];
  priceRange?: string;
  status: 'running' | 'upcoming' | 'closing' | 'closed';
}

export class VenueShowScraper {
  private readonly userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36';

  async scrapeAllVenuesAndShows(): Promise<void> {
    console.log('Starting comprehensive venue and show schedule scraping...');
    
    const scrapers = [
      this.scrapeWestEndTheatres(),
      this.scrapeBroadwayTheatres(),
      this.scrapeUKRegionalTheatres(),
      this.scrapeShowSchedules()
    ];

    await Promise.allSettled(scrapers);
    console.log('Venue and show scraping complete');
  }

  private async fetchWithRetry(url: string, retries = 3): Promise<string> {
    for (let i = 0; i < retries; i++) {
      try {
        const response = await fetch(url, {
          headers: { 'User-Agent': this.userAgent }
        });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return await response.text();
      } catch (error) {
        if (i === retries - 1) throw error;
        await this.delay(2000 * (i + 1));
      }
    }
    throw new Error('All retry attempts failed');
  }

  private async delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // Scrape West End theatre information
  private async scrapeWestEndTheatres(): Promise<void> {
    try {
      // Official London Theatre website
      const html = await this.fetchWithRetry('https://officiallondontheatre.com/london-west-end-guide/');
      const $ = cheerio.load(html);
      
      const venues: VenueData[] = [];
      
      $('.theatre-listing').each((_, element) => {
        const name = $(element).find('.theatre-name').text().trim();
        const address = $(element).find('.theatre-address').text().trim();
        const capacity = parseInt($(element).find('.capacity').text().replace(/\D/g, '')) || undefined;
        const website = $(element).find('a').attr('href') || '';
        
        if (name) {
          venues.push({
            name,
            address,
            capacity,
            currentShows: [],
            website
          });
        }
      });

      // Update venues in database
      for (const venue of venues) {
        await this.updateVenueInDatabase(venue);
      }

    } catch (error) {
      console.error('Error scraping West End theatres:', error);
    }
  }

  // Scrape Broadway theatre information
  private async scrapeBroadwayTheatres(): Promise<void> {
    try {
      const html = await this.fetchWithRetry('https://www.broadway.org/shows');
      const $ = cheerio.load(html);
      
      $('.show-listing').each((_, element) => {
        const title = $(element).find('.show-title').text().trim();
        const venue = $(element).find('.theatre-name').text().trim();
        const status = $(element).find('.status').text().trim();
        
        if (title && venue) {
          // Process Broadway show data
          this.updateShowInDatabase({
            title,
            venue,
            status: status.toLowerCase().includes('running') ? 'running' : 'upcoming',
            matineeDays: ['Wednesday', 'Saturday', 'Sunday'],
            eveningDays: ['Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
          });
        }
      });

    } catch (error) {
      console.error('Error scraping Broadway theatres:', error);
    }
  }

  // Scrape UK Regional theatres
  private async scrapeUKRegionalTheatres(): Promise<void> {
    const regionalTheatres = [
      { name: 'Sheffield Crucible', url: 'https://www.sheffieldtheatres.co.uk/' },
      { name: 'Royal Exchange Theatre', url: 'https://www.royalexchange.co.uk/' },
      { name: 'Birmingham Rep', url: 'https://www.birmingham-rep.co.uk/' },
      { name: 'Bristol Old Vic', url: 'https://bristololdvic.org.uk/' },
      { name: 'Chichester Festival Theatre', url: 'https://www.cft.org.uk/' },
      { name: 'Arcola Theatre', url: 'https://www.arcolatheatre.com/' }
    ];

    for (const theatre of regionalTheatres) {
      try {
        await this.scrapeIndividualRegionalTheatre(theatre);
      } catch (error) {
        console.error(`Error scraping ${theatre.name}:`, error);
      }
    }
  }

  private async scrapeIndividualRegionalTheatre(theatre: { name: string, url: string }): Promise<void> {
    try {
      const html = await this.fetchWithRetry(theatre.url);
      const $ = cheerio.load(html);
      
      const shows: string[] = [];
      
      // Common selectors for show titles
      const selectors = [
        '.show-title',
        '.production-title', 
        '.event-title',
        '.whats-on-title',
        'h2 a', 
        'h3 a'
      ];

      for (const selector of selectors) {
        $(selector).each((_, element) => {
          const showTitle = $(element).text().trim();
          if (showTitle && showTitle.length > 3) {
            shows.push(showTitle);
          }
        });
        if (shows.length > 0) break;
      }

      // Update venue with current shows
      await this.updateVenueInDatabase({
        name: theatre.name,
        address: '',
        currentShows: shows.slice(0, 10), // Limit to 10 shows
        website: theatre.url
      });

    } catch (error) {
      console.error(`Error scraping ${theatre.name}:`, error);
    }
  }

  // Scrape show schedules and booking information
  private async scrapeShowSchedules(): Promise<void> {
    const majorShowUrls = [
      { title: 'Oliver!', url: 'https://oliverthemusical.com/ticket-information/' },
      { title: 'Wicked', url: 'https://www.wickedthemusical.co.uk/tickets/' },
      { title: 'The Lion King', url: 'https://www.thelionking.co.uk/' },
      { title: 'Hamilton', url: 'https://hamiltonmusical.com/london/' },
      { title: 'The Phantom of the Opera', url: 'https://uk.thephantomoftheopera.com/' }
    ];

    for (const show of majorShowUrls) {
      try {
        await this.scrapeIndividualShowSchedule(show);
      } catch (error) {
        console.error(`Error scraping schedule for ${show.title}:`, error);
      }
    }
  }

  private async scrapeIndividualShowSchedule(show: { title: string, url: string }): Promise<void> {
    try {
      const html = await this.fetchWithRetry(show.url);
      const $ = cheerio.load(html);
      
      // Extract price information
      const priceText = $('.price, .ticket-price, .from').first().text();
      const priceMatch = priceText.match(/£[\d,]+/g);
      const priceRange = priceMatch ? `From ${priceMatch[0]}` : undefined;

      // Extract performance schedule
      const scheduleText = $('.schedule, .performance-times, .show-times').text().toLowerCase();
      
      const matineeDays: string[] = [];
      const eveningDays: string[] = [];
      
      if (scheduleText.includes('wednesday') && scheduleText.includes('matinee')) matineeDays.push('Wednesday');
      if (scheduleText.includes('saturday') && scheduleText.includes('matinee')) matineeDays.push('Saturday');  
      if (scheduleText.includes('sunday') && scheduleText.includes('matinee')) matineeDays.push('Sunday');
      
      ['tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].forEach(day => {
        if (scheduleText.includes(day) && scheduleText.includes('evening')) {
          eveningDays.push(day.charAt(0).toUpperCase() + day.slice(1));
        }
      });

      // Extract booking period
      const bookingText = $('.booking-period, .book-until, .extended').text();
      const dateMatch = bookingText.match(/(\d{1,2})\s+(january|february|march|april|may|june|july|august|september|october|november|december)\s+(\d{4})/i);
      
      let endDate: Date | undefined;
      if (dateMatch) {
        const [, day, month, year] = dateMatch;
        const monthIndex = new Date(Date.parse(month + " 1, 2000")).getMonth();
        endDate = new Date(parseInt(year), monthIndex, parseInt(day));
      }

      const scheduleData: ShowScheduleData = {
        title: show.title,
        venue: this.getVenueForShow(show.title),
        endDate,
        matineeDays: matineeDays.length > 0 ? matineeDays : ['Wednesday', 'Saturday', 'Sunday'],
        eveningDays: eveningDays.length > 0 ? eveningDays : ['Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
        priceRange,
        status: 'running'
      };

      await this.updateShowInDatabase(scheduleData);

    } catch (error) {
      console.error(`Error scraping schedule for ${show.title}:`, error);
    }
  }

  private getVenueForShow(title: string): string {
    const venueMap: { [key: string]: string } = {
      'Oliver!': 'Gielgud Theatre',
      'Wicked': 'Apollo Victoria Theatre', 
      'The Lion King': 'Lyceum Theatre',
      'Hamilton': 'Victoria Palace Theatre',
      'The Phantom of the Opera': 'Her Majesty\'s Theatre'
    };
    return venueMap[title] || '';
  }

  // Update venue information in database
  private async updateVenueInDatabase(venueData: VenueData): Promise<void> {
    try {
      const [existingVenue] = await db
        .select()
        .from(venues)
        .where(eq(venues.name, venueData.name))
        .limit(1);

      if (existingVenue) {
        await db
          .update(venues)
          .set({
            address: venueData.address || existingVenue.address,
            capacity: venueData.capacity || existingVenue.capacity,
            website: venueData.website || existingVenue.website,
            updatedAt: new Date()
          })
          .where(eq(venues.id, existingVenue.id));
      } else {
        await db
          .insert(venues)
          .values({
            name: venueData.name,
            address: venueData.address,
            capacity: venueData.capacity,
            website: venueData.website,
            createdAt: new Date(),
            updatedAt: new Date()
          });
      }

      console.log(`Updated venue: ${venueData.name}`);
    } catch (error) {
      console.error(`Error updating venue ${venueData.name}:`, error);
    }
  }

  // Update show information in database  
  private async updateShowInDatabase(showData: ShowScheduleData): Promise<void> {
    try {
      const [existingShow] = await db
        .select()
        .from(shows)
        .where(and(
          eq(shows.title, showData.title),
          eq(shows.venue, showData.venue)
        ))
        .limit(1);

      const updateData = {
        status: showData.status,
        endDate: showData.endDate,
        priceRange: showData.priceRange,
        matineeDays: showData.matineeDays.join(','),
        eveningDays: showData.eveningDays.join(','),
        updatedAt: new Date()
      };

      if (existingShow) {
        await db
          .update(shows)
          .set(updateData)
          .where(eq(shows.id, existingShow.id));
      } else {
        await db
          .insert(shows)
          .values({
            title: showData.title,
            venue: showData.venue,
            startDate: showData.startDate,
            ...updateData,
            createdAt: new Date()
          });
      }

      console.log(`Updated show: ${showData.title} at ${showData.venue}`);
    } catch (error) {
      console.error(`Error updating show ${showData.title}:`, error);
    }
  }
}

export const venueShowScraper = new VenueShowScraper();