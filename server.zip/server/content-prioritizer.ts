import { db } from "./db";
import { articles, reviews } from "@shared/schema";
import { desc, eq, and, gte, sql } from "drizzle-orm";

interface ContentPriority {
  id: number;
  type: 'article' | 'review';
  title: string;
  excerpt: string;
  category: string;
  region: string;
  publishedAt: Date;
  priority: number;
  urgency: 'breaking' | 'lead' | 'featured' | 'standard';
  tags: string[];
  imageUrl?: string;
}

interface ContentHierarchy {
  breakingNews: ContentPriority[];
  leadStories: ContentPriority[];
  featuredContent: ContentPriority[];
  latestContent: ContentPriority[];
}

export class ContentPrioritizer {
  private urgencyKeywords = {
    breaking: [
      'breaking', 'urgent', 'dies', 'died', 'death', 'passes away', 'obituary',
      'closes', 'closing', 'cancelled', 'emergency', 'fire', 'accident',
      'announces retirement', 'quits', 'resigns', 'injured', 'hospitalized'
    ],
    lead: [
      'announces', 'announces new', 'world premiere', 'opening', 'opens',
      'casting announced', 'cast announced', 'new musical', 'new play',
      'broadway debut', 'west end debut', 'transfer', 'extends', 'extension',
      'tony awards', 'olivier awards', 'wins', 'nominated', 'review',
      'first look', 'exclusive', 'interview'
    ],
    featured: [
      'photos', 'behind the scenes', 'rehearsal', 'preview', 'first night',
      'gala', 'red carpet', 'celebrity', 'star', 'tickets on sale'
    ]
  };

  private categoryPriority = {
    'obituary': 10,
    'announcement': 9,
    'review': 8,
    'news': 7,
    'interview': 6,
    'feature': 5,
    'photos': 4
  };

  private venuePriority = {
    // West End Theatres
    'theatre royal drury lane': 10,
    'london palladium': 10,
    'his majesty\'s theatre': 9,
    'palace theatre': 9,
    'lyceum theatre': 9,
    'prince of wales theatre': 8,
    'savoy theatre': 8,
    'apollo victoria': 8,
    'dominion theatre': 8,
    
    // Broadway Theatres
    'majestic theatre': 10,
    'palace theatre broadway': 10,
    'gershwin theatre': 9,
    'minskoff theatre': 9,
    'nederlander theatre': 8,
    'ambassador theatre': 8,
    'broadhurst theatre': 8,
    'imperial theatre': 8,
    
    // Off-West End
    'old vic': 7,
    'national theatre': 9,
    'royal opera house': 8,
    'royal albert hall': 7,
    
    // Off-Broadway
    'lucille lortel theatre': 6,
    'cherry lane theatre': 6,
    'atlantic theater': 6
  };

  async prioritizeContent(): Promise<ContentHierarchy> {
    console.log('🔄 Prioritizing content for homepage display...');

    // Get all content from last 7 days
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - 7);

    const [articlesData, reviewsData] = await Promise.all([
      db.select().from(articles)
        .where(gte(articles.publishedAt, cutoffDate))
        .orderBy(desc(articles.publishedAt))
        .limit(100),
      
      db.select().from(reviews)
        .where(gte(reviews.publishedAt, cutoffDate))
        .orderBy(desc(reviews.publishedAt))
        .limit(50)
    ]);

    // Convert to unified content format
    const allContent: ContentPriority[] = [
      ...articlesData.map(article => ({
        id: article.id,
        type: 'article' as const,
        title: article.title,
        excerpt: article.excerpt,
        category: article.category,
        region: article.region,
        publishedAt: article.publishedAt,
        priority: 0,
        urgency: 'standard' as const,
        tags: article.tags || [],
        imageUrl: article.imageUrl
      })),
      ...reviewsData.map(review => ({
        id: review.id,
        type: 'review' as const,
        title: review.showTitle,
        excerpt: review.excerpt,
        category: 'review',
        region: review.region,
        publishedAt: review.publishedAt,
        priority: 0,
        urgency: 'standard' as const,
        tags: review.tags || [],
        imageUrl: review.imageUrl
      }))
    ];

    // Calculate priority scores
    const prioritizedContent = allContent.map(content => ({
      ...content,
      priority: this.calculatePriority(content),
      urgency: this.determineUrgency(content)
    }));

    // Sort by priority and recency
    prioritizedContent.sort((a, b) => {
      // First sort by urgency
      const urgencyOrder = { breaking: 4, lead: 3, featured: 2, standard: 1 };
      if (urgencyOrder[a.urgency] !== urgencyOrder[b.urgency]) {
        return urgencyOrder[b.urgency] - urgencyOrder[a.urgency];
      }
      
      // Then by priority score
      if (a.priority !== b.priority) {
        return b.priority - a.priority;
      }
      
      // Finally by recency
      return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
    });

    // Categorize content
    const hierarchy: ContentHierarchy = {
      breakingNews: prioritizedContent.filter(c => c.urgency === 'breaking').slice(0, 3),
      leadStories: prioritizedContent.filter(c => c.urgency === 'lead').slice(0, 6),
      featuredContent: prioritizedContent.filter(c => c.urgency === 'featured').slice(0, 8),
      latestContent: prioritizedContent.slice(0, 20)
    };

    console.log(`📊 Content prioritized: ${hierarchy.breakingNews.length} breaking, ${hierarchy.leadStories.length} lead stories`);
    
    // Log breaking news for monitoring
    if (hierarchy.breakingNews.length > 0) {
      console.log('🚨 BREAKING NEWS DETECTED:');
      hierarchy.breakingNews.forEach(news => {
        console.log(`   - ${news.title} (${news.urgency}, priority: ${news.priority})`);
      });
    }

    return hierarchy;
  }

  private calculatePriority(content: ContentPriority): number {
    let score = 0;

    // Base score by category
    score += this.categoryPriority[content.category] || 3;

    // Recency bonus (higher for newer content)
    const hoursAge = (Date.now() - content.publishedAt.getTime()) / (1000 * 60 * 60);
    if (hoursAge < 2) score += 8;
    else if (hoursAge < 6) score += 6;
    else if (hoursAge < 12) score += 4;
    else if (hoursAge < 24) score += 2;

    // Venue priority bonus
    const titleLower = content.title.toLowerCase();
    const excerptLower = content.excerpt.toLowerCase();
    const combinedText = `${titleLower} ${excerptLower}`;
    
    for (const [venue, venuePriority] of Object.entries(this.venuePriority)) {
      if (combinedText.includes(venue)) {
        score += venuePriority;
        break;
      }
    }

    // Show title priority (major shows get higher priority)
    const majorShows = [
      'lion king', 'phantom of the opera', 'wicked', 'hamilton', 'chicago',
      'book of mormon', 'frozen', 'aladdin', 'mary poppins', 'mamma mia',
      'les miserables', 'cats', 'mousetrap', 'jersey boys'
    ];

    for (const show of majorShows) {
      if (combinedText.includes(show)) {
        score += 3;
        break;
      }
    }

    // Celebrity/star bonus
    const celebrities = [
      'hugh jackman', 'lin-manuel miranda', 'andrew lloyd webber', 'stephen sondheim',
      'cameron mackintosh', 'matthew bourne', 'sam mendes', 'trevor nunn'
    ];

    for (const celebrity of celebrities) {
      if (combinedText.includes(celebrity)) {
        score += 4;
        break;
      }
    }

    return score;
  }

  private determineUrgency(content: ContentPriority): 'breaking' | 'lead' | 'featured' | 'standard' {
    const titleLower = content.title.toLowerCase();
    const excerptLower = content.excerpt.toLowerCase();
    const combinedText = `${titleLower} ${excerptLower}`;

    // Check for breaking news keywords
    for (const keyword of this.urgencyKeywords.breaking) {
      if (combinedText.includes(keyword)) {
        return 'breaking';
      }
    }

    // Check for lead story keywords
    for (const keyword of this.urgencyKeywords.lead) {
      if (combinedText.includes(keyword)) {
        return 'lead';
      }
    }

    // Check for featured content keywords
    for (const keyword of this.urgencyKeywords.featured) {
      if (combinedText.includes(keyword)) {
        return 'featured';
      }
    }

    return 'standard';
  }

  async getHomepageContent(): Promise<{
    hero: ContentPriority | null;
    breaking: ContentPriority[];
    lead: ContentPriority[];
    latest: ContentPriority[];
  }> {
    const hierarchy = await this.prioritizeContent();

    // Hero story is the top breaking news or lead story
    const hero = hierarchy.breakingNews[0] || hierarchy.leadStories[0] || hierarchy.latestContent[0] || null;

    return {
      hero,
      breaking: hierarchy.breakingNews.slice(1, 4), // Skip hero if it's breaking news
      lead: hierarchy.leadStories.slice(hero?.urgency === 'lead' ? 1 : 0, 6),
      latest: hierarchy.latestContent.slice(0, 12)
    };
  }

  async markAsStale(contentId: number, contentType: 'article' | 'review'): Promise<void> {
    // Mark content as less urgent after 24 hours
    const table = contentType === 'article' ? articles : reviews;
    
    await db.update(table)
      .set({ 
        updatedAt: new Date(),
        // Could add a 'stale' flag if needed in schema
      })
      .where(eq(table.id, contentId));
  }

  async generateContentReport(): Promise<string> {
    const hierarchy = await this.prioritizeContent();
    
    return `
CONTENT PRIORITIZATION REPORT
Generated: ${new Date().toISOString()}

BREAKING NEWS: ${hierarchy.breakingNews.length} items
${hierarchy.breakingNews.map(item => `  • ${item.title} (${item.priority})`).join('\n')}

LEAD STORIES: ${hierarchy.leadStories.length} items
${hierarchy.leadStories.map(item => `  • ${item.title} (${item.priority})`).join('\n')}

FEATURED CONTENT: ${hierarchy.featuredContent.length} items
TOTAL CONTENT POOL: ${hierarchy.latestContent.length} items

PRIORITY ALGORITHM STATUS: Active
LAST REFRESH: ${new Date().toISOString()}
    `.trim();
  }
}

export const contentPrioritizer = new ContentPrioritizer();