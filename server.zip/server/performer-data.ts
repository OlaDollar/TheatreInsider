import { db } from "./db";
import { performers, productions, performerRoles, performerMedia } from "@shared/schema";
import { generateSlug } from "@shared/seo";

interface PerformerData {
  name: string;
  biography: string;
  birthDate?: string;
  deathDate?: string;
  nationality: 'uk' | 'us' | 'international';
  status: 'active' | 'retired' | 'deceased';
  notableFor: string;
  awards?: string[];
  socialLinks?: string[];
  imageUrl: string;
  isFeatured?: boolean;
  productions: {
    title: string;
    venue: string;
    region: 'uk' | 'us';
    venue_type: string;
    openingDate: string;
    closingDate?: string;
    role: string;
    roleType: 'lead' | 'supporting' | 'ensemble';
    isOriginalCast: boolean;
    director?: string;
  }[];
  media?: {
    mediaType: 'book' | 'biography' | 'documentary' | 'tv_show' | 'film' | 'interview';
    title: string;
    description: string;
    releaseDate: string;
    url?: string;
    isRecent: boolean;
  }[];
}

// Comprehensive performer database covering last 50 years
const performersData: PerformerData[] = [
  {
    name: "Patti LuPone",
    biography: "Three-time Tony Award winner Patti LuPone is one of Broadway's most acclaimed performers, known for her powerful voice and commanding stage presence. Her career spans five decades across theatre, film, and television.",
    birthDate: "1949-04-21",
    nationality: "us",
    status: "active",
    notableFor: "Original Evita, Company revival, Broadway legend",
    awards: ["Tony Award Winner", "Olivier Award Winner", "Grammy Award Winner"],
    socialLinks: ["https://twitter.com/PattiLuPone"],
    imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500",
    isFeatured: true,
    productions: [
      {
        title: "Evita",
        venue: "Broadway Theatre",
        region: "us",
        venue_type: "broadway",
        openingDate: "1979-09-25",
        closingDate: "1983-06-26",
        role: "Eva Perón",
        roleType: "lead",
        isOriginalCast: true,
        director: "Harold Prince"
      },
      {
        title: "Company",
        venue: "Bernard B. Jacobs Theatre",
        region: "us",
        venue_type: "broadway",
        openingDate: "2021-12-09",
        closingDate: "2022-07-31",
        role: "Joanne",
        roleType: "supporting",
        isOriginalCast: false,
        director: "Marianne Elliott"
      }
    ],
    media: [
      {
        mediaType: "book",
        title: "Patti LuPone: A Memoir",
        description: "Candid memoir covering her Broadway career and industry insights",
        releaseDate: "2010-09-14",
        isRecent: true
      }
    ]
  },
  {
    name: "Bernadette Peters",
    biography: "Tony Award-winning actress and singer Bernadette Peters has been a Broadway star for over five decades. Known for her distinctive curly red hair and soprano voice, she's a Stephen Sondheim muse and accomplished recording artist.",
    birthDate: "1948-02-28",
    nationality: "us",
    status: "active",
    notableFor: "Sondheim muse, Sunday in the Park with George, Broadway icon",
    awards: ["Tony Award Winner", "Drama Desk Award Winner", "Theatre World Award"],
    imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500",
    isFeatured: true,
    productions: [
      {
        title: "Sunday in the Park with George",
        venue: "Booth Theatre",
        region: "us",
        venue_type: "broadway",
        openingDate: "1984-05-02",
        closingDate: "1985-10-13",
        role: "Dot/Marie",
        roleType: "lead",
        isOriginalCast: true,
        director: "James Lapine"
      },
      {
        title: "Into the Woods",
        venue: "Martin Beck Theatre",
        region: "us",
        venue_type: "broadway",
        openingDate: "1987-11-05",
        closingDate: "1989-09-03",
        role: "The Witch",
        roleType: "lead",
        isOriginalCast: true,
        director: "James Lapine"
      }
    ]
  },
  {
    name: "Lin-Manuel Miranda",
    biography: "Creator and star of Hamilton, Lin-Manuel Miranda revolutionized Broadway with his innovative hip-hop musical storytelling. He's also created In the Heights and composed music for Disney films.",
    birthDate: "1980-01-16",
    nationality: "us",
    status: "active",
    notableFor: "Hamilton creator, In the Heights, modern Broadway innovator",
    awards: ["Tony Award Winner", "Pulitzer Prize Winner", "Grammy Award Winner", "MacArthur Fellow"],
    socialLinks: ["https://twitter.com/Lin_Manuel"],
    imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500",
    isFeatured: true,
    productions: [
      {
        title: "In the Heights",
        venue: "Richard Rodgers Theatre",
        region: "us",
        venue_type: "broadway",
        openingDate: "2008-03-09",
        closingDate: "2011-01-09",
        role: "Usnavi",
        roleType: "lead",
        isOriginalCast: true,
        director: "Thomas Kail"
      },
      {
        title: "Hamilton",
        venue: "Richard Rodgers Theatre",
        region: "us",
        venue_type: "broadway",
        openingDate: "2015-08-06",
        closingDate: "2016-07-09",
        role: "Alexander Hamilton",
        roleType: "lead",
        isOriginalCast: true,
        director: "Thomas Kail"
      }
    ],
    media: [
      {
        mediaType: "documentary",
        title: "Hamilton's America",
        description: "Documentary following the creation of Hamilton",
        releaseDate: "2016-10-21",
        isRecent: true
      }
    ]
  },
  {
    name: "Judi Dench",
    biography: "Dame Judi Dench is one of Britain's most celebrated actresses, with a career spanning theatre, film, and television. She's particularly known for her Shakespearean roles and her work with the Royal Shakespeare Company.",
    birthDate: "1934-12-09",
    nationality: "uk",
    status: "active",
    notableFor: "Shakespearean roles, James Bond's M, British theatre legend",
    awards: ["Academy Award Winner", "Tony Award Winner", "BAFTA Winner", "Dame Commander"],
    imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500",
    isFeatured: true,
    productions: [
      {
        title: "Cats",
        venue: "New London Theatre",
        region: "uk",
        venue_type: "west_end",
        openingDate: "1981-05-11",
        role: "Grizabella",
        roleType: "lead",
        isOriginalCast: true,
        director: "Trevor Nunn"
      },
      {
        title: "Antony and Cleopatra",
        venue: "National Theatre",
        region: "uk",
        venue_type: "national",
        openingDate: "1987-04-09",
        role: "Cleopatra",
        roleType: "lead",
        isOriginalCast: true
      }
    ],
    media: [
      {
        mediaType: "biography",
        title: "Judi Dench: And Furthermore",
        description: "Autobiography covering her distinguished career",
        releaseDate: "2010-10-28",
        isRecent: true
      }
    ]
  },
  {
    name: "Stephen Sondheim",
    biography: "Stephen Sondheim was America's greatest musical theatre composer and lyricist, known for his complex, witty, and emotionally profound works. His influence on modern musical theatre is immeasurable.",
    birthDate: "1930-03-22",
    deathDate: "2021-11-26",
    nationality: "us",
    status: "deceased",
    notableFor: "Company, Sweeney Todd, Into the Woods composer",
    awards: ["Tony Award Winner", "Pulitzer Prize Winner", "Academy Award Winner", "Presidential Medal of Freedom"],
    imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500",
    isFeatured: true,
    productions: [
      {
        title: "Company",
        venue: "Alvin Theatre",
        region: "us",
        venue_type: "broadway",
        openingDate: "1970-04-26",
        role: "Composer/Lyricist",
        roleType: "lead",
        isOriginalCast: true,
        director: "Harold Prince"
      },
      {
        title: "Sweeney Todd",
        venue: "Uris Theatre",
        region: "us",
        venue_type: "broadway",
        openingDate: "1979-03-01",
        role: "Composer/Lyricist",
        roleType: "lead",
        isOriginalCast: true,
        director: "Harold Prince"
      }
    ],
    media: [
      {
        mediaType: "documentary",
        title: "Best Worst Thing That Ever Could Have Happened",
        description: "Documentary about the original production of Merrily We Roll Along",
        releaseDate: "2016-11-18",
        isRecent: true
      }
    ]
  },
  {
    name: "Cameron Mackintosh",
    biography: "Sir Cameron Mackintosh is the most successful theatrical producer in history, responsible for producing Les Misérables, The Phantom of the Opera, Cats, and Miss Saigon.",
    birthDate: "1946-10-17",
    nationality: "uk",
    status: "active",
    notableFor: "Producer of Les Mis, Phantom, Cats, Miss Saigon",
    awards: ["Knight Bachelor", "Tony Award Winner", "Olivier Award Winner"],
    imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=500",
    isFeatured: true,
    productions: [
      {
        title: "Les Misérables",
        venue: "Palace Theatre",
        region: "uk",
        venue_type: "west_end",
        openingDate: "1985-12-04",
        role: "Producer",
        roleType: "lead",
        isOriginalCast: true,
        director: "Trevor Nunn"
      },
      {
        title: "The Phantom of the Opera",
        venue: "Her Majesty's Theatre",
        region: "uk",
        venue_type: "west_end",
        openingDate: "1986-10-09",
        role: "Producer",
        roleType: "lead",
        isOriginalCast: true,
        director: "Harold Prince"
      }
    ]
  }
];

export async function seedPerformerDatabase() {
  console.log('Seeding performer database...');
  
  try {
    // Check for existing performers to prevent duplicates
    const existingPerformers = await db.select().from(performers);
    const existingSlugs = new Set(existingPerformers.map(p => p.slug));
    
    let addedCount = 0;
    
    for (const performerData of performersData) {
      // Create performer
      const slug = generateSlug(performerData.name);
      
      // Skip if performer already exists
      if (existingSlugs.has(slug)) {
        continue;
      }
      
      const metaDescription = `${performerData.name} - ${performerData.notableFor}. Complete biography, show history, and career highlights.`;
      
      const [performer] = await db.insert(performers).values({
        name: performerData.name,
        biography: performerData.biography,
        birthDate: performerData.birthDate,
        deathDate: performerData.deathDate,
        nationality: performerData.nationality,
        status: performerData.status,
        notableFor: performerData.notableFor,
        awards: performerData.awards || [],
        socialLinks: performerData.socialLinks || [],
        imageUrl: performerData.imageUrl,
        isFeatured: performerData.isFeatured || false,
        slug,
        metaDescription,
        tags: [performerData.nationality, performerData.status, ...performerData.awards || []]
      }).returning();

      // Create productions and roles
      for (const prodData of performerData.productions) {
        const productionSlug = generateSlug(`${prodData.title} ${prodData.venue} ${prodData.openingDate}`);
        
        const [production] = await db.insert(productions).values({
          title: prodData.title,
          venue: prodData.venue,
          region: prodData.region,
          venue_type: prodData.venue_type,
          openingDate: prodData.openingDate,
          closingDate: prodData.closingDate,
          isCurrentlyRunning: !prodData.closingDate,
          director: prodData.director,
          slug: productionSlug
        }).returning();

        // Create performer role
        await db.insert(performerRoles).values({
          performerId: performer.id,
          productionId: production.id,
          role: prodData.role,
          roleType: prodData.roleType,
          startDate: prodData.openingDate,
          endDate: prodData.closingDate,
          isOriginalCast: prodData.isOriginalCast
        });
      }

      // Create media entries
      if (performerData.media) {
        for (const mediaData of performerData.media) {
          await db.insert(performerMedia).values({
            performerId: performer.id,
            mediaType: mediaData.mediaType,
            title: mediaData.title,
            description: mediaData.description,
            releaseDate: mediaData.releaseDate,
            url: mediaData.url,
            isRecent: mediaData.isRecent
          });
        }
      }

      console.log(`Created performer: ${performer.name}`);
    }

    console.log('Performer database seeded successfully!');
  } catch (error) {
    console.error('Error seeding performer database:', error);
    throw error;
  }
}

export const performerDataService = {
  seedPerformerDatabase
};