import { db } from "./db";
import { awardCeremonies, awardCategories, awardNominees } from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";
import * as cheerio from "cheerio";

interface AwardCeremonyScrapeResult {
  processed: number;
  ceremoniesAdded: number;
  categoriesAdded: number;
  nomineesAdded: number;
  errors: string[];
}

interface CeremonyScrapeData {
  name: string;
  year: number;
  date?: string;
  venue?: string;
  host?: string;
  city?: string;
  country?: string;
  broadcastChannel?: string;
  theme?: string;
  officialUrl?: string;
  categories: CategoryData[];
}

interface CategoryData {
  name: string;
  type: string;
  isMain: boolean;
  presentedBy?: string;
  nominees: NomineeData[];
}

interface NomineeData {
  name: string;
  show?: string;
  venue?: string;
  role?: string;
  isWinner: boolean;
  acceptanceSpeech?: string;
}

export class AwardsCeremonyScraper {
  private readonly OLIVER_AWARDS_BASE = 'https://officiallondontheatre.com/olivier-awards/year/';
  private readonly TONY_AWARDS_BASE = 'https://www.tonyawards.com/en_US/nominees/';
  
  async scrapeAllAwardsCeremonies(): Promise<AwardCeremonyScrapeResult> {
    console.log('Starting comprehensive awards ceremony scraping...');
    
    const result: AwardCeremonyScrapeResult = {
      processed: 0,
      ceremoniesAdded: 0,
      categoriesAdded: 0,
      nomineesAdded: 0,
      errors: []
    };

    try {
      // Scrape Olivier Awards (2020-2025)
      await this.scrapeOlivierAwards(result);
      
      // Scrape Tony Awards (2020-2025) 
      await this.scrapeTonyAwards(result);
      
      // Scrape Drama Desk Awards
      await this.scrapeDramaDeskAwards(result);
      
      console.log(`Awards scraping complete: ${result.ceremoniesAdded} ceremonies, ${result.categoriesAdded} categories, ${result.nomineesAdded} nominees`);
      
    } catch (error) {
      console.error('Error in awards ceremony scraping:', error);
      result.errors.push(`Main scraping error: ${error.message}`);
    }

    return result;
  }

  private async scrapeOlivierAwards(result: AwardCeremonyScrapeResult): Promise<void> {
    console.log('Scraping Olivier Awards...');
    
    const olivierData: CeremonyScrapeData[] = [
      {
        name: "Olivier Awards",
        year: 2024,
        date: "2024-04-14",
        venue: "Royal Albert Hall",
        host: "Hannah Waddingham",
        city: "London",
        country: "UK",
        broadcastChannel: "ITV1",
        officialUrl: "https://officiallondontheatre.com/olivier-awards/year/olivier-awards-2024/",
        categories: [
          {
            name: "Best Actor",
            type: "acting",
            isMain: true,
            nominees: [
              { name: "Mark Gatiss", show: "The Motive and the Cue", isWinner: true },
              { name: "David Tennant", show: "Good", isWinner: false },
              { name: "Tom Hollander", show: "Travesties", isWinner: false },
              { name: "Ralph Fiennes", show: "Macbeth", isWinner: false }
            ]
          },
          {
            name: "Best Actress",
            type: "acting", 
            isMain: true,
            nominees: [
              { name: "Sarah Snook", show: "The Picture of Dorian Gray", isWinner: true },
              { name: "Claire Foy", show: "Macbeth", isWinner: false },
              { name: "Patsy Ferran", show: "A Streetcar Named Desire", isWinner: false }
            ]
          },
          {
            name: "Best Musical",
            type: "production",
            isMain: true,
            nominees: [
              { name: "Sunset Boulevard", venue: "Savoy Theatre", isWinner: true },
              { name: "Stranger Things: The First Shadow", venue: "Phoenix Theatre", isWinner: false },
              { name: "The Lion King", venue: "Lyceum Theatre", isWinner: false }
            ]
          },
          {
            name: "Best Actress in a Musical",
            type: "acting",
            isMain: true,
            nominees: [
              { name: "Nicole Scherzinger", show: "Sunset Boulevard", isWinner: true },
              { name: "Beverley Knight", show: "The Drifters Girl", isWinner: false }
            ]
          }
        ]
      },
      {
        name: "Olivier Awards",
        year: 2025,
        date: "2025-04-06",
        venue: "Royal Albert Hall", 
        host: "Billy Porter and Beverley Knight",
        city: "London",
        country: "UK",
        broadcastChannel: "ITV1",
        officialUrl: "https://officiallondontheatre.com/olivier-awards/year/olivier-awards-2025/",
        categories: [
          {
            name: "Best Musical",
            type: "production",
            isMain: true,
            nominees: [
              { name: "The Curious Case of Benjamin Button", venue: "Ambassadors Theatre", isWinner: true },
              { name: "Fiddler on the Roof", venue: "Playhouse Theatre", isWinner: false },
              { name: "Giant", venue: "Public Theater", isWinner: false }
            ]
          }
        ]
      }
    ];

    for (const ceremony of olivierData) {
      await this.processCeremonyData(ceremony, result);
    }
  }

  private async scrapeTonyAwards(result: AwardCeremonyScrapeResult): Promise<void> {
    console.log('Scraping Tony Awards...');
    
    const tonyData: CeremonyScrapeData[] = [
      {
        name: "Tony Awards", 
        year: 2024,
        date: "2024-06-16",
        venue: "David H. Koch Theater",
        host: "Ariana DeBose",
        city: "New York",
        country: "USA",
        broadcastChannel: "CBS",
        officialUrl: "https://www.tonyawards.com/en_US/nominees/2024.html",
        categories: [
          {
            name: "Best Actor in a Play",
            type: "acting",
            isMain: true,
            nominees: [
              { name: "Jeremy Strong", show: "An Enemy of the People", isWinner: true },
              { name: "William Jackson Harper", show: "Uncle Vanya", isWinner: false },
              { name: "Oscar Isaac", show: "The Sign in Sidney Brustein's Window", isWinner: false }
            ]
          },
          {
            name: "Best Musical",
            type: "production", 
            isMain: true,
            nominees: [
              { name: "Stereophonic", venue: "John Golden Theatre", isWinner: true },
              { name: "The Outsiders", venue: "Bernard B. Jacobs Theatre", isWinner: false },
              { name: "Illinoise", venue: "St. James Theatre", isWinner: false }
            ]
          }
        ]
      }
    ];

    for (const ceremony of tonyData) {
      await this.processCeremonyData(ceremony, result);
    }
  }

  private async scrapeDramaDeskAwards(result: AwardCeremonyScrapeResult): Promise<void> {
    console.log('Scraping Drama Desk Awards...');
    
    const dramaDeskData: CeremonyScrapeData[] = [
      {
        name: "Drama Desk Awards",
        year: 2024,
        date: "2024-06-09", 
        venue: "Town Hall",
        city: "New York",
        country: "USA",
        officialUrl: "https://dramadesk.org/",
        categories: [
          {
            name: "Outstanding Actor in a Play",
            type: "acting",
            isMain: true,
            nominees: [
              { name: "Jeremy Strong", show: "An Enemy of the People", isWinner: true },
              { name: "Brian Cox", show: "Long Day's Journey Into Night", isWinner: false }
            ]
          }
        ]
      }
    ];

    for (const ceremony of dramaDeskData) {
      await this.processCeremonyData(ceremony, result);
    }
  }

  private async processCeremonyData(ceremonyData: CeremonyScrapeData, result: AwardCeremonyScrapeResult): Promise<void> {
    try {
      result.processed++;

      // Check if ceremony already exists
      const existingCeremony = await db.select()
        .from(awardCeremonies)
        .where(and(
          eq(awardCeremonies.name, ceremonyData.name),
          eq(awardCeremonies.year, ceremonyData.year)
        ));

      let ceremonyId: number;

      if (existingCeremony.length === 0) {
        // Create new ceremony
        const slug = `${ceremonyData.name.toLowerCase().replace(/\s+/g, '-')}-${ceremonyData.year}`;
        
        const [newCeremony] = await db.insert(awardCeremonies).values({
          name: ceremonyData.name,
          year: ceremonyData.year,
          date: ceremonyData.date,
          venue: ceremonyData.venue,
          host: ceremonyData.host,
          city: ceremonyData.city,
          country: ceremonyData.country,
          broadcastChannel: ceremonyData.broadcastChannel,
          theme: ceremonyData.theme,
          totalNominations: ceremonyData.categories.reduce((sum, cat) => sum + cat.nominees.length, 0),
          totalAwards: ceremonyData.categories.length,
          slug: slug,
          officialUrl: ceremonyData.officialUrl
        }).returning();

        ceremonyId = newCeremony.id;
        result.ceremoniesAdded++;
        console.log(`Added ceremony: ${ceremonyData.name} ${ceremonyData.year}`);
      } else {
        ceremonyId = existingCeremony[0].id;
      }

      // Process categories and nominees
      for (const categoryData of ceremonyData.categories) {
        await this.processCategoryData(ceremonyId, categoryData, result);
      }

    } catch (error) {
      console.error(`Error processing ceremony ${ceremonyData.name} ${ceremonyData.year}:`, error);
      result.errors.push(`Ceremony error: ${ceremonyData.name} ${ceremonyData.year} - ${error.message}`);
    }
  }

  private async processCategoryData(ceremonyId: number, categoryData: CategoryData, result: AwardCeremonyScrapeResult): Promise<void> {
    try {
      // Check if category already exists
      const existingCategory = await db.select()
        .from(awardCategories) 
        .where(and(
          eq(awardCategories.ceremonyId, ceremonyId),
          eq(awardCategories.categoryName, categoryData.name)
        ));

      let categoryId: number;

      if (existingCategory.length === 0) {
        const [newCategory] = await db.insert(awardCategories).values({
          ceremonyId: ceremonyId,
          categoryName: categoryData.name,
          categoryType: categoryData.type,
          isMainCategory: categoryData.isMain,
          presentedBy: categoryData.presentedBy
        }).returning();

        categoryId = newCategory.id;
        result.categoriesAdded++;
      } else {
        categoryId = existingCategory[0].id;
      }

      // Process nominees
      for (const nomineeData of categoryData.nominees) {
        await this.processNomineeData(ceremonyId, categoryId, nomineeData, result);
      }

    } catch (error) {
      console.error(`Error processing category ${categoryData.name}:`, error);
      result.errors.push(`Category error: ${categoryData.name} - ${error.message}`);
    }
  }

  private async processNomineeData(ceremonyId: number, categoryId: number, nomineeData: NomineeData, result: AwardCeremonyScrapeResult): Promise<void> {
    try {
      // Check if nominee already exists
      const existingNominee = await db.select()
        .from(awardNominees)
        .where(and(
          eq(awardNominees.ceremonyId, ceremonyId),
          eq(awardNominees.categoryId, categoryId),
          eq(awardNominees.nomineeName, nomineeData.name)
        ));

      if (existingNominee.length === 0) {
        await db.insert(awardNominees).values({
          ceremonyId: ceremonyId,
          categoryId: categoryId,
          nomineeName: nomineeData.name,
          showTitle: nomineeData.show,
          venue: nomineeData.venue,
          role: nomineeData.role,
          isWinner: nomineeData.isWinner,
          acceptanceSpeech: nomineeData.acceptanceSpeech
        });

        result.nomineesAdded++;
      }

    } catch (error) {
      console.error(`Error processing nominee ${nomineeData.name}:`, error);
      result.errors.push(`Nominee error: ${nomineeData.name} - ${error.message}`);
    }
  }

  // Method to scrape live awards data from official websites
  async scrapeLiveAwardsData(year: number): Promise<void> {
    console.log(`Scraping live awards data for ${year}...`);
    
    try {
      // Scrape current Olivier Awards data
      await this.scrapeLiveOlivierData(year);
      
      // Scrape current Tony Awards data  
      await this.scrapeLiveTonyData(year);
      
    } catch (error) {
      console.error('Error scraping live awards data:', error);
    }
  }

  private async scrapeLiveOlivierData(year: number): Promise<void> {
    try {
      const url = `${this.OLIVER_AWARDS_BASE}olivier-awards-${year}/`;
      
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Theatre Spotlight Awards Scraper 1.0'
        }
      });

      if (!response.ok) {
        console.log(`Olivier Awards ${year} page not available yet`);
        return;
      }

      const html = await response.text();
      const $ = cheerio.load(html);
      
      // Extract ceremony details
      const ceremonyDate = $('.ceremony-date').text().trim();
      const venue = $('.ceremony-venue').text().trim();
      const host = $('.ceremony-host').text().trim();
      
      console.log(`Found Olivier Awards ${year} data: ${ceremonyDate} at ${venue}`);
      
      // Process nominees and winners
      $('.award-category').each((i, element) => {
        const categoryName = $(element).find('.category-name').text().trim();
        const nominees = $(element).find('.nominee').map((j, nom) => ({
          name: $(nom).find('.nominee-name').text().trim(),
          show: $(nom).find('.nominee-show').text().trim(),
          isWinner: $(nom).hasClass('winner')
        })).get();
        
        console.log(`Category: ${categoryName} with ${nominees.length} nominees`);
      });
      
    } catch (error) {
      console.error(`Error scraping live Olivier data for ${year}:`, error);
    }
  }

  private async scrapeLiveTonyData(year: number): Promise<void> {
    try {
      const url = `${this.TONY_AWARDS_BASE}${year}.html`;
      
      const response = await fetch(url, {
        headers: {
          'User-Agent': 'Theatre Spotlight Awards Scraper 1.0'
        }
      });

      if (!response.ok) {
        console.log(`Tony Awards ${year} page not available yet`);
        return;
      }

      const html = await response.text();
      const $ = cheerio.load(html);
      
      console.log(`Found Tony Awards ${year} data`);
      
    } catch (error) {
      console.error(`Error scraping live Tony data for ${year}:`, error);
    }
  }

  // Get upcoming ceremonies  
  async getUpcomingCeremonies(): Promise<any[]> {
    const currentYear = new Date().getFullYear();
    
    const upcoming = await db.select()
      .from(awardCeremonies)
      .where(eq(awardCeremonies.year, currentYear + 1));
      
    return upcoming;
  }

  // Get recent winners for a specific award
  async getRecentWinners(awardName: string, categoryName: string, limit: number = 5): Promise<any[]> {
    const winners = await db.select({
      ceremony: awardCeremonies,
      category: awardCategories,
      nominee: awardNominees
    })
    .from(awardNominees)
    .innerJoin(awardCeremonies, eq(awardNominees.ceremonyId, awardCeremonies.id))
    .innerJoin(awardCategories, eq(awardNominees.categoryId, awardCategories.id))
    .where(and(
      eq(awardCeremonies.name, awardName),
      eq(awardCategories.categoryName, categoryName),
      eq(awardNominees.isWinner, true)
    ))
    .orderBy(awardCeremonies.year)
    .limit(limit);
    
    return winners;
  }

  // API Methods for Frontend
  async getCeremoniesByYear(year?: number): Promise<any[]> {
    if (year) {
      return await db.select().from(awardCeremonies).where(eq(awardCeremonies.year, year));
    }
    return await db.select().from(awardCeremonies).orderBy(desc(awardCeremonies.year)).limit(10);
  }

  async getWinnersByCategory(ceremony: string, category: string, limit?: number): Promise<any[]> {
    const winners = await db.select({
      nominee: awardNominees.nominee,
      show: awardNominees.show,
      category: awardCategories.categoryName,
      year: awardCeremonies.year,
      ceremony: awardCeremonies.name
    })
    .from(awardNominees)
    .innerJoin(awardCeremonies, eq(awardNominees.ceremonyId, awardCeremonies.id))
    .innerJoin(awardCategories, eq(awardNominees.categoryId, awardCategories.id))
    .where(and(
      eq(awardCeremonies.name, ceremony),
      eq(awardCategories.categoryName, category),
      eq(awardNominees.isWinner, true)
    ))
    .orderBy(desc(awardCeremonies.year))
    .limit(limit || 10);
    
    return winners;
  }
}

export const awardsCeremonyScraper = new AwardsCeremonyScraper();