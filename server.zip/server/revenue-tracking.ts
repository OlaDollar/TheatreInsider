import { db } from "./db";
import { analytics } from "../shared/schema";
import { gte, sql } from "drizzle-orm";

interface RevenueStream {
  source: 'advertising' | 'affiliate' | 'subscriptions' | 'sponsorship' | 'merchandise';
  amount: number;
  currency: 'GBP' | 'USD' | 'EUR';
  date: Date;
  description: string;
  paymentMethod: 'bank_transfer' | 'paypal' | 'stripe' | 'direct_deposit';
}

interface CostItem {
  category: 'hosting' | 'domain' | 'software' | 'marketing' | 'content' | 'legal';
  amount: number;
  currency: 'GBP' | 'USD' | 'EUR';
  date: Date;
  description: string;
  recurring: boolean;
  nextPayment?: Date;
}

interface RevenueReport {
  period: string;
  totalRevenue: number;
  totalCosts: number;
  netProfit: number;
  profitMargin: number;
  revenueBreakdown: Record<string, number>;
  costBreakdown: Record<string, number>;
  projectedNextMonth: number;
  bankingDetails: BankingSetup;
}

interface BankingSetup {
  primaryAccount: {
    accountName: string;
    sortCode?: string;
    accountNumber?: string;
    iban?: string;
    swiftCode?: string;
    bank: string;
  };
  paymentMethods: {
    stripe: boolean;
    paypal: boolean;
    directDeposit: boolean;
  };
  taxInfo: {
    vatRegistered: boolean;
    vatNumber?: string;
    taxRate: number;
    nextVatReturn?: Date;
  };
}

export class RevenueTracker {
  private revenueStreams: RevenueStream[] = [];
  private costs: CostItem[] = [];
  
  // Estimated monthly costs for Theatre Spotlight
  private monthlyCosts: CostItem[] = [
    {
      category: 'hosting',
      amount: 30,
      currency: 'USD',
      date: new Date(),
      description: 'Railway + Supabase hosting',
      recurring: true,
      nextPayment: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    },
    {
      category: 'domain',
      amount: 12,
      currency: 'GBP',
      date: new Date(),
      description: 'Domain registration (annual)',
      recurring: true,
      nextPayment: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
    },
    {
      category: 'software',
      amount: 20,
      currency: 'USD',
      date: new Date(),
      description: 'OpenAI API for content generation',
      recurring: true,
      nextPayment: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
    }
  ];

  private bankingSetup: BankingSetup = {
    primaryAccount: {
      accountName: "Theatre Spotlight Media Ltd",
      bank: "TO BE CONFIGURED",
      sortCode: "XX-XX-XX",
      accountNumber: "XXXXXXXX"
    },
    paymentMethods: {
      stripe: true,  // For subscriptions
      paypal: true,  // For affiliate payments
      directDeposit: true  // For advertising revenue
    },
    taxInfo: {
      vatRegistered: false, // Will need to register when revenue > £85k
      taxRate: 0.20, // UK Corporation Tax
      nextVatReturn: undefined
    }
  };

  async trackRevenue(revenue: RevenueStream): Promise<void> {
    this.revenueStreams.push(revenue);
    
    // Store in database
    console.log(`Revenue tracked: ${revenue.source} - £${revenue.amount}`);
    
    // Check if we need to register for VAT
    const yearlyRevenue = await this.getYearlyRevenue();
    if (yearlyRevenue > 85000 && !this.bankingSetup.taxInfo.vatRegistered) {
      await this.sendVATRegistrationAlert();
    }
  }

  async trackCost(cost: CostItem): Promise<void> {
    this.costs.push(cost);
    console.log(`Cost tracked: ${cost.category} - £${cost.amount}`);
  }

  async generateMonthlyReport(year: number, month: number): Promise<RevenueReport> {
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0);
    
    const monthlyRevenue = this.revenueStreams.filter(r => 
      r.date >= startDate && r.date <= endDate
    );
    
    const monthlyCosts = this.costs.filter(c => 
      c.date >= startDate && c.date <= endDate
    );

    const totalRevenue = monthlyRevenue.reduce((sum, r) => sum + r.amount, 0);
    const totalCosts = monthlyCosts.reduce((sum, c) => sum + c.amount, 0);
    const netProfit = totalRevenue - totalCosts;
    const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

    const revenueBreakdown = monthlyRevenue.reduce((acc, r) => {
      acc[r.source] = (acc[r.source] || 0) + r.amount;
      return acc;
    }, {} as Record<string, number>);

    const costBreakdown = monthlyCosts.reduce((acc, c) => {
      acc[c.category] = (acc[c.category] || 0) + c.amount;
      return acc;
    }, {} as Record<string, number>);

    return {
      period: `${year}-${month.toString().padStart(2, '0')}`,
      totalRevenue,
      totalCosts,
      netProfit,
      profitMargin,
      revenueBreakdown,
      costBreakdown,
      projectedNextMonth: totalRevenue * 1.1, // 10% growth estimate
      bankingDetails: this.bankingSetup
    };
  }

  async sendMonthlyRevenueEmail(report: RevenueReport): Promise<void> {
    const emailContent = `
Subject: Theatre Spotlight Monthly Revenue Report - ${report.period}

THEATRE SPOTLIGHT FINANCIAL SUMMARY
Period: ${report.period}

💰 REVENUE PERFORMANCE
Total Revenue: £${report.totalRevenue.toFixed(2)}
Total Costs: £${report.totalCosts.toFixed(2)}
Net Profit: £${report.netProfit.toFixed(2)}
Profit Margin: ${report.profitMargin.toFixed(1)}%

📊 REVENUE BREAKDOWN
${Object.entries(report.revenueBreakdown).map(([source, amount]) => 
  `${source.charAt(0).toUpperCase() + source.slice(1)}: £${amount.toFixed(2)}`
).join('\n')}

💸 COST BREAKDOWN
${Object.entries(report.costBreakdown).map(([category, amount]) => 
  `${category.charAt(0).toUpperCase() + category.slice(1)}: £${amount.toFixed(2)}`
).join('\n')}

🏦 BANKING & PAYMENTS
Primary Account: ${report.bankingDetails.primaryAccount.bank}
Account: ${report.bankingDetails.primaryAccount.accountName}
Sort Code: ${report.bankingDetails.primaryAccount.sortCode}
Account Number: ${report.bankingDetails.primaryAccount.accountNumber}

Payment Methods Active:
- Stripe: ${report.bankingDetails.paymentMethods.stripe ? 'Active' : 'Inactive'}
- PayPal: ${report.bankingDetails.paymentMethods.paypal ? 'Active' : 'Inactive'}
- Direct Deposit: ${report.bankingDetails.paymentMethods.directDeposit ? 'Active' : 'Inactive'}

📈 PROJECTIONS
Next Month Estimate: £${report.projectedNextMonth.toFixed(2)}
Annual Run Rate: £${(report.totalRevenue * 12).toFixed(2)}

${report.bankingDetails.taxInfo.vatRegistered ? 
  `VAT Return Due: ${report.bankingDetails.taxInfo.nextVatReturn}` : 
  'VAT Registration: Not required (under £85k threshold)'
}

---
Report generated automatically by Theatre Spotlight Revenue Tracker
Access full dashboard: https://theatrespotlight.com/admin/revenue
    `;

    console.log('MONTHLY REVENUE EMAIL:');
    console.log(emailContent);
    
    // In production, send actual email
    // await sendEmail({
    //   to: 'owner@theatrespotlight.com',
    //   subject: `Theatre Spotlight Revenue Report - ${report.period}`,
    //   body: emailContent
    // });
  }

  private async getYearlyRevenue(): Promise<number> {
    const oneYearAgo = new Date(Date.now() - 365 * 24 * 60 * 60 * 1000);
    return this.revenueStreams
      .filter(r => r.date >= oneYearAgo)
      .reduce((sum, r) => sum + r.amount, 0);
  }

  private async sendVATRegistrationAlert(): Promise<void> {
    const alertContent = `
🚨 VAT REGISTRATION REQUIRED

Your annual revenue has exceeded £85,000. You must register for VAT within 30 days.

Actions Required:
1. Register with HMRC online
2. Update banking details with VAT number
3. Adjust pricing to include VAT
4. Set up quarterly VAT returns

Next Steps:
- Visit: https://www.gov.uk/vat-registration
- Contact accountant for professional advice
- Update Theatre Spotlight pricing structure

Current Annual Revenue: £${await this.getYearlyRevenue()}
    `;

    console.log('VAT REGISTRATION ALERT:');
    console.log(alertContent);
  }

  async configureBankingDetails(bankingInfo: Partial<BankingSetup>): Promise<void> {
    this.bankingSetup = { ...this.bankingSetup, ...bankingInfo };
    console.log('Banking details updated:', this.bankingSetup);
  }

  async getPaymentIntegrationUrls(): Promise<Record<string, string>> {
    return {
      stripe: 'https://dashboard.stripe.com/register',
      paypal: 'https://www.paypal.com/uk/business/accept-payments',
      googleAdsense: 'https://www.google.com/adsense/start/',
      amazonAssociates: 'https://affiliate-program.amazon.co.uk',
      ticketmasterAffiliates: 'https://affiliates.ticketmaster.com'
    };
  }

  async estimateRevenueAtMilestones(): Promise<Record<string, number>> {
    return {
      '£1000_monthly': 1000,
      '£6000_monthly': 6000,
      '£20000_monthly': 20000,
      'hosting_cost_ratio_1k': (30 / 1000) * 100, // 3%
      'hosting_cost_ratio_6k': (49 / 6000) * 100, // 0.8%
      'hosting_cost_ratio_20k': (120 / 20000) * 100 // 0.6%
    };
  }
}

export const revenueTracker = new RevenueTracker();