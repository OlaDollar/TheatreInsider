/**
 * Theatre Data Scraper
 * Scrapes real-time show data from major UK and US theatre websites
 * Updates every hour to capture new announcements
 */

import cheerio from 'cheerio';
import { db } from './db';
import { shows } from '@shared/schema';
import { eq } from 'drizzle-orm';

interface TheatreSource {
  name: string;
  region: 'uk' | 'us';
  venueType: 'west_end' | 'off_west_end' | 'broadway' | 'off_broadway' | 'regional';
  url: string;
  apiUrl?: string;
  selectors: {
    showTitle?: string;
    venue?: string;
    description?: string;
    dates?: string;
    ticketUrl?: string;
    imageUrl?: string;
    cast?: string;
  };
}

interface ScrapedShow {
  title: string;
  venue: string;
  region: 'uk' | 'us';
  venueType: string;
  genre: string;
  status: 'running' | 'preview' | 'announced' | 'closed';
  description: string;
  ticketUrl: string;
  officialWebsite: string;
  imageUrl?: string;
  director?: string;
  composer?: string;
  cast: string[];
  duration?: string;
  ageRating?: string;
  openingDate?: Date;
  closingDate?: Date;
  popularity: number;
  priceRange?: {
    min: number;
    max: number;
    currency: 'GBP' | 'USD';
  };
  ticketAvailability: 'available' | 'limited' | 'sold_out' | 'not_on_sale';
}

export class TheatreDataScraper {
  private theatreSources: TheatreSource[] = [
    // Major West End Theatres
    {
      name: "Official London Theatre",
      region: "uk",
      venueType: "west_end",
      url: "https://officiallondontheatre.com/shows/",
      selectors: {
        showTitle: ".show-title",
        venue: ".venue-name",
        description: ".show-description",
        dates: ".show-dates",
        ticketUrl: ".book-tickets",
        imageUrl: ".show-image img"
      }
    },
    {
      name: "WhatsOnStage",
      region: "uk",
      venueType: "west_end",
      url: "https://www.whatsonstage.com/london-theatre/",
      selectors: {
        showTitle: ".listing-title",
        venue: ".venue-title",
        description: ".listing-description"
      }
    },
    // Major Broadway Theatres
    {
      name: "Broadway.org",
      region: "us",
      venueType: "broadway",
      url: "https://www.broadway.org/shows/",
      selectors: {
        showTitle: ".show-name",
        venue: ".theatre-name",
        description: ".show-synopsis"
      }
    },
    {
      name: "Playbill Broadway",
      region: "us",
      venueType: "broadway",
      url: "https://www.playbill.com/productions",
      selectors: {
        showTitle: ".bsp-bio-text h3",
        venue: ".bsp-bio-text .venue"
      }
    },
    // Individual Major Theatres - UK
    {
      name: "National Theatre",
      region: "uk",
      venueType: "regional",
      url: "https://www.nationaltheatre.org.uk/whats-on/",
      selectors: {
        showTitle: ".event-title",
        venue: ".venue-name",
        description: ".event-description"
      }
    },
    {
      name: "Royal Shakespeare Company",
      region: "uk",
      venueType: "regional",
      url: "https://www.rsc.org.uk/whats-on/",
      selectors: {
        showTitle: ".production-title",
        venue: ".venue-name",
        description: ".production-description"
      }
    }
  ];

  private majorVenues = {
    uk: [
      "Lyceum Theatre", "His Majesty's Theatre", "Apollo Victoria Theatre",
      "Victoria Palace Theatre", "Phoenix Theatre", "Prince of Wales Theatre",
      "Cambridge Theatre", "Gielgud Theatre", "Duchess Theatre", "Fortune Theatre",
      "Garrick Theatre", "Criterion Theatre", "Aldwych Theatre", "Adelphi Theatre",
      "Duke of York's Theatre", "Noel Coward Theatre", "Palace Theatre",
      "Piccadilly Theatre", "Playhouse Theatre", "Savoy Theatre", "Strand Theatre",
      "Vaudeville Theatre", "Wyndham's Theatre", "Her Majesty's Theatre"
    ],
    us: [
      "Richard Rodgers Theatre", "Minskoff Theatre", "Gershwin Theatre",
      "Majestic Theatre", "Broadhurst Theatre", "Imperial Theatre", "Palace Theatre",
      "St. James Theatre", "Winter Garden Theatre", "Lunt-Fontanne Theatre",
      "Nederlander Theatre", "Ambassador Theatre", "Bernard B. Jacobs Theatre",
      "Brooks Atkinson Theatre", "Eugene O'Neill Theatre", "Hayes Theater",
      "Lyceum Theatre", "Music Box Theatre", "Neil Simon Theatre"
    ]
  };

  async scrapeAllTheatres(): Promise<{ scraped: number; updated: number; newShows: number }> {
    console.log('🎭 Starting comprehensive theatre data scraping...');
    
    let totalScraped = 0;
    let totalUpdated = 0;
    let newShows = 0;

    // Add current West End shows manually since scraping is limited
    const { westEndTheatres } = await import('./west-end-theatres');
    
    for (const theatre of westEndTheatres) {
      try {
        const show: ScrapedShow = {
          title: theatre.currentShow,
          venue: theatre.name,
          region: 'uk',
          venueType: 'west_end',
          genre: 'musical', // Most current West End shows are musicals
          status: 'running',
          description: `${theatre.currentShow} at ${theatre.name}`,
          ticketUrl: `https://example.com/tickets/${theatre.currentShow.toLowerCase().replace(/\s+/g, '-')}`,
          officialWebsite: `https://example.com/show/${theatre.currentShow.toLowerCase().replace(/\s+/g, '-')}`,
          cast: [],
          popularity: 85,
          priceRange: { min: 25, max: 150, currency: 'GBP' },
          ticketAvailability: 'available'
        };

        const result = await this.upsertShow(show);
        totalScraped++;
        if (result.isNew) newShows++;
        if (result.updated) totalUpdated++;
      } catch (error) {
        console.error(`Error adding ${theatre.currentShow}:`, error);
      }
    }

    // Scrape from major theatre listing sites
    for (const source of this.theatreSources) {
      try {
        console.log(`Scraping ${source.name}...`);
        const shows = await this.scrapeTheatreSource(source);
        
        for (const show of shows) {
          const result = await this.upsertShow(show);
          totalScraped++;
          if (result.isNew) newShows++;
          if (result.updated) totalUpdated++;
        }
        
        // Rate limiting
        await this.delay(2000);
      } catch (error) {
        console.error(`Error scraping ${source.name}:`, error);
      }
    }

    // Scrape individual major venues
    await this.scrapeMajorVenues();

    console.log(`🎭 Theatre scraping complete: ${totalScraped} scraped, ${totalUpdated} updated, ${newShows} new`);
    
    return { scraped: totalScraped, updated: totalUpdated, newShows };
  }

  private async scrapeTheatreSource(source: TheatreSource): Promise<ScrapedShow[]> {
    try {
      const response = await fetch(source.url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
        }
      });

      if (!response.ok) {
        console.warn(`Failed to fetch ${source.url}: ${response.status}`);
        return [];
      }

      const html = await response.text();
      const $ = cheerio.load(html);
      const shows: ScrapedShow[] = [];

      // Extract show information using selectors
      $(source.selectors.showTitle || '.show, .production, .event').each((index, element) => {
        try {
          const $el = $(element);
          const title = this.extractText($el, source.selectors.showTitle);
          const venue = this.extractText($el, source.selectors.venue) || source.name;
          
          if (title && title.length > 2) {
            const show: ScrapedShow = {
              title: this.cleanText(title),
              venue: this.cleanText(venue),
              region: source.region,
              venueType: source.venueType,
              genre: this.inferGenre(title),
              status: this.inferStatus(title, $el.text()),
              description: this.cleanText(this.extractText($el, source.selectors.description) || `${title} at ${venue}`),
              ticketUrl: this.extractUrl($el, source.selectors.ticketUrl) || source.url,
              officialWebsite: source.url,
              imageUrl: this.extractImageUrl($el, source.selectors.imageUrl),
              cast: this.extractCast($el, source.selectors.cast),
              duration: this.extractDuration($el.text()),
              ageRating: this.extractAgeRating($el.text()),
              openingDate: this.extractDate($el.text(), 'opening'),
              closingDate: this.extractDate($el.text(), 'closing'),
              popularity: this.calculatePopularity(title, venue),
              priceRange: this.estimatePriceRange(source.region, source.venueType),
              ticketAvailability: this.inferTicketAvailability($el.text())
            };
            
            shows.push(show);
          }
        } catch (error) {
          console.warn('Error parsing show element:', error);
        }
      });

      return shows.slice(0, 50); // Limit to avoid overwhelming the system
    } catch (error) {
      console.error(`Error scraping ${source.url}:`, error);
      return [];
    }
  }

  private async scrapeMajorVenues(): Promise<void> {
    // Scrape specific major venues that have their own websites
    const venueUrls = [
      // UK Major Venues
      { name: "Lyceum Theatre", url: "https://www.lyceum-theatre.co.uk", region: "uk" as const },
      { name: "Apollo Victoria Theatre", url: "https://apollovictoriatheatre.com", region: "uk" as const },
      { name: "Victoria Palace Theatre", url: "https://victoriapalacetheatre.co.uk", region: "uk" as const },
      // US Major Venues
      { name: "Richard Rodgers Theatre", url: "https://www.richardrodgerstheatre.com", region: "us" as const },
      { name: "Gershwin Theatre", url: "https://www.gershwintheatre.com", region: "us" as const }
    ];

    for (const venue of venueUrls) {
      try {
        console.log(`Scraping ${venue.name} directly...`);
        await this.scrapeIndividualVenue(venue);
        await this.delay(1500);
      } catch (error) {
        console.warn(`Could not scrape ${venue.name}:`, error);
      }
    }
  }

  private async scrapeIndividualVenue(venue: { name: string; url: string; region: 'uk' | 'us' }): Promise<void> {
    try {
      const response = await fetch(venue.url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });

      if (!response.ok) return;

      const html = await response.text();
      const $ = cheerio.load(html);

      // Look for current show information
      const showTitles = [
        $('h1').first().text(),
        $('.show-title').first().text(),
        $('.current-show').first().text(),
        $('title').text().split('|')[0]
      ].filter(title => title && title.length > 2);

      if (showTitles.length > 0) {
        const currentShow: ScrapedShow = {
          title: this.cleanText(showTitles[0]),
          venue: venue.name,
          region: venue.region,
          venueType: venue.region === 'uk' ? 'west_end' : 'broadway',
          genre: this.inferGenre(showTitles[0]),
          status: 'running',
          description: this.cleanText($('.description, .synopsis, .about').first().text() || `${showTitles[0]} at ${venue.name}`),
          ticketUrl: venue.url,
          officialWebsite: venue.url,
          cast: [],
          popularity: this.calculatePopularity(showTitles[0], venue.name),
          priceRange: this.estimatePriceRange(venue.region, venue.region === 'uk' ? 'west_end' : 'broadway'),
          ticketAvailability: 'available'
        };

        await this.upsertShow(currentShow);
      }
    } catch (error) {
      console.warn(`Error scraping ${venue.name}:`, error);
    }
  }

  private async upsertShow(show: ScrapedShow): Promise<{ isNew: boolean; updated: boolean }> {
    try {
      // Check if show already exists
      const existingShows = await db.select()
        .from(shows)
        .where(eq(shows.title, show.title));

      const existingShow = existingShows.find(s => 
        s.venue.toLowerCase() === show.venue.toLowerCase()
      );

      const showData = {
        title: show.title,
        venue: show.venue,
        region: show.region,
        category: show.genre,
        status: show.status,
        description: show.description,
        ticketUrl: show.ticketUrl,
        officialWebsite: show.officialWebsite,
        imageUrl: show.imageUrl,
        director: show.director,
        composer: show.composer,
        cast: show.cast,
        duration: show.duration,
        ageRating: show.ageRating,
        openingDate: show.openingDate,
        closingDate: show.closingDate,
        popularity: show.popularity,
        lastUpdated: new Date(),
        slug: this.generateSlug(show.title)
      };

      if (existingShow) {
        // Update existing show
        await db.update(shows)
          .set(showData)
          .where(eq(shows.id, existingShow.id));
        
        return { isNew: false, updated: true };
      } else {
        // Insert new show
        await db.insert(shows).values(showData);
        return { isNew: true, updated: false };
      }
    } catch (error) {
      console.error('Error upserting show:', error);
      return { isNew: false, updated: false };
    }
  }

  // Helper methods
  private extractText($el: cheerio.Cheerio, selector?: string): string {
    if (!selector) return $el.text().trim();
    return $el.find(selector).first().text().trim() || $el.closest(selector).text().trim();
  }

  private extractUrl($el: cheerio.Cheerio, selector?: string): string {
    if (!selector) return '';
    const link = $el.find(selector).first().attr('href') || $el.find('a').first().attr('href');
    return link ? (link.startsWith('http') ? link : `https:${link}`) : '';
  }

  private extractImageUrl($el: cheerio.Cheerio, selector?: string): string {
    if (!selector) return '';
    const img = $el.find(selector).first().attr('src') || $el.find('img').first().attr('src');
    return img ? (img.startsWith('http') ? img : `https:${img}`) : '';
  }

  private extractCast($el: cheerio.Cheerio, selector?: string): string[] {
    if (!selector) return [];
    const castText = $el.find(selector).text() || $el.find('.cast, .starring').text();
    return castText.split(/[,&]/).map(name => name.trim()).filter(name => name.length > 1);
  }

  private cleanText(text: string): string {
    return text.replace(/\s+/g, ' ').trim().replace(/[^\w\s-':.,!?]/g, '');
  }

  private inferGenre(title: string): string {
    const musicalKeywords = ['musical', 'music', 'song', 'sing', 'opera', 'concert'];
    const playKeywords = ['play', 'drama', 'comedy', 'tragedy'];
    
    const lowerTitle = title.toLowerCase();
    
    if (musicalKeywords.some(keyword => lowerTitle.includes(keyword))) {
      return 'musical';
    }
    if (playKeywords.some(keyword => lowerTitle.includes(keyword))) {
      return 'play';
    }
    
    // Default assumption for major theatres
    return 'musical';
  }

  private inferStatus(title: string, fullText: string): 'running' | 'preview' | 'announced' | 'closed' {
    const text = fullText.toLowerCase();
    
    if (text.includes('preview') || text.includes('opening soon')) return 'preview';
    if (text.includes('announced') || text.includes('coming') || text.includes('2025') || text.includes('2026')) return 'announced';
    if (text.includes('closed') || text.includes('final') || text.includes('ended')) return 'closed';
    
    return 'running';
  }

  private extractDuration(text: string): string | undefined {
    const durationMatch = text.match(/(\d+h?\s*\d*m?|\d+\s*hours?\s*\d*\s*minutes?)/i);
    return durationMatch ? durationMatch[1] : undefined;
  }

  private extractAgeRating(text: string): string | undefined {
    const ratingMatch = text.match(/(U|PG|12A?|15|18|G|PG-13|R)/i);
    return ratingMatch ? ratingMatch[1].toUpperCase() : undefined;
  }

  private extractDate(text: string, type: 'opening' | 'closing'): Date | undefined {
    const patterns = [
      /(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/,
      /(\d{1,2}\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{2,4})/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match) {
        const date = new Date(match[1]);
        if (!isNaN(date.getTime())) {
          return date;
        }
      }
    }
    return undefined;
  }

  private calculatePopularity(title: string, venue: string): number {
    // Base popularity on known successful shows and major venues
    const popularShows = ['lion king', 'phantom', 'hamilton', 'wicked', 'chicago', 'mamma mia'];
    const majorVenues = this.majorVenues.uk.concat(this.majorVenues.us);
    
    let popularity = 50; // Base score
    
    if (popularShows.some(show => title.toLowerCase().includes(show))) {
      popularity += 30;
    }
    
    if (majorVenues.some(v => venue.toLowerCase().includes(v.toLowerCase()))) {
      popularity += 20;
    }
    
    return Math.min(100, popularity);
  }

  private estimatePriceRange(region: 'uk' | 'us', venueType: string): { min: number; max: number; currency: 'GBP' | 'USD' } {
    const ranges = {
      uk: {
        west_end: { min: 20, max: 150, currency: 'GBP' as const },
        off_west_end: { min: 15, max: 80, currency: 'GBP' as const },
        regional: { min: 15, max: 60, currency: 'GBP' as const }
      },
      us: {
        broadway: { min: 30, max: 200, currency: 'USD' as const },
        off_broadway: { min: 20, max: 100, currency: 'USD' as const },
        regional: { min: 20, max: 80, currency: 'USD' as const }
      }
    };
    
    return ranges[region][venueType as keyof typeof ranges[typeof region]] || ranges[region].regional;
  }

  private inferTicketAvailability(text: string): 'available' | 'limited' | 'sold_out' | 'not_on_sale' {
    const lowerText = text.toLowerCase();
    
    if (lowerText.includes('sold out') || lowerText.includes('no tickets')) return 'sold_out';
    if (lowerText.includes('limited') || lowerText.includes('few left')) return 'limited';
    if (lowerText.includes('coming soon') || lowerText.includes('on sale')) return 'not_on_sale';
    
    return 'available';
  }

  private generateSlug(title: string): string {
    return title.toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const theatreDataScraper = new TheatreDataScraper();