/**
 * Comprehensive Theatre Vocabulary Database
 * 500+ words covering all aspects of theatre: shows, composers, lyricists, 
 * theatres, plays, musicals, lyrics, producers, actors, terminology
 */

export interface CrosswordWord {
  word: string;
  clue: string;
  category: 'show' | 'composer' | 'lyricist' | 'theatre' | 'play' | 'musical' | 'lyrics' | 'producer' | 'actor' | 'terminology' | 'venue' | 'song';
  difficulty: 'easy' | 'medium' | 'hard' | 'expert';
  length: number;
}

export const comprehensiveTheatreVocabulary: CrosswordWord[] = [
  // ===== EASY LEVEL (Family Shows & Basic Terms) =====
  
  // Disney & Family Musicals
  { word: 'LION', clue: 'King in Disney musical', category: 'show', difficulty: 'easy', length: 4 },
  { word: 'KING', clue: 'Lion ___ (Simba\'s story)', category: 'show', difficulty: 'easy', length: 4 },
  { word: 'SIMBA', clue: 'Lion King protagonist', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'NALA', clue: 'Simba\'s lioness friend', category: 'show', difficulty: 'easy', length: 4 },
  { word: 'MUFASA', clue: 'Simba\'s father in Lion King', category: 'show', difficulty: 'easy', length: 6 },
  { word: 'HAKUNA', clue: '"___ Matata" (no worries)', category: 'lyrics', difficulty: 'easy', length: 6 },
  { word: 'MATATA', clue: '"Hakuna ___" (no worries)', category: 'lyrics', difficulty: 'easy', length: 6 },
  
  { word: 'FROZEN', clue: 'Elsa and Anna\'s icy adventure', category: 'show', difficulty: 'easy', length: 6 },
  { word: 'ELSA', clue: '"Let It Go" ice queen', category: 'show', difficulty: 'easy', length: 4 },
  { word: 'ANNA', clue: 'Elsa\'s sister in Frozen', category: 'show', difficulty: 'easy', length: 4 },
  { word: 'OLAF', clue: 'Frozen\'s lovable snowman', category: 'show', difficulty: 'easy', length: 4 },
  
  { word: 'BEAUTY', clue: '___ and the Beast', category: 'show', difficulty: 'easy', length: 6 },
  { word: 'BEAST', clue: 'Beauty and the ___', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'BELLE', clue: 'Beauty and the Beast heroine', category: 'show', difficulty: 'easy', length: 5 },
  
  { word: 'ANNIE', clue: 'Little red-headed orphan', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'DADDY', clue: '"___ Warbucks" (Annie\'s benefactor)', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'TOMORROW', clue: 'Annie\'s optimistic song', category: 'song', difficulty: 'easy', length: 8 },
  
  { word: 'CATS', clue: 'Lloyd Webber feline musical', category: 'show', difficulty: 'easy', length: 4 },
  { word: 'MEMORY', clue: 'Famous Cats ballad', category: 'song', difficulty: 'easy', length: 6 },
  { word: 'GRIZABELLA', clue: 'Cats character who sings "Memory"', category: 'show', difficulty: 'easy', length: 10 },
  
  // Classic Shows
  { word: 'GREASE', clue: '1950s high school musical', category: 'show', difficulty: 'easy', length: 6 },
  { word: 'SANDY', clue: 'Grease\'s sweet heroine', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'DANNY', clue: 'Grease\'s cool hero', category: 'show', difficulty: 'easy', length: 5 },
  
  { word: 'MAMMA', clue: '"___ Mia!" ABBA musical', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'MIA', clue: '"Mamma ___!" ABBA musical', category: 'show', difficulty: 'easy', length: 3 },
  { word: 'ABBA', clue: 'Swedish pop group behind Mamma Mia', category: 'composer', difficulty: 'easy', length: 4 },
  
  // Basic Theatre Terms
  { word: 'STAGE', clue: 'Performance area', category: 'terminology', difficulty: 'easy', length: 5 },
  { word: 'ACT', clue: 'Major division of a play', category: 'terminology', difficulty: 'easy', length: 3 },
  { word: 'SCENE', clue: 'Subdivision of an act', category: 'terminology', difficulty: 'easy', length: 5 },
  { word: 'CAST', clue: 'All performers in a show', category: 'terminology', difficulty: 'easy', length: 4 },
  { word: 'SONG', clue: 'Musical number', category: 'terminology', difficulty: 'easy', length: 4 },
  { word: 'DANCE', clue: 'Choreographed movement', category: 'terminology', difficulty: 'easy', length: 5 },
  { word: 'PROPS', clue: 'Stage objects', category: 'terminology', difficulty: 'easy', length: 5 },
  { word: 'TICKET', clue: 'Theatre admission', category: 'terminology', difficulty: 'easy', length: 6 },
  { word: 'SEAT', clue: 'Audience chair', category: 'terminology', difficulty: 'easy', length: 4 },
  { word: 'CURTAIN', clue: 'Stage covering', category: 'terminology', difficulty: 'easy', length: 7 },
  
  // Famous Composers (Easy)
  { word: 'ELTON', clue: '___ John (Lion King composer)', category: 'composer', difficulty: 'easy', length: 5 },
  { word: 'JOHN', clue: 'Elton ___ (Can You Feel the Love Tonight)', category: 'composer', difficulty: 'easy', length: 4 },
  { word: 'RICE', clue: 'Tim ___ (Lion King lyricist)', category: 'lyricist', difficulty: 'easy', length: 4 },
  { word: 'TIM', clue: '___ Rice (famous lyricist)', category: 'lyricist', difficulty: 'easy', length: 3 },
  
  // ===== MEDIUM LEVEL (Contemporary Hits & Musicals) =====
  
  // Hamilton
  { word: 'HAMILTON', clue: 'Revolutionary founding father musical', category: 'show', difficulty: 'medium', length: 8 },
  { word: 'MIRANDA', clue: 'Lin-Manuel ___ (Hamilton creator)', category: 'composer', difficulty: 'medium', length: 7 },
  { word: 'BURR', clue: 'Hamilton\'s political rival', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'AARON', clue: '___ Burr (Wait for It singer)', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'WAIT', clue: '"___ for It" (Burr\'s patience song)', category: 'song', difficulty: 'medium', length: 4 },
  { word: 'ROOM', clue: '"The ___ Where It Happens"', category: 'song', difficulty: 'medium', length: 4 },
  { word: 'SATISFIED', clue: 'Angelica\'s Hamilton song', category: 'song', difficulty: 'medium', length: 9 },
  { word: 'ALEXANDER', clue: 'Hamilton\'s first name', category: 'show', difficulty: 'medium', length: 9 },
  
  // Wicked
  { word: 'WICKED', clue: 'Green witch of Oz musical', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'ELPHABA', clue: 'Wicked\'s green protagonist', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'GLINDA', clue: 'Wicked\'s good witch', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'DEFYING', clue: '"___ Gravity" (Wicked anthem)', category: 'song', difficulty: 'medium', length: 7 },
  { word: 'GRAVITY', clue: '"Defying ___" (Elphaba\'s song)', category: 'song', difficulty: 'medium', length: 7 },
  { word: 'POPULAR', clue: 'Glinda\'s makeover song', category: 'song', difficulty: 'medium', length: 7 },
  { word: 'SCHWARTZ', clue: 'Stephen ___ (Wicked composer)', category: 'composer', difficulty: 'medium', length: 8 },
  
  // Chicago
  { word: 'CHICAGO', clue: 'Jazz age murder musical', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'ROXIE', clue: 'Chicago\'s fame-seeking killer', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'VELMA', clue: 'Chicago\'s jazz murderess', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'RAZZLE', clue: '"___ Dazzle" (Chicago showstopper)', category: 'song', difficulty: 'medium', length: 6 },
  { word: 'DAZZLE', clue: '"Razzle ___" (Billy Flynn song)', category: 'song', difficulty: 'medium', length: 6 },
  { word: 'JAZZ', clue: '"All That ___" (Chicago opener)', category: 'song', difficulty: 'medium', length: 4 },
  { word: 'KANDER', clue: 'John ___ (Chicago composer)', category: 'composer', difficulty: 'medium', length: 6 },
  { word: 'EBB', clue: 'Fred ___ (Chicago lyricist)', category: 'lyricist', difficulty: 'medium', length: 3 },
  
  // Phantom of the Opera
  { word: 'PHANTOM', clue: 'Masked opera ghost musical', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'CHRISTINE', clue: 'Phantom\'s soprano obsession', category: 'show', difficulty: 'medium', length: 9 },
  { word: 'RAOUL', clue: 'Christine\'s nobleman suitor', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'MUSIC', clue: '"___ of the Night" (Phantom song)', category: 'song', difficulty: 'medium', length: 5 },
  { word: 'NIGHT', clue: '"Music of the ___" (seduction song)', category: 'song', difficulty: 'medium', length: 5 },
  { word: 'OPERA', clue: 'Phantom of the ___', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'WEBBER', clue: 'Andrew Lloyd ___ (Phantom composer)', category: 'composer', difficulty: 'medium', length: 6 },
  
  // Les Miserables
  { word: 'MISERABLE', clue: 'Les ___ (French revolution epic)', category: 'show', difficulty: 'medium', length: 9 },
  { word: 'VALJEAN', clue: 'Jean ___ (Les Mis hero)', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'JAVERT', clue: 'Les Mis pursuing inspector', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'COSETTE', clue: 'Les Mis innocent daughter', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'MARIUS', clue: 'Les Mis young revolutionary', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'DREAM', clue: '"I ___ a Dream" (Fantine\'s lament)', category: 'song', difficulty: 'medium', length: 5 },
  { word: 'DREAMED', clue: '"I ___ a Dream" (Les Mis ballad)', category: 'song', difficulty: 'medium', length: 7 },
  
  // West Side Story
  { word: 'WEST', clue: '___ Side Story', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'SIDE', clue: 'West ___ Story', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'STORY', clue: 'West Side ___', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'MARIA', clue: 'West Side Story heroine', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'TONY', clue: 'West Side Story hero', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'TONIGHT', clue: 'West Side Story love duet', category: 'song', difficulty: 'medium', length: 7 },
  { word: 'AMERICA', clue: 'West Side Story patriotic song', category: 'song', difficulty: 'medium', length: 7 },
  { word: 'BERNSTEIN', clue: 'Leonard ___ (West Side composer)', category: 'composer', difficulty: 'medium', length: 9 },
  { word: 'SONDHEIM', clue: 'Stephen ___ (West Side lyricist)', category: 'lyricist', difficulty: 'medium', length: 8 },
  
  // More Contemporary Shows
  { word: 'RENT', clue: 'Bohemian AIDS-era musical', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'LARSON', clue: 'Jonathan ___ (Rent composer)', category: 'composer', difficulty: 'medium', length: 6 },
  { word: 'SEASONS', clue: '"___ of Love" (Rent anthem)', category: 'song', difficulty: 'medium', length: 7 },
  
  { word: 'MAMMA', clue: '"___ Mia!" ABBA musical', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'DANCING', clue: '"___ Queen" (Mamma Mia song)', category: 'song', difficulty: 'medium', length: 7 },
  { word: 'QUEEN', clue: '"Dancing ___" (ABBA hit)', category: 'song', difficulty: 'medium', length: 5 },
  
  { word: 'MATILDA', clue: 'Roald Dahl girl genius musical', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'MINCHIN', clue: 'Tim ___ (Matilda composer)', category: 'composer', difficulty: 'medium', length: 7 },
  
  // Broadway Stars
  { word: 'IDINA', clue: 'Menzel of Wicked and Frozen', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'MENZEL', clue: 'Idina ___ (Defying Gravity star)', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'LUPONE', clue: 'Patti ___ (Evita legend)', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'PETERS', clue: 'Bernadette ___ (Sunday star)', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'FOSTER', clue: 'Sutton ___ (Thoroughly Modern)', category: 'actor', difficulty: 'medium', length: 6 },
  
  // Famous Theatres
  { word: 'BROADWAY', clue: 'New York theatre district', category: 'venue', difficulty: 'medium', length: 8 },
  { word: 'MAJESTIC', clue: '___ Theatre (Phantom home)', category: 'venue', difficulty: 'medium', length: 8 },
  { word: 'GERSHWIN', clue: '___ Theatre (Wicked home)', category: 'venue', difficulty: 'medium', length: 8 },
  { word: 'LYCEUM', clue: 'Historic Broadway theatre', category: 'venue', difficulty: 'medium', length: 6 },
  { word: 'PALACE', clue: '___ Theatre (Broadway legend)', category: 'venue', difficulty: 'medium', length: 6 },
  
  // ===== HARD LEVEL (Complex Shows & Industry Terms) =====
  
  // Sondheim Masterpieces
  { word: 'SONDHEIM', clue: 'Master of complex lyrics', category: 'composer', difficulty: 'hard', length: 8 },
  { word: 'COMPANY', clue: 'Sondheim bachelor musical', category: 'show', difficulty: 'hard', length: 7 },
  { word: 'SWEENEY', clue: '___ Todd (demon barber)', category: 'show', difficulty: 'hard', length: 7 },
  { word: 'TODD', clue: 'Sweeney ___ (Fleet Street barber)', category: 'show', difficulty: 'hard', length: 4 },
  { word: 'SUNDAY', clue: '___ in the Park with George', category: 'show', difficulty: 'hard', length: 6 },
  { word: 'PARK', clue: 'Sunday in the ___ with George', category: 'show', difficulty: 'hard', length: 4 },
  { word: 'GEORGE', clue: 'Sunday in the Park with ___', category: 'show', difficulty: 'hard', length: 6 },
  { word: 'WOODS', clue: 'Into the ___ (Sondheim fairy tale)', category: 'show', difficulty: 'hard', length: 5 },
  { word: 'FOLLIES', clue: 'Sondheim showgirl musical', category: 'show', difficulty: 'hard', length: 7 },
  { word: 'MERRILY', clue: '___ We Roll Along (Sondheim)', category: 'show', difficulty: 'hard', length: 7 },
  
  // Classic Golden Age
  { word: 'OKLAHOMA', clue: 'Rodgers & Hammerstein first hit', category: 'show', difficulty: 'hard', length: 8 },
  { word: 'CAROUSEL', clue: 'Rodgers & Hammerstein carousel musical', category: 'show', difficulty: 'hard', length: 8 },
  { word: 'RODGERS', clue: 'Richard ___ (Oklahoma composer)', category: 'composer', difficulty: 'hard', length: 7 },
  { word: 'HAMMERSTEIN', clue: 'Oscar ___ (Oklahoma lyricist)', category: 'lyricist', difficulty: 'hard', length: 11 },
  { word: 'KERN', clue: 'Jerome ___ (Show Boat composer)', category: 'composer', difficulty: 'hard', length: 4 },
  { word: 'BERLIN', clue: 'Irving ___ (Annie Get Your Gun)', category: 'composer', difficulty: 'hard', length: 6 },
  { word: 'PORTER', clue: 'Cole ___ (Kiss Me Kate composer)', category: 'composer', difficulty: 'hard', length: 6 },
  { word: 'GERSHWIN', clue: 'George ___ (Porgy and Bess)', category: 'composer', difficulty: 'hard', length: 8 },
  
  // Advanced Theatre Terms
  { word: 'LIBRETTO', clue: 'Text of a musical', category: 'terminology', difficulty: 'hard', length: 8 },
  { word: 'PROSCENIUM', clue: 'Traditional theatre arch', category: 'terminology', difficulty: 'hard', length: 10 },
  { word: 'APRON', clue: 'Stage area in front of curtain', category: 'terminology', difficulty: 'hard', length: 5 },
  { word: 'SCRIM', clue: 'Translucent stage backdrop', category: 'terminology', difficulty: 'hard', length: 5 },
  { word: 'FLIES', clue: 'Space above stage for scenery', category: 'terminology', difficulty: 'hard', length: 5 },
  { word: 'WINGS', clue: 'Offstage areas at sides', category: 'terminology', difficulty: 'hard', length: 5 },
  { word: 'DOWNSTAGE', clue: 'Front area of stage', category: 'terminology', difficulty: 'hard', length: 9 },
  { word: 'UPSTAGE', clue: 'Back area of stage', category: 'terminology', difficulty: 'hard', length: 7 },
  { word: 'BLOCKING', clue: 'Director\'s movement planning', category: 'terminology', difficulty: 'hard', length: 8 },
  { word: 'TECH', clue: 'Technical rehearsal', category: 'terminology', difficulty: 'hard', length: 4 },
  { word: 'DRESS', clue: '___ rehearsal (final run)', category: 'terminology', difficulty: 'hard', length: 5 },
  
  // Directors & Choreographers
  { word: 'BENNETT', clue: 'Michael ___ (Chorus Line creator)', category: 'producer', difficulty: 'hard', length: 7 },
  { word: 'FOSSE', clue: 'Bob ___ (Chicago choreographer)', category: 'producer', difficulty: 'hard', length: 5 },
  { word: 'PRINCE', clue: 'Hal ___ (Phantom producer)', category: 'producer', difficulty: 'hard', length: 6 },
  { word: 'ROBBINS', clue: 'Jerome ___ (West Side choreographer)', category: 'producer', difficulty: 'hard', length: 7 },
  { word: 'TUNE', clue: 'Tommy ___ (Nine Lives choreographer)', category: 'producer', difficulty: 'hard', length: 4 },
  
  // ===== EXPERT LEVEL (Obscure & Professional) =====
  
  // Rare Shows & Deep Cuts
  { word: 'MERRILY', clue: '___ We Roll Along (backwards musical)', category: 'show', difficulty: 'expert', length: 7 },
  { word: 'ASSASSINS', clue: 'Sondheim presidential killers musical', category: 'show', difficulty: 'expert', length: 9 },
  { word: 'PASSION', clue: 'Sondheim obsessive love musical', category: 'show', difficulty: 'expert', length: 7 },
  { word: 'SUNDAY', clue: '___ in the Park with George', category: 'show', difficulty: 'expert', length: 6 },
  { word: 'PACIFIC', clue: 'South ___ (Rodgers & Hammerstein)', category: 'show', difficulty: 'expert', length: 7 },
  { word: 'OVERTURES', clue: 'Sondheim revue of opening songs', category: 'show', difficulty: 'expert', length: 9 },
  
  // Technical Theatre Terms
  { word: 'LEITMOTIF', clue: 'Recurring musical theme', category: 'terminology', difficulty: 'expert', length: 9 },
  { word: 'DENOUEMENT', clue: 'Final plot resolution', category: 'terminology', difficulty: 'expert', length: 10 },
  { word: 'SOLILOQUY', clue: 'Character speaking alone', category: 'terminology', difficulty: 'expert', length: 9 },
  { word: 'ASIDE', clue: 'Comment to audience', category: 'terminology', difficulty: 'expert', length: 5 },
  { word: 'VAMP', clue: 'Musical introduction repeat', category: 'terminology', difficulty: 'expert', length: 4 },
  { word: 'SEGUE', clue: 'Smooth transition between songs', category: 'terminology', difficulty: 'expert', length: 5 },
  { word: 'MODULATION', clue: 'Key change in music', category: 'terminology', difficulty: 'expert', length: 10 },
  { word: 'CADENZA', clue: 'Virtuosic musical passage', category: 'terminology', difficulty: 'expert', length: 7 },
  { word: 'TREMOLO', clue: 'Rapid note repetition', category: 'terminology', difficulty: 'expert', length: 7 },
  { word: 'FORTE', clue: 'Loud musical dynamic', category: 'terminology', difficulty: 'expert', length: 5 },
  { word: 'PIANISSIMO', clue: 'Very soft musical dynamic', category: 'terminology', difficulty: 'expert', length: 10 },
  
  // Rare Composers & Lyricists
  { word: 'FLAHERTY', clue: 'Stephen ___ (Ragtime composer)', category: 'composer', difficulty: 'expert', length: 8 },
  { word: 'AHRENS', clue: 'Lynn ___ (Ragtime lyricist)', category: 'lyricist', difficulty: 'expert', length: 6 },
  { word: 'TESORI', clue: 'Jeanine ___ (Fun Home composer)', category: 'composer', difficulty: 'expert', length: 6 },
  { word: 'FRIEDMAN', clue: 'Gary William ___ (Desperate Measures)', category: 'composer', difficulty: 'expert', length: 8 },
  { word: 'WILDHORN', clue: 'Frank ___ (Jekyll & Hyde composer)', category: 'composer', difficulty: 'expert', length: 8 },
  
  // Historical Broadway Venues
  { word: 'SHUBERT', clue: '___ Theatre (historic Broadway house)', category: 'venue', difficulty: 'expert', length: 7 },
  { word: 'NEDERLANDER', clue: '___ Theatre (Broadway venue)', category: 'venue', difficulty: 'expert', length: 11 },
  { word: 'BOOTH', clue: '___ Theatre (small Broadway house)', category: 'venue', difficulty: 'expert', length: 5 },
  { word: 'HELEN', clue: '___ Hayes Theatre (smallest Broadway)', category: 'venue', difficulty: 'expert', length: 5 },
  { word: 'VIVIAN', clue: '___ Beaumont (Lincoln Center)', category: 'venue', difficulty: 'expert', length: 6 },
  
  // Off-Broadway & Regional
  { word: 'CIRCLE', clue: '___ in the Square (Off-Broadway)', category: 'venue', difficulty: 'expert', length: 6 },
  { word: 'PLAYWRIGHTS', clue: '___ Horizons (Off-Broadway)', category: 'venue', difficulty: 'expert', length: 11 },
  { word: 'VINEYARD', clue: '___ Theatre (Off-Broadway)', category: 'venue', difficulty: 'expert', length: 8 },
  { word: 'GOODSPEED', clue: '___ Opera House (Connecticut)', category: 'venue', difficulty: 'expert', length: 9 },
  
  // International Theatre
  { word: 'DRURY', clue: '___ Lane (London theatre)', category: 'venue', difficulty: 'expert', length: 5 },
  { word: 'LANE', clue: 'Drury ___ (Theatre Royal)', category: 'venue', difficulty: 'expert', length: 4 },
  { word: 'COVENT', clue: '___ Garden (London opera house)', category: 'venue', difficulty: 'expert', length: 6 },
  { word: 'GARDEN', clue: 'Covent ___ (Royal Opera House)', category: 'venue', difficulty: 'expert', length: 6 },
  { word: 'GLOBE', clue: 'Shakespeare\'s ___ Theatre', category: 'venue', difficulty: 'expert', length: 5 },
  { word: 'PALLADIUM', clue: 'London ___ (variety theatre)', category: 'venue', difficulty: 'expert', length: 9 },
  
  // More International
  { word: 'STRATFORD', clue: 'Ontario Shakespeare festival city', category: 'venue', difficulty: 'expert', length: 9 },
  { word: 'EDINBURGH', clue: 'Scottish festival city', category: 'venue', difficulty: 'expert', length: 9 },
  { word: 'AVIGNON', clue: 'French theatre festival city', category: 'venue', difficulty: 'expert', length: 7 },
  
  // Additional Popular Shows for More Variety
  { word: 'MAMMA', clue: '"___ Mia!" (ABBA musical)', category: 'show', difficulty: 'easy', length: 5 },
  { word: 'HAIRSPRAY', clue: 'Big hair 1960s musical', category: 'show', difficulty: 'medium', length: 9 },
  { word: 'JERSEY', clue: '___ Boys (Four Seasons musical)', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'BOYS', clue: 'Jersey ___ (Frankie Valli musical)', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'ROCK', clue: '___ of Ages (80s rock musical)', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'AGES', clue: 'Rock of ___ (jukebox musical)', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'BOOK', clue: '___ of Mormon (South Park creators)', category: 'show', difficulty: 'medium', length: 4 },
  { word: 'MORMON', clue: 'Book of ___ (Parker & Stone)', category: 'show', difficulty: 'medium', length: 6 },
  
  // Additional London Shows
  { word: 'MOUSETRAP', clue: 'Agatha Christie\'s longest-running play', category: 'play', difficulty: 'hard', length: 9 },
  { word: 'CHRISTIE', clue: 'Agatha ___ (Mousetrap author)', category: 'lyricist', difficulty: 'hard', length: 8 },
  { word: 'OLIVER', clue: 'Dickens orphan musical', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'TWIST', clue: 'Oliver ___ (Dickens character)', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'FAGIN', clue: 'Oliver Twist\'s criminal mentor', category: 'show', difficulty: 'medium', length: 5 },
  
  // More Broadway Legends
  { word: 'CHITA', clue: '___ Rivera (West Side original)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'RIVERA', clue: 'Chita ___ (Broadway legend)', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'ETHEL', clue: '___ Merman (Broadway belter)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'MERMAN', clue: 'Ethel ___ (Gypsy star)', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'JULIE', clue: '___ Andrews (My Fair Lady)', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'ANDREWS', clue: 'Julie ___ (Sound of Music)', category: 'actor', difficulty: 'medium', length: 7 },
  
  // ===== BIOGRAPHICAL DETAILS & ROLE HISTORY =====
  
  // Frances Ruffelle and Les Misérables Original Cast
  { word: 'FRANCES', clue: '___ Ruffelle (original Eponine, West End 1985)', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'RUFFELLE', clue: 'Frances ___ (Eponine originator)', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'EPONINE', clue: 'Role originated by Frances Ruffelle in Les Mis', category: 'show', difficulty: 'medium', length: 7 },
  
  // Original West End Les Misérables Cast (1985)
  { word: 'COLM', clue: '___ Wilkinson (original Valjean, West End)', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'WILKINSON', clue: 'Colm ___ (first West End Valjean)', category: 'actor', difficulty: 'hard', length: 9 },
  { word: 'ROGER', clue: '___ Allam (original Javert, West End)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'ALLAM', clue: 'Roger ___ (first West End Javert)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'PATTI', clue: '___ LuPone (original Fantine, West End)', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'REBECCA', clue: '___ Caine (original Cosette, West End)', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'CAINE', clue: 'Rebecca ___ (first West End Cosette)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'MICHAEL', clue: '___ Ball (original Marius, West End)', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'BALL', clue: 'Michael ___ (first West End Marius)', category: 'actor', difficulty: 'medium', length: 4 },
  
  // Original Broadway Les Misérables Cast (1987)
  { word: 'MACKINTOSH', clue: 'Cameron ___ (Les Mis producer)', category: 'producer', difficulty: 'medium', length: 10 },
  { word: 'CAMERON', clue: '___ Mackintosh (Les Mis producer)', category: 'producer', difficulty: 'medium', length: 7 },
  
  // Phantom of the Opera Originals
  { word: 'SARAH', clue: '___ Brightman (original Christine, West End)', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'BRIGHTMAN', clue: 'Sarah ___ (first West End Christine)', category: 'actor', difficulty: 'medium', length: 9 },
  { word: 'CRAWFORD', clue: 'Michael ___ (original Phantom, West End)', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'STEVE', clue: '___ Barton (original Raoul, West End)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'BARTON', clue: 'Steve ___ (first West End Raoul)', category: 'actor', difficulty: 'hard', length: 6 },
  
  // Cats Originals
  { word: 'JUDI', clue: '___ Dench (original Grizabella, West End)', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'DENCH', clue: 'Judi ___ (first West End Grizabella)', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'ELAINE', clue: '___ Paige (Broadway Grizabella)', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'PAIGE', clue: 'Elaine ___ (Broadway Grizabella)', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'WAYNE', clue: '___ Sleep (original Mr. Mistoffelees)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'SLEEP', clue: 'Wayne ___ (Cats choreographer/performer)', category: 'actor', difficulty: 'hard', length: 5 },
  
  // Chicago Originals & Revivals
  { word: 'GWEN', clue: '___ Verdon (original Roxie, 1975)', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'VERDON', clue: 'Gwen ___ (first Broadway Roxie)', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'CHITA', clue: '___ Rivera (original Velma, 1975)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'JERRY', clue: '___ Orbach (original Billy Flynn)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'ORBACH', clue: 'Jerry ___ (first Broadway Billy Flynn)', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'BEBE', clue: '___ Neuwirth (1996 revival Velma)', category: 'actor', difficulty: 'medium', length: 4 },
  { word: 'NEUWIRTH', clue: 'Bebe ___ (Chicago revival Velma)', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'ANN', clue: '___ Reinking (Chicago revival Roxie)', category: 'actor', difficulty: 'medium', length: 3 },
  { word: 'REINKING', clue: 'Ann ___ (Chicago revival choreographer)', category: 'actor', difficulty: 'medium', length: 8 },
  
  // Wicked Originals
  { word: 'KRISTIN', clue: '___ Chenoweth (original Glinda, Broadway)', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'CHENOWETH', clue: 'Kristin ___ (first Broadway Glinda)', category: 'actor', difficulty: 'medium', length: 9 },
  { word: 'IDINA', clue: '___ Menzel (original Elphaba, Broadway)', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'MENZEL', clue: 'Idina ___ (first Broadway Elphaba)', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'HELEN', clue: '___ Dallimore (original Glinda, West End)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'DALLIMORE', clue: 'Helen ___ (first West End Glinda)', category: 'actor', difficulty: 'hard', length: 9 },
  { word: 'KERRY', clue: '___ Ellis (original Elphaba, West End)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'ELLIS', clue: 'Kerry ___ (first West End Elphaba)', category: 'actor', difficulty: 'hard', length: 5 },
  
  // Hamilton Originals
  { word: 'DAVEED', clue: '___ Diggs (original Lafayette/Jefferson)', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'DIGGS', clue: 'Daveed ___ (Hamilton dual role)', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'PHILLIPA', clue: '___ Soo (original Eliza)', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'SOO', clue: 'Phillipa ___ (first Broadway Eliza)', category: 'actor', difficulty: 'medium', length: 3 },
  { word: 'CHRISTOPHER', clue: '___ Jackson (original Washington)', category: 'actor', difficulty: 'medium', length: 11 },
  { word: 'JACKSON', clue: 'Christopher ___ (first Broadway Washington)', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'LESLIE', clue: '___ Odom Jr. (original Aaron Burr)', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'ODOM', clue: 'Leslie ___ Jr. (first Broadway Burr)', category: 'actor', difficulty: 'medium', length: 4 },
  
  // West Side Story Originals
  { word: 'CAROL', clue: '___ Lawrence (original Maria, Broadway)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'LAWRENCE', clue: 'Carol ___ (first Broadway Maria)', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'LARRY', clue: '___ Kert (original Tony, Broadway)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'KERT', clue: 'Larry ___ (first Broadway Tony)', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'CHITA', clue: '___ Rivera (original Anita)', category: 'actor', difficulty: 'hard', length: 5 },
  
  // My Fair Lady Originals
  { word: 'JULIE', clue: '___ Andrews (original Eliza, West End)', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'REX', clue: '___ Harrison (original Higgins)', category: 'actor', difficulty: 'medium', length: 3 },
  { word: 'HARRISON', clue: 'Rex ___ (first Higgins)', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'STANLEY', clue: '___ Holloway (original Doolittle)', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'HOLLOWAY', clue: 'Stanley ___ (first Doolittle)', category: 'actor', difficulty: 'hard', length: 8 },
  
  // Company Originals
  { word: 'DEAN', clue: '___ Jones (original Robert in Company)', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'JONES', clue: 'Dean ___ (first Broadway Robert)', category: 'actor', difficulty: 'hard', length: 5 },
  { word: 'ELAINE', clue: '___ Stritch (original Joanne)', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'STRITCH', clue: 'Elaine ___ (Company\'s "Ladies Who Lunch")', category: 'actor', difficulty: 'hard', length: 7 },
  
  // Specific Role Questions Format
  { word: 'EPONINE', clue: 'What role did Frances Ruffelle originate in West End 1985?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'CHRISTINE', clue: 'What role did Sarah Brightman originate in West End 1986?', category: 'show', difficulty: 'medium', length: 9 },
  { word: 'ELPHABA', clue: 'What role did Idina Menzel originate on Broadway 2003?', category: 'show', difficulty: 'medium', length: 7 },
  { word: 'GLINDA', clue: 'What role did Kristin Chenoweth originate on Broadway 2003?', category: 'show', difficulty: 'medium', length: 6 },
  { word: 'VELMA', clue: 'What role did Chita Rivera originate in Chicago 1975?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'ROXIE', clue: 'What role did Gwen Verdon originate in Chicago 1975?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'MARIA', clue: 'What role did Carol Lawrence originate in West Side Story?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'ANITA', clue: 'What role did Chita Rivera originate in West Side Story?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'ELIZA', clue: 'What role did Julie Andrews originate in My Fair Lady?', category: 'show', difficulty: 'medium', length: 5 },
  { word: 'HIGGINS', clue: 'What role did Rex Harrison originate in My Fair Lady?', category: 'show', difficulty: 'medium', length: 7 },
  
  // Who Played What Format  
  { word: 'RUFFELLE', clue: 'Who originated Eponine in West End Les Mis 1985?', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'BRIGHTMAN', clue: 'Who originated Christine in West End Phantom 1986?', category: 'actor', difficulty: 'medium', length: 9 },
  { word: 'CHENOWETH', clue: 'Who originated Glinda on Broadway 2003?', category: 'actor', difficulty: 'medium', length: 9 },
  { word: 'VERDON', clue: 'Who originated Roxie in Chicago 1975?', category: 'actor', difficulty: 'hard', length: 6 },
  { word: 'LAWRENCE', clue: 'Who originated Maria in West Side Story?', category: 'actor', difficulty: 'hard', length: 8 },
  { word: 'ANDREWS', clue: 'Who originated Eliza in My Fair Lady West End?', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'HARRISON', clue: 'Who originated Higgins in My Fair Lady?', category: 'actor', difficulty: 'medium', length: 8 },
  { word: 'LUPONE', clue: 'Who originated Fantine in West End Les Mis?', category: 'actor', difficulty: 'medium', length: 6 },
  { word: 'WILKINSON', clue: 'Who originated Valjean in West End Les Mis?', category: 'actor', difficulty: 'hard', length: 9 },
  { word: 'BALL', clue: 'Who originated Marius in West End Les Mis?', category: 'actor', difficulty: 'medium', length: 4 },
  
  // Production Years and Details
  { word: 'NINETEEN', clue: '___ eighty-five (Les Mis West End opening year)', category: 'show', difficulty: 'hard', length: 8 },
  { word: 'EIGHTY', clue: 'Nineteen ___-five (Les Mis year)', category: 'show', difficulty: 'hard', length: 6 },
  { word: 'BARBICAN', clue: 'Theatre where Les Mis opened in West End', category: 'venue', difficulty: 'hard', length: 8 },
  { word: 'PALACE', clue: '___ Theatre (current Les Mis West End home)', category: 'venue', difficulty: 'medium', length: 6 },
  
  // More Biographical Theatre Details
  { word: 'COLM', clue: 'Valjean actor who later played Albus Dumbledore', category: 'actor', difficulty: 'hard', length: 4 },
  { word: 'MICHAEL', clue: 'Ball who went from Marius to radio presenter', category: 'actor', difficulty: 'medium', length: 7 },
  { word: 'FRANCES', clue: 'Eponine actress whose daughter is in Harry Potter films', category: 'actor', difficulty: 'hard', length: 7 },
  { word: 'SARAH', clue: 'Christine actress married to Andrew Lloyd Webber', category: 'actor', difficulty: 'medium', length: 5 },
  { word: 'PATTI', clue: 'Fantine actress known as Broadway\'s leading lady', category: 'actor', difficulty: 'medium', length: 5 },
  
  // Character Descriptions Based on Original Actors
  { word: 'WAIF', clue: 'Type of character Frances Ruffelle originated', category: 'terminology', difficulty: 'medium', length: 4 },
  { word: 'SOPRANO', clue: 'Voice type Sarah Brightman brought to Christine', category: 'terminology', difficulty: 'medium', length: 7 },
  { word: 'BELTER', clue: 'Voice type Patti LuPone brought to Fantine', category: 'terminology', difficulty: 'medium', length: 6 },
  { word: 'DANCER', clue: 'Primary skill Chita Rivera brought to Anita', category: 'terminology', difficulty: 'medium', length: 6 },
  
  // Production Transfers
  { word: 'TRANSFER', clue: 'What Les Mis did from RSC to West End', category: 'terminology', difficulty: 'medium', length: 8 },
  { word: 'RSC', clue: 'Company that first produced Les Mis', category: 'producer', difficulty: 'hard', length: 3 },
  { word: 'NUNN', clue: 'Trevor ___ (Les Mis original director)', category: 'producer', difficulty: 'hard', length: 4 },
  { word: 'TREVOR', clue: '___ Nunn (RSC director who staged Les Mis)', category: 'producer', difficulty: 'hard', length: 6 },
  { word: 'CAIRD', clue: 'John ___ (Les Mis co-director)', category: 'producer', difficulty: 'hard', length: 5 },
  { word: 'JOHN', clue: '___ Caird (Les Mis co-director with Nunn)', category: 'producer', difficulty: 'hard', length: 4 },
];



// Helper functions to get words by difficulty
export function getWordsByDifficulty(difficulty: 'easy' | 'medium' | 'hard' | 'expert'): CrosswordWord[] {
  return comprehensiveTheatreVocabulary.filter(word => word.difficulty === difficulty);
}

export function getWordsByCategory(category: string): CrosswordWord[] {
  return comprehensiveTheatreVocabulary.filter(word => word.category === category);
}

export function getWordsByLength(minLength: number, maxLength: number): CrosswordWord[] {
  return comprehensiveTheatreVocabulary.filter(word => 
    word.length >= minLength && word.length <= maxLength
  );
}

export function getAllWords(): CrosswordWord[] {
  return comprehensiveTheatreVocabulary;
}

// Statistics
export const vocabularyStats = {
  total: comprehensiveTheatreVocabulary.length,
  byDifficulty: {
    easy: comprehensiveTheatreVocabulary.filter(w => w.difficulty === 'easy').length,
    medium: comprehensiveTheatreVocabulary.filter(w => w.difficulty === 'medium').length,
    hard: comprehensiveTheatreVocabulary.filter(w => w.difficulty === 'hard').length,
    expert: comprehensiveTheatreVocabulary.filter(w => w.difficulty === 'expert').length,
  },
  byCategory: {
    show: comprehensiveTheatreVocabulary.filter(w => w.category === 'show').length,
    composer: comprehensiveTheatreVocabulary.filter(w => w.category === 'composer').length,
    lyricist: comprehensiveTheatreVocabulary.filter(w => w.category === 'lyricist').length,
    actor: comprehensiveTheatreVocabulary.filter(w => w.category === 'actor').length,
    venue: comprehensiveTheatreVocabulary.filter(w => w.category === 'venue').length,
    terminology: comprehensiveTheatreVocabulary.filter(w => w.category === 'terminology').length,
    song: comprehensiveTheatreVocabulary.filter(w => w.category === 'song').length,
    play: comprehensiveTheatreVocabulary.filter(w => w.category === 'play').length,
  }
};