import { db } from "./db";

interface TheatreFact {
  id: string;
  date: string;
  type: 'show' | 'performer' | 'venue' | 'history';
  title: string;
  fact: string;
  relatedShow?: string;
  relatedPerformer?: string;
  imageUrl?: string;
  source?: string;
}

export class TheatreFactsGenerator {
  private facts: Omit<TheatreFact, 'id' | 'date'>[] = [
    {
      type: 'show',
      title: 'The Lion King',
      fact: 'The Lion King is the highest-grossing Broadway show of all time, having earned over $1.9 billion since opening in 1997. The show uses 232 puppets, including the massive elephant that requires three puppeteers to operate.',
      relatedShow: 'The Lion King',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'performer',
      title: 'Patti LuPone',
      fact: 'Patti LuPone was banned from attending Gypsy performances at Lincoln Center after publicly criticizing the production. She later reconciled with the theatre community and returned to triumph in Company at age 72.',
      relatedPerformer: 'Patti LuPone',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'show',
      title: 'Hamilton',
      fact: 'Lin-Manuel Miranda wrote the opening number of Hamilton in 2008 while reading Ron Chernow\'s biography on vacation. The entire musical took seven years to complete and features 46 songs with intricate rap lyrics.',
      relatedShow: 'Hamilton',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'performer',
      title: 'Bernadette Peters',
      fact: 'Bernadette Peters has been nominated for Tony Awards in four different decades (1970s, 1980s, 1990s, and 2000s). She\'s known for her distinctive curly red hair and her close collaboration with Stephen Sondheim.',
      relatedPerformer: 'Bernadette Peters',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'show',
      title: 'The Phantom of the Opera',
      fact: 'The Phantom of the Opera ran for 35 years on Broadway (1988-2023), making it the longest-running show in Broadway history. The chandelier weighs one ton and is lowered over the audience during every performance.',
      relatedShow: 'The Phantom of the Opera',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'venue',
      title: 'Theatre Royal Drury Lane',
      fact: 'Theatre Royal Drury Lane is one of London\'s oldest theatres, dating back to 1663. It\'s famously haunted by the "Man in Grey," a 18th-century ghost who appears in the upper circle and is considered good luck for productions.',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'history',
      title: 'Broadway Origins',
      fact: 'Broadway got its name from the Dutch "Breede weg" meaning "broad way." The theatre district wasn\'t established until the early 1900s when Oscar Hammerstein I built the Republic Theatre (now New Amsterdam Theatre).',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'show',
      title: 'Cats',
      fact: 'Cats was based on T.S. Eliot\'s "Old Possum\'s Book of Practical Cats." Andrew Lloyd Webber convinced Eliot\'s widow to let him use the poems by promising the musical would be "absolutely faithful" to the original text.',
      relatedShow: 'Cats',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'performer',
      title: 'Idina Menzel',
      fact: 'Idina Menzel originated both Maureen in Rent and Elphaba in Wicked. Her high F# at the end of "Defying Gravity" was so demanding that understudies were given permission to transpose it down if needed.',
      relatedPerformer: 'Idina Menzel',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'show',
      title: 'Chicago',
      fact: 'Chicago was initially a flop when it opened in 1975, closing after just 936 performances. The 1996 revival became one of Broadway\'s longest-running shows, proving that sometimes timing is everything in theatre.',
      relatedShow: 'Chicago',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'performer',
      title: 'Stephen Sondheim',
      fact: 'Stephen Sondheim was mentored by Oscar Hammerstein II, who lived near Sondheim\'s family. Hammerstein would give young Stephen assignments like "write a musical version of a play you admire" to develop his skills.',
      relatedPerformer: 'Stephen Sondheim',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'venue',
      title: 'Palace Theatre',
      fact: 'The Palace Theatre on Broadway was once considered the ultimate vaudeville venue. Playing the Palace was the pinnacle of a vaudeville performer\'s career, leading to the phrase "playing the Palace."',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'show',
      title: 'Wicked',
      fact: 'Wicked\'s "Defying Gravity" requires the actress playing Elphaba to be lifted 20 feet above the stage while singing. The hydraulic lift system is so complex it requires its own dedicated technician for every performance.',
      relatedShow: 'Wicked',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'history',
      title: 'Tony Awards',
      fact: 'The Tony Awards are named after Antoinette "Tony" Perry, a director and producer who championed new American theatre. The first ceremony in 1947 was held at the Waldorf-Astoria Hotel with no television coverage.',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'performer',
      title: 'Angela Lansbury',
      fact: 'Angela Lansbury won five Tony Awards across six decades, from 1966 to 2009. She was the oldest performer to win a Tony for Best Featured Actress at age 83 for "Blithe Spirit."',
      relatedPerformer: 'Angela Lansbury',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'show',
      title: 'Les Misérables',
      fact: 'Les Misérables was initially panned by critics in London but became a global phenomenon. The show has been seen by over 130 million people worldwide and translated into 22 languages.',
      relatedShow: 'Les Misérables',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'venue',
      title: 'Lyceum Theatre',
      fact: 'The Lyceum Theatre in London\'s West End has been home to The Lion King since 1999. The theatre was built in 1834 and has survived two World Wars, making it one of London\'s most resilient venues.',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'performer',
      title: 'Hugh Jackman',
      fact: 'Hugh Jackman is the only person to have hosted the Tony Awards four times. His 2004 opening number included a surprise appearance by Anne Hathaway, and he famously sang while suspended above the audience.',
      relatedPerformer: 'Hugh Jackman',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'show',
      title: 'Mamma Mia!',
      fact: 'Mamma Mia! has grossed over $4 billion worldwide across all productions, making it one of the most successful musicals ever. The show uses 22 ABBA songs and spawned two successful film adaptations.',
      relatedShow: 'Mamma Mia!',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'history',
      title: 'West End Origins',
      fact: 'London\'s West End theatre district began in the 17th century when Charles II lifted the ban on theatre. The area got its name because it was literally the western end of the City of London.',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    },
    {
      type: 'performer',
      title: 'Judi Dench',
      fact: 'Dame Judi Dench made her professional debut in 1957 and is still performing today. She\'s one of the few actors to have won an Oscar, Tony, Emmy, and BAFTA Award, achieving the coveted EGOT status.',
      relatedPerformer: 'Judi Dench',
      imageUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&h=300'
    }
  ];

  async getTodaysFact(): Promise<TheatreFact> {
    const today = new Date().toISOString().split('T')[0];
    const dayOfYear = this.getDayOfYear(new Date());
    const factIndex = dayOfYear % this.facts.length;
    
    const selectedFact = this.facts[factIndex];
    
    return {
      id: `fact-${today}`,
      date: today,
      ...selectedFact
    };
  }

  async getFactForDate(date: string): Promise<TheatreFact> {
    const targetDate = new Date(date);
    const dayOfYear = this.getDayOfYear(targetDate);
    const factIndex = dayOfYear % this.facts.length;
    
    const selectedFact = this.facts[factIndex];
    
    return {
      id: `fact-${date}`,
      date,
      ...selectedFact
    };
  }

  private getDayOfYear(date: Date): number {
    const start = new Date(date.getFullYear(), 0, 0);
    const diff = date.getTime() - start.getTime();
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  }

  async addCustomFact(fact: Omit<TheatreFact, 'id' | 'date'>): Promise<void> {
    this.facts.push(fact);
  }
}

export const theatreFactsGenerator = new TheatreFactsGenerator();