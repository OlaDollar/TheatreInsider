import { CrosswordPuzzle, CrosswordClue, TheatreAnswer } from '@shared/schema';

/**
 * Professional crossword constructor following standard crossword construction rules:
 * 1. Words must intersect at single letters only
 * 2. No two words can run parallel adjacent to each other
 * 3. Grid must have rotational symmetry
 * 4. Black squares should be minimized
 * 5. All letters must be part of both an across and down answer
 */
export class CrosswordConstructor {
  private gridSize = 15;
  
  constructor() {}

  private seededRandom(seed: number) {
    return function() {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };
  }

  async constructCrossword(answers: TheatreAnswer[], difficulty: 'easy' | 'medium' | 'hard', date: string): Promise<CrosswordPuzzle> {
    // Sort answers by length and difficulty appropriateness
    const sortedAnswers = this.selectOptimalAnswers(answers, difficulty);
    
    // Use difficulty as seed to ensure different grids
    const seed = difficulty === 'easy' ? 123 : difficulty === 'medium' ? 456 : 789;
    const dateSeed = parseInt(date.replace(/-/g, '')) % 1000;
    Math.random = this.seededRandom(seed * 100 + dateSeed);
    
    // Generate multiple grids and select the best one
    let bestGrid = null;
    let maxWords = 0;
    
    for (let attempt = 0; attempt < 8; attempt++) {
      const grid = this.constructGrid(sortedAnswers, difficulty);
      if (grid && grid.placedWords.length > maxWords) {
        bestGrid = grid;
        maxWords = grid.placedWords.length;
      }
    }
    
    if (!bestGrid) {
      // Fallback to simpler construction
      bestGrid = this.constructSimpleGrid(sortedAnswers, difficulty);
    }
    
    return this.formatPuzzle(bestGrid, difficulty, date);
  }

  private selectOptimalAnswers(answers: TheatreAnswer[], difficulty: 'easy' | 'medium' | 'hard'): TheatreAnswer[] {
    // Filter by difficulty with appropriate word lengths
    const difficultyFilter = {
      'easy': (a: TheatreAnswer) => a.difficulty === 'easy' && a.word.length >= 3 && a.word.length <= 8,
      'medium': (a: TheatreAnswer) => (a.difficulty === 'medium' || a.difficulty === 'easy') && a.word.length >= 4 && a.word.length <= 10,
      'hard': (a: TheatreAnswer) => a.word.length >= 5 && a.word.length <= 12
    };
    
    let filtered = answers.filter(difficultyFilter[difficulty]);
    
    // Ensure we have enough variety
    if (filtered.length < 20) {
      filtered = answers.filter(a => a.word.length >= 3 && a.word.length <= 12);
    }
    
    // Sort by construction desirability (length, common letters)
    return filtered.sort((a, b) => {
      const aScore = this.getConstructionScore(a.word);
      const bScore = this.getConstructionScore(b.word);
      return bScore - aScore;
    }).slice(0, 30);
  }

  private getConstructionScore(word: string): number {
    // Score based on length and letter frequency
    let score = word.length * 2;
    
    // Bonus for common crossword letters
    const goodLetters = 'AEIOURLSNT';
    const badLetters = 'QXZJ';
    
    for (const letter of word) {
      if (goodLetters.includes(letter)) score += 1;
      if (badLetters.includes(letter)) score -= 2;
    }
    
    return score;
  }

  private constructGrid(answers: TheatreAnswer[], difficulty: 'easy' | 'medium' | 'hard'): any {
    const grid: string[][] = Array(this.gridSize).fill(null).map(() => Array(this.gridSize).fill('#'));
    const placedWords: Array<{
      word: string;
      row: number;
      col: number;
      direction: 'across' | 'down';
      clue: string;
      answerObj: TheatreAnswer;
    }> = [];
    
    // Start with longest word in center with difficulty-based variation
    const firstWord = answers[0];
    const variation = difficulty === 'easy' ? 0 : difficulty === 'medium' ? 2 : 4;
    const centerRow = Math.floor(this.gridSize / 2) + (Math.random() > 0.5 ? variation : -variation);
    const startCol = Math.floor((this.gridSize - firstWord.word.length) / 2) + (Math.random() > 0.5 ? 1 : -1);
    
    this.placeWord(grid, firstWord.word, centerRow, startCol, 'across');
    placedWords.push({
      word: firstWord.word,
      row: centerRow,
      col: startCol,
      direction: 'across',
      clue: firstWord.clue,
      answerObj: firstWord
    });
    
    // Target word count based on difficulty - more words = harder
    const targetWords = difficulty === 'easy' ? 6 : difficulty === 'medium' ? 9 : 15;
    
    // Try to place remaining words
    for (let i = 1; i < answers.length && placedWords.length < targetWords; i++) {
      const currentWord = answers[i];
      const placement = this.findBestPlacement(grid, currentWord.word, placedWords);
      
      if (placement) {
        this.placeWord(grid, currentWord.word, placement.row, placement.col, placement.direction);
        placedWords.push({
          word: currentWord.word,
          row: placement.row,
          col: placement.col,
          direction: placement.direction,
          clue: currentWord.clue,
          answerObj: currentWord
        });
      }
    }
    
    return { grid, placedWords };
  }

  private findBestPlacement(grid: string[][], word: string, placedWords: any[]): any {
    const placements = [];
    
    // Try to intersect with each placed word
    for (const placedWord of placedWords) {
      // Find letter intersections
      for (let i = 0; i < word.length; i++) {
        for (let j = 0; j < placedWord.word.length; j++) {
          if (word[i] === placedWord.word[j]) {
            // Calculate perpendicular placement
            const oppositeDir = placedWord.direction === 'across' ? 'down' : 'across';
            
            let newRow, newCol;
            if (oppositeDir === 'across') {
              newRow = placedWord.row + j;
              newCol = placedWord.col - i;
            } else {
              newRow = placedWord.row - i;
              newCol = placedWord.col + j;
            }
            
            if (this.isValidPlacement(grid, word, newRow, newCol, oppositeDir)) {
              placements.push({
                row: newRow,
                col: newCol,
                direction: oppositeDir,
                score: this.scorePlacement(grid, word, newRow, newCol, oppositeDir, placedWords)
              });
            }
          }
        }
      }
    }
    
    // Return best scoring placement
    return placements.length > 0 ? placements.sort((a, b) => b.score - a.score)[0] : null;
  }

  private isValidPlacement(grid: string[][], word: string, row: number, col: number, direction: 'across' | 'down'): boolean {
    // Check bounds
    if (direction === 'across') {
      if (row < 0 || row >= this.gridSize || col < 0 || col + word.length > this.gridSize) return false;
      
      // Check space before and after word
      if (col > 0 && grid[row][col - 1] !== '#') return false;
      if (col + word.length < this.gridSize && grid[row][col + word.length] !== '#') return false;
    } else {
      if (row < 0 || row + word.length > this.gridSize || col < 0 || col >= this.gridSize) return false;
      
      // Check space before and after word
      if (row > 0 && grid[row - 1][col] !== '#') return false;
      if (row + word.length < this.gridSize && grid[row + word.length][col] !== '#') return false;
    }
    
    // Check each cell
    for (let i = 0; i < word.length; i++) {
      const checkRow = direction === 'across' ? row : row + i;
      const checkCol = direction === 'across' ? col + i : col;
      
      const currentCell = grid[checkRow][checkCol];
      
      // Must be empty or match for intersection
      if (currentCell !== '#' && currentCell !== word[i]) {
        return false;
      }
      
      // Check perpendicular neighbors (no adjacent words)
      if (currentCell === '#') {
        if (direction === 'across') {
          if ((checkRow > 0 && grid[checkRow - 1][checkCol] !== '#') ||
              (checkRow < this.gridSize - 1 && grid[checkRow + 1][checkCol] !== '#')) {
            return false;
          }
        } else {
          if ((checkCol > 0 && grid[checkRow][checkCol - 1] !== '#') ||
              (checkCol < this.gridSize - 1 && grid[checkRow][checkCol + 1] !== '#')) {
            return false;
          }
        }
      }
    }
    
    return true;
  }

  private scorePlacement(grid: string[][], word: string, row: number, col: number, direction: 'across' | 'down', placedWords: any[]): number {
    let score = 0;
    
    // Count intersections (good)
    for (let i = 0; i < word.length; i++) {
      const checkRow = direction === 'across' ? row : row + i;
      const checkCol = direction === 'across' ? col + i : col;
      
      if (grid[checkRow][checkCol] !== '#') {
        score += 10; // Intersection bonus
      }
    }
    
    // Prefer central placement
    const centerDistance = Math.abs(row - this.gridSize / 2) + Math.abs(col - this.gridSize / 2);
    score -= centerDistance;
    
    return score;
  }

  private placeWord(grid: string[][], word: string, row: number, col: number, direction: 'across' | 'down'): void {
    for (let i = 0; i < word.length; i++) {
      if (direction === 'across') {
        grid[row][col + i] = word[i];
      } else {
        grid[row + i][col] = word[i];
      }
    }
  }

  private constructSimpleGrid(answers: TheatreAnswer[], difficulty: 'easy' | 'medium' | 'hard'): any {
    // Fallback simple construction
    const grid: string[][] = Array(this.gridSize).fill(null).map(() => Array(this.gridSize).fill('#'));
    const placedWords: any[] = [];
    
    // Place words in a simple cross pattern
    const centerRow = 7;
    const centerCol = 7;
    
    // Place horizontal word
    if (answers.length > 0) {
      const word1 = answers[0];
      const startCol = centerCol - Math.floor(word1.word.length / 2);
      this.placeWord(grid, word1.word, centerRow, startCol, 'across');
      placedWords.push({
        word: word1.word,
        row: centerRow,
        col: startCol,
        direction: 'across',
        clue: word1.clue,
        answerObj: word1
      });
    }
    
    // Place vertical word
    if (answers.length > 1) {
      const word2 = answers[1];
      const startRow = centerRow - Math.floor(word2.word.length / 2);
      this.placeWord(grid, word2.word, startRow, centerCol, 'down');
      placedWords.push({
        word: word2.word,
        row: startRow,
        col: centerCol,
        direction: 'down',
        clue: word2.clue,
        answerObj: word2
      });
    }
    
    return { grid, placedWords };
  }

  private formatPuzzle(gridData: any, difficulty: 'easy' | 'medium' | 'hard', date: string): CrosswordPuzzle {
    const clues: CrosswordClue[] = [];
    
    // Sort words by position for proper numbering
    const sortedWords = [...gridData.placedWords].sort((a, b) => {
      if (a.row !== b.row) return a.row - b.row;
      return a.col - b.col;
    });
    
    let clueNumber = 1;
    for (const word of sortedWords) {
      clues.push({
        number: clueNumber++,
        direction: word.direction,
        clue: word.clue,
        answer: word.word,
        startRow: word.row,
        startCol: word.col,
        length: word.word.length
      });
    }
    
    const title = `Theatre Crossword ${difficulty.charAt(0).toUpperCase() + difficulty.slice(1)} - ${new Date().toLocaleDateString('en-US', { 
      weekday: 'long', 
      month: 'long', 
      day: 'numeric' 
    })}`;

    return {
      id: `crossword-${date}-${difficulty}`,
      date,
      title,
      grid: gridData.grid,
      clues: {
        across: clues.filter(c => c.direction === 'across').sort((a, b) => a.number - b.number),
        down: clues.filter(c => c.direction === 'down').sort((a, b) => a.number - b.number)
      }
    };
  }
}